#!/usr/bin/env bash
# Build dist/hearth-<version>.rpm without touching the system rpmbuild tree.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
version="$(sed -n 's/^version = "\{0,1\}\([^"]*\)".*/\1/p' "$root/pyproject.toml" | head -1)"
# Some sandboxes mount /tmp read-only for rpmbuild; keep the tree under $HOME.
top="${HEARTH_RPM_TOPDIR:-$HOME/.cache/hearth-rpm}"
rm -rf "$top"
mkdir -p "$top"
mkdir -p "$top"/{BUILD,RPMS,SOURCES,SPECS,SRPMS,BUILDROOT}
staging="$top/hearth-$version"
mkdir -p "$staging"
tar -C "$root" \
  --exclude='.venv' --exclude='.git' --exclude='.tools' --exclude='__pycache__' \
  --exclude='*.pyc' --exclude='build' --exclude='dist' \
  -cf - . | tar -C "$staging" -xf -
tar -czf "$top/SOURCES/hearth-$version.tar.gz" -C "$top" "hearth-$version"
cp "$root/packaging/hearth.spec" "$top/SPECS/"
sed -i "s/^Version:.*/Version:        $version/" "$top/SPECS/hearth.spec"
rpmbuild --define "_topdir $top" --define "_tmppath $top/tmp" -bb "$top/SPECS/hearth.spec" >/dev/null
mkdir -p "$root/dist"
find "$top/RPMS" -name '*.rpm' -exec cp {} "$root/dist/" \;
ls -la "$root/dist"/*.rpm
