#!/usr/bin/env bash
# Build dist/hearth_<version>_all.deb by hand (dpkg-deb is not on every distro).
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
version="$(sed -n 's/^version = "\{0,1\}\([^"]*\)".*/\1/p' "$root/pyproject.toml" | head -1)"
work="${HEARTH_DEB_DIR:-$HOME/.cache/hearth-deb}"
rm -rf "$work"; mkdir -p "$work"/{data,control} "$root/dist"

# payload
mkdir -p "$work/data/opt/hearth" "$work/data/usr/bin" \
         "$work/data/usr/share/applications" "$work/data/usr/share/icons/hicolor/scalable/apps"
tar -C "$root" --exclude='.venv' --exclude='.git' --exclude='.tools' --exclude='__pycache__' \
  --exclude='*.pyc' --exclude='build' --exclude='dist' --exclude='packaging' \
  -cf - src web docs README.md LICENSE pyproject.toml scripts | tar -C "$work/data/opt/hearth" -xf -
printf '#!/bin/sh\nexec /opt/hearth/.venv/bin/python -m hearth "$@"\n' > "$work/data/usr/bin/hearth"
chmod 0755 "$work/data/usr/bin/hearth"
cat > "$work/data/usr/share/applications/hearth.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=Hearth
GenericName=Local AI workspace
Comment=Private, local-first text, images, video, sound and 3D
Exec=/opt/hearth/.venv/bin/python -m hearth
Icon=hearth
Terminal=false
Categories=Utility;Development;
EOF
cp "$root/web/assets/logo.svg" "$work/data/usr/share/icons/hicolor/scalable/apps/hearth.svg"

# control
cat > "$work/control/control" <<EOF
Package: hearth
Version: $version
Section: utils
Priority: optional
Architecture: all
Maintainer: Hearth <noreply@localhost>
Depends: python3 (>= 3.12), python3-venv, python3-pip
Installed-Size: $(du -sk "$work/data" | cut -f1)
Description: Private, local-first AI workspace
 Hearth runs language, image, video, music and 3D models on your own machine
 and serves a browser workspace. Models download on first use from the launcher.
EOF
cat > "$work/control/postinst" <<'EOF'
#!/bin/sh
set -e
python3 -m venv /opt/hearth/.venv 2>/dev/null || true
/opt/hearth/.venv/bin/python -m pip install --upgrade pip >/dev/null 2>&1 || true
/opt/hearth/.venv/bin/python -m pip install -e /opt/hearth >/dev/null 2>&1 || \
  echo "Hearth: finish setup with /opt/hearth/.venv/bin/python -m pip install -e /opt/hearth"
echo "Hearth installed. Launch it from the application menu or run: hearth --no-browser"
EOF
cat > "$work/control/postrm" <<'EOF'
#!/bin/sh
rm -rf /opt/hearth/.venv
EOF
chmod 0755 "$work/control/postinst" "$work/control/postrm"

python3 - "$work" "$root/dist/hearth_${version}_all.deb" <<'PY'
import io, os, sys, tarfile, time
from pathlib import Path

work = Path(sys.argv[1]); out = Path(sys.argv[2])

def targz(src: Path, dest: Path, arc_prefix: str = "./"):
    with tarfile.open(dest, "w:gz") as tar:
        for path in sorted(src.rglob("*")):
            name = arc_prefix + str(path.relative_to(src))
            info = tar.gettarinfo(str(path), arcname=name)
            info.uid = info.gid = 0
            info.uname = info.gname = "root"
            info.mtime = int(time.time())
            if path.is_file():
                with path.open("rb") as fh:
                    tar.addfile(info, fh)
            else:
                tar.addfile(info)

ctrl = work / "control.tar.gz"
data = work / "data.tar.gz"
targz(work / "control", ctrl)
targz(work / "data", data)

def ar_entry(name: str, payload: bytes) -> bytes:
    header = f"{name:<16}{0:<12}{0:<6}{0:<6}{'100644':<8}{len(payload):<10}`\n".encode()
    return header + payload + (b"\n" if len(payload) % 2 else b"")

with out.open("wb") as fh:
    fh.write(b"!<arch>\n")
    fh.write(ar_entry("debian-binary", b"2.0\n"))
    fh.write(ar_entry("control.tar.gz", ctrl.read_bytes()))
    fh.write(ar_entry("data.tar.gz", data.read_bytes()))
print("built", out, out.stat().st_size, "bytes")
PY
ls -la "$root/dist"/*.deb
