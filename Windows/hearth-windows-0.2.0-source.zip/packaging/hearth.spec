%global debug_package %{nil}
Name:           hearth
Version:        0.2.0
Release:        1%{?dist}
Summary:        Private, local-first AI workspace for text, images, video, sound and 3D
License:        MIT
URL:            https://localhost
BuildArch:      noarch
Requires:       python3 >= 3.12
Requires:       python3-pip
Requires:       python3-virtualenv
Source0:        %{name}-%{version}.tar.gz

%description
Hearth runs language, image, video, music and 3D models on your own machine and
serves a browser workspace. The models are downloaded on first use from the
launcher; nothing leaves the computer except optional web search.

%prep
%setup -q

%install
rm -rf %{buildroot}
mkdir -p %{buildroot}/opt/hearth %{buildroot}/usr/bin %{buildroot}/usr/share/applications
mkdir -p %{buildroot}/usr/share/icons/hicolor/scalable/apps
cp -a src web docs scripts pyproject.toml README.md LICENSE %{buildroot}/opt/hearth/
cat > %{buildroot}/usr/bin/hearth <<'EOF'
#!/bin/sh
exec /opt/hearth/.venv/bin/python -m hearth "$@"
EOF
chmod 0755 %{buildroot}/usr/bin/hearth
cat > %{buildroot}/usr/share/applications/hearth.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=Hearth
GenericName=Local AI workspace
Comment=Private, local-first text, images, video, sound and 3D
Exec=/opt/hearth/.venv/bin/python -m hearth
Icon=hearth
Terminal=false
Categories=Utility;Development;
EOF
cp web/assets/logo.svg %{buildroot}/usr/share/icons/hicolor/scalable/apps/hearth.svg

%post
# Dependencies are installed per machine here rather than vendored in the RPM,
# because PyTorch picks different wheels per GPU.
/usr/bin/python3 -m venv /opt/hearth/.venv 2>/dev/null || true
/opt/hearth/.venv/bin/python -m pip install --upgrade pip >/dev/null 2>&1 || true
/opt/hearth/.venv/bin/python -m pip install -e /opt/hearth >/dev/null 2>&1 || \
  echo "Hearth: run '/opt/hearth/.venv/bin/python -m pip install -e /opt/hearth' to finish setup"
echo "Hearth installed. Start it from the application menu or with: hearth --no-browser"

%postun
rm -rf /opt/hearth/.venv

%files
/opt/hearth
/usr/bin/hearth
/usr/share/applications/hearth.desktop
/usr/share/icons/hicolor/scalable/apps/hearth.svg

%changelog
* Sat Nov 21 2026 Hearth <noreply> - 0.2.0-1
- First packaged build.
