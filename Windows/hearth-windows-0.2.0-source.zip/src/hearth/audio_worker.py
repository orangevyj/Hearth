"""Small subprocess worker for faster-whisper.

It lives in its own venv so the main Hearth process stays light. Output is
strict JSON on stdout; progress/log noise goes to stderr.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import traceback


def _download(repo: str, root: str) -> dict:
    from huggingface_hub import snapshot_download

    path = snapshot_download(repo_id=repo, cache_dir=root)
    return {"repo": repo, "path": path}


def _transcribe(path: str, repo: str, root: str, language: str) -> dict:
    import ctranslate2
    from faster_whisper import WhisperModel

    try:
        cuda = ctranslate2.get_cuda_device_count() > 0
    except Exception:
        cuda = False
    device = "cuda" if cuda else "cpu"
    compute_type = "float16" if cuda else "int8"
    model = WhisperModel(repo, device=device, compute_type=compute_type, download_root=root)
    segments, info = model.transcribe(
        path,
        language=None if language in {"", "auto", "none"} else language,
        vad_filter=True,
        beam_size=5,
        word_timestamps=False,
    )
    collected = []
    for segment in segments:
        collected.append(
            {
                "start": round(float(segment.start), 2),
                "end": round(float(segment.end), 2),
                "text": segment.text.strip(),
            }
        )
    text = " ".join(item["text"] for item in collected).strip()
    return {
        "text": text,
        "language": getattr(info, "language", language or ""),
        "language_probability": round(float(getattr(info, "language_probability", 0.0)), 4),
        "duration": round(float(getattr(info, "duration", 0.0)), 2),
        "device": device,
        "segments": collected,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="hearth-audio-worker")
    sub = parser.add_subparsers(dest="command", required=True)
    download = sub.add_parser("download")
    download.add_argument("repo")
    download.add_argument("root")
    transcribe = sub.add_parser("transcribe")
    transcribe.add_argument("path")
    transcribe.add_argument("repo")
    transcribe.add_argument("root")
    transcribe.add_argument("language", nargs="?", default="auto")
    args = parser.parse_args(argv)
    try:
        if args.command == "download":
            result = _download(args.repo, args.root)
        else:
            result = _transcribe(args.path, args.repo, args.root, args.language)
        sys.stdout.write(json.dumps(result, ensure_ascii=False) + "\n")
        sys.stdout.flush()
        return 0
    except Exception:
        traceback.print_exc(file=sys.stderr)
        return 1


if __name__ == "__main__":
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    raise SystemExit(main())
