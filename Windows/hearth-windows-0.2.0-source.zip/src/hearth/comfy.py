"""ComfyUI client and API-format workflow builders.

Hearth uses ComfyUI as the media engine: SDXL/FLUX for images, Wan 2.1 for
video, Hunyuan3D 2.1 for meshes, and ACE-Step 1.5 for music. Workflows are
built as API JSON so they can be posted straight to ``/prompt``.
"""

from __future__ import annotations

import asyncio
import random
import time
import uuid
from pathlib import Path
from typing import Any

import httpx

from . import catalog
from .attachments import Attachment, OutputStore, kind_for_path
from .config import AppConfig
from .downloader import JobCancelled
from .jobs import Job
from .runtimes import RuntimeManager


def _seed(value: int | None) -> int:
    if value is None or value < 0:
        return random.randint(1, 2**63 - 1)
    return int(value)


def _multiple(value: int, step: int, minimum: int) -> int:
    value = max(minimum, int(value))
    return max(minimum, int(round(value / step)) * step)


def _job_add(job: Job | None, item_id: str, label: str) -> None:
    if job and job.item(item_id) is None:
        job.add_item(item_id, label)


def _job_update(job: Job | None, item_id: str, **changes) -> None:
    if job:
        job.update_item(item_id, **changes)


def build_image_workflow(config: AppConfig, prompt: str, seed: int | None = None) -> dict:
    spec = catalog.get_model(config.image.model)
    if not spec:
        raise ValueError(f"Unknown image model: {config.image.model}")
    ckpt = spec.primary_file
    width = _multiple(config.image.width, 8, 256)
    height = _multiple(config.image.height, 8, 256)
    actual_seed = _seed(seed if seed is not None else config.image.seed)
    if spec.workflow == "sdxl":
        return {
            "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": ckpt}},
            "2": {
                "class_type": "CLIPTextEncode",
                "inputs": {"text": prompt, "clip": ["1", 1]},
            },
            "3": {
                "class_type": "CLIPTextEncode",
                "inputs": {"text": config.image.negative_prompt or "", "clip": ["1", 1]},
            },
            "4": {
                "class_type": "EmptyLatentImage",
                "inputs": {"width": width, "height": height, "batch_size": 1},
            },
            "5": {
                "class_type": "KSampler",
                "inputs": {
                    "seed": actual_seed,
                    "steps": config.image.steps,
                    "cfg": config.image.cfg,
                    "sampler_name": "euler_ancestral",
                    "scheduler": "normal",
                    "denoise": 1.0,
                    "model": ["1", 0],
                    "positive": ["2", 0],
                    "negative": ["3", 0],
                    "latent_image": ["4", 0],
                },
            },
            "6": {"class_type": "VAEDecode", "inputs": {"samples": ["5", 0], "vae": ["1", 2]}},
            "7": {
                "class_type": "SaveImage",
                "inputs": {"filename_prefix": "hearth/image", "images": ["6", 0]},
            },
        }
    if spec.workflow == "flux":
        steps = 4 if spec.id == "flux-schnell" else max(12, config.image.steps)
        return {
            "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": ckpt}},
            "2": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["1", 1]}},
            "3": {
                "class_type": "CLIPTextEncode",
                "inputs": {"text": config.image.negative_prompt or "", "clip": ["1", 1]},
            },
            "4": {
                "class_type": "FluxGuidance",
                "inputs": {"conditioning": ["2", 0], "guidance": 3.5},
            },
            "5": {
                "class_type": "EmptySD3LatentImage",
                "inputs": {"width": width, "height": height, "batch_size": 1},
            },
            "6": {
                "class_type": "KSampler",
                "inputs": {
                    "seed": actual_seed,
                    "steps": steps,
                    "cfg": 1.0,
                    "sampler_name": "euler",
                    "scheduler": "simple",
                    "denoise": 1.0,
                    "model": ["1", 0],
                    "positive": ["4", 0],
                    "negative": ["3", 0],
                    "latent_image": ["5", 0],
                },
            },
            "7": {"class_type": "VAEDecode", "inputs": {"samples": ["6", 0], "vae": ["1", 2]}},
            "8": {
                "class_type": "SaveImage",
                "inputs": {"filename_prefix": "hearth/image", "images": ["7", 0]},
            },
        }
    raise ValueError(f"Unsupported image workflow: {spec.workflow}")


def build_video_workflow(
    config: AppConfig,
    prompt: str,
    seed: int | None = None,
) -> dict:
    spec = catalog.get_model(config.video.model)
    if not spec:
        raise ValueError(f"Unknown video model: {config.video.model}")
    diffusion = spec.file_for("diffusion")
    encoder = spec.file_for("text_encoder")
    vae = spec.file_for("vae")
    if not (diffusion and encoder and vae):
        raise ValueError("Video model is missing diffusion, text encoder or VAE files")
    block = 32 if spec.workflow in {"wan22", "minimax-h3"} else 16
    width = _multiple(config.video.width, block, 256)
    height = _multiple(config.video.height, block, 256)
    # Wan expects 4n+1 frames.
    frames = max(9, ((int(config.video.frames) - 1) // 4) * 4 + 1)
    actual_seed = _seed(seed if seed is not None else config.video.seed)
    if spec.workflow == "minimax-h3":
        video_vae = spec.file_for("vae")
        audio_vae = spec.file_for("audio_vae")
        lora = spec.file_for("lora")
        if not (video_vae and audio_vae):
            raise ValueError("MiniMax H3 needs both its video and audio VAE files")
        # 24 fps and the model's 17k+5 frame grid; 124 frames is ~5 seconds.
        raw_frames = max(5, int(round(config.video.frames)))
        frames = raw_frames + (5 - raw_frames % 17) % 17
        steps = spec.recommended_steps or int(config.video.steps)
        nodes: dict[str, Any] = {
            "1": {
                "class_type": "UNETLoader",
                "inputs": {"unet_name": diffusion.dest.rsplit("/", 1)[-1], "weight_dtype": "default"},
            },
            "2": {
                "class_type": "CLIPLoader",
                "inputs": {"clip_name": encoder.dest.rsplit("/", 1)[-1], "type": "minimax", "device": "default"},
            },
            "3": {"class_type": "VAELoader", "inputs": {"vae_name": video_vae.dest.rsplit("/", 1)[-1]}},
            "4": {"class_type": "VAELoader", "inputs": {"vae_name": audio_vae.dest.rsplit("/", 1)[-1]}},
            "6": {
                "class_type": "MiniMaxH3ImageToVideo",
                "inputs": {
                    "clip": ["2", 0],
                    "vae": ["3", 0],
                    "prompt": prompt,
                    "width": width,
                    "height": height,
                    "length": frames,
                },
            },
            "9": {"class_type": "KSamplerSelect", "inputs": {"sampler_name": "res_multistep"}},
            "10": {"class_type": "RandomNoise", "inputs": {"noise_seed": actual_seed}},
            "11": {
                "class_type": "SamplerCustomAdvanced",
                "inputs": {
                    "noise": ["10", 0],
                    "guider": ["7", 0],
                    "sampler": ["9", 0],
                    "sigmas": ["8", 0],
                    "latent_image": ["6", 1],
                },
            },
            "12": {"class_type": "VAEDecode", "inputs": {"samples": ["11", 0], "vae": ["3", 0]}},
            "13": {"class_type": "VAEDecodeAudio", "inputs": {"samples": ["11", 0], "vae": ["4", 0]}},
            "14": {
                "class_type": "CreateVideo",
                "inputs": {"images": ["12", 0], "audio": ["13", 0], "fps": float(config.video.fps)},
            },
            "15": {
                "class_type": "SaveVideo",
                "inputs": {
                    "video": ["14", 0],
                    "filename_prefix": "hearth/video",
                    "format": "auto",
                    "codec": "auto",
                },
            },
        }
        if lora:
            nodes["5"] = {
                "class_type": "LoraLoaderModelOnly",
                "inputs": {
                    "model": ["1", 0],
                    "lora_name": lora.dest.rsplit("/", 1)[-1],
                    "strength_model": 1.0,
                },
            }
            model_ref = ["5", 0]
        else:
            model_ref = ["1", 0]
        nodes["7"] = {"class_type": "BasicGuider", "inputs": {"model": model_ref, "conditioning": ["6", 0]}}
        nodes["8"] = {
            "class_type": "BasicScheduler",
            "inputs": {
                "model": model_ref,
                "scheduler": "simple",
                "steps": steps,
                "denoise": 1.0,
            },
        }
        return nodes

    if spec.workflow == "wan22":
        return {
            "1": {
                "class_type": "UNETLoader",
                "inputs": {"unet_name": diffusion.dest.rsplit("/", 1)[-1], "weight_dtype": "default"},
            },
            "2": {
                "class_type": "CLIPLoader",
                "inputs": {"clip_name": encoder.dest.rsplit("/", 1)[-1], "type": "wan", "device": "default"},
            },
            "3": {"class_type": "VAELoader", "inputs": {"vae_name": vae.dest.rsplit("/", 1)[-1]}},
            "4": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["2", 0]}},
            "5": {
                "class_type": "CLIPTextEncode",
                "inputs": {"text": config.video.negative_prompt or "", "clip": ["2", 0]},
            },
            "6": {"class_type": "ModelSamplingSD3", "inputs": {"model": ["1", 0], "shift": 8.0}},
            "7": {
                "class_type": "Wan22ImageToVideoLatent",
                "inputs": {
                    "vae": ["3", 0],
                    "width": width,
                    "height": height,
                    "length": frames,
                    "batch_size": 1,
                },
            },
            "8": {
                "class_type": "KSampler",
                "inputs": {
                    "seed": actual_seed,
                    "steps": config.video.steps,
                    "cfg": config.video.cfg,
                    "sampler_name": "uni_pc",
                    "scheduler": "simple",
                    "denoise": 1.0,
                    "model": ["6", 0],
                    "positive": ["4", 0],
                    "negative": ["5", 0],
                    "latent_image": ["7", 0],
                },
            },
            "9": {"class_type": "VAEDecode", "inputs": {"samples": ["8", 0], "vae": ["3", 0]}},
            "10": {
                "class_type": "SaveWEBM",
                "inputs": {
                    "images": ["9", 0],
                    "filename_prefix": "hearth/video",
                    "codec": "vp9",
                    "fps": config.video.fps,
                    "crf": 30.0,
                },
            },
        }
    return {
        "1": {
            "class_type": "UNETLoader",
            "inputs": {"unet_name": diffusion.dest.rsplit("/", 1)[-1], "weight_dtype": "default"},
        },
        "2": {
            "class_type": "CLIPLoader",
            "inputs": {"clip_name": encoder.dest.rsplit("/", 1)[-1], "type": "wan", "device": "default"},
        },
        "3": {
            "class_type": "VAELoader",
            "inputs": {"vae_name": vae.dest.rsplit("/", 1)[-1]},
        },
        "4": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["2", 0]}},
        "5": {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": config.video.negative_prompt or "", "clip": ["2", 0]},
        },
        "6": {
            "class_type": "EmptyHunyuanLatentVideo",
            "inputs": {"width": width, "height": height, "length": frames, "batch_size": 1},
        },
        "7": {
            "class_type": "KSampler",
            "inputs": {
                "seed": actual_seed,
                "steps": config.video.steps,
                "cfg": config.video.cfg,
                "sampler_name": "uni_pc",
                "scheduler": "simple",
                "denoise": 1.0,
                "model": ["1", 0],
                "positive": ["4", 0],
                "negative": ["5", 0],
                "latent_image": ["6", 0],
            },
        },
        "8": {"class_type": "VAEDecode", "inputs": {"samples": ["7", 0], "vae": ["3", 0]}},
        "9": {
            "class_type": "SaveWEBM",
            "inputs": {
                "images": ["8", 0],
                "filename_prefix": "hearth/video",
                "codec": "vp9",
                "fps": config.video.fps,
                "crf": 30.0,
            },
        },
    }


def build_edit_workflow(
    config: AppConfig,
    prompt: str,
    image_names: list[str],
    seed: int | None = None,
) -> dict:
    """Instruction editing: reference image(s) plus a prompt, no init denoise."""
    spec = catalog.get_model(config.edit.model)
    if not spec:
        raise ValueError(f"Unknown edit model: {config.edit.model}")
    diffusion = spec.file_for("diffusion")
    encoder = spec.file_for("text_encoder")
    vae = spec.file_for("vae")
    if not (diffusion and encoder and vae):
        raise ValueError("Edit model is missing diffusion, text encoder or VAE files")
    if not image_names:
        raise ValueError("Editing needs at least one source image")

    width = _multiple(config.edit.width, 16, 256)
    height = _multiple(config.edit.height, 16, 256)
    actual_seed = _seed(seed if seed is not None else config.edit.seed)

    nodes: dict[str, Any] = {
        "1": {
            "class_type": "UNETLoader",
            "inputs": {"unet_name": diffusion.dest.rsplit("/", 1)[-1], "weight_dtype": "default"},
        },
        "2": {
            "class_type": "CLIPLoader",
            "inputs": {"clip_name": encoder.dest.rsplit("/", 1)[-1], "type": "flux2", "device": "default"},
        },
        "3": {"class_type": "VAELoader", "inputs": {"vae_name": vae.dest.rsplit("/", 1)[-1]}},
        "4": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["2", 0]}},
        "5": {"class_type": "ConditioningZeroOut", "inputs": {"conditioning": ["4", 0]}},
        "6": {"class_type": "Flux2Scheduler", "inputs": {"steps": int(config.edit.steps), "width": width, "height": height}},
        "7": {"class_type": "KSamplerSelect", "inputs": {"sampler_name": "euler"}},
        "8": {"class_type": "RandomNoise", "inputs": {"noise_seed": actual_seed}},
        "9": {"class_type": "EmptyFlux2LatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
    }

    # Each source image is scaled, encoded and hung off the conditioning as a
    # reference latent. Chaining is what lets the model combine several photos.
    conditioning: list = ["4", 0]
    next_id = 10
    for name in image_names:
        load_id, scale_id, encode_id, ref_id = (str(next_id + offset) for offset in range(4))
        next_id += 4
        nodes[load_id] = {"class_type": "LoadImage", "inputs": {"image": name}}
        nodes[scale_id] = {
            "class_type": "ImageScaleToTotalPixels",
            "inputs": {"image": [load_id, 0], "upscale_method": "nearest-exact", "megapixels": 1.0, "resolution_steps": 1},
        }
        nodes[encode_id] = {"class_type": "VAEEncode", "inputs": {"pixels": [scale_id, 0], "vae": ["3", 0]}}
        nodes[ref_id] = {
            "class_type": "ReferenceLatent",
            "inputs": {"conditioning": conditioning, "latent": [encode_id, 0]},
        }
        conditioning = [ref_id, 0]

    guider_id = str(next_id)
    nodes[guider_id] = {
        "class_type": "CFGGuider",
        "inputs": {"model": ["1", 0], "positive": conditioning, "negative": ["5", 0], "cfg": 1.0},
    }
    sampler_id = str(next_id + 1)
    nodes[sampler_id] = {
        "class_type": "SamplerCustomAdvanced",
        "inputs": {
            "noise": ["8", 0],
            "guider": [guider_id, 0],
            "sampler": ["7", 0],
            "sigmas": ["6", 0],
            "latent_image": ["9", 0],
        },
    }
    decode_id = str(next_id + 2)
    nodes[decode_id] = {"class_type": "VAEDecode", "inputs": {"samples": [sampler_id, 0], "vae": ["3", 0]}}
    nodes[str(next_id + 3)] = {
        "class_type": "SaveImage",
        "inputs": {"images": [decode_id, 0], "filename_prefix": "hearth/edit"},
    }
    return nodes


def build_3d_workflow(
    config: AppConfig,
    image_name: str,
    seed: int | None = None,
) -> dict:
    spec = catalog.get_model(config.three_d.model)
    if not spec:
        raise ValueError(f"Unknown 3D model: {config.three_d.model}")
    ckpt = spec.primary_file
    actual_seed = _seed(seed if seed is not None else config.three_d.seed)
    return {
        "1": {"class_type": "ImageOnlyCheckpointLoader", "inputs": {"ckpt_name": ckpt}},
        "2": {
            "class_type": "ModelSamplingAuraFlow",
            "inputs": {"model": ["1", 0], "shift": 1.0, "sampling": "flow"},
        },
        "3": {
            "class_type": "LoadImage",
            "inputs": {"image": image_name},
        },
        "4": {
            "class_type": "CLIPVisionEncode",
            "inputs": {"clip_vision": ["1", 1], "image": ["3", 0], "crop": "center"},
        },
        "5": {
            "class_type": "Hunyuan3Dv2Conditioning",
            "inputs": {"clip_vision_output": ["4", 0]},
        },
        "6": {
            "class_type": "EmptyLatentHunyuan3Dv2",
            "inputs": {"resolution": config.three_d.resolution, "batch_size": 1},
        },
        "7": {
            "class_type": "KSampler",
            "inputs": {
                "seed": actual_seed,
                "steps": config.three_d.steps,
                "cfg": config.three_d.cfg,
                "sampler_name": "euler",
                "scheduler": "normal",
                "denoise": 1.0,
                "model": ["2", 0],
                "positive": ["5", 0],
                "negative": ["5", 1],
                "latent_image": ["6", 0],
            },
        },
        "8": {
            "class_type": "VAEDecodeHunyuan3D",
            "inputs": {
                "samples": ["7", 0],
                "vae": ["1", 2],
                "num_chunks": 8000,
                "octree_resolution": config.three_d.octree_resolution,
            },
        },
        "9": {
            "class_type": "VoxelToMesh",
            "inputs": {"voxel": ["8", 0], "algorithm": "surface net", "threshold": 0.6},
        },
        "10": {
            "class_type": "SaveGLB",
            "inputs": {"mesh": ["9", 0], "filename_prefix": "hearth/3d"},
        },
    }


def build_music_workflow(
    config: AppConfig,
    tags: str,
    lyrics: str = "",
    seed: int | None = None,
) -> dict:
    spec = catalog.get_model(config.music.model)
    if not spec:
        raise ValueError(f"Unknown music model: {config.music.model}")
    actual_seed = _seed(seed if seed is not None else 0)
    # A non-distilled checkpoint needs its full step count and a real CFG pass.
    steps = max(int(config.music.steps), spec.recommended_steps)
    cfg = spec.recommended_cfg or 1.0

    if spec.workflow in {"ace-xl", "ace-xl-sft"}:
        small = spec.file_for("encoder_small")
        large = spec.file_for("encoder_large")
        vae = spec.file_for("vae")
        if not (spec.primary_file and small and large and vae):
            raise ValueError("Music model is missing diffusion, text encoder or VAE files")
        loaders = {
            "1": {
                "class_type": "UNETLoader",
                "inputs": {"unet_name": spec.primary_file, "weight_dtype": "default"},
            },
            "2": {
                "class_type": "DualCLIPLoader",
                "inputs": {
                    "clip_name1": small.dest.rsplit("/", 1)[-1],
                    "clip_name2": large.dest.rsplit("/", 1)[-1],
                    "type": "ace",
                    "device": "default",
                },
            },
            "3": {
                "class_type": "VAELoader",
                "inputs": {"vae_name": vae.dest.rsplit("/", 1)[-1]},
            },
        }
        clip_ref = ["2", 0]
        vae_ref = ["3", 0]
    else:
        loaders = {
            "1": {
                "class_type": "CheckpointLoaderSimple",
                "inputs": {"ckpt_name": spec.primary_file},
            }
        }
        clip_ref = ["1", 1]
        vae_ref = ["1", 2]

    return {
        **loaders,
        "4": {
            "class_type": "TextEncodeAceStepAudio1.5",
            "inputs": {
                "clip": clip_ref,
                "tags": tags,
                "lyrics": lyrics,
                "seed": actual_seed,
                "bpm": config.music.bpm,
                "duration": float(config.music.duration),
                "timesignature": "4",
                "language": config.music.language,
                "keyscale": "E minor",
                "generate_audio_codes": True,
                "cfg_scale": 2.0,
                "temperature": 0.85,
                "top_p": 0.9,
                "top_k": 0,
                "min_p": 0.0,
            },
        },
        "5": {
            "class_type": "ModelSamplingAuraFlow",
            "inputs": {"model": ["1", 0], "shift": 3.0},
        },
        "6": {"class_type": "ConditioningZeroOut", "inputs": {"conditioning": ["4", 0]}},
        "7": {
            "class_type": "EmptyAceStep1.5LatentAudio",
            "inputs": {"seconds": float(config.music.duration), "batch_size": 1},
        },
        "8": {
            "class_type": "KSampler",
            "inputs": {
                "seed": actual_seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": "euler",
                "scheduler": "simple",
                "denoise": 1.0,
                "model": ["5", 0],
                "positive": ["4", 0],
                "negative": ["6", 0],
                "latent_image": ["7", 0],
            },
        },
        "9": {"class_type": "VAEDecodeAudio", "inputs": {"samples": ["8", 0], "vae": vae_ref}},
        "10": {
            "class_type": "SaveAudioMP3",
            "inputs": {"audio": ["9", 0], "filename_prefix": "hearth/audio", "quality": "V0"},
        },
    }


class ComfyClient:
    def __init__(self, config_store, runtimes: RuntimeManager, outputs: OutputStore):
        self.config_store = config_store
        self.runtimes = runtimes
        self.outputs = outputs

    @property
    def config(self):
        return self.config_store.config

    @property
    def base_url(self) -> str:
        return self.runtimes.comfy_base_url

    def _guard_spec(self, spec: catalog.ModelSpec | None) -> None:
        if not spec or not self.config.load.memory_guard:
            return
        hardware = getattr(self.runtimes, "hw", None)
        if hardware is None:
            return
        available = max(
            float(getattr(hardware, "ram_available_gb", 0) or 0),
            float(getattr(hardware, "ram_gb", 0) or 0) * 0.85,
        )
        required = float(getattr(spec, "min_ram_gb", 0) or 0)
        if required and required > available:
            raise RuntimeError(
                f"{spec.name} needs about {required:.0f} GB of system RAM; "
                f"only about {available:.0f} GB is available. Free memory or turn off the memory guard in Server settings."
            )

    async def _release_text_model(self, job: Job | None = None) -> None:
        """Media needs the VRAM/RAM more than an idle chat model does."""
        if self.config.text.backend != "ollama" or not self.config.text.model:
            return
        unload = getattr(self.runtimes, "unload_ollama", None)
        if not unload:
            return
        await unload(self.config.text.model)
        if job:
            job.log("Unloaded the text model to free memory for media generation.")

    async def ensure_ready(self, job: Job | None = None) -> None:
        if await self.runtimes.comfy_running():
            return
        if not self.runtimes.comfy_installed():
            raise RuntimeError("ComfyUI is not installed. Install it from the launcher first.")
        await self.runtimes.start_comfyui(job)

    async def _extract_files(self, outputs: dict) -> list[dict]:
        found: list[dict] = []

        def scan(value: Any, node_id: str) -> None:
            if isinstance(value, dict):
                if value.get("filename"):
                    entry = {
                        "filename": value.get("filename"),
                        "subfolder": value.get("subfolder", ""),
                        "type": value.get("type", "output"),
                        "node": node_id,
                    }
                    if entry not in found:
                        found.append(entry)
                else:
                    for nested in value.values():
                        scan(nested, node_id)
            elif isinstance(value, list):
                for nested in value:
                    scan(nested, node_id)

        for node_id, node_output in (outputs or {}).items():
            scan(node_output, str(node_id))
        return found

    async def _prompt_error(self, data: dict) -> str:
        node_errors = data.get("node_errors") or {}
        if node_errors:
            parts = []
            for node_id, info in node_errors.items():
                errors = info.get("errors") or []
                messages = [item.get("message") or item.get("type") for item in errors]
                parts.append(f"node {node_id}: {'; '.join(str(m) for m in messages)}")
            return "ComfyUI rejected the workflow: " + " | ".join(parts)
        if data.get("error"):
            error = data["error"]
            if isinstance(error, dict):
                return str(error.get("message") or error)
            return str(error)
        return "ComfyUI rejected the workflow"

    async def run_workflow(
        self,
        workflow: dict,
        *,
        kind: str,
        timeout: float,
        job: Job | None = None,
        item_id: str = "generation",
        label: str = "Generating",
    ) -> list[Attachment]:
        await self._release_text_model(job)
        await self.ensure_ready(job)
        _job_add(job, item_id, label)
        _job_update(job, item_id, status="running", message="queued")
        client_id = uuid.uuid4().hex
        started = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(60.0, connect=15.0)) as client:
                response = await client.post(
                    f"{self.base_url}/prompt",
                    json={"prompt": workflow, "client_id": client_id},
                )
                if response.status_code >= 400:
                    raise RuntimeError(f"ComfyUI HTTP {response.status_code}: {response.text[:500]}")
                data = response.json()
                if data.get("node_errors"):
                    raise RuntimeError(await self._prompt_error(data))
                prompt_id = data.get("prompt_id")
                if not prompt_id:
                    raise RuntimeError("ComfyUI did not return a prompt id")
                deadline = time.monotonic() + timeout
                entry: dict | None = None
                while time.monotonic() < deadline:
                    if job and job.cancelled:
                        raise JobCancelled("cancelled")
                    history = await client.get(f"{self.base_url}/history/{prompt_id}")
                    if history.status_code < 400:
                        payload = history.json()
                        if prompt_id in payload:
                            entry = payload[prompt_id]
                            break
                    if job:
                        elapsed = time.monotonic() - started
                        _job_update(job, item_id, message=f"rendering · {elapsed:.0f}s")
                    await asyncio.sleep(1.0)
                if entry is None:
                    raise RuntimeError(f"ComfyUI did not finish within {timeout:.0f}s")
                status = entry.get("status") or {}
                if status.get("status_str") == "error" or status.get("completed") is False:
                    messages = []
                    for message in status.get("messages") or []:
                        if isinstance(message, (list, tuple)) and len(message) > 1:
                            messages.append(str(message[1])[:400])
                    raise RuntimeError("ComfyUI generation failed: " + ("; ".join(messages) or "unknown error"))
                files = await self._extract_files(entry.get("outputs") or {})
                if not files:
                    raise RuntimeError("ComfyUI finished but produced no files")
                attachments: list[Attachment] = []
                for index, file in enumerate(files):
                    params = {
                        "filename": file["filename"],
                        "subfolder": file["subfolder"],
                        "type": file["type"],
                    }
                    download = await client.get(f"{self.base_url}/view", params=params)
                    if download.status_code >= 400:
                        raise RuntimeError(f"Could not download {file['filename']}: HTTP {download.status_code}")
                    suffix = Path(file["filename"]).suffix or ".bin"
                    attachment = self.outputs.save_bytes(
                        download.content,
                        kind=kind_for_path(file["filename"]),
                        suffix=suffix,
                        prefix=kind,
                        meta={
                            "comfy_filename": file["filename"],
                            "comfy_node": file["node"],
                            "subfolder": file["subfolder"],
                        },
                    )
                    attachments.append(attachment)
                    if job:
                        _job_update(
                            job,
                            item_id,
                            message=f"saved {index + 1}/{len(files)}",
                        )
                _job_update(job, item_id, status="done", message=f"{len(attachments)} file(s)")
                if job:
                    job.log(f"{label} finished in {time.monotonic() - started:.1f}s")
                hardware = getattr(self.runtimes, "hw", None)
                low_vram = bool(hardware and getattr(hardware, "total_vram_gb", 0) < 12)
                if self.config.load.unload_comfy_after_job or low_vram:
                    await self.runtimes.free_comfy()
                    if job:
                        job.log("Freed ComfyUI memory so the text model can reload.")
                return attachments
        except JobCancelled:
            _job_update(job, item_id, status="canceled")
            raise
        except Exception as exc:
            _job_update(job, item_id, status="error", error=str(exc))
            raise

    async def generate_edit(
        self,
        prompt: str,
        image_paths: list[Path],
        job: Job | None = None,
        seed: int | None = None,
        config: AppConfig | None = None,
    ) -> list[Attachment]:
        """Edit one or more photos with an instruction."""
        cfg = config or self.config
        self._guard_spec(catalog.get_model(cfg.edit.model))
        if not image_paths:
            raise ValueError("Editing needs at least one source image")
        names = [await self.runtimes.comfy_upload_image(path, "hearth/edit-src") for path in image_paths]
        workflow = build_edit_workflow(cfg, prompt, names, seed=seed)
        return await self.run_workflow(
            workflow,
            kind="image",
            timeout=cfg.image.timeout_s,
            job=job,
            item_id="generate:edit",
            label="Editing image",
        )

    async def generate_image(
        self,
        prompt: str,
        job: Job | None = None,
        seed: int | None = None,
        config: AppConfig | None = None,
    ) -> list[Attachment]:
        cfg = config or self.config
        self._guard_spec(catalog.get_model(cfg.image.model))
        workflow = build_image_workflow(cfg, prompt, seed=seed)
        return await self.run_workflow(
            workflow,
            kind="image",
            timeout=cfg.image.timeout_s,
            job=job,
            item_id="generate:image",
            label="Generating image",
        )

    async def generate_video(
        self,
        prompt: str,
        job: Job | None = None,
        seed: int | None = None,
        config: AppConfig | None = None,
    ) -> list[Attachment]:
        cfg = config or self.config
        self._guard_spec(catalog.get_model(cfg.video.model))
        workflow = build_video_workflow(cfg, prompt, seed=seed)
        return await self.run_workflow(
            workflow,
            kind="video",
            timeout=cfg.video.timeout_s,
            job=job,
            item_id="generate:video",
            label="Generating video",
        )

    async def generate_music(
        self,
        tags: str,
        lyrics: str = "",
        job: Job | None = None,
        seed: int | None = None,
        config: AppConfig | None = None,
    ) -> list[Attachment]:
        cfg = config or self.config
        self._guard_spec(catalog.get_model(cfg.music.model))
        workflow = build_music_workflow(cfg, tags, lyrics=lyrics, seed=seed)
        return await self.run_workflow(
            workflow,
            kind="audio",
            timeout=cfg.music.timeout_s,
            job=job,
            item_id="generate:music",
            label="Composing music",
        )

    async def generate_3d(
        self,
        image_path: Path,
        job: Job | None = None,
        seed: int | None = None,
        config: AppConfig | None = None,
    ) -> list[Attachment]:
        cfg = config or self.config
        self._guard_spec(catalog.get_model(cfg.three_d.model))
        await self.ensure_ready(job)
        image_name = await self.runtimes.comfy_upload_image(Path(image_path))
        workflow = build_3d_workflow(cfg, image_name, seed=seed)
        return await self.run_workflow(
            workflow,
            kind="model3d",
            timeout=cfg.three_d.timeout_s,
            job=job,
            item_id="generate:3d",
            label="Building 3D model",
        )
