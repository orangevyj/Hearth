"""Run Hearth: ``python -m hearth``."""

from __future__ import annotations

import argparse
import os
import socket
import sys
import threading
import time
import webbrowser


def _free_port(host: str, start: int, attempts: int = 30) -> int:
    bind_host = "" if host in {"0.0.0.0", "::"} else host
    for offset in range(attempts):
        port = start + offset
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((bind_host, port))
            except OSError:
                continue
            return port
    raise RuntimeError(f"No free port found between {start} and {start + attempts - 1}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="hearth", description="Hearth — a private, local AI workspace.")
    parser.add_argument("--host", default=None, help="Bind address (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=None, help="Port (default: 8770)")
    parser.add_argument("--no-browser", action="store_true", help="Don't open the launcher in a browser")
    parser.add_argument("--data-dir", default=None, help="Override the Hearth data directory")
    parser.add_argument("--config-dir", default=None, help="Override the Hearth config directory")
    parser.add_argument("--cache-dir", default=None, help="Override the Hearth cache directory")
    parser.add_argument("--log-level", default="warning", choices=["critical", "error", "warning", "info", "debug"])
    parser.add_argument("--version", action="store_true", help="Print the version and exit")
    args = parser.parse_args(argv)

    if args.version:
        from hearth import __version__

        print(__version__)
        return 0

    if args.data_dir:
        os.environ["HEARTH_DATA_DIR"] = args.data_dir
    if args.config_dir:
        os.environ["HEARTH_CONFIG_DIR"] = args.config_dir
    if args.cache_dir:
        os.environ["HEARTH_CACHE_DIR"] = args.cache_dir

    # Import after the environment is configured: paths are resolved at import time.
    from hearth.app import AppState, create_app
    from hearth.paths import DATA_DIR

    state = AppState()
    host = args.host or state.config.server.host or "127.0.0.1"
    if not args.host and state.config.server.allow_remote:
        # Serving other devices needs a reachable interface.
        host = "0.0.0.0"
    requested = args.port or state.config.server.port or 8770
    port = _free_port(host, requested)
    if port != requested:
        print(f"Port {requested} is busy; using {port} instead.")
    if host != state.config.server.host or port != state.config.server.port:
        # Persist the actual bind address so the UI links match reality.
        state.config_store.update({"server": {"host": host, "port": port}})
        state.invalidate()

    display_host = "127.0.0.1" if host in {"0.0.0.0", "::"} else host
    url = f"http://{display_host}:{port}"
    print(f"Hearth: {url}")
    print(f"Data:   {DATA_DIR}")
    print(f"Config: {state.config_store.path}")

    if not args.no_browser and state.config.server.open_browser:
        def open_later() -> None:
            time.sleep(1.1)
            with __import__("contextlib").suppress(Exception):
                webbrowser.open(url)

        threading.Thread(target=open_later, daemon=True).start()

    import uvicorn

    uvicorn.run(
        create_app(state),
        host=host,
        port=port,
        log_level=args.log_level,
        access_log=False,
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        sys.exit(130)
