"""Small platform differences the server has to handle.

Everything else in Hearth is portable Python; these are the places where Linux
and Windows genuinely disagree: executable names, virtualenv layout and how you
stop a process tree.
"""

from __future__ import annotations

import contextlib
import os
import subprocess
import sys
from pathlib import Path

IS_WINDOWS = os.name == "nt"


def platform_name() -> str:
    return "windows" if IS_WINDOWS else ("darwin" if sys.platform == "darwin" else "linux")


def exe(name: str) -> str:
    """ollama -> ollama.exe on Windows."""
    if name.lower().endswith(".exe"):
        return name
    return f"{name}.exe" if IS_WINDOWS else name


def venv_python(venv: Path) -> Path:
    """Where a virtualenv keeps its interpreter on this platform."""
    if IS_WINDOWS:
        return venv / "Scripts" / "python.exe"
    return venv / "bin" / "python"


def ollama_asset(arch: str = "amd64") -> str:
    """The release asset name Ollama publishes for this platform."""
    if IS_WINDOWS:
        return f"ollama-windows-{arch}.zip"
    return f"ollama-linux-{arch}.tar.zst"


def piper_asset() -> str:
    if IS_WINDOWS:
        return "piper_windows_amd64.zip"
    return "piper_linux_x86_64.tar.gz"


def spawn_kwargs() -> dict:
    """Detach a long-running child process the way this platform expects."""
    if IS_WINDOWS:
        # CREATE_NEW_PROCESS_GROUP keeps Ctrl+C in the console away from it.
        return {"creationflags": 0x00000200}
    return {"start_new_session": True}


def terminate_tree(proc: subprocess.Popen | None) -> None:
    """Stop a process and its children (taskkill /T on Windows)."""
    if proc is None or proc.poll() is not None:
        return
    if IS_WINDOWS:
        with contextlib.suppress(OSError, subprocess.SubprocessError):
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                capture_output=True,
                timeout=15,
            )
        with contextlib.suppress(subprocess.TimeoutExpired, OSError):
            proc.wait(timeout=8)
        return
    import signal

    def signal_tree(sig: int) -> None:
        try:
            os.killpg(proc.pid, sig)
        except (ProcessLookupError, PermissionError, OSError):
            # Not a group leader (or already gone): fall back to the process.
            with contextlib.suppress(OSError):
                proc.send_signal(sig)

    signal_tree(signal.SIGTERM)
    try:
        proc.wait(timeout=8)
    except subprocess.TimeoutExpired:
        signal_tree(signal.SIGKILL)
        with contextlib.suppress(subprocess.TimeoutExpired, OSError):
            proc.wait(timeout=5)
