"""SQLite chat persistence."""

from __future__ import annotations

import contextlib
import json
import sqlite3
import threading
import uuid
from datetime import UTC, datetime
from pathlib import Path

from .attachments import Attachment


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _title_from(text: str) -> str:
    text = " ".join((text or "").split())
    if not text:
        return "New chat"
    return text[:64] + ("…" if len(text) > 64 else "")


class ChatStore:
    def __init__(self, path: Path | None = None):
        from . import paths

        self.path = path or paths.DB_FILE
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._init()

    def _migrate(self) -> None:
        """Bring an existing database up to the current schema."""
        tables = {
            row["name"]
            for row in self._conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        if "chats" in tables:
            columns = {row["name"] for row in self._conn.execute("PRAGMA table_info(chats)")}
            if "owner" not in columns:
                # Chats existed before accounts did: everything is local until now.
                self._conn.execute("ALTER TABLE chats ADD COLUMN owner TEXT NOT NULL DEFAULT ''")

    def _init(self) -> None:
        with self._lock, self._conn:
            self._migrate()
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS chats (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    model TEXT NOT NULL DEFAULT '',
                    owner TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
                    seq INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL DEFAULT '',
                    meta TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    UNIQUE(chat_id, seq)
                );
                CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, seq);
                CREATE TABLE IF NOT EXISTS attachments (
                    id TEXT PRIMARY KEY,
                    message_id TEXT REFERENCES messages(id) ON DELETE CASCADE,
                    kind TEXT NOT NULL,
                    filename TEXT NOT NULL,
                    path TEXT NOT NULL,
                    mime TEXT NOT NULL DEFAULT '',
                    size INTEGER NOT NULL DEFAULT 0,
                    meta TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_attachments_message ON attachments(message_id);
                """
            )

    # ------------------------------------------------------------------
    # serialization
    # ------------------------------------------------------------------
    @staticmethod
    def _message(row: sqlite3.Row, attachments: list[dict]) -> dict:
        try:
            meta = json.loads(row["meta"] or "{}")
        except json.JSONDecodeError:
            meta = {}
        return {
            "id": row["id"],
            "chat_id": row["chat_id"],
            "role": row["role"],
            "content": row["content"],
            "meta": meta,
            "created_at": row["created_at"],
            "attachments": attachments,
        }

    @staticmethod
    def _attachment(row: sqlite3.Row) -> dict:
        try:
            meta = json.loads(row["meta"] or "{}")
        except json.JSONDecodeError:
            meta = {}
        try:
            from . import paths

            url = "/media/" + Path(row["path"]).resolve().relative_to(paths.DATA_DIR.resolve()).as_posix()
        except (ValueError, OSError):
            url = ""
        return {
            "id": row["id"],
            "message_id": row["message_id"],
            "kind": row["kind"],
            "filename": row["filename"],
            "path": row["path"],
            "mime": row["mime"],
            "size": row["size"],
            "meta": meta,
            "url": url,
            "created_at": row["created_at"],
        }

    # ------------------------------------------------------------------
    # chats
    # ------------------------------------------------------------------
    def create_chat(self, title: str = "New chat", model: str = "", owner: str = "") -> dict:
        stamp = _now()
        chat_id = uuid.uuid4().hex
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO chats (id, title, model, owner, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                (chat_id, title or "New chat", model, owner or "", stamp, stamp),
            )
        return self.get_chat(chat_id)

    def list_chats(self, query: str = "", owner: str | None = None) -> list[dict]:
        """owner=None lists every chat (local admin); owner="x" only that account's."""
        owner_clause = "c.owner = ?" if owner is not None else "1=1"
        with self._lock:
            if query.strip():
                pattern = f"%{query.strip()}%"
                params: tuple = (pattern, pattern) if owner is None else (owner, pattern, pattern)
                rows = self._conn.execute(
                    f"""
                    SELECT c.*,
                        (SELECT content FROM messages m WHERE m.chat_id=c.id ORDER BY seq DESC LIMIT 1) AS preview,
                        (SELECT COUNT(*) FROM messages m WHERE m.chat_id=c.id) AS message_count
                    FROM chats c
                    WHERE {owner_clause}
                      AND (c.title LIKE ?
                           OR EXISTS (SELECT 1 FROM messages m WHERE m.chat_id=c.id AND m.content LIKE ?))
                    ORDER BY c.updated_at DESC
                    """,
                    params,
                ).fetchall()
            else:
                params = () if owner is None else (owner,)
                rows = self._conn.execute(
                    f"""
                    SELECT c.*,
                        (SELECT content FROM messages m WHERE m.chat_id=c.id ORDER BY seq DESC LIMIT 1) AS preview,
                        (SELECT COUNT(*) FROM messages m WHERE m.chat_id=c.id) AS message_count
                    FROM chats c WHERE {owner_clause} ORDER BY c.updated_at DESC
                    """,
                    params,
                ).fetchall()
        return [
            {
                "id": row["id"],
                "title": row["title"],
                "model": row["model"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "preview": (row["preview"] or "")[:180],
                "message_count": row["message_count"],
            }
            for row in rows
        ]

    def get_chat(self, chat_id: str, owner: str | None = None) -> dict | None:
        with self._lock:
            chat = self._conn.execute("SELECT * FROM chats WHERE id = ?", (chat_id,)).fetchone()
            if not chat:
                return None
            if owner is not None and str(chat["owner"] or "") != owner:
                return None
            messages = self._conn.execute(
                "SELECT * FROM messages WHERE chat_id = ? ORDER BY seq", (chat_id,)
            ).fetchall()
            attachment_rows = self._conn.execute(
                """
                SELECT a.* FROM attachments a
                JOIN messages m ON a.message_id = m.id
                WHERE m.chat_id = ?
                ORDER BY a.created_at
                """,
                (chat_id,),
            ).fetchall()
        grouped: dict[str, list[dict]] = {}
        for row in attachment_rows:
            grouped.setdefault(row["message_id"], []).append(self._attachment(row))
        return {
            "id": chat["id"],
            "title": chat["title"],
            "model": chat["model"],
            "owner": str(chat["owner"] or ""),
            "created_at": chat["created_at"],
            "updated_at": chat["updated_at"],
            "messages": [self._message(row, grouped.get(row["id"], [])) for row in messages],
        }

    def rename_chat(self, chat_id: str, title: str, owner: str | None = None) -> dict | None:
        if owner is not None and self.get_chat(chat_id, owner=owner) is None:
            return None
        with self._lock, self._conn:
            self._conn.execute(
                "UPDATE chats SET title = ?, updated_at = ? WHERE id = ?",
                ((title or "Untitled").strip()[:120], _now(), chat_id),
            )
        return self.get_chat(chat_id)

    def set_model(self, chat_id: str, model: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("UPDATE chats SET model = ?, updated_at = ? WHERE id = ?", (model, _now(), chat_id))

    def delete_chat(self, chat_id: str, owner: str | None = None) -> bool:
        if owner is not None and self.get_chat(chat_id, owner=owner) is None:
            return False
        with self._lock, self._conn:
            cursor = self._conn.execute("DELETE FROM chats WHERE id = ?", (chat_id,))
        return cursor.rowcount > 0

    def close(self) -> None:
        with self._lock, contextlib.suppress(sqlite3.Error):
            self._conn.close()

    def count_chats(self, owner: str | None = None) -> int:
        with self._lock:
            if owner is None:
                row = self._conn.execute("SELECT COUNT(*) AS n FROM chats").fetchone()
            else:
                row = self._conn.execute("SELECT COUNT(*) AS n FROM chats WHERE owner = ?", (owner,)).fetchone()
        return int(row["n"] if row else 0)

    # ------------------------------------------------------------------
    # messages
    # ------------------------------------------------------------------
    def add_message(
        self,
        chat_id: str,
        role: str,
        content: str,
        meta: dict | None = None,
        attachment_ids: list[str] | None = None,
    ) -> dict:
        stamp = _now()
        message_id = uuid.uuid4().hex
        with self._lock, self._conn:
            row = self._conn.execute(
                "SELECT COALESCE(MAX(seq), 0) + 1 AS next FROM messages WHERE chat_id = ?", (chat_id,)
            ).fetchone()
            seq = int(row["next"])
            self._conn.execute(
                "INSERT INTO messages (id, chat_id, seq, role, content, meta, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (message_id, chat_id, seq, role, content or "", json.dumps(meta or {}, ensure_ascii=False), stamp),
            )
            self._conn.execute("UPDATE chats SET updated_at = ? WHERE id = ?", (stamp, chat_id))
            if role == "user":
                chat = self._conn.execute("SELECT title FROM chats WHERE id = ?", (chat_id,)).fetchone()
                if chat and chat["title"] in {"New chat", "Untitled", ""}:
                    self._conn.execute(
                        "UPDATE chats SET title = ? WHERE id = ?", (_title_from(content), chat_id)
                    )
        if attachment_ids:
            self.link_attachments(message_id, attachment_ids)
        return self.get_message(message_id) or {}

    def get_message(self, message_id: str) -> dict | None:
        with self._lock:
            row = self._conn.execute("SELECT * FROM messages WHERE id = ?", (message_id,)).fetchone()
            if not row:
                return None
            attachment_rows = self._conn.execute(
                "SELECT * FROM attachments WHERE message_id = ? ORDER BY created_at", (message_id,)
            ).fetchall()
        return self._message(row, [self._attachment(item) for item in attachment_rows])

    def update_message(self, message_id: str, content: str | None = None, meta: dict | None = None) -> dict | None:
        with self._lock, self._conn:
            row = self._conn.execute("SELECT chat_id FROM messages WHERE id = ?", (message_id,)).fetchone()
            if not row:
                return None
            if content is not None:
                self._conn.execute("UPDATE messages SET content = ? WHERE id = ?", (content, message_id))
            if meta is not None:
                self._conn.execute(
                    "UPDATE messages SET meta = ? WHERE id = ?",
                    (json.dumps(meta, ensure_ascii=False), message_id),
                )
            self._conn.execute("UPDATE chats SET updated_at = ? WHERE id = ?", (_now(), row["chat_id"]))
        return self.get_message(message_id)

    def delete_message_and_after(self, chat_id: str, message_id: str) -> list[str]:
        with self._lock, self._conn:
            row = self._conn.execute(
                "SELECT seq FROM messages WHERE id = ? AND chat_id = ?", (message_id, chat_id)
            ).fetchone()
            if not row:
                return []
            seq = row["seq"]
            ids = [
                item["id"]
                for item in self._conn.execute(
                    "SELECT id FROM messages WHERE chat_id = ? AND seq >= ?", (chat_id, seq)
                ).fetchall()
            ]
            self._conn.execute("DELETE FROM messages WHERE chat_id = ? AND seq >= ?", (chat_id, seq))
            self._conn.execute("UPDATE chats SET updated_at = ? WHERE id = ?", (_now(), chat_id))
        return ids

    # ------------------------------------------------------------------
    # attachments
    # ------------------------------------------------------------------
    def store_attachment(self, attachment: Attachment | dict) -> str:
        data = attachment.to_dict() if isinstance(attachment, Attachment) else dict(attachment)
        attachment_id = str(data.get("id") or uuid.uuid4().hex[:12])
        with self._lock, self._conn:
            self._conn.execute(
                """
                INSERT INTO attachments (id, message_id, kind, filename, path, mime, size, meta, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    kind=excluded.kind, filename=excluded.filename, path=excluded.path,
                    mime=excluded.mime, size=excluded.size, meta=excluded.meta
                """,
                (
                    attachment_id,
                    data.get("message_id"),
                    data.get("kind", "file"),
                    data.get("filename", "file"),
                    data.get("path", ""),
                    data.get("mime", ""),
                    int(data.get("size") or 0),
                    json.dumps(data.get("meta") or {}, ensure_ascii=False),
                    data.get("created_at") or _now(),
                ),
            )
        return attachment_id

    def store_attachments(self, attachments: list[Attachment | dict]) -> list[str]:
        return [self.store_attachment(item) for item in attachments]

    def link_attachments(self, message_id: str, attachment_ids: list[str]) -> None:
        ids = [item for item in attachment_ids if item]
        if not ids:
            return
        placeholders = ",".join("?" for _ in ids)
        with self._lock, self._conn:
            message = self._conn.execute(
                "SELECT id FROM messages WHERE id = ?", (message_id,)
            ).fetchone()
            if not message:
                raise ValueError(f"Unknown message: {message_id}")
            rows = self._conn.execute(
                f"SELECT id, message_id FROM attachments WHERE id IN ({placeholders})", ids
            ).fetchall()
            found = {row["id"] for row in rows}
            missing = [item for item in ids if item not in found]
            if missing:
                raise ValueError(f"Unknown attachment(s): {', '.join(missing)}")
            conflict = [row["id"] for row in rows if row["message_id"] not in {None, "", message_id}]
            if conflict:
                raise ValueError(f"Attachment(s) already belong to another message: {', '.join(conflict)}")
            self._conn.execute(
                f"UPDATE attachments SET message_id = ? WHERE id IN ({placeholders})",
                [message_id, *ids],
            )

    def pending_attachments(self, ids: list[str]) -> list[dict]:
        if not ids:
            return []
        placeholders = ",".join("?" for _ in ids)
        with self._lock:
            rows = self._conn.execute(
                f"SELECT * FROM attachments WHERE id IN ({placeholders}) AND message_id IS NULL", ids
            ).fetchall()
        return [self._attachment(row) for row in rows]

    def get_attachment(self, attachment_id: str) -> dict | None:
        with self._lock:
            row = self._conn.execute("SELECT * FROM attachments WHERE id = ?", (attachment_id,)).fetchone()
        return self._attachment(row) if row else None

    # ------------------------------------------------------------------
    # export
    # ------------------------------------------------------------------
    def export_markdown(self, chat_id: str) -> str | None:
        chat = self.get_chat(chat_id)
        if not chat:
            return None
        lines = [f"# {chat['title']}", ""]
        for message in chat["messages"]:
            role = "You" if message["role"] == "user" else "Hearth"
            lines.append(f"## {role}")
            lines.append("")
            if message["content"]:
                lines.append(message["content"])
                lines.append("")
            for attachment in message.get("attachments") or []:
                lines.append(f"- [{attachment['filename']}]({attachment.get('url', '')})")
            lines.append("")
        return "\n".join(lines).strip() + "\n"
