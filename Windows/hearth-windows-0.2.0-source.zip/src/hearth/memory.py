"""Durable things the assistant should remember.

Memories are the user's, not the model's: everything the model writes lands
here, the user can switch any of them off or delete them, and only the enabled
ones reach the system prompt.
"""

from __future__ import annotations

import json
import os
import tempfile
import uuid
from datetime import UTC, datetime
from pathlib import Path

from . import paths

MAX_TEXT = 500
MAX_ITEMS = 500


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class MemoryStore:
    def __init__(self, path: Path | None = None):
        self.path = path or paths.MEMORY_FILE
        self._items: list[dict] = self._load()

    # -- persistence -------------------------------------------------
    def _load(self) -> list[dict]:
        if not self.path.exists():
            return []
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []
        items = raw.get("items") if isinstance(raw, dict) else raw
        if not isinstance(items, list):
            return []
        cleaned = []
        for item in items:
            if not isinstance(item, dict) or not str(item.get("text") or "").strip():
                continue
            cleaned.append(
                {
                    "id": str(item.get("id") or uuid.uuid4().hex[:12]),
                    "text": str(item["text"]).strip()[:MAX_TEXT],
                    "enabled": bool(item.get("enabled", True)),
                    "source": str(item.get("source") or "user"),
                    "created_at": str(item.get("created_at") or _now()),
                    "updated_at": str(item.get("updated_at") or item.get("created_at") or _now()),
                }
            )
        return cleaned

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps({"items": self._items}, indent=2, ensure_ascii=False)
        fd, tmp_name = tempfile.mkstemp(prefix=".memories-", dir=str(self.path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.write("\n")
            os.chmod(tmp_name, 0o600)
            os.replace(tmp_name, self.path)
        finally:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)

    # -- reads -------------------------------------------------------
    @property
    def items(self) -> list[dict]:
        return [dict(item) for item in self._items]

    def get(self, memory_id: str) -> dict | None:
        for item in self._items:
            if item["id"] == memory_id:
                return dict(item)
        return None

    def enabled(self) -> list[dict]:
        return [dict(item) for item in self._items if item.get("enabled")]

    def count(self) -> dict:
        return {
            "total": len(self._items),
            "enabled": sum(1 for item in self._items if item.get("enabled")),
        }

    def prompt_block(self, limit: int = 40) -> str:
        """The text injected into the system prompt, or an empty string."""
        active = [item for item in self._items if item.get("enabled")][: max(0, int(limit))]
        if not active:
            return ""
        lines = "\n".join(f"- {item['text']}" for item in active)
        return (
            "\n\nThings the user asked you to remember (use them; do not read this list back "
            f"word for word):\n{lines}"
        )

    # -- writes ------------------------------------------------------
    def add(self, text: str, source: str = "model") -> dict:
        cleaned = str(text or "").strip()[:MAX_TEXT]
        if not cleaned:
            raise ValueError("A memory needs some text")
        for item in self._items:
            if item["text"].lower() == cleaned.lower():
                # Refreshing an existing memory is friendlier than a duplicate.
                item["enabled"] = True
                item["updated_at"] = _now()
                self._save()
                return dict(item)
        if len(self._items) >= MAX_ITEMS:
            raise ValueError(f"Hearth keeps at most {MAX_ITEMS} memories; delete a few first")
        item = {
            "id": uuid.uuid4().hex[:12],
            "text": cleaned,
            "enabled": True,
            "source": source,
            "created_at": _now(),
            "updated_at": _now(),
        }
        self._items.append(item)
        self._save()
        return dict(item)

    def update(self, memory_id: str, **changes) -> dict | None:
        for item in self._items:
            if item["id"] != memory_id:
                continue
            if "text" in changes and changes["text"] is not None:
                text = str(changes["text"]).strip()[:MAX_TEXT]
                if not text:
                    raise ValueError("A memory needs some text")
                item["text"] = text
            if "enabled" in changes and changes["enabled"] is not None:
                item["enabled"] = bool(changes["enabled"])
            item["updated_at"] = _now()
            self._save()
            return dict(item)
        return None

    def remove(self, memory_id: str) -> bool:
        kept = [item for item in self._items if item["id"] != memory_id]
        if len(kept) == len(self._items):
            return False
        self._items = kept
        self._save()
        return True

    def forget_matching(self, text: str) -> int:
        """Delete memories whose text matches (exactly, then loosely)."""
        needle = str(text or "").strip().lower()
        if not needle:
            return 0
        exact = [item for item in self._items if item["text"].lower() == needle]
        targets = exact or [item for item in self._items if needle in item["text"].lower()]
        if not targets:
            return 0
        ids = {item["id"] for item in targets}
        self._items = [item for item in self._items if item["id"] not in ids]
        self._save()
        return len(ids)

    def clear(self, only_enabled: bool = False) -> int:
        before = len(self._items)
        if only_enabled:
            self._items = [item for item in self._items if not item.get("enabled")]
        else:
            self._items = []
        self._save()
        return before - len(self._items)
