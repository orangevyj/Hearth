"""Hardware-aware Fast / Balanced / Smart presets."""

from __future__ import annotations

from dataclasses import dataclass, field

from . import catalog
from .config import AppConfig
from .hardware import HardwareInfo

Tier = str  # "fast" / "balanced" / "smart", or a custom preset id

RUNTIME_OVERHEAD_GB = 9.5  # Ollama binary + ComfyUI/torch/requirements, first install


@dataclass
class Preset:
    tier: Tier
    name: str
    tagline: str
    recommended: bool
    text_model: str
    image_model: str
    video_model: str
    three_d_model: str
    music_model: str
    tts_voice: str
    stt_model: str
    load_mode: str
    download_gb: float
    peak_vram_gb: float
    peak_ram_gb: float
    summary: str
    notes: list[str] = field(default_factory=list)
    custom: bool = False

    def model_specs(self) -> dict[str, catalog.ModelSpec | None]:
        return {
            "text": catalog.get_model(self.text_model),
            "image": catalog.get_model(self.image_model),
            "video": catalog.get_model(self.video_model),
            "three_d": catalog.get_model(self.three_d_model),
            "music": catalog.get_model(self.music_model),
        }

    def to_dict(self) -> dict:
        specs = self.model_specs()
        return {
            "tier": self.tier,
            "name": self.name,
            "custom": self.custom,
            "tagline": self.tagline,
            "recommended": self.recommended,
            "text_model": self.text_model,
            "image_model": self.image_model,
            "video_model": self.video_model,
            "three_d_model": self.three_d_model,
            "music_model": self.music_model,
            "tts_voice": self.tts_voice,
            "stt_model": self.stt_model,
            "load_mode": self.load_mode,
            "download_gb": round(self.download_gb, 1),
            "peak_vram_gb": round(self.peak_vram_gb, 1),
            "peak_ram_gb": round(self.peak_ram_gb, 1),
            "summary": self.summary,
            "notes": self.notes,
            "models": {
                key: (spec.to_dict() if spec else None) for key, spec in specs.items()
            },
            "audio": {
                "tts_voice": catalog.get_tts_voice(self.tts_voice).to_dict(),
                "stt_model": catalog.get_stt_model(self.stt_model).to_dict(),
            },
        }

    def _music_patch(self, enabled: bool) -> dict:
        patch: dict = {"enabled": enabled, "model": self.music_model}
        spec = catalog.get_model(self.music_model)
        if spec and spec.recommended_steps:
            # Keep the sampler in step with the checkpoint: turbo stays at 8,
            # the SFT model needs its full run.
            patch["steps"] = spec.recommended_steps
        return patch

    def config_patch(self, modalities: dict[str, bool] | None = None) -> dict:
        selected = modalities or {}
        return {
            "preset": self.tier,
            "setup_complete": True,
            "text": {"enabled": selected.get("text", True), "model": self.text_model},
            "image": {"enabled": selected.get("image", True), "model": self.image_model},
            "video": {"enabled": selected.get("video", True), "model": self.video_model},
            "three_d": {"enabled": selected.get("three_d", True), "model": self.three_d_model},
            "music": self._music_patch(selected.get("music", True)),
            "audio": {
                "enabled": selected.get("audio", True),
                "voice": self.tts_voice,
                "stt_model": self.stt_model,
            },
            "load": {"mode": self.load_mode},
        }


def _pick(
    models: tuple[catalog.ModelSpec, ...],
    vram_budget: float,
    ram_budget: float,
) -> catalog.ModelSpec:
    """Pick the highest-quality model that fits the tier's budgets.

    If nothing fits both budgets we fall back to the smallest model; the
    preset notes then explain the offload cost. We deliberately do *not* let
    the quality tier pick something far over budget just because it has enough
    system RAM — that is what the Smart tier is for.
    """
    fitting = [
        spec
        for spec in models
        if spec.min_vram_gb <= vram_budget and spec.min_ram_gb <= ram_budget
    ]
    if fitting:
        return max(fitting, key=lambda item: item.quality)
    return min(models, key=lambda item: (item.min_ram_gb, item.size_gb))


def _load_mode(tier: Tier, hw: HardwareInfo) -> str:
    if tier == "fast":
        return "lazy"
    if tier == "balanced":
        return "text_resident" if hw.total_vram_gb >= 12 else "lazy"
    if hw.total_vram_gb >= 32 and hw.ram_gb >= 64:
        return "keep_all"
    return "lazy"


def _stt_for(tier: Tier, hw: HardwareInfo) -> str:
    if tier == "fast" or hw.ram_gb < 12:
        return "small"
    if tier == "balanced":
        return "medium"
    return "large-v3-turbo"


def _best_quality(specs: tuple[catalog.ModelSpec, ...], model_id: str) -> catalog.ModelSpec:
    for spec in specs:
        if spec.id == model_id:
            return spec
    return specs[0]


def build_presets(hw: HardwareInfo) -> list[Preset]:
    vram = max(hw.total_vram_gb, 0.0)
    ram = max(hw.ram_gb, 0.0)

    text = {
        "fast": _pick(
            catalog.TEXT_MODELS,
            max(3.0, vram * 0.75 + 1.0),
            max(4.0, ram * 0.35),
        ),
        "balanced": _pick(
            catalog.TEXT_MODELS,
            max(4.5, vram * 0.95 + 1.0),
            max(6.0, ram * 0.60),
        ),
        "smart": _pick(
            catalog.TEXT_MODELS,
            max(10.0, vram * 2.5 + 2.0),
            max(12.0, ram * 0.85),
        ),
    }
    # Editors are for changing a photo, so they must not win the text-to-image
    # ladder just because they score well.
    generation_models = tuple(spec for spec in catalog.IMAGE_MODELS if spec.workflow != "flux2-edit")
    image = {
        "fast": _pick(generation_models, max(4.0, vram * 0.8 + 1.0), max(8.0, ram * 0.45)),
        "balanced": _pick(
            generation_models, max(6.0, vram * 1.6 + 1.0), max(12.0, ram * 0.80)
        ),
        "smart": _pick(generation_models, max(8.0, vram * 2.6 + 2.0), max(16.0, ram * 0.95)),
    }
    video = {
        "fast": _pick(catalog.VIDEO_MODELS, max(4.0, vram * 0.8 + 1.0), max(8.0, ram * 0.65)),
        "balanced": _pick(catalog.VIDEO_MODELS, max(6.0, vram * 1.6 + 1.0), max(12.0, ram * 0.85)),
        "smart": _pick(catalog.VIDEO_MODELS, max(10.0, vram * 2.8 + 2.0), max(20.0, ram * 0.95)),
    }
    # MiniMax H3 (with audio) is the quality pick for the upper tiers; the Fast
    # tier keeps the small Wan model so it stays quick.
    h3 = catalog.get_model("minimax-h3")
    if h3 and ram >= h3.min_ram_gb:
        video["balanced"] = h3
        video["smart"] = h3
    small_video = catalog.get_model("wan2.1-1.3b")
    if small_video:
        video["fast"] = small_video

    # 3D and music are currently one strong model each. Pick it unless the
    # machine is genuinely too small, in which case the preset still lists it
    # but flags the offload cost.
    three_d = _best_quality(catalog.THREE_D_MODELS, "hunyuan3d-2.1")
    # Music steps up with the tier: the all-in-one turbo stays the quick pick,
    # the XL checkpoints are for people who want the better mix.
    music: dict[str, catalog.ModelSpec] = {}
    for tier, model_id in (
        ("fast", "ace-step-1.5"),
        ("balanced", "ace-step-1.5-xl-turbo"),
        ("smart", "ace-step-1.5-xl-sft"),
    ):
        spec = catalog.get_model(model_id) or catalog.MUSIC_MODELS[0]
        if ram < spec.min_ram_gb:
            # The XL checkpoints offload a lot; without the RAM, stay small.
            spec = catalog.get_model("ace-step-1.5") or spec
        music[tier] = spec

    recommended_tier: Tier
    if vram >= 20:
        recommended_tier = "smart"
    elif vram >= 6 or ram >= 24:
        recommended_tier = "balanced"
    else:
        recommended_tier = "fast"

    presets: list[Preset] = []
    for tier in ("fast", "balanced", "smart"):
        text_spec = text[tier]
        image_spec = image[tier]
        video_spec = video[tier]
        music_spec = music[tier]
        stt_id = _stt_for(tier, hw)
        stt_spec = catalog.get_stt_model(stt_id)
        tts_spec = catalog.get_tts_voice("en_US-amy-medium")
        load_mode = _load_mode(tier, hw)

        media = [image_spec, video_spec, three_d, music_spec]
        if load_mode == "keep_all":
            peak_vram = text_spec.min_vram_gb + sum(item.min_vram_gb for item in media)
            peak_ram = text_spec.min_ram_gb + sum(item.min_ram_gb for item in media)
        elif load_mode == "text_resident":
            peak_vram = text_spec.min_vram_gb + max(item.min_vram_gb for item in media)
            peak_ram = text_spec.min_ram_gb + max(item.min_ram_gb for item in media)
        else:
            peak_vram = max([text_spec.min_vram_gb, *(item.min_vram_gb for item in media)])
            peak_ram = max([text_spec.min_ram_gb, *(item.min_ram_gb for item in media)])

        download = (
            text_spec.total_size_gb
            + image_spec.total_size_gb
            + video_spec.total_size_gb
            + three_d.total_size_gb
            + music_spec.total_size_gb
            + stt_spec.size_gb
            + tts_spec.size_gb
            + RUNTIME_OVERHEAD_GB
        )

        notes: list[str] = []
        if not hw.gpu_usable:
            notes.append("GPU driver is not responding right now; inference falls back to the CPU until it is usable.")
        if peak_vram > max(vram, 0.1):
            overload = peak_vram - vram
            notes.append(
                f"About {overload:.0f} GB will spill to system RAM; generations will be slower but still run."
            )
        if load_mode == "lazy":
            notes.append("Loads models on demand and unloads them after the idle timeout.")
        elif load_mode == "text_resident":
            notes.append("Keeps the text model warm; image, video, sound and 3D load on demand.")
        else:
            notes.append("Keeps the fitted set of models resident for instant switching.")

        summary = (
            f"{text_spec.name} · {image_spec.name} · {video_spec.name} · "
            f"{three_d.name} · {music_spec.name} · {stt_spec.name}"
        )
        presets.append(
            Preset(
                tier=tier,
                name=tier.capitalize(),
                tagline={
                    "fast": "Small, snappy, and gentle on memory.",
                    "balanced": "The everyday sweet spot.",
                    "smart": "The best quality this machine can reach.",
                }[tier],
                recommended=tier == recommended_tier,
                text_model=text_spec.id,
                image_model=image_spec.id,
                video_model=video_spec.id,
                three_d_model=three_d.id,
                music_model=music_spec.id,
                tts_voice=tts_spec.id,
                stt_model=stt_id,
                load_mode=load_mode,
                download_gb=download,
                peak_vram_gb=peak_vram,
                peak_ram_gb=peak_ram,
                summary=summary,
                notes=notes,
            )
        )
    return presets


def build_custom_presets(definitions: list[dict], hw: HardwareInfo) -> list[Preset]:
    """Turn saved preset definitions into the same shape as the built-ins."""
    vram = max(hw.total_vram_gb, 0.0)
    presets: list[Preset] = []
    for item in definitions or []:
        text_spec = catalog.get_model(str(item.get("text_model") or ""))
        image_spec = catalog.get_model(str(item.get("image_model") or ""))
        video_spec = catalog.get_model(str(item.get("video_model") or ""))
        three_d = catalog.get_model(str(item.get("three_d_model") or ""))
        music_spec = catalog.get_model(str(item.get("music_model") or ""))
        if not all((text_spec, image_spec, video_spec, three_d, music_spec)):
            continue
        stt_spec = catalog.get_stt_model(str(item.get("stt_model") or ""))
        tts_spec = catalog.get_tts_voice(str(item.get("tts_voice") or ""))

        media = [image_spec, video_spec, three_d, music_spec]
        peak_vram = max([text_spec.min_vram_gb, *(spec.min_vram_gb for spec in media)])
        peak_ram = max([text_spec.min_ram_gb, *(spec.min_ram_gb for spec in media)])
        download = (
            text_spec.total_size_gb
            + image_spec.total_size_gb
            + video_spec.total_size_gb
            + three_d.total_size_gb
            + music_spec.total_size_gb
            + stt_spec.size_gb
            + tts_spec.size_gb
            + RUNTIME_OVERHEAD_GB
        )
        notes = ["Your own mix: Hearth did not pick these models."]
        if peak_vram > vram:
            notes.append(f"About {peak_vram - vram:.0f} GB will spill to system RAM; generations still run, just slower.")
        if not hw.gpu_usable:
            notes.append("GPU driver is not responding right now; inference falls back to the CPU.")
        notes.append("Loads models on demand and unloads them after the idle timeout.")

        presets.append(
            Preset(
                tier=str(item["id"]),
                name=str(item.get("name") or "Custom preset"),
                tagline="Your own mix.",
                recommended=False,
                text_model=text_spec.id,
                image_model=image_spec.id,
                video_model=video_spec.id,
                three_d_model=three_d.id,
                music_model=music_spec.id,
                tts_voice=tts_spec.id,
                stt_model=stt_spec.id,
                load_mode="lazy",
                download_gb=download,
                peak_vram_gb=peak_vram,
                peak_ram_gb=peak_ram,
                summary=(
                    f"{text_spec.name} · {image_spec.name} · {video_spec.name} · "
                    f"{three_d.name} · {music_spec.name} · {stt_spec.name}"
                ),
                notes=notes,
                custom=True,
            )
        )
    return presets


def all_presets(hw: HardwareInfo, custom_definitions: list[dict] | None = None) -> list[Preset]:
    return [*build_presets(hw), *build_custom_presets(custom_definitions or [], hw)]


def find_preset(hw: HardwareInfo, tier: str, custom_definitions: list[dict] | None = None) -> Preset | None:
    return next((preset for preset in all_presets(hw, custom_definitions) if preset.tier == tier), None)


def presets_payload(hw: HardwareInfo, custom_definitions: list[dict] | None = None) -> dict:
    presets = all_presets(hw, custom_definitions)
    return {
        "hardware_summary": hw.summary,
        "recommended": next((p.tier for p in presets if p.recommended), "fast"),
        "presets": [preset.to_dict() for preset in presets],
        "custom": [preset.tier for preset in presets if getattr(preset, "custom", False)],
    }


def preset_config_patch(preset: Preset, modalities: dict[str, bool] | None = None) -> dict:
    return preset.config_patch(modalities)


def preset_download_items(preset: Preset, config: AppConfig, modalities: dict[str, bool]) -> list[dict]:
    """The concrete install plan for a preset, in dependency order."""
    items: list[dict] = []
    if modalities.get("text", True) and config.text.backend == "ollama":
        spec = catalog.get_model(preset.text_model)
        if spec:
            items.append(
                {
                    "kind": "ollama",
                    "id": spec.id,
                    "label": spec.name,
                    "size_gb": spec.total_size_gb,
                }
            )
    needs_comfy = any(modalities.get(key, True) for key in ("image", "video", "three_d", "music"))
    if needs_comfy:
        items.append(
            {
                "kind": "runtime",
                "id": "comfyui",
                "label": "ComfyUI runtime",
                "size_gb": 8.0,
            }
        )
        for modality in ("image", "video", "three_d", "music"):
            if not modalities.get(modality, True):
                continue
            model_id = {
                "image": preset.image_model,
                "video": preset.video_model,
                "three_d": preset.three_d_model,
                "music": preset.music_model,
            }[modality]
            spec = catalog.get_model(model_id)
            if spec:
                items.append(
                    {
                        "kind": "comfyui",
                        "id": spec.id,
                        "label": spec.name,
                        "size_gb": spec.total_size_gb,
                    }
                )
    if modalities.get("audio", True):
        items.append(
            {
                "kind": "audio",
                "id": "audio",
                "label": "Speech runtime (Piper + faster-whisper)",
                "size_gb": 0.5,
            }
        )
    return items
