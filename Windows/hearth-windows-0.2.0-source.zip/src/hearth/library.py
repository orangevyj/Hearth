"""User-owned models and presets.

Hearth ships a fixed catalogue, but people bring their own checkpoints and
their own idea of a good mix. These small JSON stores keep that: custom
models (imported from the Hub or from a file already on disk) and saved
presets built in the launcher.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
import uuid
from pathlib import Path
from typing import Any

from . import catalog, paths


def _read_list(path: Path) -> list[dict]:
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if isinstance(raw, dict):
        raw = raw.get("items") or []
    return [item for item in raw if isinstance(item, dict)]


def _write_list(path: Path, items: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(items, indent=2, ensure_ascii=False)
    fd, tmp_name = tempfile.mkstemp(prefix=".lib-", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.write("\n")
        os.replace(tmp_name, path)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def slugify(value: str, fallback: str = "item") -> str:
    cleaned = re.sub(r"[^a-z0-9]+", "-", (value or "").lower()).strip("-")
    return cleaned[:48] or fallback


class CustomModelStore:
    """Imported models that live alongside the built-in catalogue."""

    WORKFLOWS = {
        "image": ("sdxl", "flux"),
        "video": ("wan", "wan22"),
        "three_d": ("hunyuan3d",),
        "music": ("ace", "ace-xl", "ace-xl-sft"),
    }
    REUSABLE_ROLES = ("checkpoint", "diffusion", "text_encoder", "vae", "encoder_small", "encoder_large")

    def __init__(self, path: Path | None = None):
        self.path = path or paths.CUSTOM_MODELS_FILE
        self._items: list[dict] = _read_list(self.path)

    # -- reads ------------------------------------------------------
    @property
    def items(self) -> list[dict]:
        return list(self._items)

    def specs(self) -> list[catalog.ModelSpec]:
        specs: list[catalog.ModelSpec] = []
        for item in self._items:
            try:
                specs.append(self.to_spec(item))
            except (KeyError, TypeError, ValueError):
                continue
        return specs

    def to_spec(self, item: dict) -> catalog.ModelSpec:
        files = tuple(
            catalog.ModelFile(
                repo=str(entry.get("repo") or ""),
                filename=str(entry.get("filename") or entry.get("dest") or ""),
                dest=str(entry["dest"]),
                size_gb=float(entry.get("size_gb") or 0.0),
                role=str(entry.get("role") or "checkpoint"),
            )
            for entry in item.get("files") or []
        )
        return catalog.ModelSpec(
            id=str(item["id"]),
            name=str(item.get("name") or item["id"]),
            modality=str(item["modality"]),  # type: ignore[arg-type]
            runtime="comfyui",
            size_gb=float(item.get("size_gb") or sum(f.size_gb for f in files)),
            min_vram_gb=float(item.get("min_vram_gb") or 0.0),
            min_ram_gb=float(item.get("min_ram_gb") or 0.0),
            quality=int(item.get("quality") or 50),
            description=str(item.get("description") or "Imported model."),
            license=str(item.get("license") or ""),
            files=files,
            workflow=str(item.get("workflow") or ""),
            tags=tuple(item.get("tags") or ("custom",)),
            notes=str(item.get("notes") or ""),
            recommended_steps=int(item.get("recommended_steps") or 0),
            recommended_cfg=float(item.get("recommended_cfg") or 0.0),
        )

    # -- writes -----------------------------------------------------
    def add(self, item: dict) -> dict:
        model_id = str(item["id"])
        rest = [entry for entry in self._items if entry.get("id") != model_id]
        self._items = [*rest, item]
        _write_list(self.path, self._items)
        return item

    def remove(self, model_id: str) -> bool:
        kept = [entry for entry in self._items if entry.get("id") != model_id]
        if len(kept) == len(self._items):
            return False
        self._items = kept
        _write_list(self.path, self._items)
        return True

    # -- validation -------------------------------------------------
    def validate(self, payload: dict[str, Any], comfy_models_dir: Path | None = None) -> dict:
        modality = str(payload.get("modality") or "").strip()
        if modality not in self.WORKFLOWS:
            raise ValueError(f"Unsupported modality: {modality or '(missing)'}")
        workflow = str(payload.get("workflow") or "").strip()
        if workflow not in self.WORKFLOWS[modality]:
            allowed = ", ".join(self.WORKFLOWS[modality])
            raise ValueError(f"{modality} models must use one of: {allowed}")
        name = str(payload.get("name") or "").strip()
        if not name:
            raise ValueError("Give the model a name")
        files: list[dict] = []
        for entry in payload.get("files") or []:
            dest = str(entry.get("dest") or "").strip().lstrip("/")
            if not dest or ".." in Path(dest).parts:
                raise ValueError("Each file needs a destination inside the ComfyUI models folder")
            role = str(entry.get("role") or "checkpoint")
            if role not in self.REUSABLE_ROLES:
                raise ValueError(f"Unknown file role: {role}")
            repo = str(entry.get("repo") or "").strip()
            filename = str(entry.get("filename") or "").strip()
            source = str(entry.get("source") or ("hf" if repo else "local"))
            size_gb = float(entry.get("size_gb") or 0.0)
            if source == "local":
                if comfy_models_dir is None:
                    raise ValueError("Local files need the ComfyUI runtime folder")
                target = (comfy_models_dir / dest).resolve()
                if comfy_models_dir.resolve() not in target.parents and target != comfy_models_dir.resolve():
                    raise ValueError("That path escapes the ComfyUI models folder")
                if not target.exists():
                    raise ValueError(f"No file at {dest} inside the ComfyUI models folder")
                size_gb = round(target.stat().st_size / 1024**3, 3)
                repo, filename = "", dest.rsplit("/", 1)[-1]
            elif not (repo and filename):
                raise ValueError("Hub imports need a repository and a file name")
            files.append(
                {
                    "repo": repo,
                    "filename": filename,
                    "dest": dest,
                    "size_gb": size_gb,
                    "role": role,
                    "source": source,
                }
            )
        if not files:
            raise ValueError("Add at least one file")
        model_id = slugify(str(payload.get("id") or name), "custom-model")
        if catalog.get_model(model_id) and model_id not in {entry.get("id") for entry in self._items}:
            model_id = f"{model_id}-custom"
        return {
            "id": model_id,
            "name": name,
            "modality": modality,
            "workflow": workflow,
            "description": str(payload.get("description") or "Imported model."),
            "quality": int(payload.get("quality") or 50),
            "min_vram_gb": float(payload.get("min_vram_gb") or 0.0),
            "min_ram_gb": float(payload.get("min_ram_gb") or 0.0),
            "recommended_steps": int(payload.get("recommended_steps") or 0),
            "recommended_cfg": float(payload.get("recommended_cfg") or 0.0),
            "size_gb": round(sum(item["size_gb"] for item in files), 3),
            "files": files,
        }


class CustomPresetStore:
    """Presets the user assembled in the launcher."""

    FIELDS = (
        "text_model",
        "image_model",
        "video_model",
        "three_d_model",
        "music_model",
        "tts_voice",
        "stt_model",
    )

    def __init__(self, path: Path | None = None):
        self.path = path or paths.CUSTOM_PRESETS_FILE
        self._items: list[dict] = _read_list(self.path)

    @property
    def items(self) -> list[dict]:
        return list(self._items)

    def get(self, preset_id: str) -> dict | None:
        for item in self._items:
            if item.get("id") == preset_id:
                return item
        return None

    def validate(self, payload: dict[str, Any]) -> dict:
        name = str(payload.get("name") or "").strip()
        if not name:
            raise ValueError("Give the preset a name")
        selections: dict[str, str] = {}
        for key in self.FIELDS:
            value = str(payload.get(key) or "").strip()
            if not value:
                raise ValueError(f"Pick a model for {key.replace('_model', '').replace('_', ' ')}")
            selections[key] = value
        existing = self.get(str(payload.get("id") or "")) or {}
        preset_id = str(payload.get("id") or f"custom-{slugify(name, 'preset')}")
        if not existing and any(entry.get("id") == preset_id for entry in self._items):
            preset_id = f"{preset_id}-{uuid.uuid4().hex[:4]}"
        return {"id": preset_id, "name": name, **selections}

    def save(self, item: dict) -> dict:
        preset_id = str(item["id"])
        rest = [entry for entry in self._items if entry.get("id") != preset_id]
        self._items = [*rest, item]
        _write_list(self.path, self._items)
        return item

    def remove(self, preset_id: str) -> bool:
        kept = [entry for entry in self._items if entry.get("id") != preset_id]
        if len(kept) == len(self._items):
            return False
        self._items = kept
        _write_list(self.path, self._items)
        return True
