"""The Hearth clients the server can hand out.

The server ships the builds it knows about (Android APK, Windows bundle, Linux
bundle) in one folder. A device that connects without the app can be told which
one to download, based on its user agent.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from . import paths

# filename -> (platform, label, description)
KNOWN_CLIENTS: dict[str, tuple[str, str, str]] = {
    "hearth-android.apk": ("android", "Hearth for Android", "Connect-only client: chat, photos, media, viewers."),
    "hearth-windows.zip": ("windows", "Hearth for Windows", "Run the server here, or connect to this machine."),
    "hearth-linux.tar.gz": ("linux", "Hearth for Linux (source)", "Run the server here, or connect to this machine."),
    "hearth-linux.deb": ("linux-deb", "Hearth for Debian / Ubuntu", "Native .deb package."),
    "hearth-linux.rpm": ("linux-rpm", "Hearth for Fedora / RHEL", "Native .rpm package."),
}

MIME_TYPES = {
    ".apk": "application/vnd.android.package-archive",
    ".zip": "application/zip",
    ".gz": "application/gzip",
    ".tgz": "application/gzip",
    ".tar": "application/x-tar",
}


def detect_platform(user_agent: str) -> str:
    """Guess the visitor's platform from its user agent."""
    ua = (user_agent or "").lower()
    if re.search(r"android", ua):
        return "android"
    if re.search(r"iphone|ipad|ipod", ua):
        return "ios"
    if re.search(r"windows", ua):
        return "windows"
    if re.search(r"mac os|macintosh", ua):
        return "macos"
    if re.search(r"linux|x11", ua):
        return "linux"
    return "unknown"


def clients_dir() -> Path:
    return paths.CLIENTS_DIR


def available() -> list[dict]:
    """What can be downloaded right now."""
    directory = clients_dir()
    items: list[dict] = []
    for name, (platform, label, description) in KNOWN_CLIENTS.items():
        path = directory / name
        if not path.is_file():
            continue
        items.append(
            {
                "id": name,
                "platform": platform,
                "label": label,
                "description": description,
                "filename": name,
                "size_mb": round(path.stat().st_size / 1e6, 1),
                "url": f"/downloads/{name}",
            }
        )
    return items


def payload(user_agent: str = "") -> dict:
    items = available()
    platform = detect_platform(user_agent)
    match = next((item for item in items if item["platform"] == platform), None)
    return {
        "clients": items,
        "detected": platform,
        "recommended": match["platform"] if match else "",
    }


def resolve(filename: str) -> Path:
    """A client file inside the clients folder, or FileNotFoundError."""
    if "/" in filename or "\\" in filename or filename.startswith("."):
        raise FileNotFoundError(filename)
    path = (clients_dir() / filename).resolve()
    root = clients_dir().resolve()
    if root not in path.parents or not path.is_file():
        raise FileNotFoundError(filename)
    return path


def mime_for(filename: str) -> str:
    for suffix, mime in MIME_TYPES.items():
        if filename.endswith(suffix):
            return mime
    return "application/octet-stream"


MANIFEST_NAME = "clients.json"


def manifest() -> dict[str, dict]:
    """platform -> {version, file} for the builds this server stores."""
    path = clients_dir() / MANIFEST_NAME
    if not path.is_file():
        return {}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    builds = raw.get("builds") if isinstance(raw, dict) else None
    if not isinstance(builds, dict):
        return {}
    cleaned: dict[str, dict] = {}
    for platform, entry in builds.items():
        if not isinstance(entry, dict):
            continue
        cleaned[str(platform)] = {
            "version": str(entry.get("version") or ""),
            "file": str(entry.get("file") or ""),
        }
    return cleaned


def version_tuple(value: str) -> tuple[int, ...]:
    parts: list[int] = []
    for piece in (value or "").split("."):
        digits = re.sub(r"\D", "", piece)
        parts.append(int(digits) if digits else 0)
    return tuple(parts) if parts else (0,)


def is_older(client_version: str, build_version: str) -> bool:
    """True when the client is behind the build the server would hand out."""
    if not build_version:
        return False
    return version_tuple(client_version) < version_tuple(build_version)


def parse_client_header(value: str) -> tuple[str, str]:
    """'android/0.1.0' -> ('android', '0.1.0')."""
    raw = (value or "").strip()
    if "/" not in raw:
        return raw.lower(), ""
    platform, version = raw.split("/", 1)
    return platform.strip().lower(), version.strip()


def version_payload(server_version: str) -> dict:
    builds = manifest()
    return {
        "server": server_version,
        "builds": {platform: entry["version"] for platform, entry in builds.items()},
        "downloads": {platform: f"/downloads/{entry['file']}" for platform, entry in builds.items() if entry["file"]},
    }
