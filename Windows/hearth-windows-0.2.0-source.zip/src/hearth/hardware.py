"""Hardware discovery and a small, honest capability model.

The goal is not to benchmark the machine, but to choose sane model tiers:
VRAM first, system RAM second, and a clear note when a GPU exists but its
driver is not usable right now.
"""

from __future__ import annotations

import contextlib
import json
import os
import platform
import re
import shutil
import subprocess
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from . import paths

GPU_VRAM_GB: dict[str, float] = {
    # NVIDIA RTX 50 / 40 / 30 / 20
    "rtx 5090": 32,
    "rtx 5080": 16,
    "rtx 5070 ti": 16,
    "rtx 5070": 12,
    "rtx 5060 ti": 16,
    "rtx 5060": 8,
    "rtx 5050": 8,
    "rtx 4090": 24,
    "rtx 4080 super": 16,
    "rtx 4080": 16,
    "rtx 4070 ti super": 16,
    "rtx 4070 ti": 12,
    "rtx 4070 super": 12,
    "rtx 4070": 12,
    "rtx 4060 ti": 16,
    "rtx 4060": 8,
    "rtx 3090 ti": 24,
    "rtx 3090": 24,
    "rtx 3080 ti": 12,
    "rtx 3080": 10,
    "rtx 3070 ti": 8,
    "rtx 3070": 8,
    "rtx 3060 ti": 8,
    "rtx 3060": 12,
    "rtx 2080 ti": 11,
    "rtx 2080": 8,
    "rtx 2070": 8,
    "rtx 2060": 6,
    "titan rtx": 24,
    # Workstation
    "rtx 6000 ada": 48,
    "rtx a6000": 48,
    "rtx a5000": 24,
    "rtx a4000": 16,
    "a100": 80,
    "h100": 80,
    "l40s": 48,
    "l4": 24,
    # AMD
    "rx 9070 xt": 16,
    "rx 9070": 16,
    "rx 7900 xtx": 24,
    "rx 7900 xt": 20,
    "rx 7900 gre": 16,
    "rx 7800 xt": 16,
    "rx 7700 xt": 12,
    "rx 7600": 8,
    "rx 6950 xt": 16,
    "rx 6900 xt": 16,
    "rx 6800 xt": 16,
    "rx 6800": 16,
    "rx 6750 xt": 12,
    "rx 6700 xt": 12,
    "rx 6600": 8,
    # Intel
    "arc b580": 12,
    "arc b570": 10,
    "arc a770": 16,
    "arc a750": 8,
    "arc a380": 6,
}


@dataclass
class GpuInfo:
    vendor: str
    name: str
    vram_gb: float
    driver: str = ""
    compute_cap: str = ""
    usable: bool = False
    source: str = ""
    note: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class HardwareInfo:
    os_name: str = ""
    distro: str = ""
    kernel: str = ""
    cpu_model: str = ""
    physical_cores: int = 0
    threads: int = 0
    avx2: bool = False
    avx512: bool = False
    ram_gb: float = 0.0
    ram_available_gb: float = 0.0
    gpus: list[GpuInfo] = field(default_factory=list)
    total_vram_gb: float = 0.0
    gpu_usable: bool = False
    disk_total_gb: float = 0.0
    disk_free_gb: float = 0.0
    python_version: str = ""
    detected_at: str = ""
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        data = asdict(self)
        data["summary"] = self.summary
        return data

    @property
    def primary_gpu(self) -> GpuInfo | None:
        if not self.gpus:
            return None
        return max(self.gpus, key=lambda gpu: (gpu.usable, gpu.vram_gb))

    @property
    def summary(self) -> str:
        gpu = self.primary_gpu
        if gpu:
            state = "" if gpu.usable else " (driver unavailable)"
            return f"{gpu.name} {gpu.vram_gb:.0f} GB{state} · {self.ram_gb:.0f} GB RAM"
        return f"CPU only · {self.ram_gb:.0f} GB RAM"


def _run(command: list[str], timeout: float = 8.0) -> str | None:
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            env={**os.environ, "LC_ALL": "C"},
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    return result.stdout.strip()


def _cpu_info() -> tuple[str, int, int, bool, bool]:
    model = ""
    physical_cores = 0
    threads = os.cpu_count() or 1
    avx2 = False
    avx512 = False
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        text = cpuinfo.read_text(errors="replace")
        match = re.search(r"^model name\s*:\s*(.+)$", text, re.MULTILINE)
        if match:
            model = match.group(1).strip()
        pairs = set(re.findall(r"^physical id\s*:\s*(\d+)\s*\ncore id\s*:\s*(\d+)", text, re.MULTILINE))
        physical_cores = len(pairs)
        flags = re.search(r"^flags\s*:\s*(.+)$", text, re.MULTILINE)
        if flags:
            flag_set = set(flags.group(1).split())
            avx2 = "avx2" in flag_set
            avx512 = "avx512f" in flag_set
    if not model:
        model = platform.processor() or platform.machine()
    if not physical_cores:
        physical_cores = max(1, threads // 2)
    return model, physical_cores, threads, avx2, avx512


def _ram_gb() -> tuple[float, float]:
    meminfo = Path("/proc/meminfo")
    total = available = 0.0
    if meminfo.exists():
        for line in meminfo.read_text(errors="replace").splitlines():
            if line.startswith("MemTotal:"):
                total = int(line.split()[1]) / 1024 / 1024
            elif line.startswith("MemAvailable:"):
                available = int(line.split()[1]) / 1024 / 1024
    if not total:
        total = available = 8.0
    return round(total, 1), round(available, 1)


def _match_vram(name: str) -> float:
    lowered = name.lower()
    best: tuple[int, float] = (0, 0.0)
    for pattern, vram in GPU_VRAM_GB.items():
        if pattern in lowered and len(pattern) > best[0]:
            best = (len(pattern), vram)
    return best[1]


def _nvidia_gpus() -> list[GpuInfo]:
    if not shutil.which("nvidia-smi"):
        return []
    output = _run(
        [
            "nvidia-smi",
            "--query-gpu=name,memory.total,memory.free,driver_version,compute_cap",
            "--format=csv,noheader,nounits",
        ],
        timeout=10,
    )
    if output is None:
        output = _run(
            [
                "nvidia-smi",
                "--query-gpu=name,memory.total,memory.free,driver_version",
                "--format=csv,noheader,nounits",
            ],
            timeout=10,
        )
    gpus: list[GpuInfo] = []
    if output:
        for line in output.splitlines():
            parts = [part.strip() for part in line.split(",")]
            if len(parts) < 4:
                continue
            try:
                vram = round(float(parts[1]) / 1024, 1)
            except ValueError:
                vram = 0.0
            gpus.append(
                GpuInfo(
                    vendor="NVIDIA",
                    name=parts[0],
                    vram_gb=vram,
                    driver=parts[3],
                    compute_cap=parts[4] if len(parts) > 4 else "",
                    usable=True,
                    source="nvidia-smi",
                )
            )
    return gpus


def _amd_gpus() -> list[GpuInfo]:
    if not shutil.which("rocm-smi"):
        return []
    output = _run(["rocm-smi", "--showmeminfo", "vram", "--json"], timeout=10)
    if not output:
        return []
    gpus: list[GpuInfo] = []
    try:
        data = json.loads(output)
    except json.JSONDecodeError:
        return []
    for card, info in data.items():
        if not isinstance(info, dict):
            continue
        total = 0.0
        for key, value in info.items():
            if "vram total" in key.lower():
                with contextlib.suppress(TypeError, ValueError):
                    total = float(value) / (1024**3)
        name = info.get("Card series") or info.get("Card SKU") or card
        gpus.append(
            GpuInfo(
                vendor="AMD",
                name=str(name),
                vram_gb=round(total, 1),
                driver=info.get("Driver version", ""),
                usable=total > 0,
                source="rocm-smi",
            )
        )
    return gpus


def _lspci_gpus() -> list[GpuInfo]:
    if not shutil.which("lspci"):
        return []
    output = _run(["lspci"], timeout=6) or ""
    gpus: list[GpuInfo] = []
    for line in output.splitlines():
        if not re.search(r"(VGA compatible controller|3D controller|Display controller)", line, re.I):
            continue
        lowered = line.lower()
        vendor = "NVIDIA" if "nvidia" in lowered else "AMD" if ("amd" in lowered or "ati" in lowered) else "GPU"
        # Keep the human-readable part after the PCI address and class.
        name = re.sub(r"^[0-9a-f:.]+ .*?controller:\s*", "", line, flags=re.I).strip()
        name = re.sub(r"\s*\[[0-9a-f]{4}:[0-9a-f]{4}\].*$", "", name, flags=re.I).strip()
        vram = _match_vram(name)
        gpus.append(
            GpuInfo(
                vendor=vendor,
                name=name,
                vram_gb=vram,
                usable=False,
                source="lspci",
                note="GPU detected, but its driver is not responding.",
            )
        )
    return gpus


def _disk() -> tuple[float, float]:
    try:
        paths.ensure_dirs()
        usage = shutil.disk_usage(paths.DATA_DIR)
        return round(usage.total / 1024**3, 1), round(usage.free / 1024**3, 1)
    except OSError:
        return 0.0, 0.0


def _distro() -> str:
    release = Path("/etc/os-release")
    if release.exists():
        for line in release.read_text(errors="replace").splitlines():
            if line.startswith("PRETTY_NAME="):
                return line.split("=", 1)[1].strip().strip('"')
    return platform.platform()


def detect_hardware() -> HardwareInfo:
    cpu_model, physical_cores, threads, avx2, avx512 = _cpu_info()
    ram_gb, ram_available = _ram_gb()
    disk_total, disk_free = _disk()

    gpus = _nvidia_gpus() + _amd_gpus()
    if not gpus:
        gpus = _lspci_gpus()

    usable_gpus = [gpu for gpu in gpus if gpu.usable]
    total_vram = round(sum(gpu.vram_gb for gpu in gpus), 1)
    notes: list[str] = []
    if usable_gpus:
        notes.append(f"GPU acceleration available via {gpus[0].driver or 'driver'}.")
    elif gpus:
        notes.append(
            "A GPU is present but its driver is not responding. Hearth will plan for its VRAM "
            "and run on CPU until the driver is usable (a reboot often fixes a kernel/driver mismatch)."
        )
        for gpu in gpus:
            gpu.note = gpu.note or "Driver not responding"
    else:
        notes.append("No supported GPU detected. Models will run on the CPU and system RAM.")

    if total_vram and not usable_gpus:
        notes.append(f"Planning VRAM: {total_vram:.0f} GB (from the detected GPU model).")
    if ram_gb < 16:
        notes.append("Less than 16 GB of system RAM: prefer the Fast preset.")

    return HardwareInfo(
        os_name=platform.system(),
        distro=_distro(),
        kernel=platform.release(),
        cpu_model=cpu_model,
        physical_cores=physical_cores,
        threads=threads,
        avx2=avx2,
        avx512=avx512,
        ram_gb=ram_gb,
        ram_available_gb=ram_available,
        gpus=gpus,
        total_vram_gb=total_vram,
        gpu_usable=bool(usable_gpus),
        disk_total_gb=disk_total,
        disk_free_gb=disk_free,
        python_version=platform.python_version(),
        detected_at=datetime.now(UTC).isoformat(timespec="seconds"),
        notes=notes,
    )
