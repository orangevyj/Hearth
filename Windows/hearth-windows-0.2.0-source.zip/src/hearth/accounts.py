"""Accounts for people who connect to this Hearth from somewhere else.

Each account has a name, an optional secret and a permission set. A user
without a secret can still connect — the launcher shows a loud warning,
because anything on the network could then reach the server as that user.
"""

from __future__ import annotations

import json
import os
import secrets
import tempfile
import uuid
from datetime import UTC, datetime
from pathlib import Path

from . import crypto, paths

PERMISSION_KEYS = (
    "chat",
    "attachments",
    "tools",
    "image",
    "video",
    "music",
    "three_d",
    "audio",
    "memory",
    "change_model",
    "change_preset",
)

MEDIA_PERMISSION = {
    "image": "image",
    "video": "video",
    "music": "music",
    "three_d": "three_d",
    "speech": "audio",
}


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def default_permissions() -> dict:
    """What a fresh account may do: chat and media, but no server changes."""
    return {
        "chat": True,
        "attachments": True,
        "tools": True,
        "image": True,
        "video": True,
        "music": True,
        "three_d": True,
        "audio": True,
        "memory": True,
        "change_model": False,
        "change_preset": False,
        "allowed_models": [],
        "denied_models": [],
        "allowed_presets": [],
        "denied_presets": [],
    }


class AccountStore:
    def __init__(self, path: Path | None = None):
        self.path = path or paths.ACCOUNTS_FILE
        self._data = self._load()

    # -- persistence -------------------------------------------------
    def _load(self) -> dict:
        if not self.path.exists():
            return {"salt": crypto.new_salt(), "users": []}
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            raw = {}
        if not isinstance(raw, dict):
            raw = {}
        salt = str(raw.get("salt") or "") or crypto.new_salt()
        users = []
        for item in raw.get("users") or []:
            if not isinstance(item, dict) or not str(item.get("name") or "").strip():
                continue
            perms = default_permissions()
            stored = item.get("permissions")
            if isinstance(stored, dict):
                perms.update({key: stored[key] for key in stored if key in perms})
            users.append(
                {
                    "id": str(item.get("id") or uuid.uuid4().hex[:10]),
                    "name": str(item["name"]).strip()[:60],
                    "secret": str(item.get("secret") or ""),
                    "enabled": bool(item.get("enabled", True)),
                    "created_at": str(item.get("created_at") or _now()),
                    "last_seen": str(item.get("last_seen") or ""),
                    "permissions": perms,
                }
            )
        return {"salt": salt, "users": users}

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(self._data, indent=2, ensure_ascii=False)
        fd, tmp_name = tempfile.mkstemp(prefix=".accounts-", dir=str(self.path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.write("\n")
            os.chmod(tmp_name, 0o600)
            os.replace(tmp_name, self.path)
        finally:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)

    # -- reads -------------------------------------------------------
    @property
    def salt(self) -> str:
        return self._data["salt"]

    def users(self, reveal: bool = False) -> list[dict]:
        items = []
        for user in self._data["users"]:
            entry = {key: value for key, value in user.items() if key != "secret"}
            entry["has_secret"] = bool(user["secret"])
            if reveal:
                entry["secret"] = user["secret"]
            items.append(entry)
        return items

    def get(self, name: str) -> dict | None:
        target = (name or "").strip().lower()
        for user in self._data["users"]:
            if user["name"].lower() == target:
                return dict(user)
        return None

    def get_by_id(self, user_id: str) -> dict | None:
        for user in self._data["users"]:
            if user["id"] == user_id:
                return dict(user)
        return None

    def key_for(self, name: str) -> bytes | None:
        """The AES key for an account, or None when it has no secret."""
        user = self.get(name)
        if not user or not user["secret"] or not user["enabled"]:
            return None
        try:
            return crypto.derive_key(user["secret"], self.salt)
        except crypto.CryptoError:
            return None

    def insecure_users(self) -> list[str]:
        return [user["name"] for user in self._data["users"] if user["enabled"] and not user["secret"]]

    def touch(self, name: str) -> None:
        for user in self._data["users"]:
            if user["name"].lower() == (name or "").strip().lower():
                user["last_seen"] = _now()
                self._save()
                return

    # -- writes ------------------------------------------------------
    def add(self, name: str, secret: str = "", permissions: dict | None = None) -> dict:
        """Add an account. An empty secret means the deliberately open mode."""
        clean = (name or "").strip()[:60]
        if not clean:
            raise ValueError("Give the user a name")
        if self.get(clean):
            raise ValueError(f"A user called {clean!r} already exists")
        perms = default_permissions()
        if permissions:
            perms.update({key: permissions[key] for key in permissions if key in perms})
        user = {
            "id": uuid.uuid4().hex[:10],
            "name": clean,
            "secret": str(secret or ""),
            "enabled": True,
            "created_at": _now(),
            "last_seen": "",
            "permissions": perms,
        }
        self._data["users"].append(user)
        self._save()
        return dict(user)

    def update(self, user_id: str, **changes) -> dict | None:
        for user in self._data["users"]:
            if user["id"] != user_id:
                continue
            if "name" in changes and changes["name"]:
                renamed = str(changes["name"]).strip()[:60]
                other = self.get(renamed)
                if other and other["id"] != user_id:
                    raise ValueError(f"A user called {renamed!r} already exists")
                user["name"] = renamed
            if "secret" in changes and changes["secret"] is not None:
                user["secret"] = str(changes["secret"])
            if "enabled" in changes and changes["enabled"] is not None:
                user["enabled"] = bool(changes["enabled"])
            if isinstance(changes.get("permissions"), dict):
                perms = dict(user["permissions"])
                for key, value in changes["permissions"].items():
                    if key in perms:
                        perms[key] = value
                user["permissions"] = perms
            self._save()
            return dict(user)
        return None

    def rotate_secret(self, user_id: str) -> dict | None:
        return self.update(user_id, secret=secrets.token_urlsafe(24))

    def remove(self, user_id: str) -> bool:
        kept = [user for user in self._data["users"] if user["id"] != user_id]
        if len(kept) == len(self._data["users"]):
            return False
        self._data["users"] = kept
        self._save()
        return True
