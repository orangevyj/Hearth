"""The model catalogue.

Only models that Hearth knows how to install and drive are listed here. The
catalogue is deliberately data-driven: presets pick from it, the UI renders it,
and the installers know how to fetch every file.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal

Modality = Literal["text", "image", "video", "three_d", "music", "audio"]


@dataclass(frozen=True)
class ModelFile:
    repo: str
    filename: str
    dest: str
    size_gb: float
    role: str = "checkpoint"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class ModelSpec:
    id: str
    name: str
    modality: Modality
    runtime: str
    size_gb: float
    min_vram_gb: float
    min_ram_gb: float
    quality: int
    description: str
    vision: bool = False
    license: str = ""
    files: tuple[ModelFile, ...] = ()
    ollama_tag: str = ""
    workflow: str = ""
    tags: tuple[str, ...] = ()
    notes: str = ""
    # Recommended sampling for music models: used as a floor so a slower,
    # non-distilled checkpoint is never starved of steps.
    recommended_steps: int = 0
    recommended_cfg: float = 0.0

    def to_dict(self) -> dict:
        data = asdict(self)
        data["files"] = [asdict(item) for item in self.files]
        return data

    def file_for(self, role: str) -> ModelFile | None:
        for item in self.files:
            if item.role == role:
                return item
        return None

    @property
    def primary_file(self) -> str:
        for item in self.files:
            if item.role in {"checkpoint", "diffusion"}:
                return item.dest.rsplit("/", 1)[-1]
        return ""

    @property
    def total_size_gb(self) -> float:
        if self.files:
            return round(sum(item.size_gb for item in self.files), 2)
        return self.size_gb


TEXT_MODELS: tuple[ModelSpec, ...] = (
    ModelSpec(
        id="qwen3.5:2b",
        name="Qwen3.5 2B",
        modality="text",
        runtime="ollama",
        size_gb=2.68,
        min_vram_gb=3.0,
        min_ram_gb=4.0,
        quality=56,
        vision=True,
        description="The smallest Qwen3.5. Snappy on almost anything, good for quick answers and tool routing.",
        license="Apache-2.0",
        ollama_tag="qwen3.5:2b",
        tags=("tools", "fast", "low-vram"),
    ),
    ModelSpec(
        id="qwen3.5:4b",
        name="Qwen3.5 4B",
        modality="text",
        runtime="ollama",
        size_gb=3.32,
        min_vram_gb=4.5,
        min_ram_gb=6.0,
        quality=66,
        vision=True,
        description="The sweet spot for 8 GB cards: capable, quick, and comfortable with tools.",
        license="Apache-2.0",
        ollama_tag="qwen3.5:4b",
        tags=("tools", "recommended", "8gb"),
    ),
    ModelSpec(
        id="qwen3.5:9b",
        name="Qwen3.5 9B",
        modality="text",
        runtime="ollama",
        size_gb=6.55,
        min_vram_gb=7.5,
        min_ram_gb=9.0,
        quality=79,
        vision=True,
        description="A strong all-rounder that fits 8–12 GB cards with a little room to spare.",
        license="Apache-2.0",
        ollama_tag="qwen3.5:9b",
        tags=("tools", "recommended", "12gb"),
    ),
    ModelSpec(
        id="qwen3.5:27b-q4_K_M",
        name="Qwen3.5 27B",
        modality="text",
        runtime="ollama",
        size_gb=17.48,
        min_vram_gb=18.0,
        min_ram_gb=22.0,
        quality=88,
        vision=True,
        description="Dense, careful reasoning. Needs a 24 GB card or patient CPU/GPU offload.",
        license="Apache-2.0",
        ollama_tag="qwen3.5:27b-q4_K_M",
        tags=("tools", "quality", "24gb"),
    ),
    ModelSpec(
        id="qwen3.5:35b-a3b-q4_K_M",
        name="Qwen3.5 35B A3B",
        modality="text",
        runtime="ollama",
        size_gb=22.07,
        min_vram_gb=20.0,
        min_ram_gb=26.0,
        quality=91,
        vision=True,
        description="A mixture-of-experts model with only ~3B active parameters: fast for its size, and the best local quality tier.",
        license="Apache-2.0",
        ollama_tag="qwen3.5:35b-a3b-q4_K_M",
        tags=("tools", "moe", "quality", "24gb"),
    ),
)

IMAGE_MODELS: tuple[ModelSpec, ...] = (
    ModelSpec(
        id="sdxl-turbo",
        name="SDXL Turbo",
        modality="image",
        runtime="comfyui",
        size_gb=6.94,
        min_vram_gb=6.0,
        min_ram_gb=12.0,
        quality=62,
        description="Four-step SDXL. Fast, reliable, and happy on an 8 GB card.",
        license="Stability AI Community",
        workflow="sdxl",
        files=(
            ModelFile(
                repo="stabilityai/sdxl-turbo",
                filename="sd_xl_turbo_1.0_fp16.safetensors",
                dest="checkpoints/sdxl-turbo-fp16.safetensors",
                size_gb=6.94,
            ),
        ),
        tags=("fast", "8gb"),
    ),
    ModelSpec(
        id="flux2-klein-edit",
        name="FLUX.2 Klein Edit",
        modality="image",
        runtime="comfyui",
        size_gb=11.6,
        min_vram_gb=8.0,
        min_ram_gb=16.0,
        quality=86,
        description="Instruction-based photo editing: give it one or more pictures and say what to change. A 4B fp8 model, so it fits an 8 GB card.",
        license="FLUX.2 Klein Non-Commercial",
        workflow="flux2-edit",
        files=(
            ModelFile(
                repo="black-forest-labs/FLUX.2-klein-4b-fp8",
                filename="flux-2-klein-4b-fp8.safetensors",
                dest="diffusion_models/flux-2-klein-4b-fp8.safetensors",
                size_gb=3.79,
                role="diffusion",
            ),
            ModelFile(
                repo="Comfy-Org/z_image_turbo",
                filename="split_files/text_encoders/qwen_3_4b.safetensors",
                dest="text_encoders/qwen_3_4b.safetensors",
                size_gb=7.49,
                role="text_encoder",
            ),
            ModelFile(
                repo="Comfy-Org/flux2-dev",
                filename="split_files/vae/flux2-vae.safetensors",
                dest="vae/flux2-vae.safetensors",
                size_gb=0.32,
                role="vae",
            ),
        ),
        tags=("8gb", "edit", "quality"),
    ),
    ModelSpec(
        id="flux-schnell",
        name="FLUX.1 schnell",
        modality="image",
        runtime="comfyui",
        size_gb=17.24,
        min_vram_gb=12.0,
        min_ram_gb=20.0,
        quality=82,
        description="Black Forest Labs' 4-step FLUX. Much sharper than SDXL, with offload on smaller cards.",
        license="Apache-2.0",
        workflow="flux",
        files=(
            ModelFile(
                repo="Comfy-Org/flux1-schnell",
                filename="flux1-schnell-fp8.safetensors",
                dest="checkpoints/flux1-schnell-fp8.safetensors",
                size_gb=17.24,
            ),
        ),
        tags=("quality", "12gb", "offload"),
    ),
    ModelSpec(
        id="flux-dev",
        name="FLUX.1 dev",
        modality="image",
        runtime="comfyui",
        size_gb=17.25,
        min_vram_gb=14.0,
        min_ram_gb=24.0,
        quality=90,
        description="The highest-quality FLUX checkpoint here. Slower and best with 16 GB+ VRAM.",
        license="FLUX.1 Non-Commercial",
        workflow="flux",
        files=(
            ModelFile(
                repo="Comfy-Org/flux1-dev",
                filename="flux1-dev-fp8.safetensors",
                dest="checkpoints/flux1-dev-fp8.safetensors",
                size_gb=17.25,
            ),
        ),
        tags=("quality", "16gb", "offload"),
    ),
)

VIDEO_MODELS: tuple[ModelSpec, ...] = (
    ModelSpec(
        id="wan2.1-1.3b",
        name="Wan 2.1 T2V 1.3B",
        modality="video",
        runtime="comfyui",
        size_gb=9.83,
        min_vram_gb=8.0,
        min_ram_gb=18.0,
        quality=66,
        description="Text-to-video that fits consumer cards. 480p, a few seconds at a time.",
        license="Apache-2.0",
        workflow="wan",
        files=(
            ModelFile(
                repo="Comfy-Org/Wan_2.1_ComfyUI_repackaged",
                filename="split_files/diffusion_models/wan2.1_t2v_1.3B_fp16.safetensors",
                dest="diffusion_models/wan2.1_t2v_1.3B_fp16.safetensors",
                size_gb=2.84,
                role="diffusion",
            ),
            ModelFile(
                repo="Comfy-Org/Wan_2.1_ComfyUI_repackaged",
                filename="split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                dest="text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                size_gb=6.74,
                role="text_encoder",
            ),
            ModelFile(
                repo="Comfy-Org/Wan_2.1_ComfyUI_repackaged",
                filename="split_files/vae/wan_2.1_vae.safetensors",
                dest="vae/wan_2.1_vae.safetensors",
                size_gb=0.25,
                role="vae",
            ),
        ),
        tags=("8gb", "offload"),
    ),
    ModelSpec(
        id="wan2.2-5b",
        name="Wan 2.2 TI2V 5B",
        modality="video",
        runtime="comfyui",
        size_gb=16.89,
        min_vram_gb=8.0,
        min_ram_gb=20.0,
        quality=82,
        description="The newer 5B Wan: much better motion and prompt adherence than 1.3B, with a 720p/24 fps target. Reuses the UMT5 encoder.",
        license="Apache-2.0",
        workflow="wan22",
        files=(
            ModelFile(
                repo="Comfy-Org/Wan-2.2",
                filename="split_files/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors",
                dest="diffusion_models/wan2.2_ti2v_5B_fp16.safetensors",
                size_gb=9.31,
                role="diffusion",
            ),
            ModelFile(
                repo="Comfy-Org/Wan_2.1_ComfyUI_repackaged",
                filename="split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                dest="text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                size_gb=6.27,
                role="text_encoder",
            ),
            ModelFile(
                repo="Comfy-Org/Wan-2.2",
                filename="split_files/vae/wan2.2_vae.safetensors",
                dest="vae/wan2.2_vae.safetensors",
                size_gb=1.31,
                role="vae",
            ),
        ),
        tags=("8gb", "quality", "offload"),
    ),
    ModelSpec(
        id="minimax-h3",
        name="MiniMax H3",
        modality="video",
        runtime="comfyui",
        size_gb=42.04,
        min_vram_gb=8.0,
        min_ram_gb=24.0,
        quality=93,
        description="MiniMax H3 with sound: 5-second 24 fps clips that come with their own audio track. Huge int8 weights, so it streams from disk and is slower than Wan.",
        license="MiniMax Community",
        workflow="minimax-h3",
        recommended_steps=8,
        files=(
            ModelFile(
                repo="",
                filename="minimax_h3_fl2va_pruned_int8_convrot.safetensors",
                dest="diffusion_models/minimax_h3_fl2va_pruned_int8_convrot.safetensors",
                size_gb=20.97,
                role="diffusion",
            ),
            ModelFile(
                repo="",
                filename="qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
                dest="text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
                size_gb=15.69,
                role="text_encoder",
            ),
            ModelFile(
                repo="",
                filename="minimax_h3_video_vae_int8_convrot.safetensors",
                dest="vae/minimax_h3_video_vae_int8_convrot.safetensors",
                size_gb=2.81,
                role="vae",
            ),
            ModelFile(
                repo="",
                filename="minimax_h3_audio_vae_fp32.safetensors",
                dest="vae/minimax_h3_audio_vae_fp32.safetensors",
                size_gb=0.61,
                role="audio_vae",
            ),
            ModelFile(
                repo="",
                filename="minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors",
                dest="loras/minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors",
                size_gb=1.96,
                role="lora",
            ),
        ),
        tags=("8gb", "quality", "offload", "audio"),
    ),
    ModelSpec(
        id="wan2.1-14b",
        name="Wan 2.1 T2V 14B",
        modality="video",
        runtime="comfyui",
        size_gb=21.28,
        min_vram_gb=24.0,
        min_ram_gb=40.0,
        quality=86,
        description="The big Wan model: more motion, more detail, and a heavy 24 GB-class workload.",
        license="Apache-2.0",
        workflow="wan",
        files=(
            ModelFile(
                repo="Comfy-Org/Wan_2.1_ComfyUI_repackaged",
                filename="split_files/diffusion_models/wan2.1_t2v_14B_fp8_e4m3fn.safetensors",
                dest="diffusion_models/wan2.1_t2v_14B_fp8_e4m3fn.safetensors",
                size_gb=14.29,
                role="diffusion",
            ),
            ModelFile(
                repo="Comfy-Org/Wan_2.1_ComfyUI_repackaged",
                filename="split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                dest="text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                size_gb=6.74,
                role="text_encoder",
            ),
            ModelFile(
                repo="Comfy-Org/Wan_2.1_ComfyUI_repackaged",
                filename="split_files/vae/wan_2.1_vae.safetensors",
                dest="vae/wan_2.1_vae.safetensors",
                size_gb=0.25,
                role="vae",
            ),
        ),
        tags=("quality", "24gb"),
    ),
)

THREE_D_MODELS: tuple[ModelSpec, ...] = (
    ModelSpec(
        id="hunyuan3d-2.1",
        name="Hunyuan3D 2.1",
        modality="three_d",
        runtime="comfyui",
        size_gb=7.37,
        min_vram_gb=6.0,
        min_ram_gb=16.0,
        quality=82,
        description="Image-to-3D mesh generation. Hearth creates a preview image first, then turns it into a GLB.",
        license="Tencent Hunyuan Community",
        workflow="hunyuan3d",
        files=(
            ModelFile(
                repo="Comfy-Org/Hunyuan-3D-2.1",
                filename="hunyuan_3d_v2.1.safetensors",
                dest="checkpoints/hunyuan_3d_v2.1.safetensors",
                size_gb=7.37,
            ),
        ),
        tags=("8gb", "image-to-3d"),
        notes="Needs an input image. Hearth generates one from your prompt automatically.",
    ),
)

MUSIC_MODELS: tuple[ModelSpec, ...] = (
    ModelSpec(
        id="ace-step-1.5",
        name="ACE-Step 1.5",
        modality="music",
        runtime="comfyui",
        size_gb=10.03,
        min_vram_gb=8.0,
        min_ram_gb=20.0,
        quality=80,
        description="Text-to-music with vocals or instrumentals. 8 steps, a few minutes for a short track.",
        license="Apache-2.0",
        workflow="ace",
        files=(
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="checkpoints/ace_step_1.5_turbo_aio.safetensors",
                dest="checkpoints/ace_step_1.5_turbo_aio.safetensors",
                size_gb=10.03,
            ),
        ),
        tags=("8gb", "offload"),
    ),
    ModelSpec(
        id="ace-step-1.5-xl-turbo",
        name="ACE-Step 1.5 XL Turbo",
        modality="music",
        runtime="comfyui",
        size_gb=18.52,
        min_vram_gb=8.0,
        min_ram_gb=24.0,
        quality=88,
        description="The XL ACE-Step: a wider backbone than the all-in-one turbo, so denser arrangements, cleaner vocals and a better mix. Still 8-step turbo sampling, just a heavier checkpoint.",
        license="Apache-2.0",
        workflow="ace-xl",
        recommended_steps=8,
        recommended_cfg=1.0,
        files=(
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="split_files/diffusion_models/acestep_v1.5_xl_turbo_bf16.safetensors",
                dest="diffusion_models/acestep_v1.5_xl_turbo_bf16.safetensors",
                size_gb=9.29,
                role="diffusion",
            ),
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="split_files/vae/ace_1.5_vae.safetensors",
                dest="vae/ace_1.5_vae.safetensors",
                size_gb=0.32,
                role="vae",
            ),
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="split_files/text_encoders/qwen_0.6b_ace15.safetensors",
                dest="text_encoders/qwen_0.6b_ace15.safetensors",
                size_gb=1.11,
                role="encoder_small",
            ),
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="split_files/text_encoders/qwen_4b_ace15.safetensors",
                dest="text_encoders/qwen_4b_ace15.safetensors",
                size_gb=7.8,
                role="encoder_large",
            ),
        ),
        tags=("8gb", "quality", "offload"),
    ),
    ModelSpec(
        id="ace-step-1.5-xl-sft",
        name="ACE-Step 1.5 XL SFT",
        modality="music",
        runtime="comfyui",
        size_gb=18.52,
        min_vram_gb=10.0,
        min_ram_gb=24.0,
        quality=92,
        description="The XL checkpoint without turbo distillation: 40 steps and a real CFG pass, so the best mix and vocal clarity ACE-Step offers — several times slower than turbo.",
        license="Apache-2.0",
        workflow="ace-xl-sft",
        recommended_steps=40,
        recommended_cfg=6.0,
        files=(
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="split_files/diffusion_models/acestep_v1.5_xl_sft_bf16.safetensors",
                dest="diffusion_models/acestep_v1.5_xl_sft_bf16.safetensors",
                size_gb=9.29,
                role="diffusion",
            ),
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="split_files/vae/ace_1.5_vae.safetensors",
                dest="vae/ace_1.5_vae.safetensors",
                size_gb=0.32,
                role="vae",
            ),
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="split_files/text_encoders/qwen_0.6b_ace15.safetensors",
                dest="text_encoders/qwen_0.6b_ace15.safetensors",
                size_gb=1.11,
                role="encoder_small",
            ),
            ModelFile(
                repo="Comfy-Org/ACE-Step-1.5",
                filename="split_files/text_encoders/qwen_4b_ace15.safetensors",
                dest="text_encoders/qwen_4b_ace15.safetensors",
                size_gb=7.8,
                role="encoder_large",
            ),
        ),
        tags=("quality", "offload", "slow"),
    ),
)


@dataclass(frozen=True)
class TtsVoice:
    id: str
    name: str
    repo: str
    onnx_path: str
    size_gb: float
    language: str

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def filename(self) -> str:
        return self.onnx_path.rsplit("/", 1)[-1]


TTS_VOICES: tuple[TtsVoice, ...] = (
    TtsVoice(
        id="en_US-amy-medium",
        name="Amy (US English)",
        repo="rhasspy/piper-voices",
        onnx_path="en/en_US/amy/medium/en_US-amy-medium.onnx",
        size_gb=0.063,
        language="en-US",
    ),
    TtsVoice(
        id="en_US-lessac-medium",
        name="Lessac (US English)",
        repo="rhasspy/piper-voices",
        onnx_path="en/en_US/lessac/medium/en_US-lessac-medium.onnx",
        size_gb=0.063,
        language="en-US",
    ),
    TtsVoice(
        id="en_GB-alba-medium",
        name="Alba (British English)",
        repo="rhasspy/piper-voices",
        onnx_path="en/en_GB/alba/medium/en_GB-alba-medium.onnx",
        size_gb=0.063,
        language="en-GB",
    ),
)


@dataclass(frozen=True)
class SttModel:
    id: str
    name: str
    repo: str
    size_gb: float
    min_vram_gb: float
    quality: int
    description: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


STT_MODELS: tuple[SttModel, ...] = (
    SttModel(
        id="small",
        name="Whisper small",
        repo="Systran/faster-whisper-small",
        size_gb=0.48,
        min_vram_gb=1.0,
        quality=60,
        description="Fast and accurate enough for dictation.",
    ),
    SttModel(
        id="medium",
        name="Whisper medium",
        repo="Systran/faster-whisper-medium",
        size_gb=1.53,
        min_vram_gb=2.0,
        quality=76,
        description="A good balance for longer recordings.",
    ),
    SttModel(
        id="large-v3-turbo",
        name="Whisper large-v3 turbo",
        repo="deepdml/faster-whisper-large-v3-turbo-ct2",
        size_gb=1.62,
        min_vram_gb=4.0,
        quality=90,
        description="The best accuracy per second in the Whisper family.",
    ),
)

PIPER_BINARY = ModelFile(
    repo="rhasspy/piper",
    filename="piper_linux_x86_64.tar.gz",
    dest="piper/piper_linux_x86_64.tar.gz",
    size_gb=0.012,
    role="binary",
)

ALL_MODELS: dict[str, ModelSpec] = {
    spec.id: spec
    for spec in (*TEXT_MODELS, *IMAGE_MODELS, *VIDEO_MODELS, *THREE_D_MODELS, *MUSIC_MODELS)
}
TTS_BY_ID = {voice.id: voice for voice in TTS_VOICES}
STT_BY_ID = {model.id: model for model in STT_MODELS}


# Imported models live beside the built-in catalogue. The store reloads them
# at startup and after every import, so the rest of the app can keep asking
# catalog.get_model / models_for and get the full picture.
_CUSTOM_MODELS: dict[str, ModelSpec] = {}

_BUILTIN_BY_MODALITY: dict[str, tuple[ModelSpec, ...]] = {
    "text": TEXT_MODELS,
    "image": IMAGE_MODELS,
    "video": VIDEO_MODELS,
    "three_d": THREE_D_MODELS,
    "music": MUSIC_MODELS,
}


def register_custom_models(specs: list[ModelSpec] | tuple[ModelSpec, ...]) -> None:
    """Replace the imported-model overlay (built-ins are never touched)."""
    global _CUSTOM_MODELS
    _CUSTOM_MODELS = {spec.id: spec for spec in specs if spec.id not in ALL_MODELS}


def custom_models() -> tuple[ModelSpec, ...]:
    return tuple(_CUSTOM_MODELS.values())


def is_custom(model_id: str) -> bool:
    return model_id in _CUSTOM_MODELS


def models_for(modality: str) -> tuple[ModelSpec, ...]:
    builtin = _BUILTIN_BY_MODALITY.get(modality, ())
    extra = tuple(spec for spec in _CUSTOM_MODELS.values() if spec.modality == modality)
    return (*builtin, *extra)


def get_model(model_id: str) -> ModelSpec | None:
    return ALL_MODELS.get(model_id) or _CUSTOM_MODELS.get(model_id)


def get_tts_voice(voice_id: str) -> TtsVoice:
    return TTS_BY_ID.get(voice_id, TTS_VOICES[0])


def get_stt_model(model_id: str) -> SttModel:
    return STT_BY_ID.get(model_id, STT_MODELS[0])


def catalog_payload() -> dict:
    def entries(modality: str, specs: tuple[ModelSpec, ...]) -> list[dict]:
        payload = [spec.to_dict() for spec in specs]
        for spec in _CUSTOM_MODELS.values():
            if spec.modality == modality:
                item = spec.to_dict()
                item["custom"] = True
                payload.append(item)
        return payload

    return {
        "text": entries("text", TEXT_MODELS),
        "image": entries("image", IMAGE_MODELS),
        "video": entries("video", VIDEO_MODELS),
        "three_d": entries("three_d", THREE_D_MODELS),
        "music": entries("music", MUSIC_MODELS),
        "tts": [voice.to_dict() for voice in TTS_VOICES],
        "stt": [model.to_dict() for model in STT_MODELS],
    }
