"""Configuration schema and persistence for Hearth."""

from __future__ import annotations

import copy
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from . import paths

DEFAULT_SYSTEM_PROMPT = """You are Hearth, a private AI assistant running entirely on the user's own computer.
You are warm, concise, and practical. You can use tools to search the web, read pages, generate images,
generate video, compose music, speak text aloud, and create 3D models. Use a tool when it genuinely helps.
Never claim to have generated or looked up something unless a tool result confirms it.
When you use web results, cite them with bracketed numbers such as [1].
When you create media, say what you made in one or two sentences; the interface will show the file.
Today is {date}."""


class ModelSettings(BaseModel):
    model_config = ConfigDict(extra="ignore")

    enabled: bool = True
    model: str = ""


class ServerConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    host: str = "127.0.0.1"
    allow_remote: bool = False
    port: int = 8770
    open_browser: bool = True
    auto_start_services: bool = True
    keep_services_on_stop: bool = True
    # Remote panel login: set from the machine itself, stored as a PBKDF2 hash.
    panel_code_hash: str = ""
    panel_code_salt: str = ""


class LoadConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    mode: Literal["lazy", "keep_all", "text_resident"] = "lazy"
    idle_unload_minutes: int = Field(default=10, ge=0, le=240)
    unload_comfy_after_job: bool = False
    memory_guard: bool = True
    max_loaded_models: int = Field(default=2, ge=1, le=8)


class TextConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    enabled: bool = True
    backend: Literal["ollama", "openai", "demo"] = "ollama"
    base_url: str = "http://127.0.0.1:11434"
    api_key: str = ""
    model: str = "qwen3.5:9b"
    context_tokens: int = Field(default=8192, ge=1024, le=131072)
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float = Field(default=0.9, ge=0.0, le=1.0)
    system_prompt: str = DEFAULT_SYSTEM_PROMPT
    tools_enabled: bool = True
    thinking: bool = False
    tool_mode: Literal["auto", "native", "prompt"] = "auto"
    max_tool_rounds: int = Field(default=4, ge=0, le=10)
    keep_alive: str = "10m"
    vision_model: str = ""

    @field_validator("base_url")
    @classmethod
    def _strip_slash(cls, value: str) -> str:
        return value.rstrip("/")


class ImageConfig(ModelSettings):
    model: str = "sdxl-turbo"
    width: int = Field(default=1024, ge=256, le=2048)
    height: int = Field(default=1024, ge=256, le=2048)
    steps: int = Field(default=4, ge=1, le=80)
    cfg: float = Field(default=1.0, ge=0.0, le=20.0)
    seed: int = -1
    negative_prompt: str = ""
    timeout_s: int = Field(default=600, ge=30, le=3600)


class EditConfig(ModelSettings):
    """Photo editing: one or more source images plus an instruction."""

    model: str = "flux2-klein-edit"
    width: int = Field(default=1024, ge=256, le=2048)
    height: int = Field(default=1024, ge=256, le=2048)
    steps: int = Field(default=4, ge=1, le=60)
    seed: int = -1


class VideoConfig(ModelSettings):
    model: str = "wan2.1-1.3b"
    width: int = Field(default=832, ge=256, le=1280)
    height: int = Field(default=480, ge=256, le=1280)
    frames: int = Field(default=33, ge=9, le=161)
    fps: int = Field(default=16, ge=4, le=60)
    safe_limits: bool = True
    steps: int = Field(default=24, ge=4, le=60)
    cfg: float = Field(default=6.0, ge=1.0, le=20.0)
    seed: int = -1
    negative_prompt: str = "overexposed, static, blurred details, subtitles, low quality, jpeg artifacts"
    timeout_s: int = Field(default=3600, ge=60, le=7200)


class ThreeDConfig(ModelSettings):
    model: str = "hunyuan3d-2.1"
    resolution: int = Field(default=4096, ge=1024, le=8192)
    steps: int = Field(default=30, ge=8, le=60)
    cfg: float = Field(default=5.0, ge=1.0, le=12.0)
    octree_resolution: int = Field(default=256, ge=64, le=512)
    seed: int = -1
    timeout_s: int = Field(default=1800, ge=60, le=3600)


class MemoryConfig(BaseModel):
    """What the assistant is allowed to remember about you."""

    model_config = ConfigDict(extra="ignore")

    enabled: bool = True
    inject_limit: int = Field(default=40, ge=1, le=200)


class MusicConfig(ModelSettings):
    model: str = "ace-step-1.5"
    duration: int = Field(default=30, ge=5, le=180)
    bpm: int = Field(default=120, ge=30, le=240)
    steps: int = Field(default=8, ge=4, le=40)
    language: str = "en"
    timeout_s: int = Field(default=1800, ge=60, le=3600)


class AudioConfig(ModelSettings):
    model: str = "whisper-small"
    tts_engine: Literal["auto", "piper", "espeak", "none"] = "auto"
    voice: str = "en_US-amy-medium"
    stt_model: str = "small"
    language: str = "auto"
    timeout_s: int = Field(default=600, ge=30, le=3600)


class SearchConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    enabled: bool = True
    provider: Literal["auto", "searxng", "duckduckgo"] = "auto"
    searxng_url: str = ""
    max_results: int = Field(default=5, ge=1, le=12)
    fetch_pages: bool = True
    fetch_count: int = Field(default=2, ge=0, le=5)
    safe_search: bool = True
    timeout_s: int = Field(default=12, ge=3, le=60)

    @field_validator("searxng_url")
    @classmethod
    def _strip_slash(cls, value: str) -> str:
        return value.rstrip("/")


class ToolPermissions(BaseModel):
    model_config = ConfigDict(extra="ignore")

    web_search: bool = True
    fetch_url: bool = True
    generate_image: bool = True
    edit_image: bool = True
    generate_video: bool = True
    generate_music: bool = True
    text_to_speech: bool = True
    generate_3d: bool = True
    remember: bool = True
    forget_memory: bool = True

    def allows(self, name: str) -> bool:
        return bool(getattr(self, name, False))


class RuntimeConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ollama_port: int = Field(default=11434, ge=1024, le=65535)
    comfyui_port: int = Field(default=8188, ge=1024, le=65535)
    ollama_auto_start: bool = True
    comfyui_auto_start: bool = True
    prefer_system_ollama: bool = True
    comfyui_vram_mode: Literal["auto", "ram", "high", "cpu"] = "auto"
    comfyui_reserve_vram_gb: float = Field(default=1.0, ge=0.0, le=16.0)
    comfyui_vram_headroom_gb: float = Field(default=0.0, ge=0.0, le=16.0)


class UIConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    theme: Literal["dark", "light", "system"] = "dark"
    show_timings: bool = True
    compact_messages: bool = False


class AppConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    version: int = 1
    setup_complete: bool = False
    preset: str = "balanced"
    server: ServerConfig = Field(default_factory=ServerConfig)
    load: LoadConfig = Field(default_factory=LoadConfig)
    text: TextConfig = Field(default_factory=TextConfig)
    image: ImageConfig = Field(default_factory=ImageConfig)
    edit: EditConfig = Field(default_factory=EditConfig)
    video: VideoConfig = Field(default_factory=VideoConfig)
    three_d: ThreeDConfig = Field(default_factory=ThreeDConfig)
    music: MusicConfig = Field(default_factory=MusicConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    audio: AudioConfig = Field(default_factory=AudioConfig)
    search: SearchConfig = Field(default_factory=SearchConfig)
    tools: ToolPermissions = Field(default_factory=ToolPermissions)
    runtimes: RuntimeConfig = Field(default_factory=RuntimeConfig)
    ui: UIConfig = Field(default_factory=UIConfig)

    def model_settings(self, modality: str) -> ModelSettings:
        mapping = {
            "text": self.text,
            "image": self.image,
        "edit": self.edit,
            "video": self.video,
            "three_d": self.three_d,
            "music": self.music,
            "audio": self.audio,
        }
        return mapping[modality]


def deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge *patch* into *base* without mutating either."""
    result = copy.deepcopy(base)
    for key, value in (patch or {}).items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


class ConfigStore:
    def __init__(self, path: Path | None = None):
        self.path = path or paths.CONFIG_FILE
        self._config = AppConfig()

    @property
    def config(self) -> AppConfig:
        return self._config

    def load(self) -> AppConfig:
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                raw = {}
            merged = deep_merge(AppConfig().model_dump(), raw if isinstance(raw, dict) else {})
            self._config = AppConfig.model_validate(merged)
        else:
            self._config = AppConfig()
            self.save()
        return self._config

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(self._config.model_dump(), indent=2, ensure_ascii=False)
        fd, tmp_name = tempfile.mkstemp(prefix=".config-", dir=str(self.path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.write("\n")
            os.chmod(tmp_name, 0o600)
            os.replace(tmp_name, self.path)
        finally:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)

    def update(self, patch: dict[str, Any] | AppConfig) -> AppConfig:
        if isinstance(patch, AppConfig):
            self._config = patch
        else:
            merged = deep_merge(self._config.model_dump(), patch)
            self._config = AppConfig.model_validate(merged)
        self.save()
        return self._config

    def reset(self) -> AppConfig:
        self._config = AppConfig()
        self.save()
        return self._config
