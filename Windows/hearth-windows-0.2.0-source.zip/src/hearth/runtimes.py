"""Runtime installation, service lifecycle and model installation.

Hearth manages its own copies of Ollama, ComfyUI, Piper and faster-whisper
under ``~/.local/share/hearth/runtimes``. Nothing here needs root.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import platform
import shutil
import subprocess
import tarfile
import threading
import time
import zipfile
from pathlib import Path
from typing import Any

import httpx

from . import catalog, osutil, paths
from .config import ConfigStore
from .downloader import Downloader, JobCancelled, SourcePicker
from .hardware import HardwareInfo, detect_hardware
from .jobs import Job, JobManager
from .proc import run_capture, run_checked, run_command

OLLAMA_RELEASE = "https://github.com/ollama/ollama/releases/latest/download"
PIPER_RELEASE = "https://github.com/rhasspy/piper/releases/download/2023.11.14-2"


def _human_gb(value: float) -> str:
    return f"{value:.1f} GB"


class RuntimeManager:
    def __init__(
        self,
        config_store: ConfigStore,
        jobs: JobManager,
        hardware_provider=detect_hardware,
        sources: SourcePicker | None = None,
    ):
        self.config_store = config_store
        self.jobs = jobs
        self.hardware_provider = hardware_provider
        self.sources = sources or SourcePicker()
        self.downloader = Downloader(self.sources)

        self.ollama_dir = paths.RUNTIMES_DIR / "ollama"
        self.comfy_dir = paths.RUNTIMES_DIR / "comfyui"
        self.comfy_root = self.comfy_dir / "ComfyUI"
        self.comfy_python = osutil.venv_python(self.comfy_dir / ".venv")
        self.audio_dir = paths.RUNTIMES_DIR / "audio"
        self.audio_python = osutil.venv_python(self.audio_dir / ".venv")
        self.piper_dir = paths.RUNTIMES_DIR / "piper"
        self.ollama_models_dir = paths.MODELS_DIR / "ollama"
        self.whisper_cache = paths.MODELS_DIR / "whisper"

        self._procs: dict[str, subprocess.Popen] = {}
        self._log_handles: dict[str, Any] = {}
        self._lock = threading.RLock()
        self._comfy_cpu_mode = False
        self._ollama_external = False

    # ------------------------------------------------------------------
    # config / hardware helpers
    # ------------------------------------------------------------------
    @property
    def config(self):
        return self.config_store.config

    @property
    def hw(self) -> HardwareInfo:
        return self.hardware_provider()

    def _uv(self) -> str:
        local = paths.PROJECT_ROOT / ".tools" / osutil.exe("uv")
        if local.exists():
            return str(local)
        found = shutil.which(osutil.exe("uv"))
        if found:
            return found
        raise RuntimeError("uv is missing. Run the Hearth launcher once so it can bootstrap its toolchain.")

    def _log_path(self, name: str) -> Path:
        return paths.LOGS_DIR / f"{name}.log"

    def _tail(self, name: str, lines: int = 200) -> str:
        path = self._log_path(name)
        if not path.exists():
            return ""
        try:
            content = path.read_text(errors="replace").splitlines()
        except OSError:
            return ""
        return "\n".join(content[-lines:])

    def _append_log(self, name: str, line: str) -> None:
        try:
            with self._log_path(name).open("a", encoding="utf-8") as handle:
                handle.write(line.rstrip() + "\n")
        except OSError:
            pass

    # ------------------------------------------------------------------
    # generic process helpers
    # ------------------------------------------------------------------
    def _spawn(self, name: str, command: list[str], env: dict[str, str], cwd: Path | None = None) -> None:
        with self._lock:
            self._stop_process_locked(name)
            log_path = self._log_path(name)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            handle = log_path.open("a", encoding="utf-8")
            handle.write(f"\n--- {time.strftime('%Y-%m-%d %H:%M:%S')} starting {' '.join(command)} ---\n")
            handle.flush()
            proc = subprocess.Popen(
                command,
                cwd=str(cwd) if cwd else None,
                env={**os.environ, **env},
                stdin=subprocess.DEVNULL,
                stdout=handle,
                stderr=subprocess.STDOUT,
                **osutil.spawn_kwargs(),
            )
            self._procs[name] = proc
            self._log_handles[name] = handle

    def _stop_process_locked(self, name: str) -> None:
        proc = self._procs.pop(name, None)
        osutil.terminate_tree(proc)
        handle = self._log_handles.pop(name, None)
        if handle:
            with contextlib.suppress(OSError):
                handle.close()

    def stop_process(self, name: str) -> None:
        with self._lock:
            self._stop_process_locked(name)

    def _is_alive(self, name: str) -> bool:
        with self._lock:
            proc = self._procs.get(name)
            return bool(proc and proc.poll() is None)

    async def _health(self, url: str, timeout: float = 2.0) -> dict | None:
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.get(url)
            if response.status_code < 500:
                return {"status": response.status_code, "json": response.json()}
        except (httpx.HTTPError, ValueError, OSError):
            return None
        return None

    async def _wait_http(self, url: str, timeout: float, job: Job | None = None, label: str = "") -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if job and job.cancelled:
                return False
            result = await self._health(url, timeout=2.0)
            if result:
                return True
            await asyncio.sleep(1.0)
        return False

    # ------------------------------------------------------------------
    # Ollama
    # ------------------------------------------------------------------
    @property
    def ollama_base_url(self) -> str:
        return f"http://127.0.0.1:{self.config.runtimes.ollama_port}"

    def ollama_binary(self) -> Path | None:
        managed = self.ollama_dir / "bin" / osutil.exe("ollama")
        if managed.exists() and os.access(managed, os.X_OK):
            return managed
        if self.config.runtimes.prefer_system_ollama:
            found = shutil.which("ollama")
            if found:
                return Path(found)
        return None

    def ollama_installed(self) -> bool:
        return self.ollama_binary() is not None

    async def ollama_running(self) -> bool:
        return await self._health(f"{self.ollama_base_url}/api/version", timeout=1.5) is not None

    async def ollama_models(self) -> list[dict]:
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f"{self.ollama_base_url}/api/tags")
                response.raise_for_status()
                data = response.json()
            return data.get("models", [])
        except (httpx.HTTPError, ValueError, OSError):
            return []

    async def install_ollama(self, job: Job) -> None:
        item = "runtime:ollama"
        job.add_item(item, "Ollama runtime", size_gb=2.0)
        if self.ollama_installed():
            job.update_item(item, status="skipped", message="already installed")
            return
        job.update_item(item, status="running", message="downloading")
        arch = "arm64" if platform.machine().lower() in {"aarch64", "arm64"} else "amd64"
        asset = osutil.ollama_asset(arch)
        url = f"{OLLAMA_RELEASE}/{asset}"
        target = self.ollama_dir / asset
        self.ollama_dir.mkdir(parents=True, exist_ok=True)
        try:
            await asyncio.to_thread(
                self.downloader.download,
                url,
                target,
                job,
                item,
                expected_bytes=0,
                label="Ollama runtime",
                max_retries=2,
            )
            job.update_item(item, message="extracting")
            job.log("Extracting Ollama (this can take a minute)…")
            await asyncio.to_thread(self._extract_archive, target, self.ollama_dir)
            binary = self._find_file(self.ollama_dir, osutil.exe("ollama"))
            if binary and binary.parent.name != "bin":
                # Some archives place it at the root; keep a stable bin/ path.
                bin_dir = self.ollama_dir / "bin"
                bin_dir.mkdir(exist_ok=True)
                target_bin = bin_dir / "ollama"
                if binary != target_bin and not target_bin.exists():
                    shutil.copy2(binary, target_bin)
                binary = target_bin
            if not binary:
                raise RuntimeError("Ollama archive did not contain an ollama binary")
            os.chmod(binary, 0o755)
            target.unlink(missing_ok=True)
            job.update_item(item, status="done", message="installed")
            job.log("Ollama installed.")
        except JobCancelled:
            job.update_item(item, status="canceled")
            raise
        except Exception as exc:
            job.update_item(item, status="error", error=str(exc))
            raise

    async def start_ollama(self, job: Job | None = None) -> dict:
        if await self.ollama_running():
            self._ollama_external = not self._is_alive("ollama")
            return {"started": False, "external": self._ollama_external, "base_url": self.ollama_base_url}
        binary = self.ollama_binary()
        if not binary:
            raise RuntimeError("Ollama is not installed. Install it from the launcher first.")
        self.ollama_models_dir.mkdir(parents=True, exist_ok=True)
        keep_alive = "-1" if self.config.load.mode in {"keep_all", "text_resident"} else self.config.text.keep_alive
        env = {
            "OLLAMA_HOST": f"127.0.0.1:{self.config.runtimes.ollama_port}",
            "OLLAMA_MODELS": str(self.ollama_models_dir),
            "OLLAMA_KEEP_ALIVE": keep_alive,
            "OLLAMA_MAX_LOADED_MODELS": str(max(1, self.config.load.max_loaded_models)),
            "OLLAMA_NUM_PARALLEL": "1",
            "OLLAMA_FLASH_ATTENTION": "1",
            "OLLAMA_DEBUG": "0",
        }
        self._spawn("ollama", [str(binary), "serve"], env)
        if job:
            job.log("Starting Ollama…")
        ok = await self._wait_http(f"{self.ollama_base_url}/api/version", timeout=90, job=job)
        if not ok:
            tail = self._tail("ollama", 40)
            self.stop_process("ollama")
            raise RuntimeError("Ollama did not become ready.\n" + tail)
        self._ollama_external = False
        if job:
            job.log("Ollama is ready.")
        return {"started": True, "external": False, "base_url": self.ollama_base_url}

    async def stop_ollama(self) -> None:
        if self._is_alive("ollama"):
            self.stop_process("ollama")
            await asyncio.sleep(0.5)

    async def ollama_version(self) -> str:
        result = await self._health(f"{self.ollama_base_url}/api/version", timeout=2)
        if result and isinstance(result.get("json"), dict):
            return str(result["json"].get("version") or "")
        return ""

    async def pull_ollama_model(self, spec: catalog.ModelSpec, job: Job) -> None:
        item = f"ollama:{spec.id}"
        job.add_item(item, spec.name, size_gb=spec.total_size_gb)
        if not await self.ollama_running():
            await self.start_ollama(job)
        existing = await self.ollama_models()
        names = {entry.get("name", "") for entry in existing}
        if spec.ollama_tag in names or spec.ollama_tag.replace(":latest", "") in {
            name.replace(":latest", "") for name in names
        }:
            job.update_item(item, status="skipped", message="already installed")
            return
        job.update_item(item, status="running", message="pulling")
        await asyncio.to_thread(self._pull_ollama_sync, spec, job, item)

    def _pull_ollama_sync(self, spec: catalog.ModelSpec, job: Job, item: str) -> None:
        url = f"{self.ollama_base_url}/api/pull"
        timeout = httpx.Timeout(connect=20.0, read=None, write=None, pool=None)
        try:
            with (
                httpx.Client(timeout=timeout) as client,
                client.stream("POST", url, json={"model": spec.ollama_tag, "stream": True}) as response,
            ):
                response.raise_for_status()
                for line in response.iter_lines():
                    if job.cancelled:
                        raise JobCancelled("cancelled")
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        job.log(line)
                        continue
                    if data.get("error"):
                        raise RuntimeError(str(data["error"]))
                    status = data.get("status", "")
                    total = int(data.get("total") or 0)
                    completed = int(data.get("completed") or 0)
                    if data.get("digest"):
                        job.log(f"{status} {data['digest'][:12]}")
                    speed = 0.0
                    eta = None
                    if total and completed:
                        speed = completed / max(
                            1.0, time.monotonic() - getattr(self, "_pull_started", time.monotonic())
                        )
                    job.update_item(
                        item,
                        status="running",
                        total_bytes=total or int(spec.size_gb * 1_000_000_000),
                        completed_bytes=completed,
                        message=status,
                        speed_bps=speed,
                        eta_s=eta,
                    )
                    if status == "success":
                        job.update_item(
                            item, status="done", completed_bytes=total or completed, message="installed"
                        )
                        job.log(f"{spec.name} installed.")
                        return
            job.update_item(item, status="done", message="installed")
        except JobCancelled:
            job.update_item(item, status="canceled")
            raise
        except Exception as exc:
            job.update_item(item, status="error", error=str(exc))
            raise

    async def preload_ollama(self, model: str, job: Job | None = None) -> bool:
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(300.0, connect=10.0)) as client:
                response = await client.post(
                    f"{self.ollama_base_url}/api/generate",
                    json={"model": model, "prompt": "", "stream": False, "keep_alive": -1},
                )
            if job:
                job.log(f"Preloaded {model}: HTTP {response.status_code}")
            return response.status_code < 400
        except (httpx.HTTPError, OSError) as exc:
            if job:
                job.log(f"Could not preload {model}: {exc}")
            return False

    async def unload_ollama(self, model: str) -> None:
        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                await client.post(
                    f"{self.ollama_base_url}/api/generate",
                    json={"model": model, "prompt": "", "stream": False, "keep_alive": 0},
                )
        except (httpx.HTTPError, OSError):
            return
        # Ollama accepts the unload request immediately; wait until the runner is
        # actually gone so ComfyUI doesn't start while the text model still owns VRAM.
        for _ in range(40):
            loaded = await self.ollama_ps()
            if not any(entry.get("name") == model for entry in loaded):
                return
            await asyncio.sleep(0.25)

    async def ollama_ps(self) -> list[dict]:
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f"{self.ollama_base_url}/api/ps")
                response.raise_for_status()
                return response.json().get("models", [])
        except (httpx.HTTPError, ValueError, OSError):
            return []

    async def ollama_show(self, model: str) -> dict:
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(f"{self.ollama_base_url}/api/show", json={"model": model})
                response.raise_for_status()
                return response.json()
        except (httpx.HTTPError, ValueError, OSError):
            return {}

    # ------------------------------------------------------------------
    # ComfyUI
    # ------------------------------------------------------------------
    @property
    def comfy_base_url(self) -> str:
        return f"http://127.0.0.1:{self.config.runtimes.comfyui_port}"

    def comfy_installed(self) -> bool:
        return (self.comfy_root / "main.py").exists() and self.comfy_python.exists()

    async def comfy_running(self) -> bool:
        return await self._health(f"{self.comfy_base_url}/system_stats", timeout=1.5) is not None

    async def install_comfyui(self, job: Job) -> None:
        item = "runtime:comfyui"
        job.add_item(item, "ComfyUI + PyTorch", size_gb=8.0)
        if self.comfy_installed():
            job.update_item(item, status="skipped", message="already installed")
            return
        job.update_item(item, status="running", message="preparing")
        try:
            self.comfy_dir.mkdir(parents=True, exist_ok=True)
            if not (self.comfy_root / "main.py").exists():
                if self.comfy_root.exists():
                    job.log("Removing an incomplete ComfyUI checkout…")
                    shutil.rmtree(self.comfy_root)
                job.update_item(item, message="cloning ComfyUI")
                code = await run_command(
                    ["git", "clone", "--depth", "1", "https://github.com/comfyanonymous/ComfyUI", str(self.comfy_root)],
                    job=job,
                )
                if code != 0:
                    job.log("git clone failed; trying the GitHub tarball…")
                    archive = self.comfy_dir / "comfyui.tar.gz"
                    await asyncio.to_thread(
                        self.downloader.download,
                        "https://codeload.github.com/comfyanonymous/ComfyUI/tar.gz/refs/heads/master",
                        archive,
                        job,
                        item,
                        label="ComfyUI source",
                    )
                    await asyncio.to_thread(self._extract_archive, archive, self.comfy_dir)
                    archive.unlink(missing_ok=True)
                    extracted = [path for path in self.comfy_dir.iterdir() if path.is_dir() and path.name.startswith("ComfyUI-")]
                    if extracted and not self.comfy_root.exists():
                        extracted[0].rename(self.comfy_root)
            if not (self.comfy_root / "main.py").exists():
                raise RuntimeError("ComfyUI source is missing main.py")
            if not self.comfy_python.exists():
                job.update_item(item, message="creating Python 3.12 environment")
                await run_checked(
                    [self._uv(), "venv", "--python", "3.12", str(self.comfy_dir / ".venv")],
                    job=job,
                    cwd=self.comfy_dir,
                )
            torch_index = self.torch_index()
            job.update_item(item, message=f"installing PyTorch ({'CUDA' if 'cu' in torch_index else 'CPU'}) — the big download")
            job.log(f"PyTorch index: {torch_index}")
            await run_checked(
                [
                    self._uv(),
                    "pip",
                    "install",
                    "--python",
                    str(self.comfy_python),
                    "torch",
                    "torchvision",
                    "torchaudio",
                    "--index-url",
                    torch_index,
                ],
                job=job,
                timeout=3600,
            )
            job.update_item(item, message="installing ComfyUI requirements")
            await run_checked(
                [
                    self._uv(),
                    "pip",
                    "install",
                    "--python",
                    str(self.comfy_python),
                    "-r",
                    str(self.comfy_root / "requirements.txt"),
                    "--index-url",
                    self.sources.pypi_index(),
                ],
                job=job,
                timeout=3600,
            )
            if not self.comfy_python.exists():
                raise RuntimeError("ComfyUI environment was not created")
            job.update_item(item, status="done", message="installed")
            job.log("ComfyUI installed.")
        except JobCancelled:
            job.update_item(item, status="canceled")
            raise
        except Exception as exc:
            job.update_item(item, status="error", error=str(exc))
            raise

    def comfy_command(self) -> list[str]:
        settings = self.config.runtimes
        command = [
            str(self.comfy_python),
            "main.py",
            "--listen",
            "127.0.0.1",
            "--port",
            str(settings.comfyui_port),
            "--disable-auto-launch",
            "--preview-method",
            "none",
        ]
        self._comfy_cpu_mode = (not self.hw.gpu_usable) or settings.comfyui_vram_mode == "cpu"
        if self._comfy_cpu_mode:
            command.append("--cpu")
        else:
            if settings.comfyui_vram_mode == "ram":
                command.append("--disable-smart-memory")
            elif settings.comfyui_vram_mode == "high":
                command.append("--highvram")
            if settings.comfyui_reserve_vram_gb > 0:
                command.extend(["--reserve-vram", f"{settings.comfyui_reserve_vram_gb:g}"])
            if settings.comfyui_vram_headroom_gb > 0:
                command.extend(["--vram-headroom", f"{settings.comfyui_vram_headroom_gb:g}"])
        return command

    async def start_comfyui(self, job: Job | None = None) -> dict:
        if await self.comfy_running():
            return {"started": False, "base_url": self.comfy_base_url}
        if not self.comfy_installed():
            raise RuntimeError("ComfyUI is not installed. Install it from the launcher first.")
        command = self.comfy_command()
        env = {
            "PYTHONUNBUFFERED": "1",
            "HF_ENDPOINT": self.sources.hf_endpoint(),
            "PYTORCH_CUDA_ALLOC_CONF": "expandable_segments:True",
            "CUDA_MODULE_LOADING": "LAZY",
        }
        self._spawn("comfyui", command, env, cwd=self.comfy_root)
        if job:
            job.log("Starting ComfyUI" + (" (CPU mode — GPU driver unavailable)" if self._comfy_cpu_mode else "") + "…")
        ok = await self._wait_http(f"{self.comfy_base_url}/system_stats", timeout=300, job=job)
        if not ok:
            tail = self._tail("comfyui", 60)
            self.stop_process("comfyui")
            raise RuntimeError("ComfyUI did not become ready.\n" + tail)
        if job:
            job.log("ComfyUI is ready.")
        return {"started": True, "base_url": self.comfy_base_url, "cpu_mode": self._comfy_cpu_mode}

    async def stop_comfyui(self) -> None:
        if self._is_alive("comfyui"):
            self.stop_process("comfyui")
            await asyncio.sleep(0.5)

    async def comfy_version(self) -> str:
        result = await self._health(f"{self.comfy_base_url}/system_stats", timeout=2)
        if result and isinstance(result.get("json"), dict):
            return str(result["json"].get("system", {}).get("comfyui_version") or "")
        return ""

    async def comfy_queue(self) -> dict:
        try:
            async with httpx.AsyncClient(timeout=4.0) as client:
                response = await client.get(f"{self.comfy_base_url}/queue")
                response.raise_for_status()
                return response.json()
        except (httpx.HTTPError, ValueError, OSError):
            return {}

    async def free_comfy(self) -> None:
        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                await client.post(
                    f"{self.comfy_base_url}/free",
                    json={"unload_models": True, "free_memory": True},
                )
        except (httpx.HTTPError, OSError):
            pass

    def comfy_missing_files(self, spec: catalog.ModelSpec) -> list[catalog.ModelFile]:
        """The files a model still needs on disk (shared files count once)."""
        missing: list[catalog.ModelFile] = []
        seen: set[str] = set()
        for item in spec.files:
            if item.dest in seen:
                continue
            seen.add(item.dest)
            if not (self.comfy_root / "models" / item.dest).exists():
                missing.append(item)
        return missing

    def comfy_present_gb(self, spec: catalog.ModelSpec) -> float:
        missing = {item.dest for item in self.comfy_missing_files(spec)}
        seen: set[str] = set()
        present = 0.0
        for item in spec.files:
            if item.dest in seen:
                continue
            seen.add(item.dest)
            if item.dest not in missing:
                present += item.size_gb
        return round(present, 2)

    def comfy_model_installed(self, spec: catalog.ModelSpec) -> bool:
        if not spec.files:
            return False
        return not self.comfy_missing_files(spec)

    async def download_comfy_model(self, spec: catalog.ModelSpec, job: Job) -> None:
        if not self.comfy_installed():
            await self.install_comfyui(job)
        missing = {item.dest for item in self.comfy_missing_files(spec)}
        if not missing:
            present_gb = self.comfy_present_gb(spec)
            job.log(f"{spec.name} is already installed ({present_gb:g} GB on disk); nothing to download.")
            return
        present_gb = self.comfy_present_gb(spec)
        if present_gb:
            job.log(
                f"{spec.name}: {present_gb:g} GB already on disk, "
                f"{round(spec.total_size_gb - present_gb, 2):g} GB to fetch."
            )
        seen: set[str] = set()
        for item in spec.files:
            if item.dest in seen or item.dest not in missing:
                continue
            seen.add(item.dest)
            item_id = f"comfy:{spec.id}:{item.dest}"
            job.add_item(item_id, f"{spec.name} · {item.filename.rsplit('/', 1)[-1]}", size_gb=item.size_gb)
            dest = self.comfy_root / "models" / item.dest
            job.update_item(item_id, status="running", message="downloading")
            try:
                await asyncio.to_thread(
                    self.downloader.download_hf,
                    item.repo,
                    item.filename,
                    dest,
                    job,
                    item_id,
                    expected_gb=item.size_gb,
                    label=f"{spec.name} · {dest.name}",
                )
            except JobCancelled:
                job.update_item(item_id, status="canceled")
                raise
            except Exception as exc:
                job.update_item(item_id, status="error", error=str(exc))
                raise
        job.log(f"{spec.name} is installed.")

    async def comfy_upload_image(self, image_path: Path, subfolder: str = "hearth") -> str:
        url = f"{self.comfy_base_url}/upload/image"
        with image_path.open("rb") as handle:
            files = {"image": (image_path.name, handle, "image/png")}
            data = {"type": "input", "subfolder": subfolder, "overwrite": "true"}
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(url, files=files, data=data)
                response.raise_for_status()
                payload = response.json()
        name = payload.get("name") or image_path.name
        folder = payload.get("subfolder") or subfolder
        return f"{folder}/{name}" if folder else name

    # ------------------------------------------------------------------
    # Speech: Piper + espeak-ng + faster-whisper
    # ------------------------------------------------------------------
    def piper_binary(self) -> Path | None:
        name = osutil.exe("piper")
        candidates = [self.piper_dir / name, self.piper_dir / "piper" / name]
        for path in candidates:
            if path.is_file() and os.access(path, os.X_OK):
                return path
        for path in self.piper_dir.rglob(name):
            if path.is_file() and os.access(path, os.X_OK):
                return path
        return None

    def piper_voice_files(self, voice_id: str) -> tuple[Path, Path]:
        voice = catalog.get_tts_voice(voice_id)
        onnx = self.piper_dir / "voices" / voice.filename
        return onnx, onnx.with_suffix(onnx.suffix + ".json")

    def piper_installed(self, voice_id: str | None = None) -> bool:
        if not self.piper_binary():
            return False
        if voice_id:
            onnx, config = self.piper_voice_files(voice_id)
            return onnx.exists() and config.exists()
        return True

    async def install_piper(self, job: Job, voice_id: str | None = None) -> None:
        voice_id = voice_id or self.config.audio.voice
        voice = catalog.get_tts_voice(voice_id)
        item = "runtime:piper"
        job.add_item(item, "Piper speech runtime", size_gb=0.08)
        try:
            self.piper_dir.mkdir(parents=True, exist_ok=True)
            if not self.piper_binary():
                job.update_item(item, status="running", message="downloading Piper")
                asset = osutil.piper_asset()
                archive = self.piper_dir / asset
                await asyncio.to_thread(
                    self.downloader.download,
                    f"{PIPER_RELEASE}/{asset}",
                    archive,
                    job,
                    item,
                    expected_bytes=12_000_000,
                    label="Piper",
                )
                job.update_item(item, message="extracting Piper")
                await asyncio.to_thread(self._extract_archive, archive, self.piper_dir)
                archive.unlink(missing_ok=True)
                if not osutil.IS_WINDOWS:
                    for candidate in self.piper_dir.rglob(osutil.exe("piper")):
                        if candidate.is_file():
                            os.chmod(candidate, 0o755)
                binary = self.piper_binary()
                if binary and not osutil.IS_WINDOWS:
                    os.chmod(binary, 0o755)
            onnx, config = self.piper_voice_files(voice_id)
            if not onnx.exists():
                job.update_item(item, message=f"downloading voice {voice.name}")
                (self.piper_dir / "voices").mkdir(parents=True, exist_ok=True)
                await asyncio.to_thread(
                    self.downloader.download_hf,
                    voice.repo,
                    voice.onnx_path,
                    onnx,
                    job,
                    item,
                    expected_gb=voice.size_gb,
                    label=voice.name,
                )
            if not config.exists():
                await asyncio.to_thread(
                    self.downloader.download_hf,
                    voice.repo,
                    voice.onnx_path + ".json",
                    config,
                    job,
                    item,
                    label=f"{voice.name} config",
                )
            if not self.piper_binary():
                raise RuntimeError("Piper binary was not found after extraction")
            job.update_item(item, status="done", message="installed")
        except JobCancelled:
            job.update_item(item, status="canceled")
            raise
        except Exception as exc:
            job.update_item(item, status="error", error=str(exc))
            raise

    async def install_audio(self, job: Job, stt_model: str | None = None) -> None:
        stt_model = stt_model or self.config.audio.stt_model
        await self.install_piper(job)
        item = "runtime:whisper"
        job.add_item(item, "faster-whisper", size_gb=0.4)
        if not self.audio_python.exists():
            job.update_item(item, status="running", message="creating audio environment")
            self.audio_dir.mkdir(parents=True, exist_ok=True)
            await run_checked(
                [self._uv(), "venv", "--python", "3.12", str(self.audio_dir / ".venv")],
                job=job,
                cwd=self.audio_dir,
            )
            await run_checked(
                [
                    self._uv(),
                    "pip",
                    "install",
                    "--python",
                    str(self.audio_python),
                    "faster-whisper",
                    "--index-url",
                    self.sources.pypi_index(),
                ],
                job=job,
                timeout=1800,
            )
            job.update_item(item, status="done", message="installed")
        else:
            job.update_item(item, status="skipped", message="already installed")
        await self.ensure_whisper_model(stt_model, job)

    def _whisper_model_dir(self, repo: str) -> Path | None:
        slug = repo.replace("/", "--")
        self.whisper_cache.mkdir(parents=True, exist_ok=True)
        for candidate in self.whisper_cache.glob(f"models--{slug}*"):
            for model_file in candidate.rglob("model.bin"):
                return model_file.parent
        for model_file in self.whisper_cache.rglob("model.bin"):
            if slug.split("--")[-1] in str(model_file):
                return model_file.parent
        return None

    async def ensure_whisper_model(self, stt_model: str, job: Job) -> None:
        spec = catalog.get_stt_model(stt_model)
        if not self.audio_python.exists():
            raise RuntimeError("The audio environment is not installed. Install speech support first.")
        item = f"whisper:{spec.id}"
        job.add_item(item, spec.name, size_gb=spec.size_gb)
        if self._whisper_model_dir(spec.repo):
            job.update_item(item, status="skipped", message="already installed")
            return
        job.update_item(item, status="running", message="downloading model")
        worker = Path(__file__).with_name("audio_worker.py")
        code, _out, err = await run_capture(
            [
                str(self.audio_python),
                str(worker),
                "download",
                spec.repo,
                str(self.whisper_cache),
            ],
            env={"HF_ENDPOINT": self.sources.hf_endpoint(), "PYTHONUNBUFFERED": "1"},
            job=job,
            timeout=1800,
        )
        if code != 0:
            job.update_item(item, status="error", error=err.strip()[-2000:])
            raise RuntimeError(f"Could not download {spec.name}: {err.strip()[-500:]}")
        job.update_item(item, status="done", message="installed")

    async def transcribe_audio(
        self,
        path: Path,
        stt_model: str,
        language: str = "auto",
        job: Job | None = None,
    ) -> dict:
        if self.config.text.backend == "ollama":
            await self.unload_ollama(self.config.text.model)
        if not self.audio_python.exists():
            raise RuntimeError("Speech-to-text is not installed. Install speech support in the launcher.")
        spec = catalog.get_stt_model(stt_model)
        if not self._whisper_model_dir(spec.repo):
            if job:
                await self.ensure_whisper_model(stt_model, job)
            else:
                raise RuntimeError(f"{spec.name} is not downloaded yet.")
        worker = Path(__file__).with_name("audio_worker.py")
        code, out, err = await run_capture(
            [
                str(self.audio_python),
                str(worker),
                "transcribe",
                str(path),
                spec.repo,
                str(self.whisper_cache),
                language,
            ],
            env={"HF_ENDPOINT": self.sources.hf_endpoint(), "PYTHONUNBUFFERED": "1"},
            job=job,
            timeout=self.config.audio.timeout_s,
        )
        if code != 0:
            raise RuntimeError(err.strip()[-1000:] or "Transcription failed")
        try:
            return json.loads(out.strip().splitlines()[-1])
        except (json.JSONDecodeError, IndexError) as exc:
            raise RuntimeError(f"Unexpected transcription output: {out[-500:]}") from exc

    async def tts(self, text: str, out_path: Path, voice_id: str | None = None) -> dict:
        voice_id = voice_id or self.config.audio.voice
        out_path.parent.mkdir(parents=True, exist_ok=True)
        piper = self.piper_binary()
        onnx, config = self.piper_voice_files(voice_id)
        if piper and onnx.exists() and config.exists():
            env = {**os.environ, "LD_LIBRARY_PATH": str(self.piper_dir) + ":" + os.environ.get("LD_LIBRARY_PATH", "")}
            result = await asyncio.to_thread(
                subprocess.run,
                [str(piper), "--model", str(onnx), "--output_file", str(out_path)],
                input=text.encode(),
                capture_output=True,
                timeout=180,
                env=env,
            )
            if result.returncode == 0 and out_path.exists():
                return {"path": out_path, "engine": "piper", "voice": voice_id}
            self._append_log("audio", f"Piper failed: {result.stderr.decode(errors='replace')[-1000:]}")
        espeak = shutil.which("espeak-ng")
        if espeak:
            lang = catalog.get_tts_voice(voice_id).language.lower()
            result = await asyncio.to_thread(
                subprocess.run,
                [espeak, "-w", str(out_path), "-v", lang, "-s", "175"],
                input=text.encode(),
                capture_output=True,
                timeout=180,
            )
            if result.returncode == 0 and out_path.exists():
                return {"path": out_path, "engine": "espeak", "voice": voice_id}
        raise RuntimeError("No speech engine is available. Install Piper or espeak-ng.")

    # ------------------------------------------------------------------
    # Preset / model installation entry points
    # ------------------------------------------------------------------
    async def install_preset(self, preset, modalities: dict[str, bool], job: Job) -> None:
        """Install everything the selected preset needs, in dependency order."""
        job.start()
        try:
            if modalities.get("text", True):
                spec = catalog.get_model(preset.text_model)
                if spec and self.config.text.backend == "ollama":
                    await self.install_ollama(job)
                    await self.pull_ollama_model(spec, job)
            needs_comfy = any(modalities.get(key, True) for key in ("image", "video", "three_d", "music"))
            if needs_comfy:
                await self.install_comfyui(job)
                for modality in ("image", "video", "three_d", "music"):
                    if not modalities.get(modality, True):
                        continue
                    model_id = {
                        "image": preset.image_model,
                        "video": preset.video_model,
                        "three_d": preset.three_d_model,
                        "music": preset.music_model,
                    }[modality]
                    spec = catalog.get_model(model_id)
                    if spec:
                        await self.download_comfy_model(spec, job)
            if modalities.get("audio", True):
                await self.install_audio(job, preset.stt_model)
            job.finish({"preset": preset.tier})
        except JobCancelled:
            job.cancel()
            raise
        except Exception as exc:
            job.fail(str(exc))
            raise

    async def install_model(self, model_id: str, job: Job) -> None:
        spec = catalog.get_model(model_id)
        if not spec:
            raise RuntimeError(f"Unknown model: {model_id}")
        job.start()
        # The caller usually pre-seeds a single item for "this model"; keep it
        # honest even when every file is already on disk.
        summary_item = f"model:{spec.id}"
        try:
            if spec.runtime == "ollama":
                await self.install_ollama(job)
                await self.pull_ollama_model(spec, job)
            elif spec.runtime == "comfyui":
                await self.install_comfyui(job)
                await self.download_comfy_model(spec, job)
            if job.item(summary_item) is not None:
                job.update_item(summary_item, status="done", message="installed")
            job.finish({"model": model_id})
        except JobCancelled:
            job.cancel()
            raise
        except Exception as exc:
            job.fail(str(exc))
            raise

    async def install_voice(self, voice_id: str, job: Job) -> None:
        job.start()
        try:
            await self.install_piper(job, voice_id)
            job.finish({"voice": voice_id})
        except JobCancelled:
            job.cancel()
            raise
        except Exception as exc:
            job.fail(str(exc))
            raise

    async def install_stt(self, stt_model: str, job: Job) -> None:
        job.start()
        try:
            await self.install_audio(job, stt_model)
            job.finish({"stt_model": stt_model})
        except JobCancelled:
            job.cancel()
            raise
        except Exception as exc:
            job.fail(str(exc))
            raise

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------
    async def lmstudio_status(self) -> dict:
        url = "http://127.0.0.1:1234/v1/models"
        try:
            async with httpx.AsyncClient(timeout=1.5) as client:
                response = await client.get(url)
                response.raise_for_status()
                data = response.json()
            return {"running": True, "models": [item.get("id") for item in data.get("data", [])]}
        except (httpx.HTTPError, ValueError, OSError):
            return {"running": False, "models": []}

    def torch_index(self) -> str:
        nvidia = any(gpu.vendor == "NVIDIA" for gpu in self.hw.gpus)
        if not nvidia:
            return "https://download.pytorch.org/whl/cpu"
        driver = ""
        if self.hw.gpus:
            driver = self.hw.gpus[0].driver or ""
        try:
            major = int(driver.split(".")[0])
        except (TypeError, ValueError):
            major = 0
        if major >= 580:
            return "https://download.pytorch.org/whl/cu130"
        if major >= 570:
            return "https://download.pytorch.org/whl/cu128"
        if major >= 550:
            return "https://download.pytorch.org/whl/cu126"
        if major >= 525:
            return "https://download.pytorch.org/whl/cu121"
        return "https://download.pytorch.org/whl/cu118"

    def log_tail(self, name: str, lines: int = 200) -> str:
        return self._tail(name, lines)

    def whisper_installed(self, stt_model: str) -> bool:
        spec = catalog.get_stt_model(stt_model)
        return bool(self._whisper_model_dir(spec.repo))

    async def status(self) -> dict:
        hw = self.hw
        ollama_running = await self.ollama_running()
        comfy_running = await self.comfy_running()
        piper = self.piper_binary()
        voice = self.config.audio.voice
        onnx, config = self.piper_voice_files(voice)
        stt_spec = catalog.get_stt_model(self.config.audio.stt_model)
        return {
            "ollama": {
                "installed": self.ollama_installed(),
                "running": ollama_running,
                "managed": self._is_alive("ollama"),
                "external": ollama_running and not self._is_alive("ollama"),
                "version": await self.ollama_version() if ollama_running else "",
                "base_url": self.ollama_base_url,
                "models": await self.ollama_models() if ollama_running else [],
                "loaded": await self.ollama_ps() if ollama_running else [],
                "log": str(self._log_path("ollama")),
                "tail": self._tail("ollama", 30),
            },
            "comfyui": {
                "installed": self.comfy_installed(),
                "running": comfy_running,
                "cpu_mode": self._comfy_cpu_mode or not hw.gpu_usable,
                "vram_mode": self.config.runtimes.comfyui_vram_mode,
                "reserve_vram_gb": self.config.runtimes.comfyui_reserve_vram_gb,
                "version": await self.comfy_version() if comfy_running else "",
                "base_url": self.comfy_base_url,
                "queue": await self.comfy_queue() if comfy_running else {},
                "log": str(self._log_path("comfyui")),
                "tail": self._tail("comfyui", 30),
            },
            "audio": {
                "piper": bool(piper),
                "piper_voice": voice,
                "piper_voice_ready": onnx.exists() and config.exists(),
                "espeak": bool(shutil.which("espeak-ng")),
                "whisper": self.audio_python.exists(),
                "whisper_model": stt_spec.id,
                "whisper_model_ready": bool(self._whisper_model_dir(stt_spec.repo)),
            },
            "lmstudio": await self.lmstudio_status(),
            "sources": self.sources.sources_payload(),
        }

    async def start_all(self) -> dict:
        result: dict[str, Any] = {}
        if self.config.text.enabled and self.config.text.backend == "ollama" and self.config.runtimes.ollama_auto_start:
            result["ollama"] = await self.start_ollama()
            if self.config.load.mode in {"keep_all", "text_resident"} and self.config.text.model:
                await self.preload_ollama(self.config.text.model)
        media_enabled = any(
            [
                self.config.image.enabled,
                self.config.video.enabled,
                self.config.three_d.enabled,
                self.config.music.enabled,
            ]
        )
        if media_enabled and self.config.runtimes.comfyui_auto_start and self.comfy_installed():
            result["comfyui"] = await self.start_comfyui()
        return result

    async def stop_all(self, unload: bool = True) -> None:
        if unload:
            if await self.ollama_running():
                await self.unload_ollama(self.config.text.model)
            if await self.comfy_running():
                await self.free_comfy()
        if not self.config.server.keep_services_on_stop:
            await self.stop_ollama()
            await self.stop_comfyui()

    async def shutdown(self) -> None:
        for name in list(self._procs.keys()):
            self.stop_process(name)

    # ------------------------------------------------------------------
    # Archive helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _find_file(root: Path, name: str) -> Path | None:
        for path in root.rglob(name):
            if path.is_file():
                return path
        return None

    @staticmethod
    def _safe_extract_tar(tar: tarfile.TarFile, dest: Path) -> None:
        dest.mkdir(parents=True, exist_ok=True)
        try:
            tar.extractall(dest, filter="data")
        except TypeError:
            for member in tar.getmembers():
                target = (dest / member.name).resolve()
                if dest.resolve() not in target.parents and target != dest.resolve():
                    raise RuntimeError("unsafe archive member") from None
            tar.extractall(dest)

    def _extract_archive(self, archive: Path, dest: Path) -> None:
        dest.mkdir(parents=True, exist_ok=True)
        name = archive.name.lower()
        if name.endswith(".zip"):
            with zipfile.ZipFile(archive) as zf:
                for member in zf.infolist():
                    target = (dest / member.filename).resolve()
                    if dest.resolve() not in target.parents and target != dest.resolve():
                        raise RuntimeError("unsafe zip member")
                zf.extractall(dest)
            return
        if name.endswith(".tar.zst") or name.endswith(".tzst"):
            try:
                result = subprocess.run(
                    ["tar", "--zstd", "-xf", str(archive), "-C", str(dest)],
                    capture_output=True,
                    text=True,
                    timeout=600,
                )
                if result.returncode == 0:
                    return
            except (OSError, subprocess.TimeoutExpired):
                pass
            import zstandard as zstd

            with archive.open("rb") as handle:
                reader = zstd.ZstdDecompressor().stream_reader(handle)
                with tarfile.open(fileobj=reader, mode="r|") as tar:
                    self._safe_extract_tar(tar, dest)
            return
        mode = "r:gz" if name.endswith((".tar.gz", ".tgz")) else "r:*"
        with tarfile.open(archive, mode) as tar:
            self._safe_extract_tar(tar, dest)
