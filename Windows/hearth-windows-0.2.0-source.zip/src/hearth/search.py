"""Web search and page reading with a small SSRF guard.

SearXNG is preferred when configured because it is self-hostable. The
DuckDuckGo HTML endpoints are a zero-config fallback. Both leave the machine;
the UI says so.
"""

from __future__ import annotations

import asyncio
import html
import ipaddress
import re
import socket
from dataclasses import asdict, dataclass
from html.parser import HTMLParser
from urllib.parse import parse_qs, unquote, urlparse

import httpx

from .config import SearchConfig

USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0 Safari/537.36 Hearth/0.1"
)
SKIP_TAGS = {"script", "style", "noscript", "svg", "canvas", "template", "iframe"}


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str = ""
    excerpt: str = ""
    provider: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class _DuckParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.results: list[SearchResult] = []
        self._mode: str | None = None
        self._href = ""
        self._title_parts: list[str] = []
        self._snippet_parts: list[str] = []
        self._in_link = False

    def handle_starttag(self, tag: str, attrs) -> None:
        attrs_dict = dict(attrs)
        classes = (attrs_dict.get("class") or "").split()
        if tag == "a" and any(item in classes for item in ("result__a", "result-link")):
            self._mode = "title"
            self._href = attrs_dict.get("href") or ""
            self._title_parts = []
            self._snippet_parts = []
            self._in_link = True
        elif tag == "a" and "result__snippet" in classes:
            self._mode = "snippet"
            self._in_link = True
        elif tag in {"td", "div"} and any(item in classes for item in ("result-snippet", "result__snippet")):
            self._mode = "snippet"
            self._in_link = False

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self._in_link:
            if self._mode == "title":
                title = " ".join("".join(self._title_parts).split())
                url = _clean_ddg_url(self._href)
                if title and url:
                    self.results.append(SearchResult(title=title, url=url, provider="duckduckgo"))
            elif self._mode == "snippet":
                snippet = " ".join("".join(self._snippet_parts).split())
                if self.results and snippet:
                    self.results[-1].snippet = snippet
            self._mode = None
            self._in_link = False
        elif tag in {"td", "div"} and self._mode == "snippet":
            snippet = " ".join("".join(self._snippet_parts).split())
            if self.results and snippet:
                self.results[-1].snippet = snippet
            self._mode = None

    def handle_data(self, data: str) -> None:
        if self._mode == "title":
            self._title_parts.append(data)
        elif self._mode == "snippet":
            self._snippet_parts.append(data)


def _clean_ddg_url(href: str) -> str:
    href = html.unescape(href or "").strip()
    if href.startswith("//"):
        href = "https:" + href
    parsed = urlparse(href)
    if "duckduckgo.com" in (parsed.netloc or ""):
        query = parse_qs(parsed.query)
        if "uddg" in query:
            return unquote(query["uddg"][0])
    return href


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title_parts: list[str] = []
        self.body_parts: list[str] = []
        self._skip = 0
        self._in_title = False

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag in SKIP_TAGS:
            self._skip += 1
        if tag == "title":
            self._in_title = True
        if tag in {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "tr", "article", "section"}:
            self.body_parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in SKIP_TAGS and self._skip:
            self._skip -= 1
        if tag == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title_parts.append(data)
            return
        if self._skip:
            return
        self.body_parts.append(data)


def _normalize_text(parts: list[str], limit: int) -> str:
    text = " ".join(parts)
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    lines = []
    for line in text.split("\n"):
        line = line.strip()
        if len(line) < 2:
            continue
        if lines and line == lines[-1]:
            continue
        lines.append(line)
    return "\n".join(lines)[:limit]


def _is_private_host(host: str) -> bool:
    if not host:
        return True
    lowered = host.lower()
    if lowered in {"localhost", "localhost.localdomain"} or lowered.endswith((".local", ".internal")):
        return True
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return True
    for info in infos:
        address = info[4][0]
        try:
            ip = ipaddress.ip_address(address)
        except ValueError:
            continue
        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_reserved
            or ip.is_multicast
            or ip.is_unspecified
        ):
            return True
    return False


def validate_public_url(url: str, allow_private: bool = False) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only http(s) URLs are allowed")
    if parsed.username or parsed.password:
        raise ValueError("URLs with credentials are not allowed")
    host = parsed.hostname or ""
    if not allow_private and _is_private_host(host):
        raise ValueError("that URL points at a private or local address")
    return url


async def fetch_page(
    url: str,
    *,
    timeout: float = 12.0,
    max_chars: int = 6000,
    allow_private: bool = False,
) -> dict:
    validate_public_url(url, allow_private=allow_private)
    headers = {"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.1"}
    async with httpx.AsyncClient(
        follow_redirects=True,
        timeout=httpx.Timeout(timeout, connect=8.0),
        headers=headers,
    ) as client, client.stream("GET", url) as response:
        if response.status_code >= 400:
            raise ValueError(f"HTTP {response.status_code} while reading {url}")
        final_url = str(response.url)
        validate_public_url(final_url, allow_private=allow_private)
        content_type = response.headers.get("content-type", "").lower()
        if not any(item in content_type for item in ("text/html", "text/plain", "application/xhtml")):
            raise ValueError(f"unsupported content type: {content_type or 'unknown'}")
        chunks: list[bytes] = []
        total = 0
        async for chunk in response.aiter_bytes(65536):
            total += len(chunk)
            if total > 2_500_000:
                break
            chunks.append(chunk)
        raw = b"".join(chunks)
        encoding = response.encoding or "utf-8"
    text = raw.decode(encoding, errors="replace")
    if "html" in content_type:
        parser = _TextExtractor()
        parser.feed(text)
        title = " ".join(parser.title_parts).strip()
        body = _normalize_text(parser.body_parts, max_chars)
    else:
        title = url
        body = _normalize_text([text], max_chars)
    return {"url": final_url, "title": title or final_url, "text": body, "content_type": content_type}


async def _searxng(query: str, config: SearchConfig) -> list[SearchResult]:
    url = config.searxng_url.rstrip("/") + "/search"
    params = {
        "q": query,
        "format": "json",
        "safesearch": 1 if config.safe_search else 0,
    }
    async with httpx.AsyncClient(
        timeout=httpx.Timeout(config.timeout_s, connect=6.0),
        headers={"User-Agent": USER_AGENT},
    ) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        data = response.json()
    results = []
    for item in (data.get("results") or [])[: config.max_results]:
        result_url = item.get("url") or ""
        if not result_url:
            continue
        results.append(
            SearchResult(
                title=html.unescape(item.get("title") or result_url),
                url=result_url,
                snippet=html.unescape(item.get("content") or ""),
                provider="searxng",
            )
        )
    return results


async def _duckduckgo(query: str, config: SearchConfig) -> list[SearchResult]:
    headers = {"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.8"}
    async with httpx.AsyncClient(
        follow_redirects=True,
        timeout=httpx.Timeout(config.timeout_s, connect=6.0),
        headers=headers,
    ) as client:
        response = await client.post("https://html.duckduckgo.com/html/", data={"q": query})
        response.raise_for_status()
        parser = _DuckParser()
        parser.feed(response.text)
        results = parser.results
        if not results:
            response = await client.get("https://lite.duckduckgo.com/lite/", params={"q": query})
            response.raise_for_status()
            parser = _DuckParser()
            parser.feed(response.text)
            results = parser.results
    cleaned: list[SearchResult] = []
    for result in results:
        if not result.url.startswith(("http://", "https://")):
            continue
        if "duckduckgo.com" in result.url:
            continue
        cleaned.append(result)
        if len(cleaned) >= config.max_results:
            break
    return cleaned


async def search_web(
    query: str,
    config: SearchConfig,
    *,
    max_results: int | None = None,
    fetch_pages: bool | None = None,
    allow_private: bool = False,
) -> dict:
    query = (query or "").strip()
    if not query:
        raise ValueError("search query is empty")
    wanted = max(1, min(max_results or config.max_results, 12))
    provider = config.provider
    results: list[SearchResult] = []
    used = ""
    errors: list[str] = []
    if provider in {"auto", "searxng"} and config.searxng_url:
        try:
            results = await _searxng(query, config)
            used = "searxng"
        except (httpx.HTTPError, ValueError, OSError) as exc:
            errors.append(f"searxng: {exc}")
            if provider == "searxng":
                raise RuntimeError(f"SearXNG search failed: {exc}") from exc
    if not results and provider in {"auto", "duckduckgo"}:
        try:
            results = await _duckduckgo(query, config)
            used = "duckduckgo"
        except (httpx.HTTPError, ValueError, OSError) as exc:
            errors.append(f"duckduckgo: {exc}")
            raise RuntimeError("Web search failed. Configure a SearXNG instance or try again.") from exc
    results = results[:wanted]
    if not results:
        return {"query": query, "provider": used or provider, "results": [], "errors": errors}
    should_fetch = config.fetch_pages if fetch_pages is None else fetch_pages
    if should_fetch and config.fetch_count:
        async def enrich(result: SearchResult) -> None:
            try:
                page = await fetch_page(
                    result.url,
                    timeout=min(config.timeout_s, 10.0),
                    max_chars=2600,
                    allow_private=allow_private,
                )
                result.excerpt = page["text"][:2600]
            except (ValueError, httpx.HTTPError, OSError):
                result.excerpt = ""

        await asyncio.gather(*(enrich(item) for item in results[: config.fetch_count]))
    return {
        "query": query,
        "provider": used,
        "results": [result.to_dict() for result in results],
        "errors": errors,
    }


def format_search_for_model(payload: dict) -> str:
    results = payload.get("results") or []
    if not results:
        return f"No web results for {payload.get('query', '')!r}."
    lines = [f"Web search results for {payload.get('query', '')!r} (provider: {payload.get('provider')}):"]
    for index, item in enumerate(results, start=1):
        lines.append(f"[{index}] {item.get('title', '')} — {item.get('url', '')}")
        snippet = (item.get("snippet") or "").strip()
        if snippet:
            lines.append(f"    {snippet}")
        excerpt = (item.get("excerpt") or "").strip()
        if excerpt:
            lines.append(f"    Page excerpt: {excerpt[:1200]}")
    lines.append("Cite these results as [1], [2], … when you use them.")
    return "\n".join(lines)


def sources_for_ui(payload: dict) -> list[dict]:
    return [
        {
            "title": item.get("title", ""),
            "url": item.get("url", ""),
            "snippet": item.get("snippet", ""),
            "provider": item.get("provider", ""),
        }
        for item in payload.get("results") or []
    ]
