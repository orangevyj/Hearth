"""FastAPI application: launcher API, chat persistence and SSE streaming."""

from __future__ import annotations

import asyncio
import base64
import json
import secrets
import time
import uuid
from contextlib import asynccontextmanager, suppress
from pathlib import Path
from typing import Annotated, Any, Literal

import httpx
from fastapi import Body, FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ValidationError

from . import __version__, catalog, clients, crypto, hf, panel, paths, remote
from .accounts import AccountStore
from .attachments import OutputStore, mime_for_path
from .chat_engine import ChatEngine, build_user_message
from .chats import ChatStore
from .comfy import ComfyClient
from .config import AppConfig, ConfigStore
from .downloader import SourcePicker
from .hardware import detect_hardware
from .jobs import JobManager
from .library import CustomModelStore, CustomPresetStore
from .memory import MemoryStore
from .presets import find_preset, presets_payload
from .runtimes import RuntimeManager
from .tools import ToolContext, execute_tool


def _norm_tag(name: str) -> str:
    return name[:-7] if name.endswith(":latest") else name


def _sse(event: dict) -> str:
    return f"event: {event.get('type', 'message')}\ndata: {json.dumps(event, ensure_ascii=False)}\n\n"


def _safe_filename(value: str) -> str:
    cleaned = "".join(ch for ch in (value or "chat") if ch.isalnum() or ch in " -_").strip()
    return (cleaned or "chat")[:80]


class PresetApplyIn(BaseModel):
    modalities: dict[str, bool] | None = None
    download: bool = True


class ChatCreateIn(BaseModel):
    title: str | None = None
    model: str | None = None


class ChatRenameIn(BaseModel):
    title: str


class MessageIn(BaseModel):
    content: str = ""
    attachment_ids: list[str] = Field(default_factory=list)
    web: bool = False
    tools: bool = True
    reasoning: bool | None = None


class EncodedUploadIn(BaseModel):
    filename: str = "upload.bin"
    mime: str = ""
    data: str = ""


class MediaReadIn(BaseModel):
    path: str = ""


class RegenerateIn(BaseModel):
    web: bool = False
    tools: bool = True
    reasoning: bool | None = None


class GenerateIn(BaseModel):
    modality: Literal["image", "video", "music", "speech", "3d"]
    prompt: str = ""
    chat_id: str | None = None
    attachment_id: str | None = None
    lyrics: str | None = None
    duration: int | None = None
    width: int | None = None
    height: int | None = None
    seconds: float | None = None
    fps: int | None = None


class TTSIn(BaseModel):
    text: str
    voice: str | None = None


class TranscribeIn(BaseModel):
    attachment_id: str


class AppState:
    def __init__(self):
        paths.ensure_dirs()
        self.config_store = ConfigStore()
        self.config_store.load()
        self.jobs = JobManager()
        self.sources = SourcePicker()
        self.hardware = detect_hardware()
        self.runtimes = RuntimeManager(
            self.config_store,
            self.jobs,
            hardware_provider=lambda: self.hardware,
            sources=self.sources,
        )
        self.accounts = AccountStore()
        self.panel = panel.PanelAccess(self.config_store)
        self.custom_models = CustomModelStore()
        self.custom_presets = CustomPresetStore()
        catalog.register_custom_models(self.custom_models.specs())
        self.outputs = OutputStore()
        self.chats = ChatStore()
        self.comfy = ComfyClient(self.config_store, self.runtimes, self.outputs)
        self.memories = MemoryStore()
        self.engine = ChatEngine(
            self.config_store,
            self.runtimes,
            self.comfy,
            self.jobs,
            self.outputs,
            hardware_summary=self.hardware.summary,
            memories=self.memories,
        )
        self.running = False
        self.csrf = secrets.token_urlsafe(32)
        self.started_at = time.time()
        self.background_tasks: set[asyncio.Task] = set()
        self.stop_events: dict[str, asyncio.Event] = {}
        self.last_error = ""
        self._status_cache: dict | None = None
        self._status_at = 0.0
        self._status_lock = asyncio.Lock()

    # ------------------------------------------------------------------
    @property
    def config(self) -> AppConfig:
        return self.config_store.config

    def invalidate(self) -> None:
        self._status_cache = None
        self._status_at = 0.0

    def refresh_hardware(self) -> None:
        self.hardware = detect_hardware()
        self.engine.hardware_summary = self.hardware.summary
        self.invalidate()

    def presets_payload(self) -> dict:
        return presets_payload(self.hardware, self.custom_presets.items)

    def reload_custom_models(self) -> None:
        catalog.register_custom_models(self.custom_models.specs())
        self.invalidate()

    def base_url(self) -> str:
        host = self.config.server.host
        if host in {"0.0.0.0", "::", ""}:
            host = "127.0.0.1"
        return f"http://{host}:{self.config.server.port}"

    def chat_url(self) -> str:
        return self.base_url() + "/chat"

    def background(self, coro) -> asyncio.Task:
        async def runner():
            try:
                await coro
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # job state already carries the useful error
                self.last_error = f"{type(exc).__name__}: {exc}"

        task = asyncio.create_task(runner())
        self.background_tasks.add(task)
        task.add_done_callback(self.background_tasks.discard)
        return task

    def _installed(self, runtime_status: dict) -> dict:
        names = {
            _norm_tag(str(item.get("name") or ""))
            for item in (runtime_status.get("ollama", {}) or {}).get("models", [])
        }
        models = {}
        for spec in catalog.TEXT_MODELS:
            models[spec.id] = _norm_tag(spec.ollama_tag) in names
        for spec in (
            *catalog.models_for("image"),
            *catalog.models_for("video"),
            *catalog.models_for("three_d"),
            *catalog.models_for("music"),
        ):
            with suppress(Exception):
                models[spec.id] = self.runtimes.comfy_model_installed(spec)
        # What is left to fetch, so the launcher can show "9.3 GB to go"
        # instead of the model's full size.
        missing: dict[str, dict] = {}
        for spec in catalog.TEXT_MODELS:
            if not models.get(spec.id):
                missing[spec.id] = {
                    "gb": spec.total_size_gb,
                    "files": [spec.ollama_tag or spec.id],
                }
        for spec in (
            *catalog.models_for("image"),
            *catalog.models_for("video"),
            *catalog.models_for("three_d"),
            *catalog.models_for("music"),
        ):
            if models.get(spec.id):
                continue
            with suppress(Exception):
                left = self.runtimes.comfy_missing_files(spec)
                if left:
                    missing[spec.id] = {
                        "gb": round(sum(item.size_gb for item in left), 2),
                        "files": [item.filename.rsplit("/", 1)[-1] for item in left],
                    }
        voices = {voice.id: self.runtimes.piper_installed(voice.id) for voice in catalog.TTS_VOICES}
        stt = {spec.id: self.runtimes.whisper_installed(spec.id) for spec in catalog.STT_MODELS}
        return {
            "models": models,
            "missing": missing,
            "voices": voices,
            "stt": stt,
            "runtimes": {
                "ollama": self.runtimes.ollama_installed(),
                "comfyui": self.runtimes.comfy_installed(),
                "piper": bool(self.runtimes.piper_binary()),
                "whisper": self.runtimes.audio_python.exists(),
            },
        }

    async def get_state(self, force: bool = False) -> dict:
        now = time.monotonic()
        if not force and self._status_cache is not None and now - self._status_at < 1.5:
            return self._status_cache
        async with self._status_lock:
            now = time.monotonic()
            if not force and self._status_cache is not None and now - self._status_at < 1.5:
                return self._status_cache
            try:
                runtime_status = await self.runtimes.status()
            except Exception as exc:
                self.last_error = f"{type(exc).__name__}: {exc}"
                runtime_status = {
                    "ollama": {"installed": self.runtimes.ollama_installed(), "running": False, "models": []},
                    "comfyui": {"installed": self.runtimes.comfy_installed(), "running": False},
                    "audio": {},
                    "lmstudio": {"running": False, "models": []},
                    "sources": self.sources.sources_payload(),
                }
            payload = {
                "app": {
                    "name": "Hearth",
                    "version": __version__,
                    "running": self.running,
                    "url": self.base_url(),
                    "chat_url": self.chat_url(),
                    "data_dir": str(paths.DATA_DIR),
                    "config_dir": str(paths.CONFIG_DIR),
                    "started_at": self.started_at,
                    "last_error": self.last_error,
                },
                "config": self.config.model_dump(),
                "hardware": self.hardware.to_dict(),
                "presets": self.presets_payload(),
                "runtimes": runtime_status,
                "jobs": self.jobs.list(),
                "catalog": catalog.catalog_payload(),
                "installed": self._installed(runtime_status),
                "memories": {**self.memories.count(), "enabled": self.config.memory.enabled},
                "chat_count": self.chats.count_chats(),
                "sources": runtime_status.get("sources", self.sources.sources_payload()),
            }
            self._status_cache = payload
            self._status_at = now
            return payload

    async def ensure_text_ready(self) -> list[str]:
        config = self.config
        warnings: list[str] = []
        if config.text.backend == "demo":
            return ["Demo mode: replies are not generated by a model."]
        if config.text.backend == "ollama":
            if not self.runtimes.ollama_installed():
                raise HTTPException(
                    status_code=409,
                    detail="Ollama is not installed yet. Install the preset or connect LM Studio.",
                )
            await self.runtimes.start_ollama()
            models = await self.runtimes.ollama_models()
            names = {_norm_tag(str(item.get("name") or "")) for item in models}
            if _norm_tag(config.text.model) not in names:
                raise HTTPException(
                    status_code=409,
                    detail=(
                        f"Text model {config.text.model!r} is not installed in Ollama. "
                        "Install it from the launcher, or switch the text backend to Demo / LM Studio."
                    ),
                )
            if config.load.mode in {"keep_all", "text_resident"}:
                ok = await self.runtimes.preload_ollama(config.text.model)
                if not ok:
                    warnings.append("The text model is installed but could not be preloaded.")
            return warnings
        base = (config.text.base_url or "").rstrip("/")
        url = base + "/models" if base.endswith("/v1") else base + "/v1/models"
        try:
            headers = {"Authorization": f"Bearer {config.text.api_key}"} if config.text.api_key else {}
            async with httpx.AsyncClient(timeout=5.0, headers=headers) as client:
                response = await client.get(url)
                response.raise_for_status()
                data = response.json()
            ids = [str(item.get("id")) for item in data.get("data", [])]
            if ids and config.text.model not in ids:
                warnings.append(
                    f"The backend is reachable, but it does not list {config.text.model!r}. "
                    "The request may still work if the model id is an alias."
                )
        except (httpx.HTTPError, ValueError, OSError) as exc:
            raise HTTPException(
                status_code=409,
                detail=f"Could not reach the OpenAI-compatible backend at {base}: {exc}",
            ) from exc
        return warnings

    async def start_server(self) -> dict:
        if self.running:
            return {"running": True, "url": self.base_url(), "chat_url": self.chat_url(), "warnings": []}
        warnings = await self.ensure_text_ready()
        config = self.config
        media_enabled = any(
            [config.image.enabled, config.video.enabled, config.three_d.enabled, config.music.enabled]
        )
        if media_enabled and config.runtimes.comfyui_auto_start:
            if self.runtimes.comfy_installed():
                try:
                    await self.runtimes.start_comfyui()
                except Exception as exc:
                    warnings.append(f"ComfyUI did not start: {exc}")
            else:
                warnings.append("ComfyUI is not installed; text works, but image/video/3D/music will ask you to install it.")
        if config.load.mode == "keep_all" and media_enabled:
            warnings.append("Keep-all keeps the text model resident; ComfyUI loads media on first use and caches them.")
        self.running = True
        self.invalidate()
        return {
            "running": True,
            "url": self.base_url(),
            "chat_url": self.chat_url(),
            "warnings": warnings,
        }

    async def stop_server(self) -> dict:
        self.running = False
        for event in list(self.stop_events.values()):
            event.set()
        await self.runtimes.stop_all(unload=True)
        self.invalidate()
        return {"running": False}


# ----------------------------------------------------------------------
# App factory
# ----------------------------------------------------------------------
def create_app(state: AppState | None = None) -> FastAPI:
    state = state or AppState()

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        # A machine that serves other devices should come back up ready after a
        # restart; otherwise every client gets "the server is stopped" until
        # someone opens the launcher.
        if state.config.server.auto_start_services and state.config.setup_complete:
            async def start_after_boot() -> None:
                await asyncio.sleep(1.5)
                with suppress(Exception):
                    await state.start_server()

            state.background(start_after_boot())
        yield
        state.stop_events.clear()
        for task in list(state.background_tasks):
            task.cancel()
        if state.background_tasks:
            await asyncio.gather(*state.background_tasks, return_exceptions=True)
        await state.runtimes.shutdown()
        state.chats.close()

    app = FastAPI(title="Hearth", version=__version__, lifespan=lifespan, docs_url=None, redoc_url=None)
    app.state.hearth = state

    @app.middleware("http")
    async def guard(request: Request, call_next):
        path = request.url.path
        client_host = request.client.host if request.client else "127.0.0.1"
        local = client_host in {"127.0.0.1", "::1", "localhost", "testclient"}
        # Off-machine traffic may only use the encrypted channel, the public
        # salt, or a plaintext session for an account that deliberately has no
        # secret. Everything else is local admin.
        if not local and path.startswith("/api/"):
            user_header = request.headers.get("x-hearth-user", "")
            panel_open = {
                "/api/admin/login",
                "/api/admin/logout",
                "/api/admin/status",
                "/api/clients",
                "/api/secure/rpc",
                "/api/remote/salt",
            }
            if path in panel_open or (path == "/api/remote/capabilities" and user_header):
                pass
            elif state.panel.check(request.cookies.get("hearth_panel")):
                # A logged-in panel session has the same reach as the machine.
                request.state.hearth_panel = True
            elif user_header:
                user = state.accounts.get(user_header)
                if not user or not user["enabled"] or user["secret"]:
                    return JSONResponse({"detail": "Unknown account for that user header."}, status_code=403)
                request.state.hearth_remote = user["name"]
            else:
                return JSONResponse(
                    {"detail": "Remote clients must connect through the encrypted channel."},
                    status_code=401,
                )
        # The encrypted channel authenticates with the account secret instead of
        # the browser session token, and remote clients never see the token.
        csrf_exempt = path in {"/api/secure/rpc", "/api/admin/login", "/api/admin/logout"}
        if (
            not csrf_exempt
            and request.method in {"POST", "PUT", "PATCH", "DELETE"}
            and path.startswith("/api/")
            and request.headers.get("x-hearth-token") != state.csrf
            and not request.headers.get("x-hearth-user")
        ):
            return JSONResponse({"detail": "Invalid or missing Hearth session token."}, status_code=403)
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("X-Hearth-Version", __version__)
        if not local and path.startswith("/api/"):
            # Remote clients are rare and worth a trace when something fails.
            with suppress(OSError):
                log_path = paths.LOGS_DIR / "remote.log"
                log_path.parent.mkdir(parents=True, exist_ok=True)
                line = (
                    f"{time.strftime('%Y-%m-%d %H:%M:%S')} {client_host} {request.method} {path} "
                    f"-> {response.status_code} user={request.headers.get('x-hearth-user', '-')}\n"
                )
                with log_path.open("a", encoding="utf-8") as handle:
                    handle.write(line)
        if request.url.path.startswith("/api/"):
            response.headers.setdefault("Cache-Control", "no-store")
        elif request.url.path.startswith(("/static/", "/assets/")):
            # A local app is updated in place; a cached module would keep an old
            # UI alive until the browser felt like revalidating.
            response.headers["Cache-Control"] = "no-store, must-revalidate"
        return response

    if (paths.WEB_DIR / "static").exists():
        app.mount("/static", StaticFiles(directory=paths.WEB_DIR / "static"), name="static")
    if (paths.WEB_DIR / "assets").exists():
        app.mount("/assets", StaticFiles(directory=paths.WEB_DIR / "assets"), name="assets")

    def remote_owner(request: Request) -> str | None:
        """The account a request acts for, or None for this machine."""
        name = request.headers.get("x-hearth-remote", "") or getattr(request.state, "hearth_remote", "")
        return str(name) or None

    def require_chat(request: Request, chat_id: str) -> dict:
        # A remote account only ever sees its own chats; anything else is a 404
        # rather than a 403 so chat ids are not enumerable.
        chat = state.chats.get_chat(chat_id, owner=remote_owner(request))
        if not chat:
            raise HTTPException(status_code=404, detail="Chat not found")
        return chat

    def require_running() -> None:
        if not state.running:
            raise HTTPException(status_code=409, detail="The server is stopped. Start it from the launcher first.")

    def current_history(chat: dict) -> list[dict]:
        history: list[dict] = []
        for message in chat.get("messages", []):
            if message["role"] == "user":
                history.append(build_user_message(message["content"], message.get("attachments") or []))
            elif message["role"] == "assistant" and message.get("content"):
                history.append({"role": "assistant", "content": message["content"]})
        return history

    def last_user_attachments(chat: dict) -> list[dict]:
        """Files on the newest user message, so tools can act on them."""
        for message in reversed(chat.get("messages", [])):
            if message["role"] == "user":
                return list(message.get("attachments") or [])
        return []

    def last_image(chat: dict) -> Path | None:
        for message in reversed(chat.get("messages", [])):
            if message["role"] != "user":
                continue
            for attachment in reversed(message.get("attachments") or []):
                if attachment.get("kind") == "image":
                    return Path(attachment["path"])
            return None
        return None

    def persist_assistant(
        assistant_id: str,
        *,
        content: str,
        thinking: str,
        tools: list[dict],
        sources: list[dict],
        usage: dict,
        stopped: bool,
        error: str,
    ) -> None:
        attachment_ids: list[str] = []
        for tool in tools:
            for attachment in tool.get("attachments") or []:
                try:
                    state.chats.store_attachment(attachment)
                    if attachment.get("id"):
                        attachment_ids.append(str(attachment["id"]))
                except Exception:
                    pass
        attachment_ids = list(dict.fromkeys(attachment_ids))
        if attachment_ids:
            with suppress(Exception):
                state.chats.link_attachments(assistant_id, attachment_ids)
        deduped_sources = []
        seen = set()
        for source in sources:
            url = source.get("url") or ""
            if url and url not in seen:
                seen.add(url)
                deduped_sources.append(source)
        final_content = content
        if not final_content and error:
            final_content = f"**Error:** {error}"
        elif not final_content and stopped:
            final_content = "_Stopped._"
        meta = {
            "model": state.config.text.model,
            "usage": usage,
            "thinking": thinking[-20000:],
            "tools": [
                {
                    "name": tool.get("name", ""),
                    "content": (tool.get("content") or "")[:4000],
                    "attachments": [
                        {"id": item.get("id"), "filename": item.get("filename"), "kind": item.get("kind"), "url": item.get("url")}
                        for item in (tool.get("attachments") or [])
                    ],
                    "sources": tool.get("sources") or [],
                    "error": tool.get("error") or "",
                }
                for tool in tools
            ],
            "sources": deduped_sources,
            "stopped": stopped,
            "error": error,
        }
        state.chats.update_message(assistant_id, content=final_content, meta=meta)

    async def stream_events(
        chat_id: str,
        assistant_id: str,
        history: list[dict],
        *,
        web: bool,
        tools_enabled: bool,
        image_path: Path | None,
        stop_event: asyncio.Event,
        reasoning: bool | None = None,
        attachments: list[dict] | None = None,
    ):
        content = ""
        thinking = ""
        tools: list[dict] = []
        sources: list[dict] = []
        usage: dict = {}
        stopped = False
        error = ""
        finalized = False

        def finalize() -> None:
            nonlocal finalized
            if finalized:
                return
            finalized = True
            with suppress(Exception):
                persist_assistant(
                    assistant_id,
                    content=content,
                    thinking=thinking,
                    tools=tools,
                    sources=sources,
                    usage=usage,
                    stopped=stopped,
                    error=error,
                )
            state.invalidate()

        try:
            async for event in state.engine.stream(
                history,
                web=web,
                tools_enabled=tools_enabled,
                reasoning=reasoning,
                last_image_path=image_path,
                attachments=attachments or [],
                should_stop=stop_event.is_set,
            ):
                kind = event.get("type")
                if kind == "delta":
                    content += event.get("text", "")
                elif kind == "replace":
                    content = event.get("text", "")
                elif kind == "thinking":
                    thinking += event.get("text", "")
                elif kind == "tool_result":
                    tools.append(
                        {
                            "name": event.get("name", ""),
                            "content": event.get("content", ""),
                            "attachments": event.get("attachments") or [],
                            "sources": event.get("sources") or [],
                            "error": event.get("error", ""),
                        }
                    )
                    sources.extend(event.get("sources") or [])
                elif kind == "usage":
                    usage = event.get("usage") or usage
                elif kind == "done":
                    stopped = bool(event.get("stopped"))
                    usage = event.get("usage") or usage
                    finalize()
                    yield _sse(event)
                    yield _sse(
                        {
                            "type": "saved",
                            "message_id": assistant_id,
                            "usage": usage,
                            "stopped": stopped,
                        }
                    )
                    return
                elif kind == "error":
                    error = event.get("error", "Unknown error")
                    finalize()
                    yield _sse(event)
                    yield _sse({"type": "saved", "message_id": assistant_id, "usage": usage, "error": error})
                    return
                yield _sse(event)
            finalize()
            yield _sse({"type": "saved", "message_id": assistant_id, "usage": usage, "stopped": stopped})
        except asyncio.CancelledError:
            stopped = True
            finalize()
            raise
        except GeneratorExit:
            stopped = True
            finalize()
            return
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            finalize()
            yield _sse({"type": "error", "error": error})
            yield _sse({"type": "saved", "message_id": assistant_id, "usage": usage, "error": error})
        finally:
            state.stop_events.pop(chat_id, None)

    async def transcribe_message_audio(chat_id: str, user_message_id: str):
        message = state.chats.get_message(user_message_id)
        if not message:
            return
        content = message.get("content") or ""
        for attachment in message.get("attachments") or []:
            if attachment.get("kind") != "audio":
                continue
            path = Path(attachment.get("path") or "")
            if not path.exists():
                continue
            if not state.runtimes.audio_python.exists():
                text = "[Audio transcription is not installed; install speech support in the launcher.]"
                content = (content + "\n\n" + text).strip()
                state.chats.update_message(user_message_id, content=content)
                yield _sse({"type": "status", "text": "Speech-to-text is not installed."})
                continue
            yield _sse({"type": "status", "text": f"Transcribing {attachment.get('filename')}…"})
            job = state.jobs.create(
                "transcribe",
                "Transcribe audio",
                items=[{"id": "transcribe", "label": attachment.get("filename", "audio")}],
            )
            job.start()
            try:
                result = await state.runtimes.transcribe_audio(
                    path,
                    state.config.audio.stt_model,
                    state.config.audio.language,
                    job=job,
                )
                job.finish({"text": result.get("text", "")})
                transcript = result.get("text", "").strip()
                if transcript:
                    content = (content + f"\n\n[Transcript of {attachment.get('filename')}]: {transcript}").strip()
                    state.chats.update_message(user_message_id, content=content)
                yield _sse(
                    {
                        "type": "transcript",
                        "attachment_id": attachment.get("id"),
                        "text": transcript,
                        "language": result.get("language", ""),
                    }
                )
            except Exception as exc:
                job.fail(str(exc))
                content = (content + f"\n\n[Could not transcribe {attachment.get('filename')}: {exc}]").strip()
                state.chats.update_message(user_message_id, content=content)
                yield _sse({"type": "status", "text": f"Transcription failed: {exc}"})

    # ------------------------------------------------------------------
    # Static UI
    # ------------------------------------------------------------------
    def html(name: str):
        path = paths.WEB_DIR / name
        if not path.exists():
            raise HTTPException(status_code=503, detail="UI assets are missing. Reinstall or rebuild Hearth.")
        return FileResponse(path, headers={"Cache-Control": "no-store"})

    @app.get("/", include_in_schema=False)
    async def launcher_page(request: Request):
        host = request.client.host if request.client else "127.0.0.1"
        at_the_machine = host in {"127.0.0.1", "::1", "localhost", "testclient"}
        if at_the_machine or state.panel.check(request.cookies.get("hearth_panel")):
            return html("index.html")
        return html("welcome.html")

    @app.get("/chat", include_in_schema=False)
    async def chat_page():
        return html("chat.html")

    @app.get("/connect", include_in_schema=False)
    async def connect_page():
        return html("connect.html")

    @app.get("/downloads/{filename}", include_in_schema=False)
    async def download_client(filename: str, request: Request):
        try:
            path = clients.resolve(filename)
        except (FileNotFoundError, ValueError):
            raise HTTPException(status_code=404, detail="That client is not available on this server") from None
        relative = str(path.relative_to(clients.clients_dir().resolve()))
        public = clients.available()
        listed = any(item["filename"] == relative for item in public)
        if not listed:
            raise HTTPException(status_code=404, detail="That client is not available on this server")
        return FileResponse(
            path,
            media_type=clients.mime_for(path.name),
            filename=path.name,
            headers={"Cache-Control": "no-cache"},
        )

    @app.post("/api/admin/login")
    async def api_admin_login(payload: Annotated[dict, Body(...)], response: Response):
        if not state.panel.configured:
            raise HTTPException(
                status_code=409,
                detail="No panel code is set on the server. Set one in the launcher (Server → Panel access).",
            )
        token = state.panel.login(str(payload.get("code") or ""))
        if not token:
            raise HTTPException(status_code=401, detail="That code is not right")
        response.set_cookie(
            "hearth_panel",
            token,
            max_age=panel.SESSION_HOURS * 3600,
            httponly=True,
            samesite="lax",
            path="/",
        )
        return {"ok": True}

    @app.post("/api/admin/logout")
    async def api_admin_logout(request: Request, response: Response):
        state.panel.logout(request.cookies.get("hearth_panel"))
        response.delete_cookie("hearth_panel", path="/")
        return {"ok": True}

    @app.get("/api/admin/status")
    async def api_admin_status(request: Request):
        return {
            "configured": state.panel.configured,
            "authenticated": state.panel.check(request.cookies.get("hearth_panel")),
        }

    @app.post("/api/server/panel-code")
    async def api_set_panel_code(request: Request, payload: Annotated[dict, Body(...)]):
        code = str(payload.get("code") or "")
        try:
            if code:
                state.panel.set_code(code)
            else:
                state.panel.clear_code()
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        state.invalidate()
        return {"configured": state.panel.configured}

    @app.get("/api/version")
    async def api_version():
        return clients.version_payload(__version__)

    @app.get("/api/clients")
    async def api_clients(request: Request):
        return clients.payload(request.headers.get("user-agent", ""))

    @app.get("/manifest.webmanifest", include_in_schema=False)
    async def manifest():
        path = paths.WEB_DIR / "manifest.webmanifest"
        if path.exists():
            return FileResponse(path, media_type="application/manifest+json")
        return Response(status_code=204)

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon():
        logo = paths.WEB_DIR / "assets" / "logo.svg"
        if logo.exists():
            return FileResponse(logo, media_type="image/svg+xml")
        return Response(status_code=204)

    @app.get("/health")
    async def health():
        return {"ok": True, "version": __version__, "running": state.running}

    # ------------------------------------------------------------------
    # State / config / hardware
    # ------------------------------------------------------------------
    @app.get("/api/state")
    async def api_state():
        payload = dict(await state.get_state())
        payload["csrf_token"] = state.csrf
        return JSONResponse(payload, headers={"Cache-Control": "no-store"})

    @app.post("/api/config")
    async def api_config(payload: Annotated[dict, Body(...)]):
        patch = payload.get("patch") if isinstance(payload.get("patch"), dict) else payload
        before = state.config.model_dump()
        try:
            config = state.config_store.update(patch)
        except (ValidationError, ValueError) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        state.invalidate()
        restart_required = (
            before.get("server", {}).get("port") != config.server.port
            or before.get("server", {}).get("host") != config.server.host
        )
        return {"config": config.model_dump(), "restart_required": restart_required}

    @app.post("/api/config/reset")
    async def api_config_reset():
        config = state.config_store.reset()
        state.invalidate()
        return {"config": config.model_dump()}

    @app.post("/api/hardware/refresh")
    async def api_hardware_refresh():
        state.refresh_hardware()
        return {"hardware": state.hardware.to_dict(), "presets": state.presets_payload()}

    # ------------------------------------------------------------------
    # Presets / models
    # ------------------------------------------------------------------
    @app.get("/api/presets")
    async def api_presets():
        return state.presets_payload()

    @app.post("/api/presets/saved")
    async def api_save_preset(payload: Annotated[dict, Body(...)]):
        try:
            item = state.custom_presets.validate(payload)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        state.custom_presets.save(item)
        state.invalidate()
        return {"preset": item, "presets": state.presets_payload()}

    @app.delete("/api/presets/saved/{preset_id}")
    async def api_delete_preset(preset_id: str):
        if not state.custom_presets.remove(preset_id):
            raise HTTPException(status_code=404, detail=f"Unknown saved preset: {preset_id}")
        state.invalidate()
        return {"deleted": preset_id, "presets": state.presets_payload()}

    @app.post("/api/presets/{tier}/apply")
    async def api_apply_preset(tier: str, body: PresetApplyIn | None = None):
        body = body or PresetApplyIn()
        preset = find_preset(state.hardware, tier, state.custom_presets.items)
        if not preset:
            raise HTTPException(status_code=404, detail=f"Unknown preset: {tier}")
        modalities = {
            "text": True,
            "image": True,
            "video": True,
            "three_d": True,
            "music": True,
            "audio": True,
        }
        if body.modalities:
            modalities.update({key: bool(value) for key, value in body.modalities.items() if key in modalities})
        state.config_store.update(preset.config_patch(modalities))
        state.invalidate()
        job = None
        if body.download:
            job = state.jobs.create("preset", f"Install {preset.name} preset", [])
            state.background(state.runtimes.install_preset(preset, modalities, job))
        return {
            "preset": preset.to_dict(),
            "modalities": modalities,
            "config": state.config.model_dump(),
            "job": job.to_dict() if job else None,
        }

    @app.post("/api/presets/custom")
    async def api_custom_preset():
        config = state.config_store.update({"preset": "custom", "setup_complete": True})
        state.invalidate()
        return {"config": config.model_dump()}

    @app.get("/api/catalog")
    async def api_catalog():
        return catalog.catalog_payload()

    @app.get("/api/models")
    async def api_models():
        payload = await state.get_state()
        return {"catalog": catalog.catalog_payload(), "installed": payload["installed"]}

    @app.post("/api/models/{model_id}/install")
    async def api_install_model(model_id: str):
        spec = catalog.get_model(model_id)
        if not spec:
            raise HTTPException(status_code=404, detail=f"Unknown model: {model_id}")
        remaining = spec.total_size_gb
        if spec.runtime == "comfyui":
            with suppress(Exception):
                left = state.runtimes.comfy_missing_files(spec)
                if left:
                    remaining = round(sum(item.size_gb for item in left), 2)
                elif spec.files:
                    remaining = 0.0
        title = f"Install {spec.name}" if remaining else f"Recheck {spec.name}"
        job = state.jobs.create(
            "model",
            title,
            items=[{"id": f"model:{spec.id}", "label": spec.name, "size_gb": remaining}],
        )
        state.background(state.runtimes.install_model(model_id, job))
        return {"job": job.to_dict()}

    @app.get("/api/hf/search")
    async def api_hf_search(q: str = "", limit: int = 12):
        try:
            results = await asyncio.to_thread(hf.search_models, q, limit, state.sources.hf_endpoint())
        except (httpx.HTTPError, ValueError) as exc:
            raise HTTPException(status_code=502, detail=f"Hugging Face search failed: {exc}") from exc
        return {"query": q, "results": results}

    @app.get("/api/hf/preview")
    async def api_hf_preview(repo: str = ""):
        try:
            return await asyncio.to_thread(hf.import_preview, repo, state.sources.hf_endpoint())
        except (httpx.HTTPError, ValueError) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post("/api/hf/import")
    async def api_hf_import(payload: Annotated[dict, Body(...)]):
        repo = str(payload.get("repo") or "").strip()
        download = bool(payload.get("download", True))
        try:
            preview = await asyncio.to_thread(hf.import_preview, repo, state.sources.hf_endpoint())
        except (httpx.HTTPError, ValueError) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        if not preview.get("importable") or not preview.get("plan"):
            raise HTTPException(
                status_code=422,
                detail=preview.get("reason") or "Hearth cannot drive that repository.",
            )
        try:
            item = state.custom_models.validate(preview["plan"])
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        state.custom_models.add(item)
        state.reload_custom_models()
        job = None
        if download:
            job = state.jobs.create(
                "model",
                f"Import {item['name']}",
                items=[{"id": f"model:{item['id']}", "label": item["name"], "size_gb": float(item.get("size_gb") or 0)}],
            )
            state.background(state.runtimes.install_model(item["id"], job))
        return {
            "model": item,
            "job": job.to_dict() if job else None,
            "catalog": catalog.catalog_payload(),
        }

    @app.post("/api/models/custom")
    async def api_import_model(payload: Annotated[dict, Body(...)]):
        try:
            item = state.custom_models.validate(
                payload, comfy_models_dir=state.runtimes.comfy_root / "models"
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        state.custom_models.add(item)
        state.reload_custom_models()
        return {"model": item, "catalog": catalog.catalog_payload()}

    @app.delete("/api/models/custom/{model_id}")
    async def api_delete_model(model_id: str):
        if not catalog.is_custom(model_id):
            raise HTTPException(status_code=404, detail=f"Not an imported model: {model_id}")
        state.custom_models.remove(model_id)
        state.reload_custom_models()
        return {"deleted": model_id, "catalog": catalog.catalog_payload()}

    @app.post("/api/models/{model_id}/unload")
    async def api_unload_model(model_id: str):
        spec = catalog.get_model(model_id)
        if not spec:
            raise HTTPException(status_code=404, detail=f"Unknown model: {model_id}")
        if spec.runtime == "ollama":
            await state.runtimes.unload_ollama(spec.ollama_tag)
        else:
            await state.runtimes.free_comfy()
        state.invalidate()
        return {"unloaded": True}

    @app.post("/api/voices/{voice_id}/install")
    async def api_install_voice(voice_id: str):
        if voice_id not in catalog.TTS_BY_ID:
            raise HTTPException(status_code=404, detail=f"Unknown voice: {voice_id}")
        job = state.jobs.create("voice", f"Install voice {voice_id}", [])
        state.background(state.runtimes.install_voice(voice_id, job))
        return {"job": job.to_dict()}

    @app.post("/api/stt/{model_id}/install")
    async def api_install_stt(model_id: str):
        if model_id not in catalog.STT_BY_ID:
            raise HTTPException(status_code=404, detail=f"Unknown speech model: {model_id}")
        job = state.jobs.create("stt", f"Install {model_id}", [])
        state.background(state.runtimes.install_stt(model_id, job))
        return {"job": job.to_dict()}

    # ------------------------------------------------------------------
    # Runtimes / server / jobs
    # ------------------------------------------------------------------
    @app.get("/api/runtimes")
    async def api_runtimes():
        return await state.runtimes.status()

    @app.post("/api/runtimes/{name}/install")
    async def api_install_runtime(name: str):
        if name not in {"ollama", "comfyui", "audio", "piper"}:
            raise HTTPException(status_code=404, detail=f"Unknown runtime: {name}")
        job = state.jobs.create("runtime", f"Install {name}", [])
        if name == "ollama":
            coro = state.runtimes.install_ollama(job)
        elif name == "comfyui":
            coro = state.runtimes.install_comfyui(job)
        elif name == "audio":
            coro = state.runtimes.install_audio(job)
        else:
            coro = state.runtimes.install_piper(job)
        state.background(coro)
        return {"job": job.to_dict()}

    @app.post("/api/runtimes/{name}/start")
    async def api_start_runtime(name: str):
        if name == "ollama":
            result = await state.runtimes.start_ollama()
        elif name == "comfyui":
            result = await state.runtimes.start_comfyui()
        else:
            raise HTTPException(status_code=400, detail="This runtime starts on demand and has no server.")
        state.invalidate()
        return result

    @app.post("/api/runtimes/{name}/stop")
    async def api_stop_runtime(name: str):
        if name == "ollama":
            await state.runtimes.stop_ollama()
        elif name == "comfyui":
            await state.runtimes.stop_comfyui()
        else:
            raise HTTPException(status_code=400, detail=f"{name} has no manageable server process.")
        state.invalidate()
        return {"stopped": True}

    @app.get("/api/runtimes/{name}/logs")
    async def api_runtime_logs(name: str, lines: int = Query(default=200, ge=10, le=2000)):
        if name not in {"ollama", "comfyui", "audio"}:
            raise HTTPException(status_code=404, detail=f"Unknown log: {name}")
        return {"name": name, "log": state.runtimes.log_tail(name, lines)}

    @app.post("/api/server/start")
    async def api_server_start():
        try:
            return await state.start_server()
        except HTTPException:
            raise
        except Exception as exc:
            state.running = False
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.post("/api/server/stop")
    async def api_server_stop():
        return await state.stop_server()

    @app.get("/api/server/status")
    async def api_server_status():
        return {
            "running": state.running,
            "url": state.base_url(),
            "chat_url": state.chat_url(),
            "runtimes": await state.runtimes.status(),
        }

    @app.get("/api/jobs")
    async def api_jobs(include_logs: bool = False):
        return {"jobs": state.jobs.list(include_logs=include_logs)}

    @app.get("/api/jobs/{job_id}")
    async def api_job(job_id: str):
        job = state.jobs.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        return job.to_dict(include_logs=True)

    @app.get("/api/jobs/{job_id}/logs")
    async def api_job_logs(job_id: str):
        job = state.jobs.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        return {"id": job_id, "logs": job.logs[-300:]}

    @app.post("/api/jobs/{job_id}/cancel")
    async def api_job_cancel(job_id: str):
        if not state.jobs.cancel(job_id):
            raise HTTPException(status_code=404, detail="Job not found")
        return {"canceled": True}

    @app.get("/api/sources")
    async def api_sources():
        return state.sources.sources_payload()

    # ------------------------------------------------------------------
    # Chats
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # Memories
    # ------------------------------------------------------------------
    @app.get("/api/memories")
    async def api_memories():
        return {
            "items": state.memories.items,
            "count": state.memories.count(),
            "enabled": state.config.memory.enabled,
        }

    @app.post("/api/memories")
    async def api_add_memory(payload: Annotated[dict, Body(...)]):
        try:
            item = state.memories.add(str(payload.get("text") or ""), source="user")
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        state.invalidate()
        return {"memory": item, "count": state.memories.count()}

    @app.patch("/api/memories/{memory_id}")
    async def api_update_memory(memory_id: str, payload: Annotated[dict, Body(...)]):
        try:
            item = state.memories.update(
                memory_id,
                text=payload.get("text"),
                enabled=payload.get("enabled"),
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        if not item:
            raise HTTPException(status_code=404, detail=f"Unknown memory: {memory_id}")
        state.invalidate()
        return {"memory": item, "count": state.memories.count()}

    @app.delete("/api/memories/{memory_id}")
    async def api_delete_memory(memory_id: str):
        if not state.memories.remove(memory_id):
            raise HTTPException(status_code=404, detail=f"Unknown memory: {memory_id}")
        state.invalidate()
        return {"deleted": memory_id, "count": state.memories.count()}

    @app.post("/api/memories/clear")
    async def api_clear_memories(payload: Annotated[dict, Body(...)] | None = None):
        only_enabled = bool((payload or {}).get("only_enabled", False))
        removed = state.memories.clear(only_enabled=only_enabled)
        state.invalidate()
        return {"removed": removed, "count": state.memories.count()}

    # ------------------------------------------------------------------
    # Remote access: accounts, capabilities, encrypted channel
    # ------------------------------------------------------------------
    def _remote_user(request: Request) -> dict:
        """The account behind an inner request, or None for local traffic."""
        name = request.headers.get("x-hearth-remote", "")
        if not name:
            return None
        user = state.accounts.get(name)
        if not user or not user["enabled"]:
            raise HTTPException(status_code=403, detail="That account is not available")
        return user

    @app.get("/api/server/users")
    async def api_users():
        return {
            "users": state.accounts.users(reveal=True),
            "salt": state.accounts.salt,
            "insecure": state.accounts.insecure_users(),
            "allow_remote": state.config.server.allow_remote,
            "port": state.config.server.port,
        }

    @app.post("/api/server/users")
    async def api_add_user(payload: Annotated[dict, Body(...)]):
        secret = payload.get("secret")
        if secret is None:
            # Safe default: every new account gets a secret. An explicit "" is
            # how the launcher creates the deliberately open account.
            secret = secrets.token_urlsafe(24)
        try:
            user = state.accounts.add(
                str(payload.get("name") or ""),
                secret=str(secret),
                permissions=payload.get("permissions"),
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        state.invalidate()
        return {"user": {k: v for k, v in user.items() if k != "secret"} | {"secret": user["secret"], "has_secret": bool(user["secret"])}}

    @app.patch("/api/server/users/{user_id}")
    async def api_update_user(user_id: str, payload: Annotated[dict, Body(...)]):
        try:
            user = state.accounts.update(
                user_id,
                name=payload.get("name"),
                secret=payload.get("secret"),
                enabled=payload.get("enabled"),
                permissions=payload.get("permissions"),
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        if not user:
            raise HTTPException(status_code=404, detail=f"Unknown user: {user_id}")
        state.invalidate()
        return {"user": {k: v for k, v in user.items() if k != "secret"} | {"secret": user["secret"], "has_secret": bool(user["secret"])}}

    @app.post("/api/server/users/{user_id}/rotate")
    async def api_rotate_secret(user_id: str):
        user = state.accounts.rotate_secret(user_id)
        if not user:
            raise HTTPException(status_code=404, detail=f"Unknown user: {user_id}")
        state.invalidate()
        return {"user": {k: v for k, v in user.items() if k != "secret"} | {"secret": user["secret"], "has_secret": True}}

    @app.delete("/api/server/users/{user_id}")
    async def api_delete_user(user_id: str):
        if not state.accounts.remove(user_id):
            raise HTTPException(status_code=404, detail=f"Unknown user: {user_id}")
        state.invalidate()
        return {"deleted": user_id}

    @app.get("/api/remote/salt")
    async def api_remote_salt():
        return {"salt": state.accounts.salt, "kind": "hearth.salt/1"}

    @app.get("/api/remote/capabilities")
    async def api_capabilities(request: Request):
        user = _remote_user(request)
        if user is None:
            raise HTTPException(status_code=400, detail="This endpoint is for remote clients")
        return remote.capabilities(state, user)

    @app.post("/api/secure/rpc")
    async def api_secure_rpc(request: Request):
        name = request.headers.get("x-hearth-user", "")
        user = state.accounts.get(name)
        if not user or not user["enabled"]:
            raise HTTPException(status_code=401, detail="Unknown or disabled user")
        if not user["secret"]:
            raise HTTPException(
                status_code=403,
                detail="This account has no secret, so it cannot use the encrypted channel. Add a secret on the server.",
            )
        key = state.accounts.key_for(name)
        if key is None:
            raise HTTPException(status_code=403, detail="Could not derive a key for that account")
        try:
            envelope = json.loads(await request.body() or b"{}")
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Malformed envelope") from exc
        # An app older than the build this server stores is asked to upgrade
        # before it talks to the models.
        platform_name, client_version = clients.parse_client_header(request.headers.get("x-hearth-client", ""))
        build = clients.manifest().get(platform_name)
        if build and clients.is_older(client_version, build["version"]):
            return JSONResponse(
                {
                    "detail": f"This app is version {client_version or 'unknown'}, but the server has {build['version']}.",
                    "client_version": client_version,
                    "required_version": build["version"],
                    "platform": platform_name,
                    "download_url": f"/downloads/{build['file']}" if build.get("file") else "",
                },
                status_code=426,
            )

        try:
            plaintext = crypto.open_sealed(key, str(envelope.get("d") or ""), aad=name.encode())
            inner = json.loads(plaintext)
        except (crypto.CryptoError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=401, detail=f"Could not open the request: {exc}") from exc

        method = str(inner.get("method") or "GET").upper()
        path = str(inner.get("path") or "/api/state")
        body = inner.get("body")
        try:
            remote.authorize(user, method, path, body)
        except remote.RemoteDenied as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        state.accounts.touch(name)

        aad = name.encode()
        if path.rstrip("/") == "/api/state" and method == "GET":
            # Never hand a remote client the local configuration.
            payload = {
                "kind": "hearth.remote-state/1",
                "app": {
                    "name": "Hearth",
                    "version": __version__,
                    "running": state.running,
                    "url": state.base_url(),
                    "chat_url": state.chat_url(),
                },
                "capabilities": remote.capabilities(state, user),
                "config": {
                    "text": {"model": state.config.text.model},
                    "ui": state.config.ui.model_dump(),
                },
                "chat_count": state.chats.count_chats(owner=user["name"]),
            }
            envelope_out = {
                "status": 200,
                "content_type": "application/json",
                "body": json.dumps(payload),
            }
            return Response(
                content=crypto.seal(key, json.dumps(envelope_out).encode("utf-8"), aad=aad),
                media_type="application/x-hearth-sealed",
            )

        transport = httpx.ASGITransport(app=request.app)
        headers = {"x-hearth-token": state.csrf, "x-hearth-remote": name}
        async with httpx.AsyncClient(transport=transport, base_url="http://hearth", timeout=None) as client:
            request_args = {"headers": headers}
            if body is not None and method not in {"GET", "HEAD"}:
                request_args["json"] = body
            inner_request = client.build_request(method, path, **request_args)
            inner_response = await client.send(inner_request, stream=True)
            content_type = inner_response.headers.get("content-type", "")
            if "text/event-stream" in content_type:
                async def relay():
                    try:
                        async for chunk in inner_response.aiter_raw():
                            if chunk:
                                yield crypto.pack_frame(key, chunk, aad=aad)
                    finally:
                        await inner_response.aclose()

                return StreamingResponse(relay(), media_type="application/x-hearth-frames")
            await inner_response.aread()
            await inner_response.aclose()
            envelope_out = {
                "status": inner_response.status_code,
                "content_type": content_type,
                "body": inner_response.text,
            }
            return Response(
                content=crypto.seal(key, json.dumps(envelope_out).encode("utf-8"), aad=aad),
                media_type="application/x-hearth-sealed",
            )

    @app.get("/api/chats")
    async def api_chats(request: Request, q: str = ""):
        owner = remote_owner(request)
        return {"chats": state.chats.list_chats(q, owner="" if owner is None else owner)}

    @app.post("/api/chats")
    async def api_create_chat(request: Request, body: ChatCreateIn | None = None):
        body = body or ChatCreateIn()
        chat = state.chats.create_chat(
            title=body.title or "New chat",
            model=body.model or state.config.text.model,
            owner=remote_owner(request) or "",
        )
        state.invalidate()
        return chat

    @app.get("/api/chats/{chat_id}")
    async def api_get_chat(request: Request, chat_id: str):
        return require_chat(request, chat_id)

    @app.patch("/api/chats/{chat_id}")
    async def api_rename_chat(request: Request, chat_id: str, body: ChatRenameIn):
        chat = state.chats.rename_chat(chat_id, body.title, owner=remote_owner(request))
        if not chat:
            raise HTTPException(status_code=404, detail="Chat not found")
        return chat

    @app.delete("/api/chats/{chat_id}")
    async def api_delete_chat(request: Request, chat_id: str):
        if not state.chats.delete_chat(chat_id, owner=remote_owner(request)):
            raise HTTPException(status_code=404, detail="Chat not found")
        state.invalidate()
        return {"deleted": True}

    @app.get("/api/chats/{chat_id}/export")
    async def api_export_chat(request: Request, chat_id: str, fmt: str = "markdown"):
        chat = require_chat(request, chat_id)
        if fmt == "json":
            return JSONResponse(
                chat,
                headers={"Content-Disposition": f'attachment; filename="{_safe_filename(chat["title"])}.json"'},
            )
        markdown = state.chats.export_markdown(chat_id)
        if markdown is None:
            raise HTTPException(status_code=404, detail="Chat not found")
        return Response(
            markdown,
            media_type="text/markdown; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{_safe_filename(chat["title"])}.md"'},
        )

    @app.post("/api/uploads")
    async def api_upload(file: Annotated[UploadFile, File(...)]):
        data = await file.read()
        if not data:
            raise HTTPException(status_code=400, detail="Uploaded file is empty")
        if len(data) > 100 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="Files larger than 100 MB are not supported")
        attachment = state.outputs.save_upload(file.filename or "upload.bin", data)
        state.chats.store_attachment(attachment)
        return attachment.to_dict()

    @app.post("/api/uploads/encoded")
    async def api_upload_encoded(body: EncodedUploadIn):
        """Upload from a remote client: the bytes arrive base64 inside the sealed channel."""
        try:
            data = base64.b64decode((body.data or "").encode("ascii"), validate=True)
        except (ValueError, UnicodeEncodeError) as exc:
            raise HTTPException(status_code=400, detail="The upload is not valid base64") from exc
        if not data:
            raise HTTPException(status_code=400, detail="Uploaded file is empty")
        if len(data) > 100 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="Files larger than 100 MB are not supported")
        attachment = state.outputs.save_upload(body.filename or "upload.bin", data)
        state.chats.store_attachment(attachment)
        return attachment.to_dict()

    @app.post("/api/media/read")
    async def api_media_read(body: MediaReadIn):
        """Generated files, read back through the encrypted channel."""
        # Clients see attachment URLs ("/media/outputs/…"); the resolver wants
        # the path relative to the data directory.
        relative = (body.path or "").strip()
        if relative.startswith("/media/"):
            relative = relative[len("/media/"):]
        relative = relative.lstrip("/")
        try:
            resolved = state.outputs.resolve_media(relative)
        except (FileNotFoundError, PermissionError, ValueError) as exc:
            raise HTTPException(status_code=404, detail="Media not found") from exc
        size = resolved.stat().st_size
        if size > 100 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="That file is too large to send through the channel")
        return {
            "filename": resolved.name,
            "mime": mime_for_path(resolved),
            "size": size,
            "data": base64.b64encode(resolved.read_bytes()).decode("ascii"),
        }

    @app.post("/api/audio/transcribe")
    async def api_transcribe(body: TranscribeIn):
        attachment = state.chats.get_attachment(body.attachment_id)
        if not attachment:
            raise HTTPException(status_code=404, detail="Attachment not found")
        if attachment.get("kind") != "audio":
            raise HTTPException(status_code=400, detail="That attachment is not audio")
        if not state.runtimes.audio_python.exists():
            raise HTTPException(status_code=409, detail="Speech-to-text is not installed. Install speech support in the launcher.")
        job = state.jobs.create(
            "transcribe",
            "Transcribe audio",
            items=[{"id": "transcribe", "label": attachment.get("filename", "audio")}],
        )
        job.start()
        try:
            result = await state.runtimes.transcribe_audio(
                Path(attachment["path"]),
                state.config.audio.stt_model,
                state.config.audio.language,
                job=job,
            )
        except Exception as exc:
            job.fail(str(exc))
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        job.finish({"text": result.get("text", "")})
        return {"job_id": job.id, **result}

    @app.post("/api/audio/tts")
    async def api_tts(body: TTSIn):
        if not body.text.strip():
            raise HTTPException(status_code=400, detail="No text supplied")
        if state.config.audio.tts_engine == "none":
            raise HTTPException(status_code=409, detail="Speech output is disabled in settings")
        temp = paths.CACHE_DIR / f"tts-{uuid.uuid4().hex}.wav"
        try:
            await state.runtimes.tts(body.text[:4000], temp, body.voice)
            attachment = state.outputs.save_path(temp, kind="audio", prefix="speech")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        finally:
            temp.unlink(missing_ok=True)
        state.chats.store_attachment(attachment)
        return attachment.to_dict()

    # ------------------------------------------------------------------
    # Streaming chat
    # ------------------------------------------------------------------
    @app.post("/api/chats/{chat_id}/messages")
    async def api_send_message(request: Request, chat_id: str, body: MessageIn):
        require_running()
        chat = require_chat(request, chat_id)
        if chat_id in state.stop_events:
            raise HTTPException(status_code=409, detail="This chat is already generating a reply.")
        if not body.content.strip() and not body.attachment_ids:
            raise HTTPException(status_code=400, detail="Write a message or attach a file.")
        attachment_ids = list(dict.fromkeys(body.attachment_ids))
        if attachment_ids:
            pending = state.chats.pending_attachments(attachment_ids)
            if len(pending) != len(attachment_ids):
                raise HTTPException(status_code=400, detail="One or more attachments are unknown or already used.")
        user_message = state.chats.add_message(
            chat_id,
            "user",
            body.content,
            attachment_ids=attachment_ids,
        )
        assistant = state.chats.add_message(
            chat_id,
            "assistant",
            "",
            meta={"model": state.config.text.model, "streaming": True},
        )
        stop_event = asyncio.Event()
        state.stop_events[chat_id] = stop_event
        state.invalidate()

        async def generate():
            try:
                yield _sse(
                    {
                        "type": "meta",
                        "chat_id": chat_id,
                        "user_message_id": user_message["id"],
                        "assistant_message_id": assistant["id"],
                        "model": state.config.text.model,
                    }
                )
                async for chunk in transcribe_message_audio(chat_id, user_message["id"]):
                    yield chunk
                fresh = state.chats.get_chat(chat_id) or chat
                history = current_history(fresh)
                image_path = last_image(fresh)
                async for chunk in stream_events(
                    chat_id,
                    assistant["id"],
                    history,
                    web=body.web,
                    tools_enabled=body.tools,
                    reasoning=body.reasoning,
                    image_path=image_path,
                    stop_event=stop_event,
                    attachments=last_user_attachments(fresh),
                ):
                    yield chunk
            finally:
                state.stop_events.pop(chat_id, None)
                placeholder = state.chats.get_message(assistant["id"])
                if placeholder and (placeholder.get("meta") or {}).get("streaming"):
                    state.chats.update_message(
                        assistant["id"],
                        meta={"model": state.config.text.model, "streaming": False, "stopped": True},
                    )

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    @app.post("/api/chats/{chat_id}/regenerate")
    async def api_regenerate(request: Request, chat_id: str, body: RegenerateIn | None = None):
        require_running()
        body = body or RegenerateIn()
        chat = require_chat(request, chat_id)
        if chat_id in state.stop_events:
            raise HTTPException(status_code=409, detail="This chat is already generating a reply.")
        assistant = next((item for item in reversed(chat["messages"]) if item["role"] == "assistant"), None)
        if not assistant:
            raise HTTPException(status_code=400, detail="There is no assistant reply to regenerate.")
        state.chats.delete_message_and_after(chat_id, assistant["id"])
        fresh = require_chat(request, chat_id)
        last_user = next((item for item in reversed(fresh["messages"]) if item["role"] == "user"), None)
        if not last_user:
            raise HTTPException(status_code=400, detail="There is no user message to regenerate from.")
        assistant = state.chats.add_message(
            chat_id,
            "assistant",
            "",
            meta={"model": state.config.text.model, "streaming": True},
        )
        stop_event = asyncio.Event()
        state.stop_events[chat_id] = stop_event
        history = current_history(fresh)
        image_path = last_image(fresh)

        async def generate():
            try:
                yield _sse(
                    {
                        "type": "meta",
                        "chat_id": chat_id,
                        "assistant_message_id": assistant["id"],
                        "model": state.config.text.model,
                    }
                )
                async for chunk in stream_events(
                    chat_id,
                    assistant["id"],
                    history,
                    web=body.web,
                    tools_enabled=body.tools,
                    reasoning=body.reasoning,
                    image_path=image_path,
                    stop_event=stop_event,
                    attachments=last_user_attachments(fresh),
                ):
                    yield chunk
            finally:
                state.stop_events.pop(chat_id, None)
                placeholder = state.chats.get_message(assistant["id"])
                if placeholder and (placeholder.get("meta") or {}).get("streaming"):
                    state.chats.update_message(
                        assistant["id"],
                        meta={"model": state.config.text.model, "streaming": False, "stopped": True},
                    )

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    @app.post("/api/chats/{chat_id}/stop")
    async def api_stop_chat(request: Request, chat_id: str):
        require_chat(request, chat_id)
        event = state.stop_events.get(chat_id)
        if not event:
            return {"stopped": False}
        event.set()
        return {"stopped": True}

    # ------------------------------------------------------------------
    # Direct generation (tool buttons)
    # ------------------------------------------------------------------
    @app.post("/api/generate")
    async def api_generate(request: Request, body: GenerateIn):
        require_running()
        owner = remote_owner(request)
        if body.chat_id:
            chat = require_chat(request, body.chat_id)
        else:
            chat = state.chats.create_chat(model=state.config.text.model, owner=owner or "")
        if body.modality in {"image", "video", "music", "3d"} and not body.prompt.strip() and not body.attachment_id:
            raise HTTPException(status_code=400, detail="A prompt is required.")
        if body.modality == "speech" and not body.prompt.strip():
            raise HTTPException(status_code=400, detail="Text is required.")
        attachment_ids: list[str] = []
        image_path: Path | None = None
        if body.attachment_id:
            attachment = state.chats.get_attachment(body.attachment_id)
            if not attachment:
                raise HTTPException(status_code=404, detail="Attachment not found")
            attachment_ids.append(body.attachment_id)
            if attachment.get("kind") == "image":
                image_path = Path(attachment["path"])
        labels = {
            "image": "Create an image",
            "video": "Create a video",
            "music": "Compose music",
            "speech": "Speak text",
            "3d": "Create a 3D model",
        }
        content = labels[body.modality] + (f": {body.prompt}" if body.prompt else " from the attached image")
        user_message = state.chats.add_message(
            chat["id"], "user", content, attachment_ids=attachment_ids
        )
        assistant = state.chats.add_message(
            chat["id"],
            "assistant",
            "",
            meta={"model": state.config.text.model, "streaming": True, "mode": "direct"},
        )
        tool_name = {
            "image": "generate_image",
            "video": "generate_video",
            "music": "generate_music",
            "speech": "text_to_speech",
            "3d": "generate_3d",
        }[body.modality]
        args: dict[str, Any] = {}
        if body.modality == "speech":
            args = {"text": body.prompt}
        else:
            args = {"prompt": body.prompt}
            if body.width:
                args["width"] = body.width
            if body.height:
                args["height"] = body.height
            if body.seconds:
                args["seconds"] = body.seconds
            if body.fps:
                args["fps"] = body.fps
            if body.duration:
                args["duration"] = body.duration
            if body.lyrics:
                args["lyrics"] = body.lyrics
            if body.modality == "3d" and image_path:
                args["use_attached_image"] = True
        item_id = f"generate:{body.modality}"
        job = state.jobs.create(
            "generate",
            labels[body.modality],
            items=[{"id": item_id, "label": labels[body.modality], "size_gb": 0}],
        )
        job.start()

        async def run_generation():
            ctx = ToolContext(
                config_store=state.config_store,
                runtimes=state.runtimes,
                comfy=state.comfy,
                jobs=state.jobs,
                outputs=state.outputs,
                last_image_path=image_path,
                job=job,
                memories=state.memories,
            )
            try:
                result = await execute_tool(tool_name, args, ctx)
                if result.error and job.status not in {"error", "canceled"}:
                    job.fail(result.error)
                elif job.status not in {"done", "error", "canceled"}:
                    job.finish({"attachments": [item.filename for item in result.attachments]})
                attachment_ids = []
                for attachment in result.attachments:
                    state.chats.store_attachment(attachment)
                    attachment_ids.append(attachment.id)
                if attachment_ids:
                    state.chats.link_attachments(assistant["id"], attachment_ids)
                state.chats.update_message(
                    assistant["id"],
                    content=result.content,
                    meta={
                        "model": state.config.text.model,
                        "streaming": False,
                        "mode": "direct",
                        "error": result.error,
                        "tools": [
                            {
                                "name": tool_name,
                                "content": result.content[:4000],
                                "attachments": [
                                    {
                                        "id": item.id,
                                        "filename": item.filename,
                                        "kind": item.kind,
                                        "url": item.url,
                                    }
                                    for item in result.attachments
                                ],
                                "sources": result.sources,
                                "error": result.error,
                            }
                        ],
                    },
                )
            except Exception as exc:
                job.fail(str(exc))
                state.chats.update_message(
                    assistant["id"],
                    content=f"**Error:** {exc}",
                    meta={"model": state.config.text.model, "streaming": False, "error": str(exc), "mode": "direct"},
                )
            finally:
                state.invalidate()

        state.background(run_generation())
        state.invalidate()
        return {
            "chat_id": chat["id"],
            "user_message_id": user_message["id"],
            "assistant_message_id": assistant["id"],
            "job_id": job.id,
        }

    # ------------------------------------------------------------------
    # Media
    # ------------------------------------------------------------------
    @app.get("/media/{path:path}")
    async def media(path: str):
        try:
            resolved = state.outputs.resolve_media(path)
        except (FileNotFoundError, PermissionError, ValueError) as exc:
            raise HTTPException(status_code=404, detail="Media not found") from exc
        return FileResponse(
            resolved,
            media_type=None,
            headers={"Cache-Control": "public, max-age=3600"},
        )

    return app
