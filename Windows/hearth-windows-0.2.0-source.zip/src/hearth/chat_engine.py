"""The chat/tool-loop orchestrator."""

from __future__ import annotations

import base64
import contextlib
import json
import time
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .attachments import Attachment
from .comfy import ComfyClient
from .config import AppConfig, ConfigStore
from .jobs import JobManager
from .llm import (
    BaseLLM,
    ToolCall,
    Usage,
    build_llm,
    parse_prompt_tool_calls,
    prompt_tool_protocol,
)
from .runtimes import RuntimeManager
from .tools import ToolContext, ToolResult, enabled_tool_specs, execute_tool


@dataclass
class ChatOutcome:
    content: str = ""
    thinking: str = ""
    attachments: list[Attachment] = field(default_factory=list)
    sources: list[dict] = field(default_factory=list)
    usage: Usage = field(default_factory=Usage)
    tool_rounds: int = 0
    stopped: bool = False


def _estimate_tokens(messages: list[dict]) -> int:
    total = 0
    for message in messages:
        content = message.get("content") or ""
        if isinstance(content, list):
            content = json.dumps(content, ensure_ascii=False)
        total += max(1, len(str(content)) // 4) + 6
        if message.get("images"):
            total += 600 * len(message["images"])
        for call in message.get("tool_calls") or []:
            total += len(json.dumps(call, ensure_ascii=False)) // 4
    return total


def trim_messages(messages: list[dict], context_tokens: int) -> list[dict]:
    """Keep the system prompt and the most recent coherent tail."""
    if not messages:
        return messages
    system = [messages[0]] if messages[0].get("role") == "system" else []
    rest = messages[1:] if system else messages[:]
    budget = max(1024, context_tokens - 512)
    while rest and _estimate_tokens(system + rest) > budget:
        rest.pop(0)
        # Never start the tail with an orphaned tool result.
        while rest and rest[0].get("role") == "tool":
            rest.pop(0)
    return system + rest


def build_user_message(content: str, attachments: list[Attachment]) -> dict:
    """Turn stored attachments into a canonical user message."""
    images: list[dict] = []
    extras: list[str] = []

    def field(attachment, key: str, default: str = ""):
        if isinstance(attachment, dict):
            return attachment.get(key, default)
        return getattr(attachment, key, default)

    for attachment in attachments:
        kind = field(attachment, "kind", "file")
        filename = field(attachment, "filename", "file")
        mime = field(attachment, "mime", "application/octet-stream")
        path = Path(field(attachment, "path", ""))
        if kind == "image" and path.exists() and path.stat().st_size <= 12_000_000:
            try:
                data = base64.b64encode(path.read_bytes()).decode("ascii")
                images.append({"data": data, "mime": mime})
                extras.append(f"[attached image: {filename}]")
            except OSError:
                extras.append(f"[attached image could not be read: {filename}]")
        elif kind == "audio":
            extras.append(f"[attached audio: {filename}]")
        elif kind == "text" and path.exists():
            try:
                text = path.read_text(errors="replace")[:50_000]
                extras.append(f"[attached text file {filename}]\n{text}")
            except OSError:
                extras.append(f"[attached text file: {filename}]")
        else:
            extras.append(f"[attached {kind}: {filename}]")
    full = (content or "").strip()
    if extras:
        full = (full + "\n\n" + "\n".join(extras)).strip()
    message: dict = {"role": "user", "content": full}
    if images:
        message["images"] = images
    return message


def _modality_system_summary(config: AppConfig) -> str:
    parts = []
    if config.image.enabled:
        parts.append(f"images via {config.image.model}")
    if config.video.enabled:
        parts.append(f"video via {config.video.model}")
    if config.music.enabled:
        parts.append(f"music via {config.music.model}")
    if config.audio.enabled and config.audio.tts_engine != "none":
        parts.append("speech")
    if config.three_d.enabled:
        parts.append(f"3D via {config.three_d.model}")
    if config.search.enabled:
        parts.append("web search")
    return ", ".join(parts) if parts else "no media tools"


def _filter_tools(config: AppConfig, tools: list[dict]) -> list[dict]:
    keep = set()
    if config.search.enabled:
        keep.update({"web_search", "fetch_url"})
    if config.image.enabled:
        keep.add("generate_image")
        if config.edit.enabled:
            # Offered alongside generation so a photo can be *changed* rather
            # than re-drawn from scratch.
            keep.add("edit_image")
    if config.video.enabled:
        keep.add("generate_video")
    if config.music.enabled:
        keep.add("generate_music")
    if config.audio.enabled and config.audio.tts_engine != "none":
        keep.add("text_to_speech")
    if config.three_d.enabled:
        keep.add("generate_3d")
    if config.memory.enabled:
        keep.update({"remember", "forget_memory"})
    return [tool for tool in tools if tool["function"]["name"] in keep]


class ChatEngine:
    def __init__(
        self,
        config_store: ConfigStore,
        runtimes: RuntimeManager,
        comfy: ComfyClient,
        jobs: JobManager,
        outputs,
        hardware_summary: str = "",
        memories=None,
    ):
        self.config_store = config_store
        self.runtimes = runtimes
        self.comfy = comfy
        self.jobs = jobs
        self.outputs = outputs
        self.hardware_summary = hardware_summary
        self.memories = memories

    @property
    def config(self) -> AppConfig:
        return self.config_store.config

    def _system_prompt(self, tools: list[dict], tool_mode: str, web: bool, vision: bool) -> str:
        config = self.config
        prompt = (config.text.system_prompt or "").replace(
            "{date}", datetime.now().strftime("%A, %B %d, %Y")
        )
        prompt += (
            "\n\nEnvironment: Hearth, running locally"
            + (f" on {self.hardware_summary}" if self.hardware_summary else "")
            + f". Available modalities: {_modality_system_summary(config)}."
        )
        if not vision:
            prompt += "\nYou cannot see images directly in this model; use the 3D tool if the user wants an image turned into a model."
        if config.video.enabled:
            prompt += (
                "\nVideo generation is capped at 1280×720 and short clips; never promise 1080p "
                "or a larger output than the video tool reports."
            )
        if web:
            prompt += (
                "\nThe user enabled web search for this message. Use web_search for anything current, "
                "and cite sources as [1], [2], …."
            )
        memory_block = ""
        if config.memory.enabled and self.memories is not None:
            memory_block = self.memories.prompt_block(config.memory.inject_limit)
        if memory_block:
            prompt += memory_block
            prompt += (
                "\nIf the user tells you something durable about themselves, save it with the remember "
                "tool; if they ask you to forget something, use forget_memory."
            )
        if tools:
            names = ", ".join(tool["function"]["name"] for tool in tools)
            prompt += f"\nTools available: {names}. Use them when they materially help."
            if tool_mode == "prompt":
                prompt += "\n\n" + prompt_tool_protocol(tools)
            else:
                prompt += " Do not print raw tool-call JSON; use the tool interface."
        else:
            prompt += "\nNo tools are available for this turn. Do not claim to have searched or generated anything."
        return prompt

    async def _choose_tool_mode(self, llm: BaseLLM, tools: list[dict]) -> tuple[str, set[str]]:
        config = self.config
        requested = config.text.tool_mode
        capabilities: set[str] = {"completion"}
        with contextlib.suppress(Exception):
            capabilities = await llm.capabilities()
        if not tools:
            return "none", capabilities
        if requested == "prompt":
            return "prompt", capabilities
        if requested == "native":
            return "native", capabilities
        if config.text.backend == "ollama" and "tools" not in capabilities:
            return "prompt", capabilities
        if config.text.backend == "demo":
            return "none", capabilities
        return "native", capabilities

    async def stream(
        self,
        messages: list[dict],
        *,
        web: bool = False,
        tools_enabled: bool = True,
        reasoning: bool | None = None,
        last_image_path: Path | None = None,
        attachments: list[dict] | None = None,
        should_stop: Callable[[], bool] | None = None,
    ) -> AsyncIterator[dict]:
        config = self.config
        llm = build_llm(config, self.runtimes)
        enabled = _filter_tools(config, enabled_tool_specs(config)) if (tools_enabled and config.text.tools_enabled) else []
        tool_mode, capabilities = await self._choose_tool_mode(llm, enabled)
        vision = "vision" in capabilities
        if not vision:
            for message in messages:
                if message.get("role") == "user" and message.get("images"):
                    message["images"] = []
        system = self._system_prompt(enabled, tool_mode, web, vision)
        canonical: list[dict] = [{"role": "system", "content": system}, *messages]
        canonical = trim_messages(canonical, config.text.context_tokens)
        tool_map = {tool["function"]["name"]: tool for tool in enabled}
        total_usage = Usage()
        started = time.monotonic()
        rounds = 0
        max_rounds = max(0, config.text.max_tool_rounds)
        if tool_mode == "none":
            max_rounds = 0

        while True:
            if should_stop and should_stop():
                yield {
                    "type": "done",
                    "usage": total_usage.to_dict(),
                    "stopped": True,
                    "tool_rounds": rounds - 1,
                }
                return
            rounds += 1
            native = tool_mode == "native"
            tools_param = enabled if native else None
            content_parts: list[str] = []
            thinking_parts: list[str] = []
            calls: list[ToolCall] = []
            round_usage = Usage()
            failed = False
            retry_prompt = False
            had_output = False
            async for event in llm.stream(
                canonical,
                tools_param,
                temperature=config.text.temperature,
                top_p=config.text.top_p,
                think=reasoning,
            ):
                if should_stop and should_stop():
                    yield {
                        "type": "done",
                        "usage": total_usage.to_dict(),
                        "stopped": True,
                        "tool_rounds": rounds - 1,
                    }
                    return
                if event.type == "delta":
                    had_output = True
                    content_parts.append(event.text)
                    yield {"type": "delta", "text": event.text}
                elif event.type == "thinking":
                    thinking_parts.append(event.text)
                    yield {"type": "thinking", "text": event.text}
                elif event.type == "tool_calls":
                    calls.extend(event.tool_calls)
                elif event.type == "error":
                    if native and event.retryable and not had_output:
                        retry_prompt = True
                        break
                    failed = True
                    yield {"type": "error", "error": event.error}
                    break
                elif event.type == "done":
                    round_usage = event.usage or Usage()
            if retry_prompt:
                tool_mode = "prompt"
                system = self._system_prompt(enabled, tool_mode, web, vision)
                canonical[0] = {"role": "system", "content": system}
                continue
            if failed:
                return
            content = "".join(content_parts)
            if tool_mode == "prompt" and not calls:
                cleaned, parsed = parse_prompt_tool_calls(content)
                if parsed:
                    calls.extend(parsed)
                    content = cleaned
                    yield {"type": "replace", "text": cleaned}
            total_usage.prompt_tokens += round_usage.prompt_tokens
            total_usage.completion_tokens += round_usage.completion_tokens
            total_usage.total_tokens += round_usage.total_tokens
            total_usage.duration_ms += round_usage.duration_ms

            if not calls:
                if not content.strip():
                    yield {"type": "error", "error": "The text model returned an empty response."}
                    return
                total_usage.duration_ms = total_usage.duration_ms or int((time.monotonic() - started) * 1000)
                if not total_usage.total_tokens:
                    total_usage.completion_tokens = max(1, len(content) // 4)
                    total_usage.total_tokens = total_usage.completion_tokens
                yield {"type": "usage", "usage": total_usage.to_dict()}
                yield {
                    "type": "done",
                    "usage": total_usage.to_dict(),
                    "stopped": False,
                    "tool_rounds": rounds - 1,
                }
                return

            if rounds > max_rounds:
                yield {
                    "type": "error",
                    "error": f"Tool-call limit reached ({max_rounds}). Ask me to continue if you want another step.",
                }
                return

            canonical.append(
                {
                    "role": "assistant",
                    "content": content,
                    "tool_calls": [call.to_openai() for call in calls],
                }
            )
            for call in calls:
                if should_stop and should_stop():
                    yield {
                        "type": "done",
                        "usage": total_usage.to_dict(),
                        "stopped": True,
                        "tool_rounds": rounds - 1,
                    }
                    return
                if call.name not in tool_map:
                    result = ToolResult(
                        name=call.name,
                        content=f"Unknown or disabled tool: {call.name}",
                        error="unknown tool",
                    )
                else:
                    yield {
                        "type": "tool_start",
                        "id": call.id,
                        "name": call.name,
                        "arguments": call.arguments,
                    }
                    ctx = ToolContext(
                        config_store=self.config_store,
                        runtimes=self.runtimes,
                        comfy=self.comfy,
                        jobs=self.jobs,
                        outputs=self.outputs,
                        last_image_path=last_image_path,
                        attachments=list(attachments or []),
                        memories=self.memories,
                    )
                    result = await execute_tool(call.name, call.arguments, ctx)
                canonical.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.id,
                        "tool_name": call.name,
                        "content": result.content[:16000],
                    }
                )
                yield {
                    "type": "tool_result",
                    "id": call.id,
                    "name": call.name,
                    "content": result.content[:2000],
                    "attachments": [item.to_dict() for item in result.attachments],
                    "sources": result.sources,
                    "error": result.error,
                }
            # Give the model the tool results and continue the loop.
            content_parts = []
            continue
