"""Thread-safe background jobs for installs, downloads and generation."""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any


def now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


@dataclass
class JobItem:
    id: str
    label: str
    status: str = "pending"  # pending | running | done | error | skipped | canceled
    size_gb: float = 0.0
    total_bytes: int = 0
    completed_bytes: int = 0
    message: str = ""
    error: str = ""
    speed_bps: float = 0.0
    eta_s: float | None = None
    started_at: str = ""
    finished_at: str = ""

    def to_dict(self) -> dict:
        progress = None
        if self.total_bytes > 0:
            progress = max(0.0, min(100.0, self.completed_bytes / self.total_bytes * 100))
        return {
            "id": self.id,
            "label": self.label,
            "status": self.status,
            "size_gb": self.size_gb,
            "total_bytes": self.total_bytes,
            "completed_bytes": self.completed_bytes,
            "progress": round(progress, 1) if progress is not None else None,
            "message": self.message,
            "error": self.error,
            "speed_bps": round(self.speed_bps, 1),
            "eta_s": round(self.eta_s, 1) if self.eta_s is not None else None,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
        }


class Job:
    def __init__(self, kind: str, title: str, items: list[dict] | None = None):
        self.id = uuid.uuid4().hex[:12]
        self.kind = kind
        self.title = title
        self.status = "queued"
        self.created_at = now_iso()
        self.updated_at = self.created_at
        self._lock = threading.RLock()
        self.items: dict[str, JobItem] = {}
        for item in items or []:
            self.add_item(
                item.get("id") or uuid.uuid4().hex[:8],
                item.get("label", "Item"),
                size_gb=float(item.get("size_gb") or 0),
            )
        self.logs: list[str] = []
        self.error = ""
        self.result: dict[str, Any] = {}
        self.cancel_event = threading.Event()

    # ---- items ---------------------------------------------------------
    def add_item(self, item_id: str, label: str, size_gb: float = 0.0) -> JobItem:
        with self._lock:
            item = JobItem(id=item_id, label=label, size_gb=size_gb)
            self.items[item_id] = item
            self._touch()
            return item

    def update_item(self, item_id: str, **changes: Any) -> None:
        with self._lock:
            item = self.items.get(item_id)
            if item is None:
                item = JobItem(id=item_id, label=changes.pop("label", item_id))
                self.items[item_id] = item
            if changes.get("status") == "running" and not item.started_at:
                item.started_at = now_iso()
            if changes.get("status") in {"done", "error", "skipped", "canceled"} and not item.finished_at:
                item.finished_at = now_iso()
            for key, value in changes.items():
                if hasattr(item, key):
                    setattr(item, key, value)
            self._touch()

    def item(self, item_id: str) -> JobItem | None:
        with self._lock:
            return self.items.get(item_id)

    # ---- lifecycle -----------------------------------------------------
    def start(self) -> None:
        with self._lock:
            self.status = "running"
            self._touch()

    def log(self, message: str) -> None:
        line = message.rstrip("\n")
        if not line:
            return
        with self._lock:
            stamp = datetime.now().strftime("%H:%M:%S")
            self.logs.append(f"[{stamp}] {line}")
            if len(self.logs) > 500:
                self.logs = self.logs[-400:]
            self._touch()

    def finish(self, result: dict[str, Any] | None = None) -> None:
        with self._lock:
            self.status = "done"
            self.result = result or {}
            self._touch()

    def fail(self, error: str) -> None:
        with self._lock:
            self.status = "error"
            self.error = str(error)
            self.log(f"ERROR: {error}")
            self._touch()

    def cancel(self) -> None:
        with self._lock:
            self.cancel_event.set()
            self.status = "canceled"
            for item in self.items.values():
                if item.status in {"pending", "running"}:
                    item.status = "canceled"
                    item.finished_at = now_iso()
            self._touch()

    @property
    def canceled(self) -> bool:
        return self.cancel_event.is_set()

    @property
    def cancelled(self) -> bool:
        return self.cancel_event.is_set()

    def _touch(self) -> None:
        self.updated_at = now_iso()

    @staticmethod
    def _weight(item: JobItem) -> int:
        if item.status == "skipped":
            return 0
        return max(int(item.total_bytes or 0), int((item.size_gb or 0) * 1_000_000_000), 1)

    @staticmethod
    def _completed(item: JobItem, weight: int) -> int:
        if item.status == "done":
            return weight
        if item.status == "skipped":
            return 0
        if item.completed_bytes:
            return min(weight, int(item.completed_bytes))
        return 0

    @property
    def total_bytes(self) -> int:
        return sum(self._weight(item) for item in self.items.values())

    @property
    def downloaded_bytes(self) -> int:
        return sum(self._completed(item, self._weight(item)) for item in self.items.values())

    @property
    def remaining_bytes(self) -> int:
        return max(0, self.total_bytes - self.downloaded_bytes)

    @property
    def progress(self) -> float | None:
        items = [item for item in self.items.values() if item.status != "skipped"]
        if not items:
            return None
        if not any(item.total_bytes > 0 or item.size_gb > 0 for item in items):
            return 100.0 if all(item.status == "done" for item in items) else None
        total = self.total_bytes
        if total:
            return round(min(100.0, self.downloaded_bytes / total * 100), 1)
        done = sum(1 for item in items if item.status == "done")
        return round(done / len(items) * 100, 1)

    @property
    def current_item(self) -> dict | None:
        for item in self.items.values():
            if item.status == "running":
                return item.to_dict()
        for item in self.items.values():
            if item.status == "pending":
                return item.to_dict()
        return None

    def to_dict(self, include_logs: bool = False) -> dict:
        with self._lock:
            data = {
                "id": self.id,
                "kind": self.kind,
                "title": self.title,
                "status": self.status,
                "progress": self.progress,
                "bytes": {
                    "total": self.total_bytes,
                    "downloaded": self.downloaded_bytes,
                    "remaining": self.remaining_bytes,
                },
                "current": self.current_item,
                "item_counts": {
                    "total": len(self.items),
                    "done": sum(1 for item in self.items.values() if item.status in {"done", "skipped"}),
                },
                "created_at": self.created_at,
                "updated_at": self.updated_at,
                "error": self.error,
                "result": self.result,
                "items": [item.to_dict() for item in self.items.values()],
                "canceled": self.cancel_event.is_set(),
            }
            if include_logs:
                data["logs"] = self.logs[-200:]
            return data


class JobManager:
    def __init__(self, max_jobs: int = 80):
        self.max_jobs = max_jobs
        self._jobs: dict[str, Job] = {}
        self._lock = threading.RLock()

    def create(self, kind: str, title: str, items: list[dict] | None = None) -> Job:
        job = Job(kind, title, items)
        with self._lock:
            self._jobs[job.id] = job
            # Keep a bounded history, but never evict a running job.
            finished = [item for item in self._jobs.values() if item.status in {"done", "error", "canceled"}]
            if len(self._jobs) > self.max_jobs:
                for old in sorted(finished, key=lambda item: item.updated_at)[: len(self._jobs) - self.max_jobs]:
                    self._jobs.pop(old.id, None)
        return job

    def get(self, job_id: str) -> Job | None:
        with self._lock:
            return self._jobs.get(job_id)

    def list(self, include_logs: bool = False) -> list[dict]:
        with self._lock:
            jobs = sorted(self._jobs.values(), key=lambda item: item.created_at, reverse=True)
            return [job.to_dict(include_logs=include_logs) for job in jobs]

    def cancel(self, job_id: str) -> bool:
        job = self.get(job_id)
        if not job:
            return False
        job.cancel()
        return True

    def wait_for(self, job_id: str, timeout: float = 30.0) -> Job | None:
        job = self.get(job_id)
        if not job:
            return None
        deadline = time.monotonic() + timeout
        while job.status in {"queued", "running"} and time.monotonic() < deadline:
            time.sleep(0.1)
        return job
