"""Attachment and generated-file bookkeeping."""

from __future__ import annotations

import mimetypes
import re
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from . import paths

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".bmp"}
VIDEO_EXT = {".mp4", ".webm", ".mov", ".mkv", ".avi"}
AUDIO_EXT = {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".opus"}
MODEL_EXT = {".glb", ".gltf", ".obj", ".stl", ".ply", ".fbx", ".usdz"}
TEXT_EXT = {".txt", ".md", ".json", ".csv", ".yaml", ".yml", ".py", ".js", ".ts", ".html", ".css"}


def kind_for_path(path: Path | str) -> str:
    suffix = Path(path).suffix.lower()
    if suffix in IMAGE_EXT:
        return "image"
    if suffix in VIDEO_EXT:
        return "video"
    if suffix in AUDIO_EXT:
        return "audio"
    if suffix in MODEL_EXT:
        return "model3d"
    if suffix in TEXT_EXT:
        return "text"
    return "file"


def mime_for_path(path: Path | str) -> str:
    mime, _ = mimetypes.guess_type(str(path))
    if mime:
        return mime
    return {
        ".glb": "model/gltf-binary",
        ".gltf": "model/gltf+json",
        ".webm": "video/webm",
        ".opus": "audio/opus",
    }.get(Path(path).suffix.lower(), "application/octet-stream")


def _slug(value: str, fallback: str = "file") -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-._")
    return cleaned[:80] or fallback


@dataclass
class Attachment:
    kind: str
    filename: str
    path: str
    mime: str
    size: int = 0
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    meta: dict = field(default_factory=dict)

    @property
    def file_path(self) -> Path:
        return Path(self.path)

    @property
    def url(self) -> str:
        try:
            rel = self.file_path.resolve().relative_to(paths.DATA_DIR.resolve())
            return "/media/" + rel.as_posix()
        except ValueError:
            return ""

    def to_dict(self) -> dict:
        data = asdict(self)
        data["url"] = self.url
        return data


class OutputStore:
    def __init__(self) -> None:
        paths.ensure_dirs()

    def _dated(self, root: Path) -> Path:
        folder = root / datetime.now(UTC).strftime("%Y-%m-%d")
        folder.mkdir(parents=True, exist_ok=True)
        return folder

    def save_bytes(
        self,
        data: bytes,
        *,
        kind: str,
        suffix: str,
        prefix: str = "hearth",
        meta: dict | None = None,
    ) -> Attachment:
        suffix = suffix if suffix.startswith(".") else f".{suffix}"
        folder = self._dated(paths.OUTPUTS_DIR)
        stamp = datetime.now(UTC).strftime("%H%M%S")
        name = f"{_slug(prefix)}-{stamp}-{uuid.uuid4().hex[:6]}{suffix}"
        path = folder / name
        path.write_bytes(data)
        return Attachment(
            kind=kind,
            filename=name,
            path=str(path),
            mime=mime_for_path(path),
            size=len(data),
            meta=meta or {},
        )

    def save_path(
        self,
        source: Path,
        *,
        kind: str | None = None,
        prefix: str = "hearth",
        meta: dict | None = None,
    ) -> Attachment:
        source = Path(source)
        data = source.read_bytes()
        return self.save_bytes(
            data,
            kind=kind or kind_for_path(source),
            suffix=source.suffix or ".bin",
            prefix=prefix,
            meta=meta,
        )

    def save_upload(self, filename: str, data: bytes) -> Attachment:
        safe_name = _slug(Path(filename).name)
        folder = self._dated(paths.UPLOADS_DIR)
        stored = f"{uuid.uuid4().hex[:10]}-{safe_name}"
        path = folder / stored
        path.write_bytes(data)
        return Attachment(
            kind=kind_for_path(path),
            filename=safe_name,
            path=str(path),
            mime=mime_for_path(path),
            size=len(data),
        )

    def register(self, path: Path, *, kind: str | None = None, meta: dict | None = None) -> Attachment:
        path = Path(path).resolve()
        try:
            path.relative_to(paths.DATA_DIR.resolve())
        except ValueError as exc:
            raise ValueError("attachment must live inside the Hearth data directory") from exc
        return Attachment(
            kind=kind or kind_for_path(path),
            filename=path.name,
            path=str(path),
            mime=mime_for_path(path),
            size=path.stat().st_size if path.exists() else 0,
            meta=meta or {},
        )

    def resolve_media(self, relative: str) -> Path:
        candidate = paths.safe_join(paths.DATA_DIR, relative)
        if not candidate.exists() or not candidate.is_file():
            raise FileNotFoundError(relative)
        allowed = (
            paths.OUTPUTS_DIR.resolve() in candidate.parents
            or paths.UPLOADS_DIR.resolve() in candidate.parents
        )
        if not allowed:
            raise PermissionError("media path is outside the output directories")
        return candidate

    def output_dir(self) -> Path:
        return self._dated(paths.OUTPUTS_DIR)
