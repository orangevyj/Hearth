"""Tool definitions and server-side execution."""

from __future__ import annotations

import asyncio
import contextlib
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import paths
from .attachments import Attachment
from .comfy import ComfyClient
from .config import AppConfig, ConfigStore
from .jobs import Job, JobManager
from .runtimes import RuntimeManager
from .search import fetch_page, format_search_for_model, search_web, sources_for_ui

TOOL_SPECS: list[dict] = [
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": (
                "Search the public web for current information. Returns titles, URLs and snippets, "
                "and may include short page excerpts. Use for news, prices, recent events, or facts "
                "you are unsure about."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "The search query."},
                    "max_results": {
                        "type": "integer",
                        "description": "How many results to return (1-12).",
                        "minimum": 1,
                        "maximum": 12,
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "fetch_url",
            "description": "Read a public web page and return its readable text. Use after web_search when a snippet is not enough.",
            "parameters": {
                "type": "object",
                "properties": {"url": {"type": "string", "description": "Public http(s) URL."}},
                "required": ["url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_image",
            "description": "Generate an image from a detailed text prompt. The image is shown to the user automatically.",
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "What the image should show. Be specific about subject, style, composition and lighting."},
                    "width": {"type": "integer", "minimum": 256, "maximum": 2048},
                    "height": {"type": "integer", "minimum": 256, "maximum": 2048},
                    "steps": {"type": "integer", "minimum": 1, "maximum": 60},
                },
                "required": ["prompt"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "edit_image",
            "description": (
                "Edit the photos the user attached: recolour, remove or add things, restyle, or combine "
                "several pictures. Uses every image on the current message unless you name ids."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "What to change, in plain language."},
                    "attachment_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Which attached images to use; defaults to all images on this message.",
                    },
                },
                "required": ["prompt"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_video",
            "description": "Generate a short, silent text-to-video clip capped at 1280×720. This is expensive and can take several minutes on 8 GB cards.",
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "The motion and scene to generate."},
                    "width": {"type": "integer", "minimum": 256, "maximum": 1280},
                    "height": {"type": "integer", "minimum": 256, "maximum": 1280},
                    "seconds": {"type": "number", "minimum": 1, "maximum": 8, "description": "Approximate clip length in seconds."},
                    "fps": {"type": "integer", "minimum": 4, "maximum": 60, "description": "Frame rate of the generated video."},
                },
                "required": ["prompt"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_music",
            "description": "Compose a short music track, with optional lyrics. Instrumental if lyrics are empty.",
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "Genre, instruments, mood and production style."},
                    "lyrics": {"type": "string", "description": "Optional lyrics with section tags like [Verse] and [Chorus]."},
                    "duration": {"type": "integer", "minimum": 5, "maximum": 120},
                    "bpm": {"type": "integer", "minimum": 30, "maximum": 240},
                },
                "required": ["prompt"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "text_to_speech",
            "description": "Speak text aloud using the configured local voice. The audio player is shown to the user.",
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "Text to speak."},
                    "voice": {"type": "string", "description": "Optional voice id, e.g. en_US-amy-medium."},
                },
                "required": ["text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_3d",
            "description": (
                "Create a 3D model (GLB) from a text prompt or from an image the user attached. "
                "Hearth generates a preview image first when given a prompt, then converts it to a mesh."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "What the 3D object should be."},
                    "use_attached_image": {
                        "type": "boolean",
                        "description": "Use the most recent user image instead of generating one from the prompt.",
                    },
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "remember",
            "description": (
                "Save a durable fact or preference about the user so later conversations can use it "
                "(name, location, how they like answers, ongoing projects). One short sentence per memory. "
                "Do not store secrets, credentials or anything transient."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "The memory, written as a short standalone sentence.",
                    }
                },
                "required": ["text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "forget_memory",
            "description": "Delete a saved memory when the user asks you to forget something.",
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "The memory to forget; a distinctive part of its text is enough.",
                    }
                },
                "required": ["text"],
            },
        },
    },
]


@dataclass
class ToolResult:
    name: str
    content: str
    attachments: list[Attachment] = field(default_factory=list)
    sources: list[dict] = field(default_factory=list)
    error: str = ""
    meta: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "content": self.content,
            "attachments": [item.to_dict() for item in self.attachments],
            "sources": self.sources,
            "error": self.error,
            "meta": self.meta,
        }


@dataclass
class ToolContext:
    config_store: ConfigStore
    runtimes: RuntimeManager
    comfy: ComfyClient
    jobs: JobManager
    outputs: Any
    last_image_path: Path | None = None
    job: Job | None = None
    attachments: list[dict] = field(default_factory=list)
    memories: Any = None

    @property
    def config(self) -> AppConfig:
        return self.config_store.config


def enabled_tool_specs(config: AppConfig) -> list[dict]:
    specs = []
    for spec in TOOL_SPECS:
        name = spec["function"]["name"]
        if config.tools.allows(name):
            specs.append(spec)
    return specs


def _clamp(value: Any, minimum: int, maximum: int, default: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(minimum, min(maximum, number))


def _new_job(ctx: ToolContext, title: str, item_id: str, label: str) -> Job:
    if ctx.job is not None:
        return ctx.job
    job = ctx.jobs.create("generate", title, items=[{"id": item_id, "label": label, "size_gb": 0}])
    job.start()
    return job


def _finish_job(job: Job, result: ToolResult) -> None:
    if result.error:
        job.fail(result.error)
    else:
        job.finish({"attachments": [item.filename for item in result.attachments]})


async def _require_comfy(ctx: ToolContext, job: Job | None = None) -> None:
    await ctx.comfy.ensure_ready(job)


async def _search(args: dict, ctx: ToolContext) -> ToolResult:
    if not ctx.config.search.enabled:
        return ToolResult(name="web_search", content="Web search is disabled.", error="web search disabled")
    query = str(args.get("query") or "").strip()
    if not query:
        return ToolResult(name="web_search", content="No query was provided.", error="empty query")
    payload = await search_web(
        query,
        ctx.config.search,
        max_results=args.get("max_results"),
    )
    return ToolResult(
        name="web_search",
        content=format_search_for_model(payload),
        sources=sources_for_ui(payload),
        meta={"provider": payload.get("provider"), "query": query},
    )


async def _fetch(args: dict, ctx: ToolContext) -> ToolResult:
    url = str(args.get("url") or "").strip()
    if not url:
        return ToolResult(name="fetch_url", content="No URL was provided.", error="empty url")
    page = await fetch_page(url, timeout=ctx.config.search.timeout_s, max_chars=6000)
    content = f"Page: {page['title']}\nURL: {page['url']}\n\n{page['text']}"
    return ToolResult(
        name="fetch_url",
        content=content,
        sources=[{"title": page["title"], "url": page["url"], "snippet": ""}],
        meta={"url": page["url"]},
    )


async def _image(args: dict, ctx: ToolContext) -> ToolResult:
    if not ctx.config.image.enabled:
        return ToolResult(name="generate_image", content="Image generation is disabled.", error="image disabled")
    prompt = str(args.get("prompt") or "").strip()
    if not prompt:
        return ToolResult(name="generate_image", content="No image prompt was provided.", error="empty prompt")
    cfg = ctx.config.model_copy(deep=True)
    cfg.image.width = _clamp(args.get("width"), 256, 2048, cfg.image.width)
    cfg.image.height = _clamp(args.get("height"), 256, 2048, cfg.image.height)
    cfg.image.steps = _clamp(args.get("steps"), 1, 60, cfg.image.steps)
    job = _new_job(ctx, "Generate image", "generate:image", "Generating image")
    try:
        attachments = await ctx.comfy.generate_image(prompt, job=job, config=cfg)
        result = ToolResult(
            name="generate_image",
            content=(
                f"Generated an image ({cfg.image.width}×{cfg.image.height}) with {cfg.image.model}. "
                f"It is displayed to the user as {attachments[0].filename if attachments else 'an attachment'}."
            ),
            attachments=attachments,
            meta={"model": cfg.image.model, "prompt": prompt},
        )
    except Exception as exc:
        result = ToolResult(
            name="generate_image",
            content=f"Image generation failed: {exc}",
            error=str(exc),
        )
    _finish_job(job, result)
    return result



def _video_pixel_frame_budget(hardware) -> int:
    """How much 720p-class video work this machine can safely attempt.

    Weights can live in system RAM, but KSampler activations must fit in VRAM.
    The values below are deliberately conservative; they match a working
    1280x720 x 29-frame run on an 8 GB RTX 5060.
    """
    if hardware is None:
        return 28_000_000
    if not getattr(hardware, "gpu_usable", False):
        return 8_000_000
    vram = float(getattr(hardware, "total_vram_gb", 0) or 0)
    if vram < 10:
        return 28_000_000
    if vram < 14:
        return 60_000_000
    if vram < 20:
        return 100_000_000
    return 200_000_000


def fit_video_request(cfg: AppConfig, hardware) -> tuple[AppConfig, list[str]]:
    """Fit resolution/length to available video memory and explain any cap."""
    notes: list[str] = []
    width = max(256, int(cfg.video.width))
    height = max(256, int(cfg.video.height))
    scale = min(1.0, 1280.0 / max(width, height))
    fitted_width = max(256, int(width * scale) // 16 * 16)
    fitted_height = max(256, int(height * scale) // 16 * 16)
    if (fitted_width, fitted_height) != (width, height):
        notes.append(f"Resolution adjusted to {fitted_width}×{fitted_height} to stay within the 1280 px limit.")
    width, height = fitted_width, fitted_height
    if not cfg.video.safe_limits:
        cfg.video.width = width
        cfg.video.height = height
        return cfg, notes
    budget = _video_pixel_frame_budget(hardware)
    max_frames = int(budget / max(1, width * height))
    max_frames = max(9, min(161, max_frames))
    max_frames = max(9, ((max_frames - 1) // 4) * 4 + 1)
    frames = int(cfg.video.frames)
    if frames > max_frames:
        notes.append(
            f"Video capped from {frames} to {max_frames} frames "
            f"({max_frames / max(cfg.video.fps, 1):.1f}s at {cfg.video.fps} fps) to fit this GPU."
        )
        frames = max_frames
    cfg.video.width = width
    cfg.video.height = height
    cfg.video.frames = frames
    return cfg, notes

async def _edit_image(args: dict, ctx: ToolContext) -> ToolResult:
    if not ctx.config.image.enabled:
        return ToolResult(name="edit_image", content="Image tools are disabled.", error="image disabled")
    prompt = str(args.get("prompt") or "").strip()
    if not prompt:
        return ToolResult(name="edit_image", content="Tell me what to change.", error="empty prompt")

    wanted = {str(item) for item in (args.get("attachment_ids") or []) if item}
    sources: list[Path] = []
    for attachment in ctx.attachments:
        if attachment.get("kind") != "image":
            continue
        if wanted and str(attachment.get("id")) not in wanted:
            continue
        path = Path(str(attachment.get("path") or ""))
        if path.is_file():
            sources.append(path)
    if not sources and ctx.last_image_path and ctx.last_image_path.is_file():
        sources = [ctx.last_image_path]
    if not sources:
        return ToolResult(
            name="edit_image",
            content="No image to edit: attach at least one photo first.",
            error="no source image",
        )

    job = _new_job(ctx, "Edit image", "generate:edit", "Editing image")
    try:
        attachments = await ctx.comfy.generate_edit(prompt, sources, job=job)
        result = ToolResult(
            name="edit_image",
            content=(
                f"Edited {len(sources)} image(s) with {ctx.config.edit.model}. "
                f"The result is displayed to the user as {attachments[0].filename if attachments else 'an attachment'}."
            ),
            attachments=attachments,
            meta={"model": ctx.config.edit.model, "prompt": prompt, "sources": len(sources)},
        )
    except Exception as exc:
        result = ToolResult(name="edit_image", content=f"Image editing failed: {exc}", error=str(exc))
    _finish_job(job, result)
    return result


async def _video(args: dict, ctx: ToolContext) -> ToolResult:
    if not ctx.config.video.enabled:
        return ToolResult(name="generate_video", content="Video generation is disabled.", error="video disabled")
    prompt = str(args.get("prompt") or "").strip()
    if not prompt:
        return ToolResult(name="generate_video", content="No video prompt was provided.", error="empty prompt")
    cfg = ctx.config.model_copy(deep=True)
    cfg.video.width = _clamp(args.get("width"), 256, 1280, cfg.video.width)
    cfg.video.height = _clamp(args.get("height"), 256, 1280, cfg.video.height)
    cfg.video.fps = _clamp(args.get("fps"), 4, 60, cfg.video.fps)
    seconds = args.get("seconds")
    if seconds is not None:
        with contextlib.suppress(TypeError, ValueError):
            cfg.video.frames = max(9, min(161, int(float(seconds) * cfg.video.fps) // 4 * 4 + 1))
    cfg, fit_notes = fit_video_request(cfg, getattr(ctx.runtimes, "hw", None))
    job = _new_job(ctx, "Generate video", "generate:video", "Generating video")
    try:
        attachments = await ctx.comfy.generate_video(prompt, job=job, config=cfg)
        result = ToolResult(
            name="generate_video",
            content=(
                f"Generated a {cfg.video.frames / max(cfg.video.fps, 1):.1f}s video at {cfg.video.fps} fps "
                f"with {cfg.video.model}. The player is displayed to the user as "
                f"{attachments[0].filename if attachments else 'an attachment'}."
                + (" " + " ".join(fit_notes) if fit_notes else "")
            ),
            attachments=attachments,
            meta={"model": cfg.video.model, "prompt": prompt},
        )
    except Exception as exc:
        result = ToolResult(
            name="generate_video",
            content=f"Video generation failed: {exc}",
            error=str(exc),
        )
    _finish_job(job, result)
    return result


async def _music(args: dict, ctx: ToolContext) -> ToolResult:
    if not ctx.config.music.enabled:
        return ToolResult(name="generate_music", content="Music generation is disabled.", error="music disabled")
    tags = str(args.get("prompt") or args.get("tags") or "").strip()
    if not tags:
        return ToolResult(name="generate_music", content="No music prompt was provided.", error="empty prompt")
    lyrics = str(args.get("lyrics") or "")
    cfg = ctx.config.model_copy(deep=True)
    cfg.music.duration = _clamp(args.get("duration"), 5, 120, cfg.music.duration)
    cfg.music.bpm = _clamp(args.get("bpm"), 30, 240, cfg.music.bpm)
    job = _new_job(ctx, "Compose music", "generate:music", "Composing music")
    try:
        attachments = await ctx.comfy.generate_music(tags, lyrics=lyrics, job=job, config=cfg)
        result = ToolResult(
            name="generate_music",
            content=(
                f"Composed a {cfg.music.duration}s track with {cfg.music.model}"
                + (" including vocals." if lyrics.strip() else " (instrumental).")
            ),
            attachments=attachments,
            meta={"model": cfg.music.model, "prompt": tags},
        )
    except Exception as exc:
        result = ToolResult(
            name="generate_music",
            content=f"Music generation failed: {exc}",
            error=str(exc),
        )
    _finish_job(job, result)
    return result


async def _speech(args: dict, ctx: ToolContext) -> ToolResult:
    if not ctx.config.audio.enabled or ctx.config.audio.tts_engine == "none":
        return ToolResult(name="text_to_speech", content="Speech is disabled.", error="speech disabled")
    text = str(args.get("text") or "").strip()
    if not text:
        return ToolResult(name="text_to_speech", content="No text was provided.", error="empty text")
    voice = str(args.get("voice") or ctx.config.audio.voice)
    job = _new_job(ctx, "Speak text", "generate:speech", "Synthesizing speech")
    temp = paths.CACHE_DIR / f"tts-{uuid.uuid4().hex}.wav"
    try:
        spoken = await ctx.runtimes.tts(text[:4000], temp, voice)
        attachment = ctx.outputs.save_path(temp, kind="audio", prefix="speech")
        result = ToolResult(
            name="text_to_speech",
            content=f"Spoke the text with {spoken.get('engine')} and attached {attachment.filename}.",
            attachments=[attachment],
            meta={"engine": spoken.get("engine"), "voice": voice},
        )
    except Exception as exc:
        result = ToolResult(name="text_to_speech", content=f"Speech failed: {exc}", error=str(exc))
    finally:
        temp.unlink(missing_ok=True)
    _finish_job(job, result)
    return result


async def _three_d(args: dict, ctx: ToolContext) -> ToolResult:
    if not ctx.config.three_d.enabled:
        return ToolResult(name="generate_3d", content="3D generation is disabled.", error="3d disabled")
    prompt = str(args.get("prompt") or "").strip()
    use_attached = bool(args.get("use_attached_image")) or ctx.last_image_path is not None
    job = _new_job(ctx, "Build 3D model", "generate:3d", "Building 3D model")
    attachments: list[Attachment] = []
    try:
        image_path: Path | None = None
        if use_attached and ctx.last_image_path and ctx.last_image_path.exists():
            image_path = ctx.last_image_path
        elif prompt:
            if not ctx.config.image.enabled:
                raise RuntimeError("An image model is needed to create a 3D preview, but image generation is disabled.")
            image_attachments = await ctx.comfy.generate_image(prompt, job=job)
            attachments.extend(image_attachments)
            if image_attachments:
                image_path = Path(image_attachments[0].path)
        if image_path is None:
            raise RuntimeError("Provide a prompt or attach an image to turn into a 3D model.")
        mesh = await ctx.comfy.generate_3d(image_path, job=job)
        attachments.extend(mesh)
        result = ToolResult(
            name="generate_3d",
            content=(
                f"Created a 3D model with {ctx.config.three_d.model}. "
                "The GLB viewer is displayed to the user."
            ),
            attachments=attachments,
            meta={"model": ctx.config.three_d.model, "prompt": prompt},
        )
    except Exception as exc:
        result = ToolResult(name="generate_3d", content=f"3D generation failed: {exc}", error=str(exc))
    _finish_job(job, result)
    return result


async def _remember(arguments: dict, ctx: ToolContext) -> ToolResult:
    store = ctx.memories
    if store is None or not ctx.config.memory.enabled:
        return ToolResult(name="remember", content="Memory is turned off in settings.", error="memory disabled")
    text = str(arguments.get("text") or "").strip()
    if not text:
        return ToolResult(name="remember", content="Nothing to remember.", error="empty text")
    try:
        item = store.add(text, source="model")
    except ValueError as exc:
        return ToolResult(name="remember", content=str(exc), error=str(exc))
    return ToolResult(
        name="remember",
        content=f"Saved to memory: {item['text']}",
        meta={"memory_id": item["id"], "memory": item["text"]},
    )


async def _forget(arguments: dict, ctx: ToolContext) -> ToolResult:
    store = ctx.memories
    if store is None or not ctx.config.memory.enabled:
        return ToolResult(name="forget_memory", content="Memory is turned off in settings.", error="memory disabled")
    text = str(arguments.get("text") or "").strip()
    removed = store.forget_matching(text)
    if not removed:
        return ToolResult(
            name="forget_memory",
            content=f"No memory matched “{text}”; nothing was deleted.",
            error="not found",
        )
    return ToolResult(name="forget_memory", content=f"Forgot {removed} memory item(s).", meta={"removed": removed})


_DISPATCH = {
    "edit_image": _edit_image,
    "remember": _remember,
    "forget_memory": _forget,
    "web_search": _search,
    "fetch_url": _fetch,
    "generate_image": _image,
    "generate_video": _video,
    "generate_music": _music,
    "text_to_speech": _speech,
    "generate_3d": _three_d,
}


async def execute_tool(name: str, arguments: dict, ctx: ToolContext) -> ToolResult:
    if not ctx.config.tools.allows(name):
        return ToolResult(name=name, content=f"The {name} tool is disabled in settings.", error="disabled")
    handler = _DISPATCH.get(name)
    if not handler:
        return ToolResult(name=name, content=f"Unknown tool: {name}", error="unknown tool")
    if not isinstance(arguments, dict):
        return ToolResult(name=name, content="Tool arguments must be an object.", error="invalid arguments")
    try:
        return await handler(arguments, ctx)
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        return ToolResult(name=name, content=f"The {name} tool failed: {exc}", error=f"{type(exc).__name__}: {exc}")
