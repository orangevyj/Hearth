"""Hugging Face search and import planning.

The launcher offers a small Hub search so a model can be found, checked and
imported without typing a repo path. Detection is deliberately conservative:
Hearth only imports architectures it can already drive, and it says why when
it cannot.
"""

from __future__ import annotations

import re
from typing import Any

import httpx

HF_ENDPOINT = "https://huggingface.co"

_SINGLE_FILE_FAMILIES: tuple[tuple[str, str, str], ...] = (
    ("three_d", "hunyuan3d", r"hunyuan.?3d"),
    ("music", "ace", r"ace[-_]?step"),
    ("image", "flux", r"flux"),
    ("image", "sdxl", r"(sdxl|stable[-_]diffusion|sd[-_]?1\.5|sd15|sd[-_]?2\.1|sd21)"),
)
_SPLIT_FAMILIES: tuple[tuple[str, str, str], ...] = (
    ("music", "ace-xl-sft", r"ace.*xl.*sft|xl_sft"),
    ("music", "ace-xl", r"ace.*xl"),
    ("video", "wan22", r"wan[._-]?2[._-]?2"),
    ("video", "wan", r"wan[._-]?2[._-]?1|wan2"),
)

FAMILY_LABELS = {
    ("image", "sdxl"): "Images · SDXL/SD checkpoint",
    ("image", "flux"): "Images · FLUX checkpoint",
    ("video", "wan"): "Video · Wan 2.1",
    ("video", "wan22"): "Video · Wan 2.2",
    ("three_d", "hunyuan3d"): "3D · Hunyuan3D",
    ("music", "ace"): "Music · ACE-Step",
    ("music", "ace-xl"): "Music · ACE-Step XL turbo",
    ("music", "ace-xl-sft"): "Music · ACE-Step XL SFT",
}


def family_label(modality: str, workflow: str) -> str:
    return FAMILY_LABELS.get((modality, workflow), f"{modality} · {workflow}")


def _size_bytes(entry: dict) -> int:
    if entry.get("size"):
        return int(entry["size"])
    lfs = entry.get("lfs") or {}
    return int(lfs.get("size") or 0)


def _gb(size: int) -> float:
    return round(size / 1024**3, 2)


def search_models(query: str, limit: int = 12, endpoint: str | None = None) -> list[dict]:
    """Search the Hub and annotate each hit with what Hearth could do with it."""
    query = (query or "").strip()
    if not query:
        return []
    params = {
        "search": query,
        "limit": max(1, min(int(limit), 25)),
        "sort": "downloads",
        "direction": -1,
        "full": "true",
    }
    with httpx.Client(timeout=20.0, follow_redirects=True) as client:
        response = client.get(f"{(endpoint or HF_ENDPOINT).rstrip('/')}/api/models", params=params)
        response.raise_for_status()
        data = response.json()
    results: list[dict] = []
    for item in data if isinstance(data, list) else []:
        tags = [str(tag) for tag in item.get("tags") or []]
        detected = detect_family(str(item.get("id") or ""), tags, item.get("pipeline_tag") or "")
        results.append(
            {
                "id": item.get("id"),
                "downloads": item.get("downloads") or 0,
                "likes": item.get("likes") or 0,
                "pipeline_tag": item.get("pipeline_tag") or "",
                "gated": bool(item.get("gated")),
                "tags": tags[:8],
                "detected": detected,
            }
        )
    return results


def detect_family(repo: str, tags: list[str] | None = None, pipeline_tag: str = "") -> dict | None:
    """Guess the (modality, workflow) pair from a repo name, tags and pipeline tag."""
    haystack = " ".join([repo, pipeline_tag, *(tags or [])]).lower()
    for modality, workflow, pattern in _SPLIT_FAMILIES:
        if re.search(pattern, haystack):
            # Split families are only offered when the repo also looks like a
            # ComfyUI split layout; the file listing confirms that later.
            return {"modality": modality, "workflow": workflow, "label": family_label(modality, workflow)}
    for modality, workflow, pattern in _SINGLE_FILE_FAMILIES:
        if re.search(pattern, haystack):
            return {"modality": modality, "workflow": workflow, "label": family_label(modality, workflow)}
    return None


def repo_files(repo: str, endpoint: str | None = None) -> dict:
    """The safetensors files of a repo, with sizes the launcher can show."""
    repo = (repo or "").strip()
    if not repo or "/" not in repo:
        raise ValueError("Use a repository id such as Comfy-Org/ACE-Step-1.5")
    with httpx.Client(timeout=25.0, follow_redirects=True) as client:
        response = client.get(f"{(endpoint or HF_ENDPOINT).rstrip('/')}/api/models/{repo}", params={"blobs": "true"})
        if response.status_code == 404:
            raise ValueError(f"No such repository: {repo}")
        if response.status_code in {401, 403}:
            raise ValueError(
                f"{repo} is private or gated. Accept its license on the Hub, then fetch it manually."
            )
        response.raise_for_status()
        meta = response.json()
    files = []
    for entry in meta.get("siblings") or []:
        name = str(entry.get("rfilename") or "")
        if not name.endswith(".safetensors"):
            continue
        size = _size_bytes(entry)
        files.append({"filename": name, "size_gb": _gb(size), "size_bytes": size})
    return {
        "repo": meta.get("id") or repo,
        "gated": bool(meta.get("gated")),
        "pipeline_tag": meta.get("pipeline_tag") or "",
        "tags": [str(tag) for tag in meta.get("tags") or []][:12],
        "license": (meta.get("cardData") or {}).get("license") or "",
        "files": sorted(files, key=lambda item: item["size_gb"], reverse=True),
    }


def _dest_for(filename: str) -> str:
    """Repo paths use split_files/<kind>/…; Hearth stores <kind>/…."""
    parts = filename.split("/")
    if parts and parts[0] in {"split_files", "split"}:
        parts = parts[1:]
    return "/".join(parts)


def _normalise_entry(entry: dict) -> dict:
    # The listing already carries size_gb; raw Hub entries carry size/lfs.
    size_gb = entry.get("size_gb")
    if size_gb is None:
        size_gb = _gb(_size_bytes(entry))
    return {
        "repo": entry["repo"],
        "filename": entry["filename"],
        "dest": _dest_for(entry["filename"]),
        "size_gb": round(float(size_gb), 2),
        "role": entry["role"],
        "source": "hf",
    }


# Variants that are not the plain text-to-video/base model. Importing one of
# these by accident would download tens of gigabytes of the wrong weights.
_NOT_THE_BASE_MODEL = (
    "lora",
    "fun",
    "vace",
    "animate",
    "s2v",
    "edit",
    "control",
    "inpaint",
    "upscale",
    "canny",
    "depth",
    "pose",
    "audio_encoder",
    "fill",
    "redux",
    "kontext",
    "outpaint",
)

# Files that are parts of a pipeline rather than the diffusion checkpoint.
_NOT_A_CHECKPOINT = ("vae", "clip_l", "clip_g", "t5xxl", "ae.safetensors", "text_encoder")


def _in_dir(files: list[dict], kind: str) -> list[dict]:
    return [item for item in files if f"/{kind}/" in f"/{item['filename'].lower()}"]


def _plausible(candidates: list[dict]) -> list[dict]:
    """Drop the fine-tune variants; the basename decides, not the folder."""
    return [
        item
        for item in candidates
        if not any(marker in item["filename"].rsplit("/", 1)[-1].lower() for marker in _NOT_THE_BASE_MODEL)
    ]


def _checkpoint_candidates(files: list[dict]) -> list[dict]:
    usable = []
    for item in files:
        name = item["filename"].rsplit("/", 1)[-1].lower()
        if any(marker in name for marker in _NOT_A_CHECKPOINT):
            continue
        usable.append(item)
    return _plausible(usable)


def _only_one(candidates: list[dict], what: str, repo: str) -> dict:
    if not candidates:
        raise ValueError(f"{repo} has no {what} file, so the split layout is incomplete.")
    if len(candidates) > 1:
        names = ", ".join(item["filename"].rsplit("/", 1)[-1] for item in candidates[:5])
        raise ValueError(
            f"{repo} bundles several {what} variants ({names}). "
            "Pick the exact files with the manual fields so the right weights get downloaded."
        )
    return candidates[0]


def plan_import(repo: str, files: list[dict], detected: dict | None = None) -> dict:
    """Turn a repo listing into a custom-model payload, or explain the refusal."""
    repo = (repo or "").strip()
    by_name = {item["filename"]: item for item in files}
    detected = detected or detect_family(repo)
    if not detected:
        raise ValueError(
            "Hearth has no workflow for this architecture, so it cannot drive it. "
            "Supported: SDXL/FLUX checkpoints, Wan 2.1/2.2, Hunyuan3D and ACE-Step."
        )
    modality, workflow = detected["modality"], detected["workflow"]

    def pick(predicate) -> dict | None:
        for name, entry in by_name.items():
            if predicate(name.lower()):
                return entry
        return None

    def in_dir(kind: str) -> dict | None:
        return pick(lambda name: f"/{kind}/" in f"/{name}")

    chosen: list[tuple[dict, str]] = []
    if workflow in {"wan", "wan22"}:
        diffusion = _only_one(
            _plausible(_in_dir(files, "diffusion_models") or _in_dir(files, "unet")), "diffusion model", repo
        )
        encoder = _only_one(_plausible(_in_dir(files, "text_encoders") or _in_dir(files, "clip")), "text encoder", repo)
        vae = _only_one(_in_dir(files, "vae"), "VAE", repo)
        chosen = [(diffusion, "diffusion"), (encoder, "text_encoder"), (vae, "vae")]
    elif workflow in {"ace-xl", "ace-xl-sft"}:
        want = "sft" if workflow == "ace-xl-sft" else "turbo"
        diffusion = _only_one(
            [item for item in _in_dir(files, "diffusion_models") if want in item["filename"].lower()],
            f"{want} diffusion model",
            repo,
        )
        small = _only_one([item for item in files if "0.6b" in item["filename"].lower()], "qwen 0.6B encoder", repo)
        large = _only_one([item for item in files if "4b" in item["filename"].lower()], "qwen 4B encoder", repo)
        vae = _only_one(_in_dir(files, "vae"), "VAE", repo)
        chosen = [(diffusion, "diffusion"), (small, "encoder_small"), (large, "encoder_large"), (vae, "vae")]
    else:
        candidates = _checkpoint_candidates(_in_dir(files, "checkpoints")) or _checkpoint_candidates(
            _in_dir(files, "diffusion_models")
        )
        if not candidates:
            candidates = _checkpoint_candidates([item for item in files if "/" not in item["filename"]])
        checkpoint = _only_one(candidates, "checkpoint", repo)
        chosen = [(checkpoint, "checkpoint")]

    name = repo.split("/")[-1].replace("_", " ").replace("-", " ").strip() or repo
    files_payload = [_normalise_entry({**entry, "repo": repo, "role": role}) for entry, role in chosen]
    return {
        "name": name,
        "modality": modality,
        "workflow": workflow,
        "description": f"Imported from {repo}.",
        "files": files_payload,
        "license": "",
    }


def import_preview(repo: str, endpoint: str | None = None) -> dict:
    """Search-result detail: what would be imported, and what it would cost."""
    listing = repo_files(repo, endpoint)
    detected = detect_family(listing["repo"], listing["tags"], listing["pipeline_tag"])
    payload: dict[str, Any] = {
        "repo": listing["repo"],
        "files": listing["files"],
        "detected": detected,
        "gated": listing["gated"],
        "license": listing["license"],
        "pipeline_tag": listing["pipeline_tag"],
        "importable": False,
        "reason": "",
        "plan": None,
    }
    if listing["gated"]:
        payload["reason"] = "This repository is gated; accept its license on the Hub and download it manually."
        return payload
    try:
        plan = plan_import(listing["repo"], listing["files"], detected)
    except ValueError as exc:
        payload["reason"] = str(exc)
        return payload
    payload["importable"] = True
    payload["plan"] = plan
    payload["size_gb"] = round(sum(item["size_gb"] for item in plan["files"]), 2)
    return payload
