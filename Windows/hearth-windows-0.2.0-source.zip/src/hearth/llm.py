"""Text backends: Ollama native, OpenAI-compatible, and a demo streamer.

The canonical message format used by the rest of Hearth is OpenAI-like:
``{"role": "assistant", "tool_calls": [...]}`` with JSON-string arguments.
Adapters translate to each backend's dialect.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

import httpx

from .config import AppConfig, TextConfig

TOOL_CALL_RE = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.DOTALL)
TOOL_FENCE_RE = re.compile(r"```(?:tool|json)\s*(\{.*?\})\s*```", re.DOTALL)


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict
    raw_arguments: str = ""

    def to_openai(self) -> dict:
        return {
            "id": self.id,
            "type": "function",
            "function": {
                "name": self.name,
                "arguments": json.dumps(self.arguments, ensure_ascii=False),
            },
        }

    def to_dict(self) -> dict:
        return {"id": self.id, "name": self.name, "arguments": self.arguments}

    def to_ollama(self) -> dict:
        return {"function": {"name": self.name, "arguments": self.arguments}}


@dataclass
class Usage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    duration_ms: int = 0

    def to_dict(self) -> dict:
        return {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "duration_ms": self.duration_ms,
        }


@dataclass
class StreamEvent:
    type: str  # delta | thinking | tool_calls | done | error
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: Usage | None = None
    error: str = ""
    retryable: bool = False
    meta: dict = field(default_factory=dict)


def _call_id() -> str:
    return "call_" + uuid.uuid4().hex[:10]


def normalize_arguments(value: Any) -> tuple[dict, str]:
    if isinstance(value, dict):
        return value, json.dumps(value, ensure_ascii=False)
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed, value
        except json.JSONDecodeError:
            pass
        return {}, value
    return {}, str(value or "")


def parse_prompt_tool_calls(content: str) -> tuple[str, list[ToolCall]]:
    """Extract ``<tool_call>...</tool_call>`` blocks from model text."""
    calls: list[ToolCall] = []
    spans: list[tuple[int, int]] = []
    for match in TOOL_CALL_RE.finditer(content):
        try:
            payload = json.loads(match.group(1))
        except json.JSONDecodeError:
            continue
        name = payload.get("name") or payload.get("tool")
        args = payload.get("arguments") or payload.get("parameters") or payload.get("args") or {}
        if not name:
            continue
        arguments, raw = normalize_arguments(args)
        calls.append(ToolCall(id=_call_id(), name=str(name), arguments=arguments, raw_arguments=raw))
        spans.append(match.span())
    if not calls:
        for match in TOOL_FENCE_RE.finditer(content):
            try:
                payload = json.loads(match.group(1))
            except json.JSONDecodeError:
                continue
            if "name" not in payload and "tool" not in payload:
                continue
            name = payload.get("name") or payload.get("tool")
            args = payload.get("arguments") or payload.get("parameters") or payload.get("args") or {}
            arguments, raw = normalize_arguments(args)
            calls.append(ToolCall(id=_call_id(), name=str(name), arguments=arguments, raw_arguments=raw))
            spans.append(match.span())
    cleaned = content
    for start, end in reversed(spans):
        cleaned = cleaned[:start] + cleaned[end:]
    return cleaned.strip(), calls


def prompt_tool_protocol(tools: list[dict]) -> str:
    schemas = []
    for tool in tools:
        fn = tool.get("function", {})
        schemas.append(
            {
                "name": fn.get("name"),
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {}),
            }
        )
    return (
        "TOOL PROTOCOL\n"
        "You can call the following tools. To call a tool, output exactly one block:\n"
        '<tool_call>{"name":"tool_name","arguments":{"key":"value"}}</tool_call>\n'
        "Do not wrap tool calls in code fences. Wait for the tool result before continuing. "
        "If no tool is needed, answer normally.\n"
        "Available tools:\n"
        + json.dumps(schemas, ensure_ascii=False, indent=2)
    )


class BaseLLM:
    name = "base"

    async def stream(
        self,
        messages: list[dict],
        tools: list[dict] | None,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int | None = None,
        think: bool | None = None,
    ) -> AsyncIterator[StreamEvent]:
        raise NotImplementedError

    async def capabilities(self) -> set[str]:
        return {"completion"}


class DemoLLM(BaseLLM):
    name = "demo"

    async def stream(
        self,
        messages: list[dict],
        tools: list[dict] | None,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int | None = None,
        think: bool | None = None,
    ) -> AsyncIterator[StreamEvent]:
        last_user = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
        text = (
            "### Hearth is in demo mode\n\n"
            "No text model is connected yet, so this reply is generated locally by the app itself — "
            "not by an AI model.\n\n"
            f"You said: “{str(last_user)[:240]}”\n\n"
            "To get a real local assistant:\n\n"
            "1. Open **Launcher → Presets** and install **Fast**, **Balanced**, or **Smart**. Hearth will "
            "download Ollama, a Qwen3.5 model, ComfyUI and the media models for the tiers you pick.\n"
            "2. Or connect an existing OpenAI-compatible server (LM Studio, llama.cpp, vLLM) under "
            "**Launcher → Models → Text**.\n"
            "3. Click **Start server** in the launcher, then come back here.\n\n"
            "Everything else — image, video, music, speech, 3D and web search — is wired up and will light "
            "up as each backend finishes installing."
        )
        started = time.monotonic()
        for index in range(0, len(text), 32):
            await asyncio.sleep(0.012)
            yield StreamEvent(type="delta", text=text[index : index + 32])
        approx = max(1, len(text) // 4)
        yield StreamEvent(
            type="done",
            usage=Usage(prompt_tokens=0, completion_tokens=approx, total_tokens=approx, duration_ms=int((time.monotonic() - started) * 1000)),
        )


class OllamaLLM(BaseLLM):
    name = "ollama"

    def __init__(self, config: TextConfig, runtimes=None):
        self.config = config
        base = (config.base_url or "http://127.0.0.1:11434").rstrip("/")
        if base.endswith("/v1"):
            base = base[:-3]
        self.base_url = base
        self.runtimes = runtimes

    def _messages(self, messages: list[dict]) -> list[dict]:
        converted: list[dict] = []
        for message in messages:
            role = message.get("role")
            content = message.get("content") or ""
            if role == "assistant" and message.get("tool_calls"):
                calls = []
                for call in message["tool_calls"]:
                    fn = call.get("function", {})
                    args, _ = normalize_arguments(fn.get("arguments"))
                    calls.append({"function": {"name": fn.get("name", ""), "arguments": args}})
                converted.append({"role": "assistant", "content": content, "tool_calls": calls})
            elif role == "tool":
                entry = {"role": "tool", "content": content}
                if message.get("tool_name"):
                    entry["tool_name"] = message["tool_name"]
                converted.append(entry)
            else:
                entry = {"role": role, "content": content}
                if message.get("images"):
                    # Ollama's native API expects raw base64 strings, not objects.
                    entry["images"] = [
                        image.get("data", "") if isinstance(image, dict) else str(image)
                        for image in message["images"]
                    ]
                converted.append(entry)
        return converted

    async def stream(
        self,
        messages: list[dict],
        tools: list[dict] | None,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int | None = None,
        think: bool | None = None,
    ) -> AsyncIterator[StreamEvent]:
        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": self._messages(messages),
            "stream": True,
            "options": {
                "temperature": temperature,
                "top_p": top_p,
                "num_ctx": self.config.context_tokens,
            },
            "keep_alive": self.config.keep_alive,
            "think": self.config.thinking if think is None else bool(think),
        }
        if max_tokens:
            payload["options"]["num_predict"] = max_tokens
        if tools:
            payload["tools"] = tools
        started = time.monotonic()
        timeout = httpx.Timeout(connect=20.0, read=None, write=60.0, pool=30.0)
        url = f"{self.base_url}/api/chat"
        try:
            async with (
                httpx.AsyncClient(timeout=timeout) as client,
                client.stream("POST", url, json=payload) as response,
            ):
                if response.status_code >= 400:
                    body = (await response.aread()).decode(errors="replace")
                    yield StreamEvent(
                        type="error",
                        error=f"Ollama HTTP {response.status_code}: {body[:500]}",
                        retryable=("tool" in body.lower() and response.status_code in {400, 404, 422}),
                    )
                    return
                usage = Usage()
                async for line in response.aiter_lines():
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if data.get("error"):
                        yield StreamEvent(type="error", error=str(data["error"]))
                        return
                    message = data.get("message") or {}
                    thinking = message.get("thinking")
                    if thinking:
                        yield StreamEvent(type="thinking", text=str(thinking))
                    content = message.get("content")
                    if content:
                        yield StreamEvent(type="delta", text=str(content))
                    raw_calls = message.get("tool_calls") or []
                    calls: list[ToolCall] = []
                    for raw in raw_calls:
                        fn = raw.get("function") or {}
                        args, raw_args = normalize_arguments(fn.get("arguments"))
                        calls.append(
                            ToolCall(
                                id=raw.get("id") or _call_id(),
                                name=str(fn.get("name") or ""),
                                arguments=args,
                                raw_arguments=raw_args,
                            )
                        )
                    if calls:
                        yield StreamEvent(type="tool_calls", tool_calls=calls)
                    if data.get("done"):
                        usage.prompt_tokens = int(data.get("prompt_eval_count") or 0)
                        usage.completion_tokens = int(data.get("eval_count") or 0)
                        usage.total_tokens = usage.prompt_tokens + usage.completion_tokens
                        duration_ns = int(data.get("total_duration") or 0)
                        usage.duration_ms = int(duration_ns / 1_000_000) if duration_ns else int((time.monotonic() - started) * 1000)
                        yield StreamEvent(type="done", usage=usage)
                        return
        except (httpx.HTTPError, OSError) as exc:
            yield StreamEvent(type="error", error=f"Could not reach Ollama: {exc}")
        except asyncio.CancelledError:
            raise

    async def capabilities(self) -> set[str]:
        if not self.runtimes:
            return {"completion", "tools"}
        try:
            info = await self.runtimes.ollama_show(self.config.model)
        except Exception:
            return {"completion"}
        capabilities = set(info.get("capabilities") or [])
        if not capabilities:
            capabilities = {"completion"}
        return capabilities


def _openai_messages(messages: list[dict]) -> list[dict]:
    converted: list[dict] = []
    for message in messages:
        if message.get("role") == "user" and message.get("images"):
            parts = []
            if message.get("content"):
                parts.append({"type": "text", "text": message["content"]})
            for image in message["images"]:
                if isinstance(image, dict):
                    mime = image.get("mime", "image/png")
                    data = image.get("data", "")
                else:
                    mime, data = "image/png", str(image)
                parts.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{data}"}})
            converted.append({"role": "user", "content": parts})
        else:
            converted.append({key: value for key, value in message.items() if key != "images"})
    return converted


class OpenAILLM(BaseLLM):
    name = "openai"

    @staticmethod
    def _reasoning_payload(think: bool | None) -> dict:
        """The OpenAI-style switch for reasoning models.

        ``None`` means "leave it to the server", which keeps the field out of
        the request so servers that never heard of it are unaffected.
        """
        if think is None:
            return {}
        return {"reasoning_effort": "medium" if think else "none"}

    def __init__(self, config: TextConfig):
        self.config = config
        base = (config.base_url or "http://127.0.0.1:1234/v1").rstrip("/")
        if base.endswith("/v1"):
            self.url = base + "/chat/completions"
        elif base.endswith("/chat/completions"):
            self.url = base
        else:
            self.url = base + "/v1/chat/completions"
        self.headers = {"Content-Type": "application/json"}
        if config.api_key:
            self.headers["Authorization"] = f"Bearer {config.api_key}"

    async def stream(
        self,
        messages: list[dict],
        tools: list[dict] | None,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int | None = None,
        think: bool | None = None,
    ) -> AsyncIterator[StreamEvent]:
        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": _openai_messages(messages),
            "stream": True,
            "temperature": temperature,
            "top_p": top_p,
        }
        if max_tokens:
            payload["max_tokens"] = max_tokens
        payload.update(self._reasoning_payload(think))
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        started = time.monotonic()
        timeout = httpx.Timeout(connect=20.0, read=None, write=60.0, pool=30.0)
        tool_buffers: dict[int, dict] = {}
        usage = Usage()
        try:
            async with (
                httpx.AsyncClient(timeout=timeout, headers=self.headers) as client,
                client.stream("POST", self.url, json=payload) as response,
            ):
                if response.status_code >= 400:
                    body = (await response.aread()).decode(errors="replace")
                    lowered = body.lower()
                    yield StreamEvent(
                        type="error",
                        error=f"Text backend HTTP {response.status_code}: {body[:600]}",
                        retryable=("tool" in lowered and "support" in lowered) or "tools" in lowered,
                    )
                    return
                content_type = response.headers.get("content-type", "")
                if "text/event-stream" not in content_type:
                    body = (await response.aread()).decode(errors="replace")
                    try:
                        data = json.loads(body)
                    except json.JSONDecodeError:
                        yield StreamEvent(type="error", error=f"Unexpected response: {body[:400]}")
                        return
                    message = (data.get("choices") or [{}])[0].get("message") or {}
                    if message.get("content"):
                        yield StreamEvent(type="delta", text=message["content"])
                    calls = []
                    for raw in message.get("tool_calls") or []:
                        fn = raw.get("function") or {}
                        args, raw_args = normalize_arguments(fn.get("arguments"))
                        calls.append(
                            ToolCall(
                                id=raw.get("id") or _call_id(),
                                name=fn.get("name", ""),
                                arguments=args,
                                raw_arguments=raw_args,
                            )
                        )
                    if calls:
                        yield StreamEvent(type="tool_calls", tool_calls=calls)
                    if data.get("usage"):
                        usage = _usage_from_openai(data["usage"], started)
                    yield StreamEvent(type="done", usage=usage)
                    return
                done = False
                async for line in response.aiter_lines():
                    if not line:
                        continue
                    if line.startswith(":"):
                        continue
                    if not line.startswith("data:"):
                        continue
                    data_text = line[5:].strip()
                    if data_text == "[DONE]":
                        done = True
                        break
                    try:
                        data = json.loads(data_text)
                    except json.JSONDecodeError:
                        continue
                    if data.get("error"):
                        message = data["error"] if isinstance(data["error"], str) else data["error"].get("message", "")
                        yield StreamEvent(type="error", error=str(message))
                        return
                    choice = (data.get("choices") or [{}])[0]
                    delta = choice.get("delta") or {}
                    if delta.get("reasoning_content"):
                        yield StreamEvent(type="thinking", text=str(delta["reasoning_content"]))
                    if delta.get("content"):
                        yield StreamEvent(type="delta", text=str(delta["content"]))
                    for raw in delta.get("tool_calls") or []:
                        index = int(raw.get("index", 0))
                        buffer = tool_buffers.setdefault(index, {"id": "", "name": "", "arguments": ""})
                        if raw.get("id"):
                            buffer["id"] = raw["id"]
                        fn = raw.get("function") or {}
                        if fn.get("name"):
                            buffer["name"] += fn["name"]
                        if fn.get("arguments"):
                            buffer["arguments"] += fn["arguments"]
                    if data.get("usage"):
                        usage = _usage_from_openai(data["usage"], started)
                    if choice.get("finish_reason"):
                        pass
                calls = []
                for _, buffer in sorted(tool_buffers.items()):
                    args, raw_args = normalize_arguments(buffer["arguments"])
                    calls.append(
                        ToolCall(
                            id=buffer["id"] or _call_id(),
                            name=buffer["name"],
                            arguments=args,
                            raw_arguments=raw_args,
                        )
                    )
                if calls:
                    yield StreamEvent(type="tool_calls", tool_calls=calls)
                if not usage.duration_ms:
                    usage.duration_ms = int((time.monotonic() - started) * 1000)
                if not done:
                    # Some servers close the stream without [DONE]; that is fine.
                    pass
                yield StreamEvent(type="done", usage=usage)
        except (httpx.HTTPError, OSError) as exc:
            yield StreamEvent(type="error", error=f"Could not reach the text backend: {exc}")
        except asyncio.CancelledError:
            raise

    async def capabilities(self) -> set[str]:
        return {"completion", "tools"}


def _usage_from_openai(usage: dict, started: float) -> Usage:
    prompt = int(usage.get("prompt_tokens") or 0)
    completion = int(usage.get("completion_tokens") or 0)
    total = int(usage.get("total_tokens") or (prompt + completion))
    return Usage(
        prompt_tokens=prompt,
        completion_tokens=completion,
        total_tokens=total,
        duration_ms=int((time.monotonic() - started) * 1000),
    )


def build_llm(config: AppConfig, runtimes=None) -> BaseLLM:
    if config.text.backend == "demo":
        return DemoLLM()
    if config.text.backend == "openai":
        return OpenAILLM(config.text)
    return OllamaLLM(config.text, runtimes=runtimes)
