"""Filesystem locations used by Hearth.

Everything is XDG-friendly by default, but can be redirected with the
HEARTH_CONFIG_DIR / HEARTH_DATA_DIR / HEARTH_CACHE_DIR environment variables
(which is also how the test suite keeps itself out of real user state).
"""

from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "hearth"
PROJECT_ROOT = Path(__file__).resolve().parents[2]
WEB_DIR = Path(os.environ.get("HEARTH_WEB_DIR", PROJECT_ROOT / "web"))


def _xdg(env_var: str, fallback: Path) -> Path:
    value = os.environ.get(env_var)
    if value:
        return Path(value).expanduser()
    return fallback


def default_dirs(is_windows: bool | None = None) -> tuple[Path, Path, Path]:
    """Where config, data and cache live when nothing overrides them.

    Windows follows its own convention (%APPDATA% / %LOCALAPPDATA%) so Hearth
    behaves like a normal Windows app; everything else stays XDG.
    """
    windows = (os.name == "nt") if is_windows is None else is_windows
    home = Path.home()
    if windows:
        roaming = Path(os.environ.get("APPDATA") or home / "AppData" / "Roaming")
        local = Path(os.environ.get("LOCALAPPDATA") or home / "AppData" / "Local")
        return (roaming / "Hearth", local / "Hearth", local / "Hearth" / "Cache")
    return (
        home / ".config" / APP_NAME,
        home / ".local" / "share" / APP_NAME,
        home / ".cache" / APP_NAME,
    )


_default_config, _default_data, _default_cache = default_dirs()
CONFIG_DIR = _xdg("HEARTH_CONFIG_DIR", _default_config)
DATA_DIR = _xdg("HEARTH_DATA_DIR", _default_data)
CACHE_DIR = _xdg("HEARTH_CACHE_DIR", _default_cache)

CONFIG_FILE = CONFIG_DIR / "config.json"
CUSTOM_MODELS_FILE = CONFIG_DIR / "custom_models.json"
CUSTOM_PRESETS_FILE = CONFIG_DIR / "custom_presets.json"
MEMORY_FILE = DATA_DIR / "memories.json"
ACCOUNTS_FILE = CONFIG_DIR / "accounts.json"
DB_FILE = DATA_DIR / "hearth.db"

OUTPUTS_DIR = DATA_DIR / "outputs"
UPLOADS_DIR = DATA_DIR / "uploads"
MODELS_DIR = DATA_DIR / "models"
CLIENTS_DIR = DATA_DIR / "clients"
RUNTIMES_DIR = DATA_DIR / "runtimes"
LOGS_DIR = DATA_DIR / "logs"
JOBS_DIR = DATA_DIR / "jobs"


def ensure_dirs() -> None:
    for directory in (
        CONFIG_DIR,
        DATA_DIR,
        CACHE_DIR,
        OUTPUTS_DIR,
        UPLOADS_DIR,
        MODELS_DIR,
        CLIENTS_DIR,
        RUNTIMES_DIR,
        LOGS_DIR,
        JOBS_DIR,
    ):
        directory.mkdir(parents=True, exist_ok=True)


def safe_join(root: Path, *parts: str) -> Path:
    """Join untrusted path parts beneath *root*, refusing traversal."""
    root = root.resolve()
    candidate = root.joinpath(*parts).resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError("path escapes its root")
    return candidate
