"""Async subprocess helpers that stream output into a job log."""

from __future__ import annotations

import asyncio
import contextlib
import os
import shlex
import signal
import subprocess
from pathlib import Path

from . import osutil
from .downloader import JobCancelled
from .jobs import Job


async def _terminate(proc: asyncio.subprocess.Process) -> None:
    """Stop a command and everything it spawned, on either platform."""
    if proc.returncode is not None:
        return
    if osutil.IS_WINDOWS:
        with contextlib.suppress(OSError, subprocess.SubprocessError):
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, timeout=15)
        with contextlib.suppress(asyncio.TimeoutError, ProcessLookupError):
            await asyncio.wait_for(proc.wait(), timeout=8)
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        await asyncio.wait_for(proc.wait(), timeout=8)
    except TimeoutError:
        with contextlib.suppress(ProcessLookupError):
            os.killpg(proc.pid, signal.SIGKILL)


async def run_command(
    command: list[str],
    *,
    cwd: Path | str | None = None,
    env: dict[str, str] | None = None,
    job: Job | None = None,
    label: str = "",
    timeout: float | None = None,
) -> int:
    """Run a command, streaming combined stdout/stderr to the job log."""
    command = [str(part) for part in command]
    if job:
        job.log(f"$ {' '.join(shlex.quote(part) for part in command)}")
        if label:
            job.log(label)
    merged_env = {**os.environ, **(env or {})}
    try:
        proc = await asyncio.create_subprocess_exec(
            *command,
            cwd=str(cwd) if cwd else None,
            env=merged_env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            **osutil.spawn_kwargs(),
        )
    except FileNotFoundError as exc:
        raise RuntimeError(f"command not found: {command[0]}") from exc

    async def pump() -> None:
        assert proc.stdout is not None
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            if job:
                job.log(line.decode(errors="replace").rstrip())

    pump_task = asyncio.create_task(pump())
    wait_task = asyncio.create_task(proc.wait())
    started = asyncio.get_running_loop().time()
    try:
        while not wait_task.done():
            if job and job.cancel_event.is_set():
                await _terminate(proc)
                raise JobCancelled("cancelled")
            if timeout is not None and asyncio.get_running_loop().time() - started > timeout:
                await _terminate(proc)
                raise TimeoutError(f"command timed out after {timeout}s")
            await asyncio.sleep(0.2)
        code = await wait_task
    finally:
        if not pump_task.done():
            try:
                await asyncio.wait_for(pump_task, timeout=5)
            except (TimeoutError, asyncio.CancelledError):
                pump_task.cancel()
        if wait_task.done() and not pump_task.done():
            pump_task.cancel()
    if job:
        job.log(f"Command exited with {code}.")
    return code


async def run_checked(*args, **kwargs) -> None:
    code = await run_command(*args, **kwargs)
    if code != 0:
        raise RuntimeError(f"command failed with exit code {code}")


async def run_capture(
    command: list[str],
    *,
    cwd: Path | str | None = None,
    env: dict[str, str] | None = None,
    job: Job | None = None,
    timeout: float | None = None,
) -> tuple[int, str, str]:
    """Run a command and capture stdout/stderr separately (for JSON results)."""
    command = [str(part) for part in command]
    if job:
        job.log(f"$ {' '.join(shlex.quote(part) for part in command)}")
    merged_env = {**os.environ, **(env or {})}
    proc = await asyncio.create_subprocess_exec(
        *command,
        cwd=str(cwd) if cwd else None,
        env=merged_env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        **osutil.spawn_kwargs(),
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except TimeoutError:
        await _terminate(proc)
        raise
    return proc.returncode or 0, stdout.decode(errors="replace"), stderr.decode(errors="replace")

