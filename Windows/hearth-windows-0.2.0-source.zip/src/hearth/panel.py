"""Remote access to the server panel.

The machine itself needs no login. Another device can reach the launcher's
settings only after presenting the access code that was set on the server —
the code is stored as a PBKDF2 hash, and a successful login gets an in-memory
session cookie.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
import time

CODE_ITERATIONS = 200_000
SESSION_HOURS = 12


def _hash(code: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", code.encode("utf-8"), salt.encode("utf-8"), CODE_ITERATIONS
    ).hex()


class PanelAccess:
    def __init__(self, config_store):
        self.config_store = config_store
        self._sessions: dict[str, float] = {}

    # -- the code ----------------------------------------------------
    @property
    def configured(self) -> bool:
        server = self.config_store.config.server
        return bool(getattr(server, "panel_code_hash", ""))

    def set_code(self, code: str) -> None:
        code = (code or "").strip()
        if len(code) < 4:
            raise ValueError("Use at least 4 characters for the panel code")
        salt = secrets.token_urlsafe(16)
        self.config_store.update(
            {"server": {"panel_code_salt": salt, "panel_code_hash": _hash(code, salt)}}
        )
        self._sessions.clear()

    def clear_code(self) -> None:
        self.config_store.update({"server": {"panel_code_salt": "", "panel_code_hash": ""}})
        self._sessions.clear()

    def verify(self, code: str) -> bool:
        server = self.config_store.config.server
        stored = getattr(server, "panel_code_hash", "")
        salt = getattr(server, "panel_code_salt", "")
        if not stored or not salt:
            return False
        return hmac.compare_digest(_hash((code or "").strip(), salt), stored)

    # -- sessions ----------------------------------------------------
    def login(self, code: str) -> str | None:
        if not self.verify(code):
            return None
        token = secrets.token_urlsafe(32)
        self._sessions[token] = time.time() + SESSION_HOURS * 3600
        return token

    def check(self, token: str | None) -> bool:
        if not token:
            return False
        expiry = self._sessions.get(token)
        if not expiry:
            return False
        if expiry < time.time():
            self._sessions.pop(token, None)
            return False
        return True

    def logout(self, token: str | None) -> None:
        if token:
            self._sessions.pop(token, None)
