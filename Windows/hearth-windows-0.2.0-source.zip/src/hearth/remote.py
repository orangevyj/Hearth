"""What a remote client may do, and what the server tells it about itself.

The server is the authority: a client asks for its capabilities, renders only
what it is allowed to see, and every request it makes is checked here again.
"""

from __future__ import annotations

import re
from typing import Any

MEDIA_PATHS = {
    "image": ("generate_image",),
    "video": ("generate_video",),
    "music": ("generate_music",),
    "three_d": ("generate_3d",),
}

# Endpoints a remote client may never touch, whatever its permissions.
ADMIN_ONLY = (
    re.compile(r"^/api/server(/|$)"),
    re.compile(r"^/api/runtimes(/|$)"),
    re.compile(r"^/api/hardware(/|$)"),
    re.compile(r"^/api/sources(/|$)"),
    re.compile(r"^/api/models/[^/]+/install$"),
    re.compile(r"^/api/models/[^/]+/unload$"),
    re.compile(r"^/api/models/custom"),
    re.compile(r"^/api/hf(/|$)"),
    re.compile(r"^/api/presets/saved"),
    re.compile(r"^/api/presets/custom$"),
    re.compile(r"^/api/voices(/|$)"),
    re.compile(r"^/api/stt(/|$)"),
    re.compile(r"^/api/config/reset$"),
    re.compile(r"^/api/secure(/|$)"),
)

READ_ONLY_METHODS = {"GET", "HEAD", "OPTIONS"}


class RemoteDenied(PermissionError):
    """The request is outside what this account may do."""


def _perm(user: dict, key: str) -> bool:
    return bool((user.get("permissions") or {}).get(key, False))


def allowed_models(user: dict, specs: list[dict]) -> list[dict]:
    perms = user.get("permissions") or {}
    denied = set(perms.get("denied_models") or [])
    allowed = set(perms.get("allowed_models") or [])
    result = []
    for spec in specs:
        if spec.get("id") in denied:
            continue
        if allowed and spec.get("id") not in allowed:
            continue
        result.append(spec)
    return result


def allowed_presets(user: dict, presets: list[dict]) -> list[dict]:
    perms = user.get("permissions") or {}
    denied = set(perms.get("denied_presets") or [])
    allowed = set(perms.get("allowed_presets") or [])
    result = []
    for preset in presets:
        if preset.get("tier") in denied:
            continue
        if allowed and preset.get("tier") not in allowed:
            continue
        result.append(preset)
    return result


def capabilities(state, user: dict) -> dict:
    """The document a client renders from."""
    from . import catalog

    media = {
        "image": _perm(user, "image"),
        "video": _perm(user, "video"),
        "music": _perm(user, "music"),
        "three_d": _perm(user, "three_d"),
        "speech": _perm(user, "audio"),
    }
    catalog_payload = catalog.catalog_payload()
    models = {
        modality: allowed_models(user, catalog_payload.get(modality, []))
        for modality in ("image", "video", "three_d", "music")
    }
    presets = allowed_presets(user, state.presets_payload().get("presets", []))
    return {
        "kind": "hearth.capabilities/1",
        "server": {
            "name": "Hearth",
            "version": getattr(state, "version", ""),
            "url": state.base_url(),
        },
        "user": {"name": user["name"], "secure": bool(user.get("secret"))},
        "permissions": {
            "chat": _perm(user, "chat"),
            "attachments": _perm(user, "attachments"),
            "tools": _perm(user, "tools"),
            "memory": _perm(user, "memory"),
            "change_model": _perm(user, "change_model"),
            "change_preset": _perm(user, "change_preset"),
            "media": media,
        },
        "models": models,
        "presets": presets,
        "text_models": catalog_payload.get("text", []) if _perm(user, "change_model") else [],
    }


def _modality_for(path: str, body: Any) -> str | None:
    if path.startswith("/api/generate") and isinstance(body, dict):
        modality = str(body.get("modality") or "")
        return "speech" if modality == "speech" else modality
    if path.startswith("/api/audio/tts"):
        return "speech"
    return None


def can_read_media(user: dict) -> bool:
    """Generated files are readable when the account may upload or generate."""
    return bool(
        _perm(user, "attachments")
        or any(_perm(user, key) for key in ("image", "video", "music", "three_d", "audio"))
    )


def authorize(user: dict, method: str, path: str, body: Any = None) -> None:
    """Raise RemoteDenied when this account may not make this request."""
    method = (method or "GET").upper()
    path = path or "/"
    if not path.startswith("/api/"):
        raise RemoteDenied("Only /api/ endpoints are reachable from a client")
    for pattern in ADMIN_ONLY:
        if pattern.search(path):
            raise RemoteDenied("That endpoint is only available on the server itself")

    if method in READ_ONLY_METHODS:
        if path.startswith("/api/memories") and not _perm(user, "memory"):
            raise RemoteDenied("Memory access is disabled for this account")
        return

    modality = _modality_for(path, body)
    if modality:
        if not _perm(user, modality):
            raise RemoteDenied(f"{modality} generation is disabled for this account")
        return

    if path.startswith("/api/uploads"):
        if not _perm(user, "attachments"):
            raise RemoteDenied("File uploads are disabled for this account")
        return

    if path in {"/api/media/read", "/api/media/read/"}:
        if not can_read_media(user):
            raise RemoteDenied("Reading generated files is disabled for this account")
        return

    if re.search(r"^/api/presets/[^/]+/apply$", path):
        if not _perm(user, "change_preset"):
            raise RemoteDenied("Changing presets is disabled for this account")
        # A client may adopt a preset's model mix, but never start downloads or
        # installs on the server.
        if isinstance(body, dict):
            body["download"] = False
        return

    if re.search(r"^/api/chats/[^/]+/(messages|regenerate)$", path):
        if not _perm(user, "chat"):
            raise RemoteDenied("Chat is disabled for this account")
        if isinstance(body, dict) and body.get("tools") and not _perm(user, "tools"):
            body["tools"] = False
        return

    if path.startswith("/api/chats") and method in {"POST", "DELETE", "PATCH"}:
        if not _perm(user, "chat"):
            raise RemoteDenied("Chat is disabled for this account")
        return

    if path.startswith("/api/memories"):
        if not _perm(user, "memory"):
            raise RemoteDenied("Memory access is disabled for this account")
        return

    if path in {"/api/config", "/api/config/"}:
        _authorize_config(user, body)
        return

    if path.startswith("/api/presets"):
        if not _perm(user, "change_preset"):
            raise RemoteDenied("Changing presets is disabled for this account")
        return

    if path.startswith("/api/audio/"):
        if not _perm(user, "audio"):
            raise RemoteDenied("Speech is disabled for this account")
        return

    raise RemoteDenied("That action is not available to remote clients")


def _authorize_config(user: dict, body: Any) -> None:
    if not isinstance(body, dict):
        raise RemoteDenied("Malformed settings change")
    patch = body.get("patch") if isinstance(body.get("patch"), dict) else body
    allowed: dict = {}
    for section in ("image", "video", "music", "three_d", "audio", "memory"):
        if section in patch and _perm(user, "memory" if section == "memory" else section):
            allowed[section] = patch[section]
    if "text" in patch and _perm(user, "change_model"):
        allowed["text"] = patch["text"]
    if "preset" in patch:
        if not _perm(user, "change_preset"):
            raise RemoteDenied("Changing presets is disabled for this account")
        allowed["preset"] = patch["preset"]
    if not allowed:
        raise RemoteDenied("This account may not change those settings")
    # Keep only what the account may touch, so a crafted patch cannot smuggle
    # in server-side settings.
    if isinstance(body.get("patch"), dict):
        body["patch"] = allowed
    else:
        body.clear()
        body.update(allowed)
