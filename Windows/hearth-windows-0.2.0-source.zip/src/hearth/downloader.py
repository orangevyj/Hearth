"""Resumable downloads with mirror/source selection.

Hearth tries to be honest about "fastest source": it probes the official
Hugging Face endpoint and a mirror, measures a small ranged download, and
caches the winner for a few hours. Downloads resume from ``.part`` files.
"""

from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from urllib.parse import quote

import httpx

from . import paths
from .jobs import Job

HF_CANDIDATES = ("https://huggingface.co", "https://hf-mirror.com")
PYPI_CANDIDATES = (
    "https://pypi.org/simple",
    "https://pypi.tuna.tsinghua.edu.cn/simple",
    "https://mirrors.aliyun.com/pypi/simple",
)
PROBE_PATH = "stabilityai/sdxl-turbo/resolve/main/text_encoder/model.fp16.safetensors"
CACHE_TTL = 6 * 3600


class DownloadError(RuntimeError):
    pass


class JobCancelled(RuntimeError):
    pass


def _now() -> float:
    return time.time()


def _human_speed(bytes_per_second: float) -> str:
    value = float(bytes_per_second)
    for unit in ("B/s", "KB/s", "MB/s", "GB/s"):
        if value < 1024 or unit == "GB/s":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} GB/s"


def _human_bytes(value: float) -> str:
    value = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TB"


class SourcePicker:
    def __init__(self, cache_path: Path | None = None):
        self.cache_path = cache_path or (paths.CACHE_DIR / "sources.json")
        self._lock = threading.RLock()
        self._cache: dict = {}
        try:
            if self.cache_path.exists():
                self._cache = json.loads(self.cache_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            self._cache = {}

    def _save(self) -> None:
        try:
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            self.cache_path.write_text(json.dumps(self._cache, indent=2), encoding="utf-8")
        except OSError:
            pass

    def _cached(self, key: str) -> str | None:
        with self._lock:
            entry = self._cache.get(key)
            if entry and _now() - entry.get("at", 0) < CACHE_TTL:
                return entry.get("value")
        return None

    def _remember(self, key: str, value: str, meta: dict | None = None) -> None:
        with self._lock:
            self._cache[key] = {"value": value, "at": _now(), "meta": meta or {}}
            self._save()

    def _probe(self, url: str, timeout: float = 8.0) -> tuple[bool, float, int]:
        """Return (ok, seconds, bytes) for a small ranged download."""
        headers = {"Range": "bytes=0-262143", "User-Agent": "Hearth/0.1"}
        started = _now()
        try:
            with httpx.Client(
                follow_redirects=True,
                timeout=httpx.Timeout(timeout, read=timeout, write=timeout, pool=timeout),
                headers=headers,
            ) as client, client.stream("GET", url) as response:
                if response.status_code >= 400:
                    return False, 0.0, 0
                total = 0
                for chunk in response.iter_bytes(65536):
                    total += len(chunk)
                    if total >= 262144:
                        break
                elapsed = max(_now() - started, 0.001)
                return total > 0, elapsed, total
        except (httpx.HTTPError, OSError):
            return False, 0.0, 0

    def hf_endpoint(self) -> str:
        override = os.environ.get("HEARTH_HF_ENDPOINT") or os.environ.get("HF_ENDPOINT")
        if override:
            return override.rstrip("/")
        cached = self._cached("hf")
        if cached:
            return cached
        best: tuple[float, str, dict] | None = None
        for endpoint in HF_CANDIDATES:
            url = f"{endpoint}/{PROBE_PATH}"
            ok, elapsed, size = self._probe(url)
            if not ok:
                continue
            speed = size / max(elapsed, 0.001)
            candidate = (speed, endpoint, {"seconds": elapsed, "bytes": size, "speed_bps": speed})
            if best is None or candidate[0] > best[0]:
                best = candidate
        if best is None:
            self._remember("hf", HF_CANDIDATES[0], {"fallback": True})
            return HF_CANDIDATES[0]
        speed, endpoint, meta = best
        self._remember("hf", endpoint, meta)
        return endpoint

    def pypi_index(self) -> str:
        override = os.environ.get("HEARTH_PYPI_INDEX") or os.environ.get("UV_DEFAULT_INDEX")
        if override:
            return override.rstrip("/")
        cached = self._cached("pypi")
        if cached:
            return cached
        best: tuple[float, str, dict] | None = None
        for index in PYPI_CANDIDATES:
            probe = index.rstrip("/") + "/fastapi/"
            started = _now()
            try:
                with httpx.Client(follow_redirects=True, timeout=6.0) as client:
                    response = client.get(probe, headers={"User-Agent": "Hearth/0.1"})
                if response.status_code >= 400:
                    continue
                elapsed = max(_now() - started, 0.001)
                candidate = (1.0 / elapsed, index, {"seconds": elapsed})
                if best is None or candidate[0] > best[0]:
                    best = candidate
            except (httpx.HTTPError, OSError):
                continue
        if best is None:
            self._remember("pypi", PYPI_CANDIDATES[0])
            return PYPI_CANDIDATES[0]
        _, index, meta = best
        self._remember("pypi", index, meta)
        return index

    def sources_payload(self) -> dict:
        with self._lock:
            return {
                "hf": self._cache.get("hf", {}),
                "pypi": self._cache.get("pypi", {}),
                "hf_choices": list(HF_CANDIDATES),
                "pypi_choices": list(PYPI_CANDIDATES),
            }

    def hf_url(self, repo: str, filename: str, endpoint: str | None = None) -> str:
        root = (endpoint or self.hf_endpoint()).rstrip("/")
        return f"{root}/{repo}/resolve/main/{quote(filename, safe='/')}?download=true"

    def hf_urls(self, repo: str, filename: str) -> list[str]:
        urls: list[str] = []
        primary = self.hf_endpoint()
        ordered = [primary, *[item for item in HF_CANDIDATES if item != primary]]
        for endpoint in ordered:
            url = self.hf_url(repo, filename, endpoint)
            if url not in urls:
                urls.append(url)
        return urls


class Downloader:
    def __init__(self, sources: SourcePicker | None = None):
        self.sources = sources or SourcePicker()

    def download(
        self,
        url: str,
        dest: Path,
        job: Job | None = None,
        item_id: str = "download",
        *,
        expected_bytes: int = 0,
        label: str = "",
        max_retries: int = 2,
    ) -> Path:
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists() and dest.stat().st_size > 0:
            if job:
                job.update_item(
                    item_id,
                    status="skipped",
                    message="already present",
                    completed_bytes=dest.stat().st_size,
                    total_bytes=max(expected_bytes, dest.stat().st_size),
                )
                job.log(f"{label or dest.name}: already present, skipping.")
            return dest

        part = dest.with_name(dest.name + ".part")
        last_error: Exception | None = None
        for attempt in range(1, max_retries + 1):
            try:
                return self._download_once(url, dest, part, job, item_id, expected_bytes, label)
            except JobCancelled:
                raise
            except (httpx.HTTPError, OSError, DownloadError) as exc:
                last_error = exc
                if job:
                    job.log(f"{label or dest.name}: attempt {attempt} failed: {exc}")
                if attempt < max_retries:
                    time.sleep(min(2.0 * attempt, 5.0))
        raise DownloadError(str(last_error) if last_error else "download failed")

    def _download_once(
        self,
        url: str,
        dest: Path,
        part: Path,
        job: Job | None,
        item_id: str,
        expected_bytes: int,
        label: str,
    ) -> Path:
        existing = part.stat().st_size if part.exists() else 0
        headers = {
            "User-Agent": "Hearth/0.1 (+local-first AI workspace)",
            "Accept-Encoding": "identity",
        }
        if existing:
            headers["Range"] = f"bytes={existing}-"
        if job:
            job.update_item(
                item_id,
                status="running",
                label=label or dest.name,
                total_bytes=max(expected_bytes, existing),
                completed_bytes=existing,
                message="connecting",
            )
            job.log(f"Downloading {label or dest.name} ({_human_bytes(existing)} already on disk)…")

        timeout = httpx.Timeout(connect=25.0, read=None, write=None, pool=None)
        with (
            httpx.Client(follow_redirects=True, timeout=timeout, headers=headers) as client,
            client.stream("GET", url) as response,
        ):
            if response.status_code == 416 and existing:
                # The partial file is already the whole file.
                part.replace(dest)
                if job:
                    job.update_item(item_id, status="done", message="complete")
                return dest
            if response.status_code not in (200, 206):
                raise DownloadError(f"HTTP {response.status_code} for {url}")
            if response.status_code == 200 and existing:
                if job:
                    job.log("Server ignored the resume range; restarting download.")
                existing = 0
            content_length = response.headers.get("content-length")
            total = int(content_length) + existing if content_length else max(expected_bytes, 0)
            mode = "ab" if existing and response.status_code == 206 else "wb"
            if mode == "wb":
                existing = 0
            downloaded = existing
            window_start = _now()
            window_bytes = 0
            last_update = 0.0
            with part.open(mode) as handle:
                for chunk in response.iter_bytes(1024 * 256):
                    if job and job.cancel_event.is_set():
                        raise JobCancelled("cancelled")
                    if not chunk:
                        continue
                    handle.write(chunk)
                    downloaded += len(chunk)
                    window_bytes += len(chunk)
                    now = _now()
                    if job and now - last_update >= 0.4:
                        elapsed = max(now - window_start, 0.001)
                        speed = window_bytes / elapsed
                        eta = (total - downloaded) / speed if total > downloaded and speed > 0 else None
                        job.update_item(
                            item_id,
                            status="running",
                            total_bytes=total or downloaded,
                            completed_bytes=downloaded,
                            speed_bps=speed,
                            eta_s=eta,
                            message=f"{_human_bytes(downloaded)} / {_human_bytes(total) if total else '?'} · {_human_speed(speed)}",
                        )
                        last_update = now
                        window_start = now
                        window_bytes = 0
                handle.flush()
                os.fsync(handle.fileno())
        actual = part.stat().st_size
        if expected_bytes and actual < int(expected_bytes * 0.95):
            raise DownloadError(
                f"incomplete download: got {_human_bytes(actual)}, expected about {_human_bytes(expected_bytes)}"
            )
        part.replace(dest)
        if job:
            job.update_item(
                item_id,
                status="done",
                total_bytes=total or actual,
                completed_bytes=actual,
                speed_bps=0,
                eta_s=0,
                message="complete",
            )
            job.log(f"Finished {label or dest.name} ({_human_bytes(actual)}).")
        return dest

    def download_hf(
        self,
        repo: str,
        filename: str,
        dest: Path,
        job: Job | None = None,
        item_id: str = "download",
        *,
        expected_gb: float = 0.0,
        label: str = "",
    ) -> Path:
        expected = int(expected_gb * 1_000_000_000) if expected_gb else 0
        errors: list[str] = []
        for url in self.sources.hf_urls(repo, filename):
            try:
                if job:
                    job.log(f"Source: {url.split('/resolve/')[0]}")
                return self.download(
                    url,
                    dest,
                    job,
                    item_id,
                    expected_bytes=expected,
                    label=label,
                    max_retries=1,
                )
            except JobCancelled:
                raise
            except (httpx.HTTPError, OSError, DownloadError) as exc:
                errors.append(f"{url.split('/resolve/')[0]}: {exc}")
                if job:
                    job.log(f"Source failed ({exc}); trying the next one.")
        raise DownloadError("; ".join(errors) or "no working source")


def expected_bytes(size_gb: float) -> int:
    return int(max(size_gb, 0) * 1_000_000_000)
