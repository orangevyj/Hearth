"""Encryption for Hearth-to-Hearth traffic.

The shared secret is never used as a key directly: each user's secret is run
through PBKDF2-HMAC-SHA256 with a per-user salt to get an AES-256-GCM key. The
server stores the secret (in an owner-only file) so the launcher can show it
again, derives keys on demand, and never sends plaintext over the wire between
a client and a remote Hearth.

Envelope layout for a single message:

    base64( nonce[12] || ciphertext || tag[16] )

Streaming responses use length-prefixed frames of the same envelope.
"""

from __future__ import annotations

import base64
import os
import struct

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

KDF_ITERATIONS = 200_000
NONCE_BYTES = 12
KEY_BYTES = 32
FRAME_HEADER = 4


class CryptoError(ValueError):
    """Raised when a payload cannot be opened (wrong secret or tampering)."""


def derive_key(secret: str, salt: str) -> bytes:
    """Turn a shared secret into an AES-256-GCM key."""
    if not secret:
        raise CryptoError("A user needs a secret before encrypted traffic can work")
    if not salt:
        raise CryptoError("A user needs a key salt")
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_BYTES,
        salt=salt.encode("utf-8"),
        iterations=KDF_ITERATIONS,
    )
    return kdf.derive(secret.encode("utf-8"))


def seal_bytes(key: bytes, plaintext: bytes, aad: bytes = b"") -> bytes:
    nonce = os.urandom(NONCE_BYTES)
    return nonce + AESGCM(key).encrypt(nonce, plaintext, aad)


def open_bytes(key: bytes, envelope: bytes, aad: bytes = b"") -> bytes:
    if len(envelope) <= NONCE_BYTES:
        raise CryptoError("Encrypted payload is too short")
    nonce, ciphertext = envelope[:NONCE_BYTES], envelope[NONCE_BYTES:]
    try:
        return AESGCM(key).decrypt(nonce, ciphertext, aad)
    except InvalidTag as exc:
        raise CryptoError("Wrong secret or tampered payload") from exc


def seal(key: bytes, plaintext: bytes, aad: bytes = b"") -> str:
    return base64.b64encode(seal_bytes(key, plaintext, aad)).decode("ascii")


def open_sealed(key: bytes, envelope: str, aad: bytes = b"") -> bytes:
    try:
        raw = base64.b64decode((envelope or "").strip(), validate=True)
    except (ValueError, TypeError) as exc:
        raise CryptoError("Encrypted payload is not valid base64") from exc
    return open_bytes(key, raw, aad)


def frame(envelope: bytes) -> bytes:
    """Length-prefix one encrypted frame for streaming responses."""
    return struct.pack(">I", len(envelope)) + envelope


def pack_frame(key: bytes, payload: bytes, aad: bytes = b"") -> bytes:
    return frame(seal_bytes(key, payload, aad))


def new_salt() -> str:
    return base64.urlsafe_b64encode(os.urandom(16)).decode("ascii")


class FrameReader:
    """Incremental reader for length-prefixed encrypted frames."""

    def __init__(self) -> None:
        self._buffer = bytearray()

    def feed(self, chunk: bytes) -> list[bytes]:
        self._buffer.extend(chunk)
        frames: list[bytes] = []
        while True:
            if len(self._buffer) < FRAME_HEADER:
                return frames
            (length,) = struct.unpack(">I", self._buffer[:FRAME_HEADER])
            if len(self._buffer) < FRAME_HEADER + length:
                return frames
            start = FRAME_HEADER
            frames.append(bytes(self._buffer[start : start + length]))
            del self._buffer[: start + length]
