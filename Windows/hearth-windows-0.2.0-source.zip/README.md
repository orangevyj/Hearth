# Hearth

**A private, local-first AI workspace for text, images, video, sound, music, 3D and web search.**

Hearth is a small launcher plus a ChatGPT-style web app. It examines your hardware, proposes **Fast / Balanced / Smart** model tiers, installs the right local runtimes and models from the fastest reachable mirror, and gives you one place to chat with tools that can call every modality.

Everything runs on your machine. There are no accounts and no cloud API keys. Only the optional web search and page reader leave the box.

---

## Quick start

```bash
./hearth
```

That is the whole install. On first run the launcher:

1. downloads [`uv`](https://github.com/astral-sh/uv) into `./.tools`,
2. lets uv fetch a private Python 3.12 runtime and the app dependencies,
3. starts the launcher at <http://127.0.0.1:8770> and opens it.

You do **not** need pip, Node, Docker or a system Python package manager. `curl` or `wget`, `bash`, and a Linux desktop are enough to begin.

### First-run wizard

The launcher scans CPU, RAM, GPU/VRAM and disk, then shows three presets sized for that machine:

- **Fast** — small, snappy, gentle on memory.
- **Balanced** — the everyday sweet spot.
- **Smart** — the best quality the machine can reach, allowing RAM offload.

Pick a tier, uncheck any modalities you do not want, and press **Install**. The launcher queues runtime installs and model downloads in the background. You can watch every item in **Activity**, resume after an interruption, or cancel.

Approximate first-install footprints (including runtimes; skip modalities to shrink it):

| Preset | All modalities | Peak planning |
|---|---:|---|
| Fast | ~48 GB | 8 GB VRAM class |
| Balanced | ~62 GB | 12 GB VRAM class |
| Smart | ~78 GB | 20 GB VRAM class |

These are estimates, not quotas. Hearth skips files that already exist.

### Start the local engine

After installation, press **Start server** in the launcher (or the engine gate in Chat). Hearth:

- starts its managed Ollama process and checks that the selected text model is installed,
- starts ComfyUI if it is installed (CPU mode when the GPU driver is unavailable),
- keeps the Hearth web server itself running so the launcher stays usable.

**Open chat** opens `/chat`. The launcher and chat share the same process and data.

---

## What you get

- **One launcher** — hardware scan, presets, per-model settings, runtime controls, download activity and logs.
- **ChatGPT-style chat** — streaming markdown, code copy, thinking blocks, tool activity, sources, attachments, read-aloud, regenerate, export, searchable history.
- **Text with tools** — the text model can call web search, page reading, image/video/music/3D generation and text-to-speech.
- **Images** — SDXL Turbo or FLUX.1 through ComfyUI.
- **Video** — Wan 2.1 and Wan 2.2 text-to-video through ComfyUI, with configurable resolution, length and frame rate (per request or in Video settings). Defaults are 480p/16 fps. Hearth caps video resolution to 1280 px and, by default, automatically shortens clips to fit activation VRAM; on an 8 GB card a 720p30 clip is roughly one second and can take several minutes. 480p is the practical choice for longer clips. Turn off **Video → Auto-fit to this GPU** if you want to attempt a larger clip and accept the OOM risk.
- **Sound** — Piper TTS (espeak-ng fallback) and Whisper transcription.
- **Music** — ACE-Step 1.5 through ComfyUI: the fast all-in-one turbo, plus the XL checkpoints (turbo and SFT) for a denser arrangement and a better mix.
- **3D** — Hunyuan3D 2.1 image-to-3D through ComfyUI; Hearth can generate the preview image first.
- **Web search** — SearXNG preferred, DuckDuckGo fallback, with page excerpts and citations.
- **Local-only controls** — lazy loading, text-resident mode, keep-all mode, idle unload, memory guard, per-modality toggles.
- **Memory** — the assistant can save durable facts and preferences with a `remember` tool (and drop them with `forget_memory`). Only enabled memories are injected into the prompt, none are injected while memory is switched off, and the **Memory** page in the launcher lists everything with a per-item switch, an add box, per-item delete and a "Forget all". They live in `~/.local/share/hearth/memories.json`; nothing is sent anywhere.
- **Memory-aware tools** — media jobs unload the text model first; on cards under 12 GB Hearth frees ComfyUI after each job so chat can reload. ComfyUI’s VRAM strategy is configurable (Automatic / Prefer RAM offload / GPU / CPU) with a VRAM reserve and headroom.
- **Existing backends** — point the text model at LM Studio, llama.cpp, vLLM or any OpenAI-compatible local server.
- **No root** — runtimes live under your data directory, never in system paths.

---

## Remote access

One machine can run the models and other devices can use them. On the host, open **Server → Remote access**: set the port, switch on **Accept connections from other devices** (Hearth then binds to all interfaces), and add accounts. Each account has a name and, unless you deliberately create an open one, a secret.

Devices connect at `http://<host>:<port>/connect` with the server address, the account name and that secret. Connecting through that page is what makes the client use the encrypted channel; the web app installs as a PWA on Android and Windows from the same page.

**What is encrypted:** everything a client sends or receives travels as an AES-256-GCM envelope through `/api/secure/rpc`. The key is derived with PBKDF2-HMAC-SHA256 (200k iterations) from the account secret and a per-server salt; the server derives the same key and never sends plaintext. Chat replies stream as individually sealed frames.

**What the server decides:** the client asks for its capability document and renders from it. Per account you can allow or deny chat, uploads, tools, memory, each media modality, changing the model and changing presets, plus per-model and per-preset denylists. The server enforces the same rules on every request, so a client cannot step outside its document. Server administration (starting services, installing models, editing accounts) is only reachable from the host itself — off-machine API calls are refused unless they carry a valid account header or arrive through the encrypted channel.

**Warning:** an account without a secret is an open door for anything that can reach the port. The launcher shows a red warning for exactly those accounts, and the encrypted channel refuses them — they can only talk plaintext.

## Memory

The assistant keeps a small, explicit list of things worth remembering (your name, units, how you like answers). It writes with the `remember` tool and deletes with `forget_memory`, both gated by the **Let the assistant use memory** switch and by their own entries under Tools. The **Memory** page shows every item with a switch: off items stay stored but are never sent to the model, so you can test a memory out, park it, or delete it outright.

## Presets

Hearth computes presets from **VRAM first**, then system RAM, then free disk. The exact model picks change with the machine. Example on an 8 GB GPU / 31 GB RAM:

| | Fast | Balanced (suggested) | Smart |
|---|---|---|---|
| Text | Qwen3.5 4B | Qwen3.5 9B | Qwen3.5 35B-A3B |
| Images | SDXL Turbo | FLUX.1 schnell | FLUX.1 dev |
| Video | Wan 2.1 1.3B | Wan 2.2 5B | Wan 2.2 5B |
| 3D | Hunyuan3D 2.1 | Hunyuan3D 2.1 | Hunyuan3D 2.1 |
| Music | ACE-Step 1.5 | ACE-Step 1.5 XL Turbo | ACE-Step 1.5 XL SFT |
| Speech | Piper + Whisper small | Piper + Whisper medium | Piper + Whisper large-v3-turbo |
| Loading | lazy | lazy / text-resident | lazy / keep-all on larger rigs |

The **Presets** page shows the exact model sizes, download estimate, peak VRAM/RAM and the reason for each pick. You can apply a preset without downloading anything and customize every model afterwards.

If none of the three tiers is quite right, **Build a preset** on the same page lets you pick one model per modality (plus voice and transcription model), name the mix and save it. Saved presets live in `~/.config/hearth/custom_presets.json`, appear beside the built-in tiers with their own size and memory estimates, apply and install exactly like them, and can be deleted again.

Install sizes are honest: the launcher reports what is still missing, so a second model in the same family only fetches the files that are not on disk yet. Files already present are skipped, and the job only lists what it actually downloads.

### Hardware detection

- CPU model, physical cores, threads, AVX2/AVX-512.
- RAM total/available.
- NVIDIA via `nvidia-smi`; AMD via `rocm-smi`; `lspci` fallback with a known-GPU VRAM table.
- If a GPU exists but its driver is unresponsive (for example after a kernel/driver update), Hearth plans for the GPU's VRAM but runs on CPU until a reboot makes the driver usable.

---

## Models and runtimes

| Modality | Engine | Choices |
|---|---|---|
| Text | Ollama | Qwen3.5 2B, 4B, 9B, 27B, 35B-A3B |
| Images | ComfyUI | SDXL Turbo, FLUX.1 schnell, FLUX.1 dev |
| Video | ComfyUI | Wan 2.1 T2V 1.3B, 14B; Wan 2.2 TI2V 5B |
| 3D | ComfyUI | Hunyuan3D 2.1 |
| Music | ComfyUI | ACE-Step 1.5 (all-in-one), ACE-Step 1.5 XL Turbo, ACE-Step 1.5 XL SFT |
| Speech | Piper / faster-whisper | Amy, Lessac, Alba voices; Whisper small/medium/large-v3-turbo |
| Web | HTTP | SearXNG JSON API or DuckDuckGo HTML |

Anything else in a family Hearth already drives can be added yourself. **Search Hugging Face…** in the import card opens a small Hub search: each hit says whether Hearth can drive it, and a suitable repository imports in one click — files, roles and destination are worked out from the repo layout, and the download starts immediately. When a repo bundles several variants (Wan 2.2 ships 14B I2V/T2V/Fun/VACE checkpoints side by side) Hearth refuses rather than guessing, and points you at the manual fields. The manual form is still there too: registers a checkpoint from a Hugging Face repository or one that is already sitting in the ComfyUI `models` folder, as long as you name the architecture family (SDXL, FLUX, Wan 2.1/2.2, Hunyuan3D 2.1, ACE-Step). Hearth only builds workflows it knows, so an unsupported architecture is refused rather than half-wired. Imports are stored in `~/.config/hearth/custom_models.json`, show up in the model pickers, and are fetched/installed like catalog models. Deleting an import only unregisters it — the weights stay on disk.

Hearth manages its own copies under `~/.local/share/hearth/runtimes`:

- **Ollama** — downloaded as a release tarball; no root, no systemd unit.
- **ComfyUI + PyTorch** — cloned into a private venv; CUDA wheels when an NVIDIA GPU is present, CPU wheels otherwise.
- **Piper** — binary plus voice models.
- **faster-whisper** — private venv; CTranslate2 models from Hugging Face.

### Use LM Studio instead of Ollama

In **Models → Text**, set the backend to **OpenAI-compatible**, set the base URL to `http://127.0.0.1:1234/v1`, enter the model id LM Studio shows, and save. Hearth detects LM Studio on port 1234 and offers a one-click **Use LM Studio** button.

### Fastest source

Before a Hugging Face download Hearth probes the official endpoint and `hf-mirror.com`, measures a small ranged transfer and caches the winner for six hours. PyPI installs use the fastest of the official index, Tsinghua and Aliyun mirrors. Downloads are resumable from `.part` files.

### Reasoning speed

Qwen3.5 can spend a long time emitting hidden reasoning tokens. Hearth turns that off by default (`Models → Text → Show reasoning tokens`) so a simple chat answers immediately; enable it for harder problems. The UI also shows an elapsed timer while waiting, so a slow model never looks frozen.

### Tool permissions

**Models → Tools** lets you hide any capability from the text model. Tools exposed to the model:

`web_search` · `fetch_url` · `generate_image` · `generate_video` · `generate_music` · `text_to_speech` · `generate_3d`

The assistant decides when to call them. The composer also has a direct **wand** menu for generating media without asking the text model first.

---

## Privacy

- The Hearth server binds to `127.0.0.1` by default.
- Chats, attachments, generated media and generated audio live under `~/.local/share/hearth`.
- Config is `~/.config/hearth/config.json` with owner-only permissions.
- Markdown is sanitized before rendering; uploaded filenames are sanitized; media paths are constrained to the data directory.
- Web search and page reading leave the machine. Use a self-hosted SearXNG URL to keep search on your network. Everything else is local.
- Model licenses belong to their authors. In particular FLUX.1 dev is non-commercial; check each model's licence before commercial use.

---

## Configuration and data

```
~/.config/hearth/config.json      # settings, model picks, backend URLs
~/.local/share/hearth/
  hearth.db                       # chats, messages, attachment metadata
  outputs/YYYY-MM-DD/             # generated images, video, audio, 3D
  uploads/YYYY-MM-DD/             # files you attach
  runtimes/                       # Ollama, ComfyUI, Piper, faster-whisper
  models/                         # Ollama model store + Whisper cache
  logs/                           # managed process logs
  jobs/                           # reserved for job metadata
~/.cache/hearth/                  # TTS temp files, mirror probe cache
```

Set `HEARTH_CONFIG_DIR`, `HEARTH_DATA_DIR` or `HEARTH_CACHE_DIR` to relocate them.

### Desktop entry

```bash
./scripts/install-desktop.sh            # application menu
./scripts/install-desktop.sh --desktop  # also add a shortcut on ~/Desktop
```

No root is required. The entry runs the project's `./hearth` bootstrap script.

---

## CLI

```bash
./hearth                          # start on 127.0.0.1:8770, open browser
./hearth --no-browser             # do not open a browser
./hearth --port 9000              # bind another port
./hearth --host 0.0.0.0           # expose on LAN (understand the risk first)
./hearth --data-dir /path         # override data directory
./hearth --config-dir /path       # override config directory
./hearth --log-level info         # uvicorn logging level
./hearth --version
```

If the requested port is busy, Hearth selects the next free port and persists it.

---

## API

Same-origin HTTP, JSON and SSE. Mutating requests require the per-process `X-Hearth-Token` returned by `GET /api/state` (CSRF protection).

| Endpoint | Purpose |
|---|---|
| `GET /api/state` | config, hardware, presets, runtimes, jobs, installed models |
| `POST /api/config` | deep-merge a config patch |
| `POST /api/presets/{tier}/apply` | apply Fast/Balanced/Smart, optionally download |
| `POST /api/models/{id}/install` | install a catalogue model |
| `POST /api/runtimes/{name}/install` | install/repair a runtime |
| `POST /api/server/start` / `stop` | start/stop the local engine |
| `GET /api/jobs` | download/install/generation job state and logs |
| `POST /api/chats/{id}/messages` | SSE chat stream |
| `POST /api/chats/{id}/regenerate` | SSE regeneration |
| `POST /api/chats/{id}/stop` | stop the active reply |
| `POST /api/uploads` | attach an image/audio/text/file |
| `POST /api/generate` | direct image/video/music/speech/3D job |
| `POST /api/audio/tts` / `transcribe` | speech endpoints |
| `GET /media/...` | generated files and uploads |

SSE event types: `meta`, `delta`, `thinking`, `tool_start`, `tool_result`, `replace`, `usage`, `status`, `transcript`, `error`, `done`, `saved`.

---

## Development

```bash
# toolchain
./hearth --version

# tests
make test          # pytest, including fake Ollama/ComfyUI/audio backends
make lint          # ruff
make fmt           # ruff format

# regenerate lockfile
make lock
```

Project layout:

```
src/hearth/
  app.py             FastAPI routes, SSE, CSRF, state
  chat_engine.py     prompt, tool loop, vision/tool-mode selection
  llm.py             Ollama native + OpenAI-compatible streaming
  tools.py           tool schemas and execution
  search.py          SearXNG / DuckDuckGo / SSRF-guarded page reader
  comfy.py           ComfyUI client + API-format workflows
  runtimes.py        managed installs, process lifecycle, audio runtime
  downloader.py      mirror probing, ranged/resumable downloads
  jobs.py            background jobs
  presets.py         hardware → Fast/Balanced/Smart
  catalog.py         model catalogue and real sources
  hardware.py        CPU/GPU/RAM/disk detection
  chats.py           SQLite persistence
web/
  index.html         launcher
  chat.html          chat app
  static/css/        warm dark/light design system
  static/js/         launcher, chat, API, icons, UI helpers
  static/vendor/     marked, DOMPurify, model-viewer (vendored)
```

See [`docs/architecture.md`](docs/architecture.md) for the request flow, install pipeline and security model.

---

## Troubleshooting

**`nvidia-smi` fails / the GPU is detected but not usable.**  
The kernel module and userspace driver are probably out of sync (common after a driver update). Hearth reports the GPU, plans VRAM from it, and runs CPU/ComfyUI `--cpu` until the driver responds. A reboot is the usual fix.

**Ollama is installed but the model does not appear.**  
The text model must be pulled into Ollama. Use **Models → Text → Pull** or the preset install. Models are only listed as installed while Ollama is running.

**ComfyUI install is slow.**  
PyTorch is the big download (CUDA wheels are several GB). Progress and pip output are streamed into **Activity → job → Details**. The runtime lives under `~/.local/share/hearth/runtimes/comfyui`, so reinstall is not needed after a restart.

**ComfyUI keeps starting in CPU mode.**  
Start the server from the launcher after the GPU driver is usable. The launcher passes `--cpu` only when `nvidia-smi` is not responding.

**The port is busy.**  
Hearth picks the next free port and writes it to config; the launcher prints the actual URL.

**Out of disk.**  
Models are large. Fast with all modalities is roughly 48 GB; Smart can exceed 78 GB. Untick video/3D/music or install one modality at a time.

**Web search returns nothing.**  
DuckDuckGo can rate-limit. Point **Models → Search → SearXNG URL** at a local instance (for example `http://127.0.0.1:8888`) for a reliable, self-hosted provider.

---

## Known limits

- Linux and Windows. On Linux the launcher and runtime installers target x86_64/aarch64; on Windows the server runs from source with `scripts\install-windows.ps1`, which creates the virtualenv, installs the Python dependencies and uv, writes `hearth.cmd` and adds a Start-menu shortcut. Config lives in `%APPDATA%\Hearth`, data and runtimes in `%LOCALAPPDATA%\Hearth`. Windows support has been exercised by the test suite's platform branches, not on Windows hardware, so treat it as new: Ollama and Piper download their Windows builds, ComfyUI and Whisper build through uv, and GPU acceleration needs the CUDA PyTorch wheels.
- macOS is untested.
- Single-user, localhost-first. There is no account system or multi-user isolation.
- 3D generation is **image-to-3D**. Hearth generates a preview image first when you give it a prompt.
- Video is short-form (typically a few seconds at 480p) and can take minutes on consumer hardware.
- Web search is the only network feature; it is intentionally not presented as local.
- Model licences are enforced by their authors, not by Hearth. FLUX.1 dev is non-commercial.
- No automatic model updates; installs are explicit, resumable and cancellable.

---

## License

MIT — see [`LICENSE`](LICENSE). Model weights and runtimes keep their own licenses.
