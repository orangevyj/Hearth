#!/usr/bin/env bash
# Bundle the clients Hearth hands out, so a device that connects without the app
# can be offered the right download.
#
#   Android  <- the built APK from the Android project
#   Windows  <- this source tree (scripts/install-windows.ps1 bootstraps it)
#   Linux    <- this source tree (scripts/install-desktop.sh bootstraps it)
set -euo pipefail

root="$(cd "$(dirname "$0")/.." && pwd)"
# Where the server looks for clients (paths.CLIENTS_DIR).
target="${HEARTH_DATA_DIR:-$HOME/.local/share/hearth}/clients"
mkdir -p "$target"

find_apk() {
  local candidates=(
    "$root/../hearth-android/app/build/outputs/apk/debug/app-debug.apk"
    "$root/../hearth-android/app/build/outputs/apk/release/app-release.apk"
  )
  for candidate in "${candidates[@]}"; do
    [ -f "$candidate" ] && { echo "$candidate"; return 0; }
  done
  return 1
}

echo "==> collecting clients into $target"
if apk="$(find_apk)"; then
  cp -f "$apk" "$target/hearth-android.apk"
  echo "    android: $apk"
else
  echo "    android: no APK found (build it in hearth-android first)"
fi

for pair in "deb:hearth-linux.deb" "rpm:hearth-linux.rpm"; do
  ext="${pair%%:*}"; name="${pair##*:}"
  artifact="$(ls -1t "$root/dist"/*."$ext" 2>/dev/null | head -1 || true)"
  if [ -n "${artifact:-}" ]; then
    cp -f "$artifact" "$target/$name"
    echo "    package: $artifact"
  fi
done

echo "==> packing Windows bundle"
rm -f "$target/hearth-windows.zip"
(cd "$root" && zip -qr "$target/hearth-windows.zip" . \
  -x '.venv/*' '.git/*' '.tools/*' '*/__pycache__/*' '*.pyc' '*.egg-info/*' 'build/*' 'dist/*')

echo "==> packing Linux bundle"
rm -f "$target/hearth-linux.tar.gz"
(cd "$root" && tar --exclude='./.venv' --exclude='./.git' --exclude='./.tools' \
  --exclude='__pycache__' --exclude='*.pyc' \
  -czf "$target/hearth-linux.tar.gz" .)

# A manifest so the server knows which version each stored build is.
version="$(sed -n 's/^version = "\{0,1\}\([^"]*\)".*/\1/p' "$root/pyproject.toml" | head -1)"
[ -n "$version" ] || version="0.0.0"
echo "==> writing clients.json (version $version)"
python3 - "$target" "$version" <<'PYEOF'
import json, sys
from pathlib import Path
target = Path(sys.argv[1]); version = sys.argv[2]
builds = {}
for platform, filename in (("android", "hearth-android.apk"), ("windows", "hearth-windows.zip"),
                           ("linux", "hearth-linux.tar.gz"), ("linux-deb", "hearth-linux.deb"),
                           ("linux-rpm", "hearth-linux.rpm")):
    if (target / filename).is_file():
        builds[platform] = {"version": version, "file": filename}
(target / "clients.json").write_text(json.dumps({"builds": builds}, indent=2) + "\n")
print("    ", ", ".join(f"{k} {v['version']}" for k, v in builds.items()) or "no builds")
PYEOF

ls -la "$target"
