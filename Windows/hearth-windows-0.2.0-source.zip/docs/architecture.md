# Hearth architecture

Hearth is a local web app. A single FastAPI process serves the launcher, the chat UI, the JSON API and media files; the model runtimes are child processes (or external servers) that the app installs and manages.

```
┌──────────────────────────────── Browser ────────────────────────────────┐
│  /            launcher: hardware, presets, models, server, activity      │
│  /chat        streaming chat, tools, attachments, media viewers          │
└───────────────────────────────┬──────────────────────────────────────────┘
                                │ HTTP + SSE (same origin, CSRF token)
┌───────────────────────────────▼──────────────────────────────────────────┐
│                              FastAPI app                                 │
│  app.py        routes, state cache, SSE generator, CSRF, media            │
│  chat_engine.py  system prompt, context trim, tool loop, stop/cancel      │
│  llm.py        Ollama native / OpenAI-compatible streaming adapters       │
│  tools.py      tool schemas + web/image/video/music/speech/3D execution   │
│  chats.py      SQLite: chats, messages, attachment metadata               │
│  jobs.py       thread-safe background jobs and progress                   │
│  runtimes.py   installs, process lifecycle, health, model pulls            │
│  downloader.py mirror probing, ranged/resumable downloads                 │
└───────┬───────────────────────┬───────────────────────┬──────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
┌───────────────┐      ┌─────────────────┐     ┌─────────────────────────┐
│ Ollama        │      │ ComfyUI          │     │ Speech                   │
│ text + tools  │      │ image/video/3D/  │     │ Piper (TTS)              │
│               │      │ music workflows  │     │ faster-whisper (STT)     │
└───────────────┘      └─────────────────┘     └─────────────────────────┘
        │                       │                       │
        └───────────────────────┴───────────────────────┘
                    local files under ~/.local/share/hearth
```

## Chat request flow

1. `POST /api/chats/{id}/messages` stores the user message and creates an assistant placeholder.
2. Audio attachments are transcribed locally and appended to the user text.
3. Media tools unload the Ollama text model before calling ComfyUI, and Hearth frees ComfyUI after the job on cards under 12 GB so the text model can reload. `ChatEngine` builds a system prompt from config + hardware + enabled modalities.
4. Tool mode:
   - **native** when Ollama reports the `tools` capability,
   - **prompt** (`<tool_call>{…}</tool_call>`) for models without native tools,
   - no tools for demo mode.
5. The LLM streams `delta` events over SSE. Tool calls become `tool_start`; execution results become `tool_result` with attachments/sources.
6. Tool calls can chain up to the configured limit. The final assistant content, tool metadata, sources and attachments are persisted in SQLite.
7. The client can stop at any point; the server cancels the stream, unloads as configured, and saves the partial message.

## Media flow

Hearth builds **ComfyUI API-format workflows** in `comfy.py`:

- SDXL / FLUX checkpoint workflows,
- configurable playback FPS for Wan video (`SaveWEBM`),
- Wan 2.1 T2V (`UNETLoader` + `CLIPLoader` + `VAELoader` + `EmptyHunyuanLatentVideo` + `SaveWEBM`),
- Hunyuan3D 2.1 (`ImageOnlyCheckpointLoader` + `CLIPVisionEncode` + `Hunyuan3Dv2Conditioning` + `VoxelToMesh` + `SaveGLB`),
- User-owned pieces: `library.py` keeps custom models (`custom_models.json`) and saved presets
  (`custom_presets.json`). Imported models are an overlay on the catalogue (`catalog.register_custom_models`),
  so `get_model` / `models_for` / `catalog_payload` and the installed/missing accounting see them without
  special cases. Saved presets are assembled into the same `Preset` dataclass as the built-in tiers.
 + `EmptyAceStep1.5LatentAudio` + `SaveAudioMP3`). The all-in-one
  checkpoint loads through `CheckpointLoaderSimple`; the XL checkpoints load as a split stack
  (`UNETLoader` + `DualCLIPLoader` with `type=ace` + `VAELoader`) and take their step/CFG floor from
  the catalogue so a non-distilled model is never starved of steps.

A generation job posts to `/prompt`, polls `/history/{id}`, downloads output files through `/view` and stores them in the data directory. Images/videos/audio/GLBs are exposed as attachment URLs under `/media`.

3D is image-to-3D: `generate_3d` either uses the user's attached image or generates a preview image first.

## Install pipeline

`POST /api/presets/{tier}/apply` with `download: true` creates a job and runs:

1. download/extract Ollama if a text model is selected and the backend is Ollama,
2. `ollama pull` the selected model (streams progress),
3. clone + install ComfyUI in a private venv with CUDA or CPU PyTorch,
4. download ComfyUI model files from Hugging Face into `ComfyUI/models/...`,
5. install Piper + a voice, create a faster-whisper venv, download the Whisper model.

Every file download is resumable and probes HF official + `hf-mirror.com` for the fastest reachable source. PyPI installs probe official/Tsinghua/Aliyun indexes. Jobs are cancelable; runtime logs are kept under `data/logs`.

## Preset algorithm

`presets.py` picks the highest-quality catalogue model that fits a tier's VRAM and RAM budgets:

- Fast: about 75% of VRAM and 35% of RAM.
- Balanced: about 95% of VRAM and 60% of RAM.
- Smart: up to 2.5× VRAM with RAM offload (85% of RAM).

If no model fits, the smallest is selected and the UI explains the offload cost. Load mode is chosen from VRAM: lazy for small cards, text-resident from 12 GB, keep-all only for high-VRAM/high-RAM machines. 3D and music currently share one strong model each.

## Security model

- Binds `127.0.0.1` by default.
- Mutating API calls require `X-Hearth-Token`, a random per-process token returned only by same-origin `GET /api/state`; cross-site pages cannot read it.
- Markdown is sanitized with DOMPurify; links get `rel="noopener noreferrer"`.
- Uploaded filenames are sanitized; media paths resolve under `outputs/` or `uploads/`.
- The page reader validates public http(s) URLs, resolves DNS and rejects private/loopback/link-local targets (SSRF guard).
- Config is written atomically with mode `0600`. API keys are never sent to any external service by Hearth.
- Runtimes are installed under the user's data directory; no root, no system packages.

## Extension points

- Add models in `catalog.py` (Ollama tags or Hugging Face files + destination).
- Add a preset rule in `presets.py`.
- Add an OpenAI-compatible endpoint under Models → Text.
- Add a ComfyUI workflow in `comfy.py` and expose it through `tools.py`.
- Add a tool schema + dispatcher in `tools.py`; the chat engine picks it up automatically.
