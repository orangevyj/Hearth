from __future__ import annotations

import http.server
import json
import threading

import hearth.chat_engine as chat_engine_module
from hearth.attachments import OutputStore
from hearth.chat_engine import ChatEngine
from hearth.config import ConfigStore
from hearth.jobs import JobManager
from hearth.llm import ToolCall, normalize_arguments, parse_prompt_tool_calls
from hearth.tools import ToolResult


class FakeRuntimes:
    def __init__(self, capabilities):
        self.capabilities = capabilities

    async def ollama_show(self, model):  # noqa: ARG002
        return {"capabilities": self.capabilities}


def ollama_server():
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):  # noqa: ANN002
            pass

        def do_POST(self):
            length = int(self.headers.get("Content-Length") or 0)
            payload = json.loads(self.rfile.read(length) or b"{}")
            if self.path == "/api/show":
                body = json.dumps({"capabilities": ["completion", "tools"]}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            has_tool = any(message.get("role") == "tool" for message in payload.get("messages", []))
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson")
            self.end_headers()

            def line(data):
                self.wfile.write((json.dumps(data) + "\n").encode())
                self.wfile.flush()

            if not has_tool:
                if payload.get("tools"):
                    line({"message": {"content": ""}, "done": False})
                    line(
                        {
                            "message": {
                                "tool_calls": [
                                    {"function": {"name": "web_search", "arguments": {"query": "hearth"}}}
                                ]
                            },
                            "done": False,
                        }
                    )
                else:
                    line(
                        {
                            "message": {
                                "content": 'Let me check. <tool_call>{"name":"web_search","arguments":{"query":"hearth"}}</tool_call>'
                            },
                            "done": False,
                        }
                    )
            else:
                line({"message": {"content": "The answer is 42 [1]."}, "done": False})
            line({"done": True, "prompt_eval_count": 10, "eval_count": 5, "total_duration": 1_000_000})

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def make_engine(tmp_path, port, capabilities, monkeypatch):
    config = ConfigStore(tmp_path / "config.json")
    config.load()
    config.update(
        {
            "text": {
                "backend": "ollama",
                "base_url": f"http://127.0.0.1:{port}",
                "model": "fake",
                "tool_mode": "auto",
            }
        }
    )

    async def fake_execute(name, args, ctx):  # noqa: ARG001
        return ToolResult(
            name=name,
            content="search result: 42 [1]",
            sources=[{"title": "Example", "url": "https://example.com", "snippet": "42"}],
        )

    monkeypatch.setattr(chat_engine_module, "execute_tool", fake_execute)
    return ChatEngine(
        config,
        FakeRuntimes(capabilities),
        None,
        JobManager(),
        OutputStore(),
        hardware_summary="test machine",
    )


async def collect(engine):
    return [event async for event in engine.stream([{"role": "user", "content": "search for hearth"}])]


async def test_native_tool_loop(tmp_path, monkeypatch):
    server = ollama_server()
    try:
        engine = make_engine(tmp_path, server.server_address[1], ["completion", "tools"], monkeypatch)
        events = await collect(engine)
        types = [event["type"] for event in events]
        assert "tool_start" in types
        assert "tool_result" in types
        assert any(event.get("text", "").find("42") >= 0 for event in events if event["type"] == "delta")
        assert any(event["type"] == "done" for event in events)
    finally:
        server.shutdown()


async def test_prompt_tool_fallback(tmp_path, monkeypatch):
    server = ollama_server()
    try:
        engine = make_engine(tmp_path, server.server_address[1], ["completion"], monkeypatch)
        events = await collect(engine)
        types = [event["type"] for event in events]
        assert "replace" in types
        assert "tool_start" in types
        assert "tool_result" in types
        assert any(event["type"] == "done" for event in events)
    finally:
        server.shutdown()


def test_prompt_tool_parser():
    cleaned, calls = parse_prompt_tool_calls(
        'Before\n<tool_call>{"name":"generate_image","arguments":{"prompt":"a cat"}}</tool_call>\nAfter'
    )
    assert "tool_call" not in cleaned
    assert calls[0].name == "generate_image"
    assert calls[0].arguments == {"prompt": "a cat"}
    assert normalize_arguments('{"x":1}')[0] == {"x": 1}


def test_tool_call_to_openai():
    call = ToolCall(id="call_1", name="x", arguments={"a": 1})
    payload = call.to_openai()
    assert payload["function"]["name"] == "x"
    assert json.loads(payload["function"]["arguments"]) == {"a": 1}


def test_ollama_images_use_raw_base64_strings():
    from hearth.config import TextConfig
    from hearth.llm import OllamaLLM

    engine = OllamaLLM(TextConfig(backend="ollama"))
    messages = engine._messages(
        [{"role": "user", "content": "what is this?", "images": [{"data": "YWJj", "mime": "image/png"}]}]
    )
    assert messages[0]["images"] == ["YWJj"]


def test_openai_images_become_content_parts():
    from hearth.llm import _openai_messages

    messages = _openai_messages(
        [{"role": "user", "content": "what is this?", "images": [{"data": "YWJj", "mime": "image/png"}]}]
    )
    parts = messages[0]["content"]
    assert parts[0] == {"type": "text", "text": "what is this?"}
    assert parts[1]["type"] == "image_url"
    assert parts[1]["image_url"]["url"] == "data:image/png;base64,YWJj"


def test_text_catalog_marks_vision():
    from hearth.catalog import TEXT_MODELS

    assert all(model.vision for model in TEXT_MODELS)


def capturing_ollama_server():
    seen: dict = {}

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):  # noqa: ANN002
            pass

        def do_POST(self):
            length = int(self.headers.get("Content-Length") or 0)
            seen["payload"] = json.loads(self.rfile.read(length) or b"{}")
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson")
            self.end_headers()
            for data in (
                {"message": {"content": "ok"}, "done": False},
                {"done": True, "prompt_eval_count": 1, "eval_count": 1, "total_duration": 1},
            ):
                self.wfile.write((json.dumps(data) + "\n").encode())
                self.wfile.flush()

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, seen


async def test_ollama_think_follows_the_message_override():
    from hearth.config import TextConfig
    from hearth.llm import OllamaLLM

    server, seen = capturing_ollama_server()
    try:
        config = TextConfig(backend="ollama", model="qwen3.5:9b", thinking=True)
        config.base_url = f"http://127.0.0.1:{server.server_address[1]}"
        llm = OllamaLLM(config)
        messages = [{"role": "user", "content": "hi"}]
        async for _ in llm.stream(messages, None, temperature=0.7, top_p=0.9):
            pass
        assert seen["payload"]["think"] is True

        async for _ in llm.stream(messages, None, temperature=0.7, top_p=0.9, think=False):
            pass
        assert seen["payload"]["think"] is False

        async for _ in llm.stream(messages, None, temperature=0.7, top_p=0.9, think=None):
            pass
        assert seen["payload"]["think"] is True  # falls back to the saved setting
    finally:
        server.shutdown()


def test_openai_effort_reflects_the_override():
    from hearth.config import TextConfig
    from hearth.llm import OpenAILLM

    config = TextConfig(backend="openai", model="local-model")
    config.base_url = "http://127.0.0.1:1/v1"
    llm = OpenAILLM(config)
    assert llm.name == "openai"
    # Explicit toggles map to the OpenAI-style effort knob; None leaves it out.
    assert llm._reasoning_payload(True) == {"reasoning_effort": "medium"}
    assert llm._reasoning_payload(False) == {"reasoning_effort": "none"}
    assert llm._reasoning_payload(None) == {}
