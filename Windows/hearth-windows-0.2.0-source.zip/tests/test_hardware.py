from __future__ import annotations

from hearth.hardware import GpuInfo, _match_vram, detect_hardware


def test_gpu_vram_table_prefers_longest_match():
    assert _match_vram("NVIDIA GeForce RTX 5060") == 8
    assert _match_vram("NVIDIA GeForce RTX 5060 Ti") == 16
    assert _match_vram("NVIDIA GeForce RTX 4090") == 24
    assert _match_vram("AMD Radeon RX 7900 XTX") == 24


def test_lspci_fallback_plans_vram_and_warns(monkeypatch):
    import hearth.hardware as hardware

    monkeypatch.setattr(hardware, "_nvidia_gpus", lambda: [])
    monkeypatch.setattr(hardware, "_amd_gpus", lambda: [])
    monkeypatch.setattr(
        hardware,
        "_lspci_gpus",
        lambda: [
            GpuInfo(
                vendor="NVIDIA",
                name="RTX 5060",
                vram_gb=8,
                usable=False,
                source="lspci",
                note="Driver not responding",
            )
        ],
    )
    info = detect_hardware()
    assert info.gpu_usable is False
    assert info.total_vram_gb == 8
    assert info.primary_gpu is not None
    assert "driver" in " ".join(info.notes).lower()
    payload = info.to_dict()
    assert payload["summary"].startswith("RTX 5060")
    assert payload["python_version"]
    assert payload["physical_cores"] >= 1
