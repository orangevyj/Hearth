from __future__ import annotations

import contextlib

from hearth.chats import ChatStore


def test_chat_crud_and_auto_title(tmp_path):
    store = ChatStore(tmp_path / "chats.db")
    chat = store.create_chat()
    assert chat["title"] == "New chat"
    store.add_message(chat["id"], "user", "Explain local inference")
    assert store.get_chat(chat["id"])["title"] == "Explain local inference"
    assistant = store.add_message(chat["id"], "assistant", "It runs here.")
    fresh = store.get_chat(chat["id"])
    assert [message["role"] for message in fresh["messages"]] == ["user", "assistant"]
    assert fresh["messages"][-1]["content"] == "It runs here."

    renamed = store.rename_chat(chat["id"], "Local notes")
    assert renamed["title"] == "Local notes"
    assert store.list_chats()[0]["preview"] == "It runs here."
    assert store.count_chats() == 1

    store.delete_message_and_after(chat["id"], assistant["id"])
    assert len(store.get_chat(chat["id"])["messages"]) == 1
    store.close()


def test_attachment_linking_and_export(tmp_path):
    store = ChatStore(tmp_path / "chats.db")
    chat = store.create_chat()
    image_path = tmp_path / "image.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n")
    attachment = {
        "id": "img1",
        "kind": "image",
        "filename": "image.png",
        "path": str(image_path),
        "mime": "image/png",
        "size": image_path.stat().st_size,
        "meta": {},
    }
    store.store_attachment(attachment)
    assert store.pending_attachments(["img1"])
    message = store.add_message(chat["id"], "user", "look", attachment_ids=["img1"])
    got = store.get_message(message["id"])
    assert got["attachments"][0]["filename"] == "image.png"
    assert store.pending_attachments(["img1"]) == []

    store.store_attachment({**attachment, "id": "img2"})
    store.add_message(chat["id"], "assistant", "seen")
    with contextlib.suppress(ValueError):
        store.link_attachments("not-a-message", ["img2"])

    markdown = store.export_markdown(chat["id"])
    assert markdown and "# " in markdown and "image.png" in markdown
    assert store.delete_chat(chat["id"]) is True
    assert store.get_chat(chat["id"]) is None
    store.close()


def test_existing_database_gains_the_owner_column(tmp_path):
    # A database created before chat ownership existed must keep working.
    import sqlite3

    from hearth.chats import ChatStore

    path = tmp_path / "old.db"
    connection = sqlite3.connect(path)
    connection.executescript(
        """
        CREATE TABLE chats (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            model TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        INSERT INTO chats (id, title, model, created_at, updated_at)
        VALUES ('legacy', 'Old chat', '', '2026-01-01T00:00:00+00:00', '2026-01-01T00:00:00+00:00');
        """
    )
    connection.commit()
    connection.close()

    store = ChatStore(path)
    try:
        chats = store.list_chats(owner="")
        assert [chat["id"] for chat in chats] == ["legacy"]
        assert store.list_chats(owner="someone") == []
        created = store.create_chat(title="new", owner="sam")
        assert created["owner"] == "sam"
        assert store.get_chat(created["id"], owner="sam") is not None
        assert store.get_chat(created["id"], owner="") is None
    finally:
        store.close()
