from __future__ import annotations

import shutil

import pytest

from hearth.config import ConfigStore
from hearth.jobs import JobManager
from hearth.runtimes import RuntimeManager


@pytest.mark.skipif(not shutil.which("espeak-ng"), reason="espeak-ng is not installed")
async def test_tts_falls_back_to_espeak(tmp_path):
    manager = RuntimeManager(ConfigStore(tmp_path / "config.json"), JobManager())
    output = tmp_path / "speech.wav"
    result = await manager.tts("Hello from Hearth", output, "en_US-amy-medium")
    assert result["engine"] == "espeak"
    assert output.exists()
    assert output.read_bytes()[:4] == b"RIFF"
