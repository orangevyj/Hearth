from __future__ import annotations

import subprocess

from hearth import osutil


def test_executable_names_follow_the_platform(monkeypatch):
    monkeypatch.setattr(osutil, "IS_WINDOWS", False)
    assert osutil.exe("ollama") == "ollama"
    assert osutil.exe("piper") == "piper"
    monkeypatch.setattr(osutil, "IS_WINDOWS", True)
    assert osutil.exe("ollama") == "ollama.exe"
    assert osutil.exe("ollama.exe") == "ollama.exe"  # not doubled


def test_venv_layout_follows_the_platform(monkeypatch, tmp_path):
    monkeypatch.setattr(osutil, "IS_WINDOWS", False)
    assert osutil.venv_python(tmp_path) == tmp_path / "bin" / "python"
    monkeypatch.setattr(osutil, "IS_WINDOWS", True)
    assert osutil.venv_python(tmp_path) == tmp_path / "Scripts" / "python.exe"


def test_runtime_assets_follow_the_platform(monkeypatch):
    monkeypatch.setattr(osutil, "IS_WINDOWS", False)
    assert osutil.ollama_asset("amd64") == "ollama-linux-amd64.tar.zst"
    assert osutil.piper_asset() == "piper_linux_x86_64.tar.gz"
    monkeypatch.setattr(osutil, "IS_WINDOWS", True)
    assert osutil.ollama_asset("amd64") == "ollama-windows-amd64.zip"
    assert osutil.piper_asset() == "piper_windows_amd64.zip"


def test_spawn_kwargs_are_platform_specific(monkeypatch):
    monkeypatch.setattr(osutil, "IS_WINDOWS", False)
    assert osutil.spawn_kwargs() == {"start_new_session": True}
    monkeypatch.setattr(osutil, "IS_WINDOWS", True)
    kwargs = osutil.spawn_kwargs()
    assert "creationflags" in kwargs and "start_new_session" not in kwargs


def test_terminate_tree_ignores_finished_processes(monkeypatch):
    monkeypatch.setattr(osutil, "IS_WINDOWS", False)
    proc = subprocess.Popen(["true"])
    proc.wait()
    osutil.terminate_tree(proc)  # must not raise
    assert proc.poll() == 0


def test_terminate_tree_stops_a_running_process(monkeypatch):
    monkeypatch.setattr(osutil, "IS_WINDOWS", False)
    # Real children are spawned detached, exactly like this.
    proc = subprocess.Popen(["sleep", "30"], **osutil.spawn_kwargs())
    osutil.terminate_tree(proc)
    assert proc.poll() is not None


def test_platform_name_reports_something(monkeypatch):
    monkeypatch.setattr(osutil, "IS_WINDOWS", True)
    assert osutil.platform_name() == "windows"
    monkeypatch.setattr(osutil, "IS_WINDOWS", False)
    assert osutil.platform_name() in {"linux", "darwin"}
