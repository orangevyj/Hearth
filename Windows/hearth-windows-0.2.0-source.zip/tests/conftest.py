from __future__ import annotations

import contextlib
import os
import shutil
import tempfile
from pathlib import Path

import pytest

# Must happen before any hearth import: paths are resolved at import time.
ROOT = Path(tempfile.mkdtemp(prefix="hearth-tests-"))
os.environ["HEARTH_CONFIG_DIR"] = str(ROOT / "config")
os.environ["HEARTH_DATA_DIR"] = str(ROOT / "data")
os.environ["HEARTH_CACHE_DIR"] = str(ROOT / "cache")


def pytest_sessionfinish(session, exitstatus):  # noqa: ARG001
    shutil.rmtree(ROOT, ignore_errors=True)


@pytest.fixture
def app_state(tmp_path):
    from hearth.app import AppState
    from hearth.chats import ChatStore
    from hearth.jobs import JobManager

    state = AppState()
    state.config_store.reset()
    state.config_store.update(
        {
            "text": {"backend": "demo"},
            "setup_complete": True,
            "server": {"host": "127.0.0.1"},
        }
    )
    state.chats.close()
    state.chats = ChatStore(tmp_path / "chats.db")
    state.jobs = JobManager()
    state.running = True
    state.stop_events.clear()
    state.invalidate()
    yield state
    with contextlib.suppress(Exception):
        state.chats.close()


@pytest.fixture
def client(app_state):
    from fastapi.testclient import TestClient

    from hearth.app import create_app

    with TestClient(create_app(app_state)) as test_client:
        yield test_client


@pytest.fixture
def auth(client):
    state = client.get("/api/state").json()
    return {"x-hearth-token": state["csrf_token"]}
