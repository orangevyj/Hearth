from __future__ import annotations

import time


def test_static_and_health(client):
    assert client.get("/").status_code == 200
    assert client.get("/chat").status_code == 200
    assert client.get("/health").json()["ok"] is True


def test_csrf_required(client, auth):
    assert client.post("/api/server/start").status_code == 403
    assert client.post("/api/server/start", headers=auth).status_code == 200


def test_chat_stream_and_persistence(client, auth):
    chat = client.post("/api/chats", headers=auth, json={}).json()
    response = client.post(
        f"/api/chats/{chat['id']}/messages",
        headers=auth,
        json={"content": "hello from pytest"},
    )
    assert response.status_code == 200
    assert "event: delta" in response.text
    assert "demo mode" in response.text
    stored = client.get(f"/api/chats/{chat['id']}").json()
    assert [message["role"] for message in stored["messages"]] == ["user", "assistant"]
    assert "demo mode" in stored["messages"][-1]["content"]
    exported = client.get(f"/api/chats/{chat['id']}/export?fmt=markdown")
    assert exported.status_code == 200
    assert "hello from pytest" in exported.text


def test_upload_and_media(client, auth):
    response = client.post(
        "/api/uploads",
        headers=auth,
        files={"file": ("note.txt", b"hello from a file", "text/plain")},
    )
    assert response.status_code == 200
    attachment = response.json()
    assert attachment["kind"] == "text"
    media = client.get(attachment["url"])
    assert media.status_code == 200
    assert b"hello from a file" in media.content


def test_preset_apply_without_download(client, auth):
    response = client.post(
        "/api/presets/fast/apply",
        headers=auth,
        json={"download": False, "modalities": {"text": True, "video": False}},
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["config"]["preset"] == "fast"
    assert payload["config"]["video"]["enabled"] is False
    assert payload["config"]["setup_complete"] is True


def test_direct_generation_reports_missing_runtime(client, auth):
    chat = client.post("/api/chats", headers=auth, json={}).json()
    response = client.post(
        "/api/generate",
        headers=auth,
        json={"modality": "image", "prompt": "a brass lantern", "chat_id": chat["id"]},
    )
    assert response.status_code == 200
    job_id = response.json()["job_id"]
    job = None
    for _ in range(80):
        job = client.get(f"/api/jobs/{job_id}").json()
        if job["status"] in {"done", "error", "canceled"}:
            break
        time.sleep(0.05)
    assert job is not None
    assert job["status"] == "error"
    stored = client.get(f"/api/chats/{chat['id']}").json()
    assert "ComfyUI" in stored["messages"][-1]["content"]


def test_rename_delete_and_server_stop(client, auth):
    chat = client.post("/api/chats", headers=auth, json={"title": "First"}).json()
    renamed = client.patch(f"/api/chats/{chat['id']}", headers=auth, json={"title": "Renamed"})
    assert renamed.json()["title"] == "Renamed"
    assert client.delete(f"/api/chats/{chat['id']}", headers=auth).json()["deleted"] is True
    assert client.get(f"/api/chats/{chat['id']}").status_code == 404
    stopped = client.post("/api/server/stop", headers=auth)
    assert stopped.json()["running"] is False


def test_saved_preset_endpoints(client, auth):
    payload = {
        "name": "Study night",
        "text_model": "qwen3.5:4b",
        "image_model": "sdxl-turbo",
        "video_model": "wan2.1-1.3b",
        "three_d_model": "hunyuan3d-2.1",
        "music_model": "ace-step-1.5",
        "tts_voice": "en_US-amy-medium",
        "stt_model": "small",
    }
    saved = client.post("/api/presets/saved", headers=auth, json=payload)
    assert saved.status_code == 200
    preset_id = saved.json()["preset"]["id"]
    names = [preset["tier"] for preset in saved.json()["presets"]["presets"]]
    assert preset_id in names

    applied = client.post(f"/api/presets/{preset_id}/apply", headers=auth, json={"download": False})
    assert applied.status_code == 200
    assert applied.json()["config"]["preset"] == preset_id
    assert applied.json()["config"]["music"]["model"] == "ace-step-1.5"

    assert client.delete(f"/api/presets/saved/{preset_id}", headers=auth).status_code == 200
    assert client.delete(f"/api/presets/saved/{preset_id}", headers=auth).status_code == 404


def test_saved_preset_needs_every_model(client, auth):
    response = client.post("/api/presets/saved", headers=auth, json={"name": "Half"})
    assert response.status_code == 422


def test_custom_model_import_endpoints(client, auth):
    bad_family = client.post(
        "/api/models/custom",
        headers=auth,
        json={"name": "Wrong", "modality": "image", "workflow": "wan", "files": []},
    )
    assert bad_family.status_code == 422

    missing_file = client.post(
        "/api/models/custom",
        headers=auth,
        json={
            "name": "Ghost",
            "modality": "image",
            "workflow": "sdxl",
            "files": [{"source": "local", "dest": "checkpoints/ghost.safetensors"}],
        },
    )
    assert missing_file.status_code == 422

    imported = client.post(
        "/api/models/custom",
        headers=auth,
        json={
            "name": "Imported SDXL",
            "modality": "image",
            "workflow": "sdxl",
            "files": [
                {
                    "repo": "org/name",
                    "filename": "m.safetensors",
                    "dest": "checkpoints/m.safetensors",
                    "size_gb": 6.4,
                }
            ],
        },
    )
    assert imported.status_code == 200
    model_id = imported.json()["model"]["id"]
    catalog_ids = [(item["id"], item.get("custom")) for item in imported.json()["catalog"]["image"]]
    assert (model_id, True) in catalog_ids
    state = client.get("/api/state").json()
    assert model_id in state["installed"]["models"]
    assert model_id in state["installed"]["missing"]

    assert client.delete(f"/api/models/custom/{model_id}", headers=auth).status_code == 200
    assert client.delete(f"/api/models/custom/{model_id}", headers=auth).status_code == 404
    after = client.get("/api/state").json()
    assert model_id not in after["installed"]["models"]


def test_message_accepts_a_reasoning_override(client, auth):
    chat = client.post("/api/chats", headers=auth, json={}).json()
    for reasoning in (True, False, None):
        body = {"content": "think about it", "reasoning": reasoning}
        response = client.post(f"/api/chats/{chat['id']}/messages", headers=auth, json=body)
        assert response.status_code == 200, response.text
        assert "event: delta" in response.text
    regenerated = client.post(f"/api/chats/{chat['id']}/regenerate", headers=auth, json={"reasoning": False})
    assert regenerated.status_code == 200


def test_memory_endpoints(client, auth):
    assert client.get("/api/memories").json()["items"] == []

    created = client.post("/api/memories", headers=auth, json={"text": "Prefers metric units."})
    assert created.status_code == 200
    memory = created.json()["memory"]
    assert memory["enabled"] is True and memory["source"] == "user"

    empty = client.post("/api/memories", headers=auth, json={"text": "   "})
    assert empty.status_code == 422

    disabled = client.patch(f"/api/memories/{memory['id']}", headers=auth, json={"enabled": False})
    assert disabled.status_code == 200
    assert disabled.json()["memory"]["enabled"] is False
    listing = client.get("/api/memories").json()
    assert listing["count"] == {"total": 1, "enabled": 0}

    edited = client.patch(f"/api/memories/{memory['id']}", headers=auth, json={"text": "Prefers miles."})
    assert edited.json()["memory"]["text"] == "Prefers miles."

    assert client.patch("/api/memories/nope", headers=auth, json={"enabled": True}).status_code == 404
    assert client.delete(f"/api/memories/{memory['id']}", headers=auth).status_code == 200
    assert client.delete(f"/api/memories/{memory['id']}", headers=auth).status_code == 404


def test_memory_count_is_in_the_launcher_state(client, auth):
    client.post("/api/memories", headers=auth, json={"text": "Lives in Lisbon."})
    state = client.get("/api/state").json()
    assert state["memories"]["total"] >= 1
    assert state["memories"]["enabled"] is True
    cleared = client.post("/api/memories/clear", headers=auth, json={})
    assert cleared.status_code == 200
    assert cleared.json()["count"]["total"] == 0


def test_chats_are_isolated_per_account(client, auth):
    alice = {**auth, "x-hearth-remote": "alice"}
    bob = {**auth, "x-hearth-remote": "bob"}

    chat = client.post("/api/chats", headers=alice, json={"title": "alice chat"}).json()
    assert chat["owner"] == "alice"

    alice_ids = [item["id"] for item in client.get("/api/chats", headers=alice).json()["chats"]]
    assert alice_ids == [chat["id"]]
    assert client.get("/api/chats", headers=bob).json()["chats"] == []

    # Another account cannot read, rename or delete it.
    assert client.get(f"/api/chats/{chat['id']}", headers=bob).status_code == 404
    assert client.patch(f"/api/chats/{chat['id']}", headers=bob, json={"title": "hijacked"}).status_code == 404
    assert client.delete(f"/api/chats/{chat['id']}", headers=bob).status_code == 404
    assert client.post(f"/api/chats/{chat['id']}/messages", headers=bob, json={"content": "hi"}).status_code == 404
    assert client.post(f"/api/chats/{chat['id']}/stop", headers=bob).status_code == 404

    # The machine itself keeps its own list, separate from every account.
    local = client.post("/api/chats", headers=auth, json={"title": "local chat"}).json()
    assert local["owner"] == ""
    local_ids = [item["id"] for item in client.get("/api/chats", headers=auth).json()["chats"]]
    assert local["id"] in local_ids
    assert chat["id"] not in local_ids

    # Two accounts stay apart from each other too.
    other = client.post("/api/chats", headers=bob, json={"title": "bob chat"}).json()
    assert other["owner"] == "bob"
    assert [item["id"] for item in client.get("/api/chats", headers=bob).json()["chats"]] == [other["id"]]
    assert [item["id"] for item in client.get("/api/chats", headers=alice).json()["chats"]] == [chat["id"]]


def remote_client(app_state):
    """A client whose address is not loopback, like another device on the LAN."""
    from fastapi.testclient import TestClient

    from hearth.app import create_app

    return TestClient(create_app(app_state), client=("203.0.113.7", 51000))


def test_remote_device_gets_a_welcome_page_not_the_launcher(app_state):
    with remote_client(app_state) as remote:
        landing = remote.get("/")
        assert landing.status_code == 200
        assert "panel" in landing.text.lower()
        assert "/api/admin/login" in landing.text
        assert remote.get("/api/state").status_code == 401


def test_remote_panel_login_with_the_configured_code(app_state):
    state = app_state
    state.panel.set_code("firefly-42")

    with remote_client(state) as remote:
        assert remote.get("/api/state").status_code == 401
        wrong = remote.post("/api/admin/login", json={"code": "nope"})
        assert wrong.status_code == 401

        good = remote.post("/api/admin/login", json={"code": "firefly-42"})
        assert good.status_code == 200
        assert good.json()["ok"] is True
        # The session cookie now unlocks the panel exactly like being local.
        assert remote.get("/api/state").status_code == 200
        assert remote.get("/").text.count("Hearth") > 0

        remote.post("/api/admin/logout")
        assert remote.get("/api/state").status_code == 401


def test_remote_login_without_a_configured_code_is_refused(app_state):
    app_state.panel.clear_code()
    with remote_client(app_state) as remote:
        response = remote.post("/api/admin/login", json={"code": "anything"})
        assert response.status_code == 409
        assert "panel code" in response.json()["detail"].lower()


def test_panel_code_can_be_set_and_cleared_from_the_machine(client, auth):
    set_code = client.post("/api/server/panel-code", headers=auth, json={"code": "abcd1234"})
    assert set_code.status_code == 200 and set_code.json()["configured"] is True
    assert client.get("/api/admin/status").json()["configured"] is True
    too_short = client.post("/api/server/panel-code", headers=auth, json={"code": "ab"})
    assert too_short.status_code == 422
    cleared = client.post("/api/server/panel-code", headers=auth, json={"code": ""})
    assert cleared.json()["configured"] is False
