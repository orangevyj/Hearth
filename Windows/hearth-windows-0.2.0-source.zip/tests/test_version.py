from __future__ import annotations

import json

from hearth import clients, crypto


def write_manifest(directory, builds):
    (directory / "clients.json").write_text(json.dumps({"builds": builds}))


def test_version_comparison_helpers():
    assert clients.version_tuple("1.2.3") == (1, 2, 3)
    assert clients.version_tuple("0.2") == (0, 2)
    assert clients.is_older("0.1.0", "0.2.0") is True
    assert clients.is_older("0.2.0", "0.2.0") is False
    assert clients.is_older("0.3.0", "0.2.0") is False
    assert clients.is_older("", "0.2.0") is True
    assert clients.is_older("0.1.0", "") is False


def test_client_header_parsing():
    assert clients.parse_client_header("android/0.1.0") == ("android", "0.1.0")
    assert clients.parse_client_header("Android/0.1.0") == ("android", "0.1.0")
    assert clients.parse_client_header("") == ("", "")
    assert clients.parse_client_header("android") == ("android", "")


def test_version_payload_lists_builds(tmp_path, monkeypatch):
    from hearth import paths

    monkeypatch.setattr(paths, "CLIENTS_DIR", tmp_path)
    write_manifest(tmp_path, {"android": {"version": "0.2.0", "file": "hearth-android.apk"}})
    payload = clients.version_payload("0.2.0")
    assert payload["server"] == "0.2.0"
    assert payload["builds"] == {"android": "0.2.0"}
    assert payload["downloads"] == {"android": "/downloads/hearth-android.apk"}


def test_version_endpoint(client, auth, tmp_path, monkeypatch):
    from hearth import paths

    monkeypatch.setattr(paths, "CLIENTS_DIR", tmp_path)
    write_manifest(tmp_path, {"android": {"version": "9.9.9", "file": "hearth-android.apk"}})
    payload = client.get("/api/version").json()
    assert payload["builds"]["android"] == "9.9.9"
    assert payload["server"]


def rpc_request(address, name, secret, salt, path, client_header):
    key = crypto.derive_key(secret, salt)
    inner = json.dumps({"method": "GET", "path": path, "body": None}).encode()
    envelope = json.dumps({"d": crypto.seal(key, inner, aad=name.encode())}).encode()
    return key, envelope


def test_old_client_is_told_to_upgrade(client, auth, app_state, tmp_path, monkeypatch):
    from hearth import paths

    monkeypatch.setattr(paths, "CLIENTS_DIR", tmp_path)
    write_manifest(tmp_path, {"android": {"version": "0.5.0", "file": "hearth-android.apk"}})
    (tmp_path / "hearth-android.apk").write_bytes(b"apk")

    user = app_state.accounts.add("handset", secret="s3cret-value")
    salt = app_state.accounts.salt
    key, envelope = rpc_request("", user["name"], user["secret"], salt, "/api/state", "")

    stale = client.post(
        "/api/secure/rpc",
        content=envelope,
        headers={"Content-Type": "application/json", "X-Hearth-User": user["name"], "X-Hearth-Client": "android/0.1.0"},
    )
    assert stale.status_code == 426
    detail = stale.json()
    assert detail["required_version"] == "0.5.0"
    assert detail["client_version"] == "0.1.0"
    assert detail["download_url"] == "/downloads/hearth-android.apk"

    fresh = client.post(
        "/api/secure/rpc",
        content=envelope,
        headers={"Content-Type": "application/json", "X-Hearth-User": user["name"], "X-Hearth-Client": "android/0.5.0"},
    )
    assert fresh.status_code == 200
