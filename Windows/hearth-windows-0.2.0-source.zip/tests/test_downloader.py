from __future__ import annotations

import http.server
import os
import threading

from hearth.downloader import Downloader, SourcePicker
from hearth.jobs import Job

PAYLOAD = os.urandom(1_000_000)


class RangeHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):  # noqa: ANN002
        pass

    def do_GET(self):
        range_header = self.headers.get("Range")
        start = int(range_header.split("=")[1].split("-")[0]) if range_header else 0
        body = PAYLOAD[start:]
        self.send_response(206 if range_header else 200)
        self.send_header("Content-Length", str(len(body)))
        if range_header:
            self.send_header("Content-Range", f"bytes {start}-{len(PAYLOAD) - 1}/{len(PAYLOAD)}")
        self.end_headers()
        self.wfile.write(body)


def serve(handler):
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def test_resumable_download(tmp_path):
    server = serve(RangeHandler)
    try:
        port = server.server_address[1]
        dest = tmp_path / "model.bin"
        part = dest.with_name("model.bin.part")
        part.write_bytes(PAYLOAD[:300_000])
        job = Job("test", "download")
        job.add_item("item", "model", size_gb=0.001)
        result = Downloader().download(
            f"http://127.0.0.1:{port}/file",
            dest,
            job,
            "item",
            expected_bytes=len(PAYLOAD),
        )
        assert result.read_bytes() == PAYLOAD
        assert not part.exists()
        assert job.item("item").status == "done"
    finally:
        server.shutdown()


def test_fresh_download(tmp_path):
    server = serve(RangeHandler)
    try:
        port = server.server_address[1]
        dest = tmp_path / "fresh.bin"
        result = Downloader().download(
            f"http://127.0.0.1:{port}/file",
            dest,
            expected_bytes=len(PAYLOAD),
        )
        assert result.read_bytes() == PAYLOAD
    finally:
        server.shutdown()


def test_hf_url_encoding():
    picker = SourcePicker()
    url = picker.hf_url("owner/repo", "folder/file with spaces.safetensors", "https://huggingface.co")
    assert url.startswith("https://huggingface.co/owner/repo/resolve/main/folder/file%20with%20spaces.safetensors")
