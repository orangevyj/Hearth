from __future__ import annotations

from hearth.hardware import GpuInfo, HardwareInfo
from hearth.presets import build_presets


def make_hw(vram: float, ram: float) -> HardwareInfo:
    return HardwareInfo(
        os_name="Linux",
        distro="Test Linux",
        kernel="test",
        cpu_model="Test CPU",
        physical_cores=6,
        threads=12,
        avx2=True,
        ram_gb=ram,
        ram_available_gb=ram * 0.7,
        gpus=[GpuInfo(vendor="NVIDIA", name="Test GPU", vram_gb=vram, usable=True)],
        total_vram_gb=vram,
        gpu_usable=True,
        disk_total_gb=1000,
        disk_free_gb=500,
        python_version="3.12",
    )


def test_8gb_preset_ladder():
    presets = {preset.tier: preset for preset in build_presets(make_hw(8, 31))}
    assert presets["fast"].text_model == "qwen3.5:4b"
    assert presets["balanced"].text_model == "qwen3.5:9b"
    assert presets["smart"].text_model == "qwen3.5:35b-a3b-q4_K_M"
    assert presets["fast"].image_model == "sdxl-turbo"
    assert presets["balanced"].image_model == "flux-schnell"
    assert presets["smart"].image_model == "flux-dev"
    assert presets["balanced"].recommended is True
    assert presets["balanced"].load_mode == "lazy"
    assert presets["fast"].load_mode == "lazy"


def test_small_machine_picks_small_models():
    presets = {preset.tier: preset for preset in build_presets(make_hw(4, 8))}
    assert presets["fast"].text_model == "qwen3.5:2b"
    assert presets["balanced"].text_model == "qwen3.5:4b"
    assert presets["smart"].text_model == "qwen3.5:9b"


def test_high_end_machine_can_keep_all_resident():
    presets = {preset.tier: preset for preset in build_presets(make_hw(48, 128))}
    assert presets["smart"].load_mode == "keep_all"
    assert presets["smart"].recommended is True


def test_preset_config_patch_respects_disabled_modalities():
    preset = next(p for p in build_presets(make_hw(8, 31)) if p.tier == "fast")
    patch = preset.config_patch({"text": True, "image": False, "video": False, "audio": True})
    assert patch["setup_complete"] is True
    assert patch["preset"] == "fast"
    assert patch["image"]["enabled"] is False
    assert patch["video"]["enabled"] is False
    assert patch["text"]["model"] == preset.text_model
    assert patch["load"]["mode"] == preset.load_mode


CUSTOM_DEF = {
    "id": "custom-study-night",
    "name": "Study night",
    "text_model": "qwen3.5:4b",
    "image_model": "sdxl-turbo",
    "video_model": "wan2.1-1.3b",
    "three_d_model": "hunyuan3d-2.1",
    "music_model": "ace-step-1.5",
    "tts_voice": "en_US-amy-medium",
    "stt_model": "small",
}


def test_custom_preset_mirrors_the_builtin_shape():
    from hearth.presets import build_custom_presets

    presets = build_custom_presets([CUSTOM_DEF], make_hw(8, 31))
    assert len(presets) == 1
    preset = presets[0]
    assert preset.tier == "custom-study-night"
    assert preset.custom is True
    assert preset.recommended is False
    assert preset.load_mode == "lazy"
    assert preset.download_gb > 0
    assert preset.peak_vram_gb > 0
    # The same shape the UI renders for the built-in tiers.
    payload = preset.to_dict()
    assert payload["custom"] is True
    assert payload["models"]["music"]["id"] == "ace-step-1.5"
    assert payload["audio"]["tts_voice"]["id"] == "en_US-amy-medium"


def test_custom_preset_is_findable_and_in_the_payload():
    from hearth.presets import build_custom_presets, find_preset, presets_payload

    hw = make_hw(8, 31)
    found = find_preset(hw, "custom-study-night", [CUSTOM_DEF])
    assert found is not None and found.name == "Study night"
    assert find_preset(hw, "custom-missing", [CUSTOM_DEF]) is None
    payload = presets_payload(hw, [CUSTOM_DEF])
    assert payload["custom"] == ["custom-study-night"]
    assert [preset["tier"] for preset in payload["presets"]][-1] == "custom-study-night"
    # A definition that points at a model Hearth no longer knows is dropped.
    assert build_custom_presets([{**CUSTOM_DEF, "image_model": "nope"}], hw) == []


def test_custom_preset_config_patch_keeps_music_steps_in_range():
    from hearth.presets import build_custom_presets

    preset = build_custom_presets([CUSTOM_DEF], make_hw(8, 31))[0]
    patch = preset.config_patch({"music": True})
    assert patch["preset"] == "custom-study-night"
    assert patch["music"]["model"] == "ace-step-1.5"
    assert patch["video"]["model"] == "wan2.1-1.3b"
