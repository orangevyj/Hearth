from __future__ import annotations

import pytest

from hearth.config import ConfigStore
from hearth.memory import MemoryStore
from hearth.tools import ToolContext, execute_tool


def store(tmp_path) -> MemoryStore:
    return MemoryStore(tmp_path / "memories.json")


def ctx(tmp_path, memories, **config_patch) -> ToolContext:
    config = ConfigStore(tmp_path / "config.json")
    config.load()
    if config_patch:
        config.update(config_patch)
    return ToolContext(
        config_store=config,
        runtimes=None,
        comfy=None,
        jobs=None,
        outputs=None,
        memories=memories,
    )


def test_adds_and_persists(tmp_path):
    first = store(tmp_path)
    item = first.add("Prefers short answers.", source="model")
    assert item["enabled"] is True and item["source"] == "model"
    again = MemoryStore(tmp_path / "memories.json")
    assert [entry["text"] for entry in again.items] == ["Prefers short answers."]


def test_duplicates_refresh_instead_of_piling_up(tmp_path):
    memories = store(tmp_path)
    item = memories.add("Lives in Lisbon.")
    memories.update(item["id"], enabled=False)
    refreshed = memories.add("lives in lisbon.")
    assert refreshed["id"] == item["id"]
    assert refreshed["enabled"] is True
    assert len(memories.items) == 1


def test_only_enabled_memories_reach_the_prompt(tmp_path):
    memories = store(tmp_path)
    memories.add("Name is Sam.")
    drop = memories.add("Was testing the music model.")
    memories.update(drop["id"], enabled=False)
    block = memories.prompt_block()
    assert "Name is Sam." in block
    assert "music model" not in block


def test_prompt_block_respects_the_limit(tmp_path):
    memories = store(tmp_path)
    for index in range(5):
        memories.add(f"Fact {index}")
    block = memories.prompt_block(limit=2)
    assert block.count("- Fact") == 2


def test_empty_memory_is_rejected(tmp_path):
    memories = store(tmp_path)
    with pytest.raises(ValueError):
        memories.add("   ")


def test_forget_matching_is_exact_then_loose(tmp_path):
    memories = store(tmp_path)
    memories.add("Favourite colour is green.")
    memories.add("Has a dog named Ada.")
    assert memories.forget_matching("Favourite colour is green.") == 1
    assert memories.forget_matching("Ada") == 1
    assert memories.items == []


def test_clear_can_keep_disabled_items(tmp_path):
    memories = store(tmp_path)
    kept = memories.add("Keep me")
    memories.update(kept["id"], enabled=False)
    memories.add("Remove me")
    assert memories.clear(only_enabled=True) == 1
    assert [item["text"] for item in memories.items] == ["Keep me"]


async def test_remember_tool_writes_to_the_store(tmp_path):
    memories = store(tmp_path)
    result = await execute_tool("remember", {"text": "Uses Fedora on a 5060."}, ctx(tmp_path, memories))
    assert result.error == ""
    assert [item["text"] for item in memories.items] == ["Uses Fedora on a 5060."]


async def test_forget_tool_deletes_matching_memories(tmp_path):
    memories = store(tmp_path)
    memories.add("Uses Fedora on a 5060.")
    result = await execute_tool("forget_memory", {"text": "Fedora"}, ctx(tmp_path, memories))
    assert result.error == ""
    assert memories.items == []


async def test_memory_tools_are_inert_when_memory_is_off(tmp_path):
    memories = store(tmp_path)
    tool_ctx = ctx(tmp_path, memories, **{"memory": {"enabled": False}})
    remember = await execute_tool("remember", {"text": "Something"}, tool_ctx)
    assert remember.error == "memory disabled"
    assert memories.items == []


async def test_memory_tools_respect_the_tool_permission(tmp_path):
    memories = store(tmp_path)
    tool_ctx = ctx(tmp_path, memories, **{"tools": {"remember": False}})
    result = await execute_tool("remember", {"text": "Something"}, tool_ctx)
    assert "disabled" in result.error


def test_system_prompt_carries_enabled_memories(tmp_path):
    from hearth.chat_engine import ChatEngine

    config = ConfigStore(tmp_path / "config.json")
    config.load()
    memories = store(tmp_path)
    memories.add("Prefers metric units.")
    hidden = memories.add("Mentioned a holiday in May.")
    memories.update(hidden["id"], enabled=False)
    engine = ChatEngine(config, None, None, None, None, memories=memories)
    prompt = engine._system_prompt([], "none", False, False)
    assert "Prefers metric units." in prompt
    assert "holiday in May" not in prompt
    assert "remember" in prompt

    config.update({"memory": {"enabled": False}})
    off_prompt = engine._system_prompt([], "none", False, False)
    assert "Prefers metric units." not in off_prompt
