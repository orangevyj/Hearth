from __future__ import annotations

import pytest

from hearth import hf


def entry(filename: str, size_gb: float) -> dict:
    return {"filename": filename, "size_gb": size_gb}


def test_detects_the_families_hearth_can_drive():
    assert hf.detect_family("Comfy-Org/Flux-1-Dev")["workflow"] == "flux"
    assert hf.detect_family("stabilityai/stable-diffusion-xl-base-1.0")["workflow"] == "sdxl"
    assert hf.detect_family("Comfy-Org/Wan-2.2")["workflow"] == "wan22"
    assert hf.detect_family("Comfy-Org/Wan-2.1")["workflow"] == "wan"
    assert hf.detect_family("tencent/Hunyuan3D-2.1")["workflow"] == "hunyuan3d"
    assert hf.detect_family("Comfy-Org/ace_step_1.5_xl_turbo")["workflow"] == "ace-xl"
    assert hf.detect_family("x/ace_step_1.5_xl_sft")["workflow"] == "ace-xl-sft"
    assert hf.detect_family("some/random-llm-gguf") is None


def test_single_file_repo_imports_the_checkpoint():
    plan = hf.plan_import(
        "Comfy-Org/ACE-Step-1.5",
        [
            entry("checkpoints/ace_step_1.5_turbo_aio.safetensors", 9.34),
            entry("split_files/diffusion_models/acestep_v1.5_base.safetensors", 4.46),
        ],
        {"modality": "music", "workflow": "ace"},
    )
    assert plan["modality"] == "music" and plan["workflow"] == "ace"
    assert [item["dest"] for item in plan["files"]] == ["checkpoints/ace_step_1.5_turbo_aio.safetensors"]
    assert plan["files"][0]["role"] == "checkpoint"
    assert plan["files"][0]["size_gb"] == 9.34


def test_split_files_are_mapped_to_roles():
    plan = hf.plan_import(
        "someone/wan-2.2-comfy",
        [
            entry("split_files/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors", 9.31),
            entry("split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors", 6.27),
            entry("split_files/vae/wan2.2_vae.safetensors", 1.31),
        ],
        {"modality": "video", "workflow": "wan22"},
    )
    roles = {item["role"]: item["dest"] for item in plan["files"]}
    assert roles["diffusion"] == "diffusion_models/wan2.2_ti2v_5B_fp16.safetensors"
    assert roles["text_encoder"] == "text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors"
    assert roles["vae"] == "vae/wan2.2_vae.safetensors"


def test_ambiguous_repo_is_refused_instead_of_guessing():
    files = [
        entry("split_files/diffusion_models/wan2.2_t2v_high_noise_14B_fp16.safetensors", 28.6),
        entry("split_files/diffusion_models/wan2.2_i2v_high_noise_14B_fp16.safetensors", 28.6),
        entry("split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors", 6.27),
        entry("split_files/vae/wan2.2_vae.safetensors", 1.31),
    ]
    with pytest.raises(ValueError, match="several diffusion model variants"):
        hf.plan_import("Comfy-Org/Wan-2.2", files, {"modality": "video", "workflow": "wan22"})


def test_variant_folders_never_win_the_checkpoint_slot():
    # A Fun/VACE/fill checkpoint is not the base model, so it must not be picked
    # even when it sorts first.
    files = [
        entry("split_files/diffusion_models/wan2.2_fun_vace_high_noise_14B_bf16.safetensors", 32.29),
        entry("split_files/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors", 9.31),
        entry("split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors", 6.27),
        entry("split_files/vae/wan2.2_vae.safetensors", 1.31),
    ]
    plan = hf.plan_import("someone/wan", files, {"modality": "video", "workflow": "wan22"})
    diffusion = next(item for item in plan["files"] if item["role"] == "diffusion")
    assert diffusion["dest"] == "diffusion_models/wan2.2_ti2v_5B_fp16.safetensors"


def test_unsupported_architecture_explains_itself():
    with pytest.raises(ValueError, match="no workflow for this architecture"):
        hf.plan_import("some/random-llm-gguf", [entry("model.safetensors", 4.0)], None)


def test_import_preview_reports_refusals_without_network(monkeypatch):
    monkeypatch.setattr(
        hf,
        "repo_files",
        lambda repo, endpoint=None: {
            "repo": repo,
            "gated": False,
            "pipeline_tag": "text-to-image",
            "tags": ["flux"],
            "license": "apache-2.0",
            "files": [
                entry("diffusion_models/flux1-dev.safetensors", 22.17),
                entry("diffusion_models/flux1-dev-fp8.safetensors", 11.9),
            ],
        },
    )
    preview = hf.import_preview("Comfy-Org/Flux-1-Dev")
    assert preview["importable"] is False
    assert "several checkpoint variants" in preview["reason"]
    assert preview["detected"]["workflow"] == "flux"


def test_import_preview_accepts_an_unambiguous_repo(monkeypatch):
    monkeypatch.setattr(
        hf,
        "repo_files",
        lambda repo, endpoint=None: {
            "repo": repo,
            "gated": False,
            "pipeline_tag": "text-to-image",
            "tags": ["flux"],
            "license": "apache-2.0",
            "files": [entry("checkpoints/flux1-schnell-fp8.safetensors", 16.05)],
        },
    )
    preview = hf.import_preview("someone/flux-schnell-fp8")
    assert preview["importable"] is True
    assert preview["size_gb"] == 16.05
    assert preview["plan"]["modality"] == "image"
    assert preview["plan"]["files"][0]["dest"] == "checkpoints/flux1-schnell-fp8.safetensors"


def test_gated_repo_is_reported_not_imported(monkeypatch):
    monkeypatch.setattr(
        hf,
        "repo_files",
        lambda repo, endpoint=None: {
            "repo": repo,
            "gated": True,
            "pipeline_tag": "text-to-image",
            "tags": ["flux"],
            "license": "other",
            "files": [entry("checkpoints/flux1-dev.safetensors", 22.17)],
        },
    )
    preview = hf.import_preview("black-forest-labs/FLUX.1-dev")
    assert preview["importable"] is False
    assert "gated" in preview["reason"]
