from __future__ import annotations

from hearth import clients, paths


def test_platform_detection_from_user_agents():
    android = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36"
    iphone = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15"
    windows = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36"
    linux = "Mozilla/5.0 (X11; Fedora; Linux x86_64) Gecko/20100101 Firefox/127.0"
    mac = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/17.4"
    assert clients.detect_platform(android) == "android"
    assert clients.detect_platform(iphone) == "ios"
    assert clients.detect_platform(windows) == "windows"
    assert clients.detect_platform(linux) == "linux"
    assert clients.detect_platform(mac) == "macos"
    assert clients.detect_platform("curl/8.0") == "unknown"
    # Android agents also mention Linux, so ordering matters.
    assert clients.detect_platform(android) != "linux"


def test_available_lists_only_present_files(tmp_path, monkeypatch):
    monkeypatch.setattr(paths, "CLIENTS_DIR", tmp_path)
    assert clients.available() == []
    (tmp_path / "hearth-android.apk").write_bytes(b"x" * 2048)
    items = clients.available()
    assert [item["platform"] for item in items] == ["android"]
    assert items[0]["url"] == "/downloads/hearth-android.apk"
    assert items[0]["size_mb"] >= 0


def test_payload_recommends_the_matching_platform(tmp_path, monkeypatch):
    monkeypatch.setattr(paths, "CLIENTS_DIR", tmp_path)
    (tmp_path / "hearth-windows.zip").write_bytes(b"x")
    (tmp_path / "hearth-android.apk").write_bytes(b"x")
    payload = clients.payload("Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
    assert payload["detected"] == "windows"
    assert payload["recommended"] == "windows"

    iphone = clients.payload("Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X)")
    assert iphone["detected"] == "ios"
    assert iphone["recommended"] == ""


def test_resolve_rejects_paths_outside_the_folder(tmp_path, monkeypatch):
    monkeypatch.setattr(paths, "CLIENTS_DIR", tmp_path)
    (tmp_path / "hearth-android.apk").write_bytes(b"x")
    assert clients.resolve("hearth-android.apk").name == "hearth-android.apk"
    for bad in ("../secret", "sub/dir.apk", ".hidden"):
        try:
            clients.resolve(bad)
        except (FileNotFoundError, ValueError):
            continue
        raise AssertionError(f"{bad} should not resolve")


def test_mime_types():
    assert clients.mime_for("hearth-android.apk") == "application/vnd.android.package-archive"
    assert clients.mime_for("hearth-windows.zip") == "application/zip"
    assert clients.mime_for("hearth-linux.tar.gz") == "application/gzip"
    assert clients.mime_for("thing.bin") == "application/octet-stream"


def test_clients_endpoint_and_downloads(client, auth, monkeypatch, tmp_path):
    monkeypatch.setattr(paths, "CLIENTS_DIR", tmp_path)
    (tmp_path / "hearth-android.apk").write_bytes(b"apk-bytes")

    listing = client.get("/api/clients", headers={"user-agent": "Mozilla/5.0 (Linux; Android 14) Mobile"})
    assert listing.status_code == 200
    payload = listing.json()
    assert payload["detected"] == "android"
    assert payload["recommended"] == "android"
    assert payload["clients"][0]["url"] == "/downloads/hearth-android.apk"

    download = client.get("/downloads/hearth-android.apk")
    assert download.status_code == 200
    assert download.content == b"apk-bytes"
    assert "android.package-archive" in download.headers["content-type"]

    assert client.get("/downloads/nope.apk").status_code == 404
    assert client.get("/downloads/../config.json").status_code == 404
