from __future__ import annotations

import os
import stat

from hearth.config import AppConfig, ConfigStore, deep_merge


def test_config_roundtrip_and_permissions(tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    config = store.load()
    assert isinstance(config, AppConfig)
    store.update({"text": {"temperature": 0.42, "model": "custom:model"}})
    mode = stat.S_IMODE(os.stat(store.path).st_mode)
    assert mode == 0o600

    reloaded = ConfigStore(store.path).load()
    assert reloaded.text.temperature == 0.42
    assert reloaded.text.model == "custom:model"
    assert reloaded.image.width == 1024


def test_deep_merge_keeps_untouched_keys():
    base = {"a": {"b": 1, "c": 2}, "d": 3}
    merged = deep_merge(base, {"a": {"b": 9}})
    assert merged == {"a": {"b": 9, "c": 2}, "d": 3}
    assert base["a"]["b"] == 1


def test_reset_restores_defaults(tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    store.load()
    store.update({"setup_complete": True, "text": {"backend": "demo"}})
    reset = store.reset()
    assert reset.setup_complete is False
    assert reset.text.backend == "ollama"
