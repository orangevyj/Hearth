from __future__ import annotations

from hearth import paths


def test_linux_dirs_are_xdg(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    config, data, cache = paths.default_dirs(is_windows=False)
    assert config == tmp_path / ".config" / "hearth"
    assert data == tmp_path / ".local" / "share" / "hearth"
    assert cache == tmp_path / ".cache" / "hearth"


def test_windows_dirs_use_appdata(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("APPDATA", r"C:\Users\sam\AppData\Roaming")
    monkeypatch.setenv("LOCALAPPDATA", r"C:\Users\sam\AppData\Local")
    config, data, cache = paths.default_dirs(is_windows=True)
    assert str(config).replace("\\", "/").endswith("AppData/Roaming/Hearth")
    assert str(data).replace("\\", "/").endswith("AppData/Local/Hearth")
    assert str(cache).replace("\\", "/").endswith("AppData/Local/Hearth/Cache")


def test_windows_falls_back_without_appdata(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("APPDATA", raising=False)
    monkeypatch.delenv("LOCALAPPDATA", raising=False)
    config, data, _ = paths.default_dirs(is_windows=True)
    assert config == tmp_path / "AppData" / "Roaming" / "Hearth"
    assert data == tmp_path / "AppData" / "Local" / "Hearth"


def test_env_overrides_win(monkeypatch, tmp_path):
    monkeypatch.setenv("HEARTH_CONFIG_DIR", str(tmp_path / "cfg"))
    monkeypatch.setenv("HEARTH_DATA_DIR", str(tmp_path / "data"))
    # The module-level constants were resolved at import time, so just prove the
    # resolver honours the environment the same way.
    assert paths._xdg("HEARTH_CONFIG_DIR", tmp_path / "ignored") == tmp_path / "cfg"
    assert paths._xdg("HEARTH_DATA_DIR", tmp_path / "ignored") == tmp_path / "data"
