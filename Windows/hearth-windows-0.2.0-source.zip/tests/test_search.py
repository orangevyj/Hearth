from __future__ import annotations

import http.server
import threading

import pytest

from hearth import search
from hearth.config import SearchConfig
from hearth.search import (
    _DuckParser,
    fetch_page,
    format_search_for_model,
    search_web,
    validate_public_url,
)


def test_duckduckgo_parser_decodes_redirect():
    parser = _DuckParser()
    parser.feed(
        """
        <div class="result">
          <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fpage">Example title</a>
          <a class="result__snippet">A useful snippet.</a>
        </div>
        """
    )
    assert parser.results
    assert parser.results[0].title == "Example title"
    assert parser.results[0].url == "https://example.com/page"
    assert "snippet" in parser.results[0].snippet.lower()


def test_ssrf_guard_rejects_local_targets():
    with pytest.raises(ValueError):
        validate_public_url("http://127.0.0.1:8080/secret")
    with pytest.raises(ValueError):
        validate_public_url("http://localhost/secret")
    with pytest.raises(ValueError):
        validate_public_url("file:///etc/passwd")
    assert validate_public_url("https://example.com/hello") == "https://example.com/hello"


async def test_fetch_page_extracts_readable_text():
    html = b"""
    <html><head><title>Test page</title><script>evil()</script></head>
    <body><h1>Hello</h1><p>Readable body text.</p><style>.x{color:red}</style></body></html>
    """

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):  # noqa: ANN002
            pass

        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html)))
            self.end_headers()
            self.wfile.write(html)

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        page = await fetch_page(f"http://127.0.0.1:{server.server_address[1]}/", allow_private=True)
        assert page["title"] == "Test page"
        assert "Readable body text" in page["text"]
        assert "evil" not in page["text"]
    finally:
        server.shutdown()


async def test_search_web_uses_configured_searxng(monkeypatch):
    async def fake_searxng(query, config):
        return [
            search.SearchResult(
                title="Result",
                url="https://example.com/result",
                snippet="Snippet",
                provider="searxng",
            )
        ]

    monkeypatch.setattr(search, "_searxng", fake_searxng)
    config = SearchConfig(provider="searxng", searxng_url="http://searxng.local", fetch_pages=False)
    payload = await search_web("hearth", config, fetch_pages=False)
    assert payload["provider"] == "searxng"
    assert payload["results"][0]["title"] == "Result"
    formatted = format_search_for_model(payload)
    assert "[1]" in formatted
    assert "example.com" in formatted
