from __future__ import annotations

import shutil
import subprocess
import tarfile

import pytest

from hearth.config import ConfigStore
from hearth.jobs import JobManager
from hearth.runtimes import RuntimeManager


def manager(tmp_path):
    return RuntimeManager(ConfigStore(tmp_path / "config.json"), JobManager())


@pytest.mark.skipif(not shutil.which("zstd"), reason="zstd is not installed")
def test_extract_zstd_tarball(tmp_path):
    source = tmp_path / "source" / "bin"
    source.mkdir(parents=True)
    binary = source / "ollama"
    binary.write_text("#!/bin/sh\n")
    binary.chmod(0o755)
    archive = tmp_path / "runtime.tar"
    with tarfile.open(archive, "w") as tar:
        tar.add(source, arcname="bin")
    compressed = tmp_path / "runtime.tar.zst"
    subprocess.run(["zstd", "-q", "-f", str(archive), "-o", str(compressed)], check=True)

    instance = manager(tmp_path)
    target = tmp_path / "extracted"
    instance._extract_archive(compressed, target)
    assert (target / "bin" / "ollama").exists()


def test_find_file_and_whisper_status(tmp_path):
    instance = manager(tmp_path)
    root = tmp_path / "tree"
    root.mkdir()
    (root / "nested").mkdir()
    (root / "nested" / "ollama").write_text("x")
    found = instance._find_file(root, "ollama")
    assert found is not None and found.name == "ollama"
    assert instance.whisper_installed("small") is False


def test_ollama_model_dir_does_not_shadow_model_listing(tmp_path):
    instance = manager(tmp_path)
    assert callable(instance.ollama_models)
    assert instance.ollama_models_dir.name == "ollama"


def test_piper_binary_prefers_file_over_directory(tmp_path):
    instance = manager(tmp_path)
    root = tmp_path / "piper"
    (root / "piper").mkdir(parents=True)
    binary = root / "piper" / "piper"
    binary.write_text("#!/bin/sh\n")
    binary.chmod(0o755)
    instance.piper_dir = root
    assert instance.piper_binary() == binary


def test_comfy_command_offload_flags(tmp_path):
    from hearth.hardware import GpuInfo, HardwareInfo

    store = ConfigStore(tmp_path / "config.json")
    store.load()
    store.update({"runtimes": {"comfyui_vram_mode": "ram", "comfyui_reserve_vram_gb": 1.5, "comfyui_vram_headroom_gb": 0.5}})
    hw = HardwareInfo(
        gpus=[GpuInfo(vendor="NVIDIA", name="GPU", vram_gb=8, usable=True)],
        total_vram_gb=8,
        gpu_usable=True,
    )
    instance = RuntimeManager(store, JobManager(), hardware_provider=lambda: hw)
    command = instance.comfy_command()
    assert "--disable-smart-memory" in command
    assert command[command.index("--reserve-vram") + 1] == "1.5"
    assert command[command.index("--vram-headroom") + 1] == "0.5"

    store.update({"runtimes": {"comfyui_vram_mode": "cpu"}})
    assert "--cpu" in instance.comfy_command()


def _spec(files):
    from hearth import catalog

    return catalog.ModelSpec(
        id="probe-model",
        name="Probe",
        modality="image",
        runtime="comfyui",
        size_gb=sum(item.size_gb for item in files),
        min_vram_gb=1,
        min_ram_gb=1,
        quality=50,
        description="test",
        workflow="sdxl",
        files=tuple(files),
    )


def test_missing_files_only_counts_what_is_absent(tmp_path):
    from hearth import catalog

    instance = manager(tmp_path)
    instance.comfy_root = tmp_path / "ComfyUI"
    spec = _spec(
        [
            catalog.ModelFile(repo="a/b", filename="a.safetensors", dest="checkpoints/a.safetensors", size_gb=4.0),
            catalog.ModelFile(repo="a/b", filename="b.safetensors", dest="vae/b.safetensors", size_gb=0.5),
        ]
    )
    (instance.comfy_root / "models" / "checkpoints").mkdir(parents=True)
    (instance.comfy_root / "models" / "checkpoints" / "a.safetensors").write_bytes(b"x")

    missing = instance.comfy_missing_files(spec)
    assert [item.dest for item in missing] == ["vae/b.safetensors"]
    assert instance.comfy_present_gb(spec) == 4.0
    assert instance.comfy_model_installed(spec) is False

    (instance.comfy_root / "models" / "vae").mkdir(parents=True)
    (instance.comfy_root / "models" / "vae" / "b.safetensors").write_bytes(b"x")
    assert instance.comfy_missing_files(spec) == []
    assert instance.comfy_model_installed(spec) is True


async def test_download_comfy_model_adds_no_items_when_everything_is_present(tmp_path):
    from hearth import catalog
    from hearth.jobs import Job

    instance = manager(tmp_path)
    instance.comfy_root = tmp_path / "ComfyUI"
    instance.comfy_root.mkdir(parents=True)
    (instance.comfy_root / "main.py").write_text("# stub")
    instance.comfy_python = tmp_path / "python"
    instance.comfy_python.write_text("#!/bin/sh\n")
    spec = _spec(
        [catalog.ModelFile(repo="a/b", filename="a.safetensors", dest="checkpoints/a.safetensors", size_gb=4.0)]
    )
    (instance.comfy_root / "models" / "checkpoints").mkdir(parents=True)
    (instance.comfy_root / "models" / "checkpoints" / "a.safetensors").write_bytes(b"x")

    job = Job("model", "Install Probe")
    await instance.download_comfy_model(spec, job)

    assert job.items == {}
    assert any("already installed" in line for line in job.logs)
