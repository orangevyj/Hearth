from __future__ import annotations

import http.server
import json
import threading

from hearth.attachments import OutputStore
from hearth.comfy import (
    ComfyClient,
    build_3d_workflow,
    build_edit_workflow,
    build_image_workflow,
    build_music_workflow,
    build_video_workflow,
)
from hearth.config import ConfigStore
from hearth.jobs import Job

PNG = b"\x89PNG\r\n\x1a\n" + b"fake-image-data" * 10


class FakeHardware:
    total_vram_gb = 8
    ram_available_gb = 24
    ram_gb = 32


class FakeRuntimes:
    def __init__(self, port: int):
        self.comfy_base_url = f"http://127.0.0.1:{port}"
        self.hw = FakeHardware()
        self.unloaded = []
        self.freed = 0

    async def unload_ollama(self, model):
        self.unloaded.append(model)

    async def comfy_running(self):
        return True

    def comfy_installed(self):
        return True

    async def start_comfyui(self, job=None):  # noqa: ARG002
        return {}

    async def free_comfy(self):
        self.freed += 1

    async def comfy_upload_image(self, path):  # noqa: ARG002
        return "hearth/uploaded.png"


def comfy_server():
    class Handler(http.server.BaseHTTPRequestHandler):
        last_prompt = None

        def log_message(self, *args):  # noqa: ANN002
            pass

        def _json(self, payload, status=200):
            body = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            length = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(length) or b"{}")
            if self.path == "/prompt":
                Handler.last_prompt = body
                self._json({"prompt_id": "p1", "number": 1, "node_errors": {}})
            elif self.path == "/free":
                self._json({"ok": True})
            else:
                self._json({"error": "not found"}, 404)

        def do_GET(self):
            if self.path.startswith("/history/p1"):
                self._json(
                    {
                        "p1": {
                            "status": {"status_str": "success", "completed": True},
                            "outputs": {
                                "9": {
                                    "images": [
                                        {"filename": "hearth-test.png", "subfolder": "hearth", "type": "output"}
                                    ]
                                }
                            },
                        }
                    }
                )
            elif self.path.startswith("/view"):
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(PNG)))
                self.end_headers()
                self.wfile.write(PNG)
            elif self.path == "/system_stats":
                self._json({"system": {"comfyui_version": "test"}})
            else:
                self._json({"error": "not found"}, 404)

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, Handler


def test_workflow_builders():
    config = ConfigStore().config
    image = build_image_workflow(config, "a cat", seed=1)
    assert image["1"]["class_type"] == "CheckpointLoaderSimple"
    assert any(node["class_type"] == "KSampler" for node in image.values())

    video = build_video_workflow(config, "a fox", seed=1)
    assert video["1"]["class_type"] == "UNETLoader"
    assert video["6"]["class_type"] == "EmptyHunyuanLatentVideo"
    assert video["9"]["class_type"] == "SaveWEBM"
    assert video["9"]["inputs"]["fps"] == config.video.fps

    wan22_config = config.model_copy(deep=True)
    wan22_config.video.model = "wan2.2-5b"
    wan22 = build_video_workflow(wan22_config, "a fox", seed=1)
    assert wan22["7"]["class_type"] == "Wan22ImageToVideoLatent"
    assert wan22["6"]["class_type"] == "ModelSamplingSD3"
    assert wan22["10"]["inputs"]["fps"] == wan22_config.video.fps

    three_d = build_3d_workflow(config, "hearth/input.png", seed=1)
    assert three_d["1"]["class_type"] == "ImageOnlyCheckpointLoader"
    assert three_d["3"]["class_type"] == "LoadImage"
    assert three_d["10"]["class_type"] == "SaveGLB"

    music = build_music_workflow(config, "lofi", lyrics="hello", seed=1)
    assert music["1"]["class_type"] == "CheckpointLoaderSimple"
    assert music["4"]["class_type"] == "TextEncodeAceStepAudio1.5"
    assert music["10"]["class_type"] == "SaveAudioMP3"
    assert music["8"]["inputs"]["cfg"] == 1.0

    xl_config = config.model_copy(deep=True)
    xl_config.music.model = "ace-step-1.5-xl-turbo"
    xl = build_music_workflow(xl_config, "lofi", lyrics="hello", seed=1)
    assert xl["1"]["class_type"] == "UNETLoader"
    assert xl["2"]["class_type"] == "DualCLIPLoader"
    assert xl["2"]["inputs"]["type"] == "ace"
    assert xl["2"]["inputs"]["clip_name1"].startswith("qwen_0.6b")
    assert xl["2"]["inputs"]["clip_name2"].startswith("qwen_4b")
    assert xl["3"]["class_type"] == "VAELoader"
    assert xl["4"]["inputs"]["clip"] == ["2", 0]
    assert xl["9"]["inputs"]["vae"] == ["3", 0]
    assert xl["8"]["inputs"]["steps"] == xl_config.music.steps

    sft_config = config.model_copy(deep=True)
    sft_config.music.model = "ace-step-1.5-xl-sft"
    sft = build_music_workflow(sft_config, "lofi", lyrics="hello", seed=1)
    # A non-distilled checkpoint must not be starved of steps or CFG.
    assert sft["8"]["inputs"]["steps"] >= 40
    assert sft["8"]["inputs"]["cfg"] == 6.0


async def test_comfy_run_downloads_attachment(tmp_path):
    server, handler = comfy_server()
    try:
        port = server.server_address[1]
        config = ConfigStore(tmp_path / "config.json")
        config.load()
        config.update({"load": {"unload_comfy_after_job": False}})
        runtimes = FakeRuntimes(port)
        client = ComfyClient(config, runtimes, OutputStore())
        job = Job("test", "image")
        attachments = await client.generate_image("a glowing forge", job=job)
        assert runtimes.unloaded == ["qwen3.5:9b"]
        assert runtimes.freed == 1
        assert len(attachments) == 1
        assert attachments[0].kind == "image"
        assert attachments[0].file_path.read_bytes() == PNG
        assert handler.last_prompt is not None
        assert "prompt" in handler.last_prompt
        assert handler.last_prompt["prompt"]["1"]["class_type"] == "CheckpointLoaderSimple"
    finally:
        server.shutdown()


def test_video_tool_exposes_frame_rate():
    from hearth.tools import TOOL_SPECS

    spec = next(tool for tool in TOOL_SPECS if tool["function"]["name"] == "generate_video")
    properties = spec["function"]["parameters"]["properties"]
    assert properties["fps"]["minimum"] == 4
    assert properties["fps"]["maximum"] == 60


def test_video_request_is_capped_for_8gb_card():
    from hearth.config import AppConfig
    from hearth.hardware import HardwareInfo
    from hearth.tools import fit_video_request

    cfg = AppConfig()
    cfg.video.width = 1280
    cfg.video.height = 720
    cfg.video.fps = 30
    cfg.video.frames = 149
    hw = HardwareInfo(total_vram_gb=8, gpu_usable=True, ram_gb=31)
    fitted, notes = fit_video_request(cfg, hw)
    assert fitted.video.width == 1280
    assert fitted.video.height == 720
    assert fitted.video.frames == 29
    assert any("capped" in note.lower() for note in notes)

    cfg.video.width = 1920
    cfg.video.height = 1080
    cfg.video.frames = 29
    fitted, notes = fit_video_request(cfg, hw)
    assert (fitted.video.width, fitted.video.height) == (1280, 720)
    assert any("Resolution adjusted" in note for note in notes)


def test_video_safe_limits_can_be_disabled():
    from hearth.config import AppConfig
    from hearth.hardware import HardwareInfo
    from hearth.tools import fit_video_request

    cfg = AppConfig()
    cfg.video.width = 1280
    cfg.video.height = 720
    cfg.video.fps = 30
    cfg.video.frames = 149
    cfg.video.safe_limits = False
    hw = HardwareInfo(total_vram_gb=8, gpu_usable=True, ram_gb=31)
    fitted, notes = fit_video_request(cfg, hw)
    assert fitted.video.frames == 149
    assert notes == []


def test_minimax_h3_workflow_uses_its_own_graph():
    config = ConfigStore().config
    config.video.model = "minimax-h3"
    config.video.frames = 121  # snapped up to the model's 17k+5 grid
    workflow = build_video_workflow(config, "a lighthouse in a storm", seed=7)
    assert workflow["1"]["class_type"] == "UNETLoader"
    assert workflow["2"]["inputs"]["type"] == "minimax"
    assert workflow["3"]["class_type"] == "VAELoader"
    assert workflow["4"]["class_type"] == "VAELoader"  # audio VAE
    assert workflow["5"]["class_type"] == "LoraLoaderModelOnly"
    assert workflow["6"]["class_type"] == "MiniMaxH3ImageToVideo"
    assert workflow["6"]["inputs"]["length"] == 124
    assert workflow["6"]["inputs"]["width"] % 32 == 0
    assert workflow["7"]["inputs"]["model"] == ["5", 0]
    assert workflow["9"]["inputs"]["sampler_name"] == "res_multistep"
    assert workflow["11"]["class_type"] == "SamplerCustomAdvanced"
    assert workflow["11"]["inputs"]["latent_image"] == ["6", 1]
    assert workflow["12"]["class_type"] == "VAEDecode"
    assert workflow["13"]["class_type"] == "VAEDecodeAudio"
    assert workflow["14"]["class_type"] == "CreateVideo"
    assert workflow["14"]["inputs"]["fps"] == config.video.fps
    assert workflow["15"]["class_type"] == "SaveVideo"


def test_presets_use_minimax_h3_for_balanced_and_smart():
    from hearth.presets import build_presets
    from tests.test_presets import make_hw

    presets = {preset.tier: preset for preset in build_presets(make_hw(8, 31))}
    assert presets["balanced"].video_model == "minimax-h3"
    assert presets["smart"].video_model == "minimax-h3"
    assert presets["fast"].video_model == "wan2.1-1.3b"


def test_edit_workflow_chains_one_reference_per_image():
    config = ConfigStore().config
    single = build_edit_workflow(config, "make the sky purple", ["first.png"], seed=5)
    assert single["1"]["class_type"] == "UNETLoader"
    assert single["2"]["inputs"]["type"] == "flux2"
    assert single["4"]["inputs"]["text"] == "make the sky purple"
    assert single["10"]["class_type"] == "LoadImage"
    assert single["11"]["class_type"] == "ImageScaleToTotalPixels"
    assert single["12"]["class_type"] == "VAEEncode"
    assert single["13"]["class_type"] == "ReferenceLatent"
    assert single["13"]["inputs"]["conditioning"] == ["4", 0]
    guider = next(node for node in single.values() if node["class_type"] == "CFGGuider")
    assert guider["inputs"]["positive"] == ["13", 0]
    assert guider["inputs"]["cfg"] == 1.0
    assert any(node["class_type"] == "SamplerCustomAdvanced" for node in single.values())

    two = build_edit_workflow(config, "put the hat from the second photo on the first", ["a.png", "b.png"], seed=5)
    refs = [node for node in two.values() if node["class_type"] == "ReferenceLatent"]
    assert len(refs) == 2
    assert refs[1]["inputs"]["conditioning"] == ["13", 0]  # second hangs off the first
    guider2 = next(node for node in two.values() if node["class_type"] == "CFGGuider")
    assert guider2["inputs"]["positive"] == ["17", 0]
    assert sum(1 for node in two.values() if node["class_type"] == "LoadImage") == 2


def test_edit_workflow_requires_a_source_image():
    config = ConfigStore().config
    try:
        build_edit_workflow(config, "anything", [], seed=1)
    except ValueError as exc:
        assert "source image" in str(exc)
    else:
        raise AssertionError("expected a ValueError without images")


async def test_edit_image_tool_uses_the_message_attachments(tmp_path):
    from hearth.config import ConfigStore as _ConfigStore
    from hearth.jobs import JobManager
    from hearth.tools import ToolContext, execute_tool

    source = tmp_path / "photo.png"
    source.write_bytes(PNG)

    class FakeComfy:
        def __init__(self):
            self.calls = []

        async def generate_edit(self, prompt, paths, job=None):
            self.calls.append((prompt, [str(p) for p in paths]))
            return []

    comfy = FakeComfy()
    config = _ConfigStore(tmp_path / "config.json")
    config.load()
    ctx = ToolContext(
        config_store=config,
        runtimes=None,
        comfy=comfy,
        jobs=JobManager(),
        outputs=None,
        attachments=[{"id": "a1", "kind": "image", "path": str(source)}],
    )
    result = await execute_tool("edit_image", {"prompt": "make it night"}, ctx)
    assert result.error == ""
    assert comfy.calls == [("make it night", [str(source)])]

    missing = await execute_tool("edit_image", {"prompt": "make it night"}, ToolContext(
        config_store=config, runtimes=None, comfy=comfy, jobs=JobManager(), outputs=None, attachments=[]))
    assert "no source image" in missing.error


async def test_generate_edit_uploads_each_source(tmp_path):
    from hearth.comfy import ComfyClient

    spec = __import__("hearth.catalog", fromlist=["catalog"]).get_model("flux2-klein-edit")
    assert spec is not None and spec.workflow == "flux2-edit"

    class FakeRuntimes:
        hw = None

        def __init__(self):
            self.uploads = []

        async def comfy_upload_image(self, path, subfolder="hearth"):
            self.uploads.append((str(path), subfolder))
            return f"hearth/{path.name}"

    runtimes = FakeRuntimes()
    config = ConfigStore(tmp_path / "config.json")
    config.load()
    client = ComfyClient(config, runtimes, OutputStore())

    async def fake_run(workflow, **kwargs):
        assert sum(1 for node in workflow.values() if node["class_type"] == "LoadImage") == 2
        return []

    client.run_workflow = fake_run  # type: ignore[assignment]
    a = tmp_path / "a.png"
    b = tmp_path / "b.png"
    a.write_bytes(PNG)
    b.write_bytes(PNG)
    await client.generate_edit("merge these", [a, b], job=None)
    assert runtimes.uploads == [(str(a), "hearth/edit-src"), (str(b), "hearth/edit-src")]
