from __future__ import annotations

import pytest

from hearth import crypto, remote
from hearth.accounts import AccountStore


def test_seal_and_open_round_trip():
    key = crypto.derive_key("correct horse battery", "salt-1")
    envelope = crypto.seal(key, b"hello there", aad=b"sam")
    assert crypto.open_sealed(key, envelope, aad=b"sam") == b"hello there"


def test_wrong_secret_cannot_open():
    key = crypto.derive_key("secret-a", "salt-1")
    other = crypto.derive_key("secret-b", "salt-1")
    envelope = crypto.seal(key, b"payload")
    with pytest.raises(crypto.CryptoError):
        crypto.open_sealed(other, envelope)


def test_tampered_payload_is_rejected():
    key = crypto.derive_key("secret-a", "salt-1")
    raw = bytearray(crypto.seal_bytes(key, b"payload"))
    raw[-1] ^= 0x01
    with pytest.raises(crypto.CryptoError):
        crypto.open_bytes(key, bytes(raw))


def test_the_same_secret_on_two_servers_gives_different_keys():
    assert crypto.derive_key("secret", "salt-1") != crypto.derive_key("secret", "salt-2")


def test_frames_survive_chunked_delivery():
    key = crypto.derive_key("secret", "salt")
    first = crypto.pack_frame(key, b"a" * 40)
    second = crypto.pack_frame(key, b"b" * 10)
    reader = crypto.FrameReader()
    assert reader.feed(first[:7]) == []
    frames = reader.feed(first[7:] + second)
    # the first frame may complete before the second arrives; both must appear
    frames += reader.feed(b"")
    assert [crypto.open_bytes(key, frame) for frame in frames] == [b"a" * 40, b"b" * 10]


def test_accounts_round_trip(tmp_path):
    store = AccountStore(tmp_path / "accounts.json")
    user = store.add("Sam", secret="s3cret")
    assert store.get("sam")["id"] == user["id"]
    assert store.key_for("sam") == crypto.derive_key("s3cret", store.salt)
    assert store.insecure_users() == []
    assert [item["name"] for item in store.users()] == ["Sam"]

    rotated = store.rotate_secret(user["id"])
    assert rotated["secret"] != "s3cret"
    assert store.key_for("sam") != crypto.derive_key("s3cret", store.salt)

    assert store.update(user["id"], enabled=False)["enabled"] is False
    assert store.key_for("sam") is None
    assert store.remove(user["id"]) is True
    assert store.users() == []


def test_accounts_flag_secretless_users(tmp_path):
    store = AccountStore(tmp_path / "accounts.json")
    store.add("Phone")
    store.add("Laptop", secret="abc")
    assert store.insecure_users() == ["Phone"]
    assert store.key_for("Phone") is None


def test_account_names_are_unique(tmp_path):
    store = AccountStore(tmp_path / "accounts.json")
    store.add("Sam", secret="a")
    with pytest.raises(ValueError):
        store.add("sam", secret="b")


def _user(**permissions) -> dict:
    perms = {
        "chat": True,
        "attachments": True,
        "tools": True,
        "image": True,
        "video": False,
        "music": False,
        "three_d": False,
        "audio": False,
        "memory": True,
        "change_model": False,
        "change_preset": False,
        "allowed_models": [],
        "denied_models": [],
        "allowed_presets": [],
        "denied_presets": [],
    }
    perms.update(permissions)
    return {"name": "sam", "secret": "x", "enabled": True, "permissions": perms}


def test_remote_can_read_and_chat():
    user = _user()
    remote.authorize(user, "GET", "/api/state")
    remote.authorize(user, "GET", "/api/chats")
    remote.authorize(user, "POST", "/api/chats")
    remote.authorize(user, "POST", "/api/chats/abc/messages", {"content": "hi"})


def test_remote_cannot_touch_server_admin():
    user = _user()
    for path in (
        "/api/server/start",
        "/api/server/users",
        "/api/models/flux-dev/install",
        "/api/runtimes/comfyui/install",
        "/api/presets/custom-work/apply",
        "/api/config/reset",
        "/api/secure/rpc",
    ):
        with pytest.raises(remote.RemoteDenied):
            remote.authorize(user, "POST", path)
    with pytest.raises(remote.RemoteDenied):
        remote.authorize(user, "GET", "/api/server/users")


def test_remote_modality_permissions_are_enforced():
    user = _user()
    remote.authorize(user, "POST", "/api/generate", {"modality": "image"})
    with pytest.raises(remote.RemoteDenied):
        remote.authorize(user, "POST", "/api/generate", {"modality": "video"})
    remote.authorize(user, "POST", "/api/uploads")
    with pytest.raises(remote.RemoteDenied):
        remote.authorize(_user(attachments=False), "POST", "/api/uploads")


def test_tools_are_switched_off_when_not_allowed():
    user = _user(tools=False)
    body = {"content": "hi", "tools": True}
    remote.authorize(user, "POST", "/api/chats/x/messages", body)
    assert body["tools"] is False


def test_config_patch_is_filtered_to_allowed_sections():
    user = _user(change_model=False, change_preset=False)
    body = {"image": {"steps": 6}, "server": {"port": 9999}, "text": {"model": "x"}}
    remote.authorize(user, "POST", "/api/config", body)  # image is allowed
    assert body == {"image": {"steps": 6}}

    locked = _user(image=False, video=False, music=False, three_d=False, audio=False, memory=False)
    with pytest.raises(remote.RemoteDenied):
        remote.authorize(locked, "POST", "/api/config", {"image": {"steps": 4}})


def test_preset_changes_need_their_permission():
    user = _user(change_preset=False)
    with pytest.raises(remote.RemoteDenied):
        remote.authorize(user, "POST", "/api/config", {"preset": "balanced"})
    remote.authorize(_user(change_preset=True), "POST", "/api/config", {"preset": "balanced"})


def test_capabilities_document_hides_what_is_not_allowed():
    class FakeState:
        version = "test"

        def base_url(self):
            return "http://127.0.0.1:1"

        def presets_payload(self):
            return {
                "presets": [
                    {"tier": "fast", "name": "Fast"},
                    {"tier": "balanced", "name": "Balanced"},
                ]
            }

    caps = remote.capabilities(FakeState(), _user(denied_presets=["balanced"], denied_models=["flux-dev"]))
    assert [preset["tier"] for preset in caps["presets"]] == ["fast"]
    assert caps["permissions"]["media"]["video"] is False
    image_ids = [model["id"] for model in caps["models"]["image"]]
    assert "flux-dev" not in image_ids and image_ids
    assert caps["text_models"] == []  # no permission to change the model


def test_account_store_ignores_a_corrupt_file(tmp_path):
    path = tmp_path / "accounts.json"
    path.write_text("{not json")
    store = AccountStore(path)
    assert store.users() == []
    assert store.salt


def test_remote_may_upload_and_read_generated_files():
    user = _user()
    remote.authorize(user, "POST", "/api/uploads/encoded", {"filename": "a.png", "data": "AAAA"})
    remote.authorize(user, "POST", "/api/media/read", {"path": "outputs/x/image.png"})
    with pytest.raises(remote.RemoteDenied):
        remote.authorize(_user(attachments=False, image=False, video=False, music=False, three_d=False, audio=False),
                         "POST", "/api/media/read", {"path": "outputs/x/image.png"})


def test_remote_preset_apply_never_downloads():
    body = {"download": True, "modalities": {"image": True}}
    remote.authorize(_user(change_preset=True), "POST", "/api/presets/balanced/apply", body)
    assert body["download"] is False
    with pytest.raises(remote.RemoteDenied):
        remote.authorize(_user(change_preset=False), "POST", "/api/presets/balanced/apply", {"download": True})


def test_media_read_accepts_the_public_url_shape(tmp_path):
    # The endpoint strips the /media/ prefix the web UI uses, so a client can
    # pass attachment["url"] verbatim.
    from hearth.attachments import OutputStore

    store = OutputStore()
    target = store.output_dir() / "probe-media.png"
    target.write_bytes(b"\x89PNG probe")
    resolved = store.resolve_media(str(target.relative_to(__import__("hearth.paths", fromlist=["DATA_DIR"]).DATA_DIR)))
    assert resolved == target
    assert "/media/" + str(target.relative_to(__import__("hearth.paths", fromlist=["DATA_DIR"]).DATA_DIR)) == (
        "/media/outputs/" + target.parent.name + "/" + target.name
    )
