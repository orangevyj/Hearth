from __future__ import annotations

from hearth.jobs import Job


def test_job_overall_progress_uses_sizes_and_current_item():
    job = Job(
        "test",
        "Download",
        items=[
            {"id": "a", "label": "File A", "size_gb": 1},
            {"id": "b", "label": "File B", "size_gb": 3},
        ],
    )
    assert job.progress == 0
    job.update_item("a", status="running", total_bytes=1_000_000_000, completed_bytes=500_000_000)
    assert job.progress == 12.5
    assert job.current_item is not None
    assert job.current_item["label"] == "File A"
    job.update_item("a", status="done")
    assert job.progress == 25.0
    job.update_item("b", status="running", total_bytes=3_000_000_000, completed_bytes=1_500_000_000)
    assert job.progress == 62.5
    job.update_item("b", status="done")
    assert job.progress == 100.0
    assert job.current_item is None
    payload = job.to_dict()
    assert payload["bytes"]["downloaded"] == 4_000_000_000
    assert payload["bytes"]["remaining"] == 0


def test_skipped_items_do_not_penalize_progress():
    job = Job(
        "test",
        "Install",
        items=[
            {"id": "present", "label": "Already installed", "size_gb": 50},
            {"id": "file", "label": "Downloaded", "size_gb": 1},
        ],
    )
    job.update_item("present", status="skipped")
    job.update_item("file", status="done")
    assert job.progress == 100.0


def test_generation_job_uses_indeterminate_progress_until_done():
    job = Job("generate", "Image", items=[{"id": "g", "label": "Rendering"}])
    assert job.progress is None
    job.update_item("g", status="running")
    assert job.progress is None
    job.update_item("g", status="done")
    assert job.progress == 100.0
