from __future__ import annotations

import json

import pytest

from hearth.library import CustomModelStore, CustomPresetStore


def local_tree(tmp_path):
    models = tmp_path / "comfy" / "models"
    (models / "checkpoints").mkdir(parents=True)
    (models / "checkpoints" / "mine.safetensors").write_bytes(b"x" * (4 * 1024 * 1024))
    return models


def test_local_import_measures_the_file(tmp_path):
    models = local_tree(tmp_path)
    store = CustomModelStore(tmp_path / "custom_models.json")
    item = store.validate(
        {
            "name": "My SDXL",
            "modality": "image",
            "workflow": "sdxl",
            "files": [{"source": "local", "dest": "checkpoints/mine.safetensors", "role": "checkpoint"}],
        },
        comfy_models_dir=models,
    )
    assert item["id"] == "my-sdxl"
    assert item["files"][0]["source"] == "local"
    assert item["files"][0]["size_gb"] > 0
    assert item["size_gb"] > 0


def test_local_import_refuses_paths_outside_the_models_folder(tmp_path):
    models = local_tree(tmp_path)
    store = CustomModelStore(tmp_path / "custom_models.json")
    with pytest.raises(ValueError):
        store.validate(
            {
                "name": "Escape",
                "modality": "image",
                "workflow": "sdxl",
                "files": [{"source": "local", "dest": "../outside.safetensors"}],
            },
            comfy_models_dir=models,
        )


def test_local_import_requires_the_file_to_exist(tmp_path):
    models = local_tree(tmp_path)
    store = CustomModelStore(tmp_path / "custom_models.json")
    with pytest.raises(ValueError, match="No file at"):
        store.validate(
            {
                "name": "Ghost",
                "modality": "image",
                "workflow": "sdxl",
                "files": [{"source": "local", "dest": "checkpoints/ghost.safetensors"}],
            },
            comfy_models_dir=models,
        )


def test_hub_import_needs_repo_and_file(tmp_path):
    store = CustomModelStore(tmp_path / "custom_models.json")
    with pytest.raises(ValueError, match="repository and a file name"):
        store.validate(
            {
                "name": "Hub",
                "modality": "music",
                "workflow": "ace",
                "files": [{"dest": "checkpoints/x.safetensors", "repo": "org/name"}],
            }
        )


def test_workflow_must_match_the_modality(tmp_path):
    store = CustomModelStore(tmp_path / "custom_models.json")
    with pytest.raises(ValueError, match="must use one of"):
        store.validate(
            {
                "name": "Wrong",
                "modality": "image",
                "workflow": "wan",
                "files": [{"dest": "checkpoints/x.safetensors", "repo": "org/name", "filename": "x.safetensors"}],
            }
        )


def test_imported_models_round_trip_through_the_store(tmp_path):
    store = CustomModelStore(tmp_path / "custom_models.json")
    item = store.validate(
        {
            "name": "Music XL",
            "modality": "music",
            "workflow": "ace-xl",
            "files": [
                {"repo": "org/name", "filename": "a.safetensors", "dest": "diffusion_models/a.safetensors", "role": "diffusion"},
                {"repo": "org/name", "filename": "b.safetensors", "dest": "vae/b.safetensors", "role": "vae", "size_gb": 0.3},
            ],
        }
    )
    store.add(item)
    reloaded = CustomModelStore(tmp_path / "custom_models.json")
    specs = reloaded.specs()
    assert [spec.id for spec in specs] == ["music-xl"]
    assert specs[0].workflow == "ace-xl"
    assert specs[0].primary_file == "a.safetensors"
    assert reloaded.remove("music-xl") is True
    assert CustomModelStore(tmp_path / "custom_models.json").items == []


def test_builtin_ids_do_not_get_shadowed(tmp_path):
    store = CustomModelStore(tmp_path / "custom_models.json")
    item = store.validate(
        {
            "name": "flux-schnell",
            "modality": "image",
            "workflow": "flux",
            "files": [{"repo": "org/name", "filename": "f.safetensors", "dest": "checkpoints/f.safetensors"}],
        }
    )
    assert item["id"] == "flux-schnell-custom"


def test_preset_store_validates_and_persists(tmp_path):
    path = tmp_path / "custom_presets.json"
    store = CustomPresetStore(path)
    with pytest.raises(ValueError, match="Pick a model"):
        store.validate({"name": "Half"})
    item = store.validate(
        {
            "name": "Study night",
            "text_model": "qwen3.5:4b",
            "image_model": "sdxl-turbo",
            "video_model": "wan2.1-1.3b",
            "three_d_model": "hunyuan3d-2.1",
            "music_model": "ace-step-1.5",
            "tts_voice": "en_US-amy-medium",
            "stt_model": "small",
        }
    )
    assert item["id"] == "custom-study-night"
    store.save(item)
    saved = json.loads(path.read_text())
    assert saved[0]["name"] == "Study night"
    assert CustomPresetStore(path).get("custom-study-night") is not None
    assert store.remove("custom-study-night") is True
    assert store.get("custom-study-night") is None
