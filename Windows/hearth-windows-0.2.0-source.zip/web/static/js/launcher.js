import { api } from './api.js?v=0.1.0';
import { icon } from './icons.js?v=0.1.0';
import {
  esc,
  escAttr,
  fmtGb,
  fmtBytes,
  fmtSpeed,
  fmtEta,
  timeAgo,
  fmtTime,
  deepClone,
  getPath,
  setPath,
  truncate,
  spinner,
  dot,
  badge,
  emptyState,
  toast,
  modal,
  confirmDialog,
  copyText,
  progress,
  donut,
  barChart,
  jobStatusKind,
  jobStatusLabel,
  setButtonBusy,
} from './ui.js?v=0.1.0';

const ROUTES = {
  overview: {
    label: 'Overview',
    title: 'Overview',
    subtitle: 'Hardware, presets and the quickest path to a working local stack.',
    icon: 'grid',
  },
  models: {
    label: 'Models',
    title: 'Models & settings',
    subtitle: 'Choose what runs locally, where it comes from and how it behaves.',
    icon: 'layers',
  },
  presets: {
    label: 'Presets',
    title: 'Presets',
    subtitle: 'Three hardware-shaped tiers. Apply one, or tune every model yourself.',
    icon: 'sliders',
  },
  server: {
    label: 'Server',
    title: 'Server',
    subtitle: 'Start the local engine, choose how models stay in memory and watch the logs.',
    icon: 'server',
  },
  memory: {
    label: 'Memory',
    title: 'Memory',
    subtitle: 'What the assistant remembers about you. Switch anything off or delete it here.',
    icon: 'memory',
  },
  activity: {
    label: 'Activity',
    title: 'Activity',
    subtitle: 'Downloads, runtime installs, source selection and generated media.',
    icon: 'activity',
  },
};

const MODALITIES = [
  { key: 'text', label: 'Text', icon: 'chat', section: 'text', path: 'text.enabled' },
  { key: 'image', label: 'Images', icon: 'image', section: 'image', path: 'image.enabled' },
  { key: 'video', label: 'Video', icon: 'video', section: 'video', path: 'video.enabled' },
  { key: 'audio', label: 'Speech', icon: 'speaker', section: 'sound', path: 'audio.enabled' },
  { key: 'music', label: 'Music', icon: 'music', section: 'music', path: 'music.enabled' },
  { key: 'three_d', label: '3D', icon: 'cube', section: 'three-d', path: 'three_d.enabled' },
];

const TOOL_LIST = [
  ['web_search', 'Web search', 'Search the public web', 'globe'],
  ['fetch_url', 'Read pages', 'Open a public URL', 'link'],
  ['generate_image', 'Images', 'Create images', 'image'],
  ['generate_video', 'Video', 'Create short clips', 'video'],
  ['generate_music', 'Music', 'Compose tracks', 'music'],
  ['text_to_speech', 'Speech', 'Speak text aloud', 'speaker'],
  ['generate_3d', '3D models', 'Create GLB meshes', 'cube'],
];

let state = null;
let route = 'overview';
let draft = null;
let dirty = false;
let onboardingOpen = false;
let onboardTier = 'balanced';
let onboardMods = { text: true, image: true, video: true, audio: true, music: true, three_d: true };
let pollTimer = null;
let pendingScroll = null;
let pollFailures = 0;
let savebar = null;

/* ------------------------------------------------------------------ */
/* Boot                                                               */
/* ------------------------------------------------------------------ */
async function boot() {
  try {
    state = await api.fetchState();
    applyTheme(resolveTheme());
    onboardTier = state.presets?.recommended || 'balanced';
    draft = deepClone(state.config);
    document.getElementById('boot').hidden = true;
    document.getElementById('app').hidden = false;
    installSavebar();
    route = parseRoute();
    render();
    if (state.remoteLost) {
      toast(
        `Disconnected from ${state.remoteLost.address}: that account is no longer valid on the server.`,
        'warn',
        8000,
      );
    }
    if (!state.config.setup_complete) showOnboarding();
    schedulePoll(1800);
  } catch (error) {
    showBootError(error);
  }
}

function showBootError(error) {
  const boot = document.getElementById('boot');
  boot.classList.add('error');
  boot.innerHTML = `
    <img src="/assets/logo.svg" alt="" />
    <div class="boot-title">Hearth</div>
    <div class="boot-sub">${esc(error?.message || 'Could not reach the local Hearth server.')}</div>
    <button class="btn primary" style="margin-top:18px" id="boot-retry">${icon('refresh', 16)} Retry</button>`;
  document.getElementById('boot-retry')?.addEventListener('click', () => window.location.reload());
}

function parseRoute() {
  const raw = (window.location.hash || '#overview').replace(/^#/, '').split('/')[0];
  return ROUTES[raw] ? raw : 'overview';
}

function navigate(next) {
  if (route === next) {
    render();
    return;
  }
  window.location.hash = `#${next}`;
}

window.addEventListener('hashchange', () => {
  route = parseRoute();
  pendingScroll = null;
  render({ toTop: true });
});

/* ------------------------------------------------------------------ */
/* Theme                                                              */
/* ------------------------------------------------------------------ */
function resolveTheme() {
  const stored = localStorage.getItem('hearth.theme');
  if (stored === 'dark' || stored === 'light') return stored;
  const configured = state?.config?.ui?.theme;
  if (configured === 'dark' || configured === 'light') return configured;
  return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', theme === 'light' ? '#f4eee4' : '#0c0b09');
}

async function toggleTheme() {
  const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
  localStorage.setItem('hearth.theme', next);
  applyTheme(next);
  renderSidebar();
  renderTopbar();
  try {
    await api.saveConfig({ ui: { theme: next } });
    state.config.ui.theme = next;
  } catch {
    // The visual theme still applies locally if persistence fails.
  }
}

/* ------------------------------------------------------------------ */
/* Polling                                                            */
/* ------------------------------------------------------------------ */
function schedulePoll(delay = 2200) {
  window.clearTimeout(pollTimer);
  pollTimer = window.setTimeout(async () => {
    await poll();
    const running = state?.jobs?.some((job) => job.status === 'running' || job.status === 'queued');
    schedulePoll(running ? 1100 : 2600);
  }, delay);
}

function stateSnapshot() {
  if (!state) return '';
  const jobs = (state.jobs || []).map((job) => `${job.id}:${job.status}`).join('|');
  const installed = JSON.stringify(state.installed || {});
  const runtimes = JSON.stringify({
    o: state.runtimes?.ollama?.running,
    oi: state.runtimes?.ollama?.installed,
    c: state.runtimes?.comfyui?.running,
    ci: state.runtimes?.comfyui?.installed,
    l: state.runtimes?.lmstudio?.running,
  });
  return JSON.stringify({
    running: state.app?.running,
    setup: state.config?.setup_complete,
    preset: state.config?.preset,
    jobs,
    installed,
    runtimes,
    config: state.config,
    hw: state.hardware?.detected_at,
    chats: state.chat_count,
  });
}

async function poll() {
  try {
    const before = stateSnapshot();
    await api.refresh();
    state = api.state;
    pollFailures = 0;
    const after = stateSnapshot();
    if (!dirty) draft = deepClone(state.config);
    if (state.config.setup_complete && onboardingOpen) closeOnboarding(false);
    if (before !== after) {
      if (!isEditing()) render({ preserveScroll: true });
      else updateJobsLive();
    } else {
      updateJobsLive();
    }
    if (pendingScroll) scrollToPending();
  } catch (error) {
    pollFailures += 1;
    if (pollFailures === 3) toast(`Lost contact with the local server: ${error.message}`, 'error', 7000);
  }
}

function isEditing() {
  const element = document.activeElement;
  return Boolean(element && ['INPUT', 'TEXTAREA', 'SELECT'].includes(element.tagName));
}

function updateJobsLive() {
  document.querySelectorAll('[data-jobs-container]').forEach((element) => {
    element.innerHTML = renderJobsInner(state.jobs || [], element.dataset.jobsDetailed === 'true');
  });
}

/* ------------------------------------------------------------------ */
/* Render shell                                                       */
/* ------------------------------------------------------------------ */
function render({ preserveScroll = false, toTop = false } = {}) {
  if (!state) return;
  const scroll = preserveScroll ? window.scrollY : 0;
  renderSidebar();
  renderTopbar();
  const view = document.getElementById('view');
  let html = '';
  if (route === 'overview') html = renderOverview();
  else if (route === 'models') html = renderModels();
  else if (route === 'presets') html = renderPresetsPage();
  else if (route === 'server') html = renderServerPage();
  else if (route === 'activity') html = renderActivityPage();
  else if (route === 'memory') html = renderMemoryPage();
  else if (state.remote) html = renderClientMode();
  view.innerHTML = `<div class="page-enter">${html}</div>`;
  updateSavebar();
  if (toTop) window.scrollTo({ top: 0, behavior: 'instant' });
  else if (preserveScroll) window.scrollTo({ top: scroll, behavior: 'instant' });
  if (pendingScroll) scrollToPending();
}

function renderSidebar() {
  const brand = document.getElementById('sidebar-brand');
  if (brand) {
    brand.innerHTML = `
      <div class="brand">
        <a class="brand-mark" href="#overview" aria-label="Hearth overview"><img src="/assets/logo.svg" alt="" /></a>
        <div>
          <div class="brand-name">Hearth</div>
          <div class="brand-sub">local AI workspace</div>
        </div>
      </div>`;
  }
  const nav = document.getElementById('nav');
  if (nav) {
    const runningJobs = (state.jobs || []).filter((job) => job.status === 'running' || job.status === 'queued').length;
    nav.innerHTML = `
      <div class="nav-label">Workspace</div>
      ${Object.entries(ROUTES)
        .map(
          ([key, item]) => `
          <a class="nav-item ${route === key ? 'active' : ''}" href="#${key}">
            ${icon(item.icon, 17)}
            <span>${item.label}</span>
            ${key === 'activity' && runningJobs ? `<span class="nav-badge">${runningJobs}</span>` : ''}
          </a>`,
        )
        .join('')}`;
  }
  const foot = document.getElementById('sidebar-foot');
  if (foot) {
    const hw = state.hardware;
    const gpu = hw.gpus?.[0];
    const summary = gpu ? `${gpu.name} · ${fmtGb(gpu.vram_gb)}` : hw.summary?.split('·')[0] || 'CPU';
    const running = state.app.running;
    const theme = document.documentElement.dataset.theme;
    foot.innerHTML = `
      <div class="mini-hw">
        <div class="mini-hw-title">${dot(running ? 'good' : 'muted')} ${running ? 'Server running' : 'Local engine'}</div>
        <div class="mini-hw-main truncate" title="${escAttr(summary)}">${esc(summary)}</div>
        <div class="mini-hw-sub">${fmtGb(hw.ram_gb)} RAM · ${hw.physical_cores} cores</div>
      </div>
      <button class="btn ${running ? 'success' : 'primary'} sidebar-chat" data-action="open-chat">
        ${icon('chat', 16)} ${running ? 'Open chat' : 'Start & chat'}
      </button>
      <div class="theme-row">
        <span>Hearth v${esc(state.app.version)}</span>
        <button class="icon-toggle" data-action="toggle-theme" title="Toggle theme">
          ${icon(theme === 'light' ? 'moon' : 'sun', 13)} ${theme === 'light' ? 'Dark' : 'Light'}
        </button>
      </div>`;
  }
}

function renderTopbar() {
  const topbar = document.getElementById('topbar');
  if (!topbar) return;
  const meta = ROUTES[route] || ROUTES.overview;
  const running = Boolean(state.app.running);
  topbar.innerHTML = `
    <div class="topbar-title">
      <div class="crumb">Hearth / ${meta.label}</div>
      <div class="page-title">${meta.title}</div>
      <div class="page-sub">${meta.subtitle}</div>
    </div>
    <div class="topbar-actions">
      ${dirty ? `<button class="btn subtle sm" data-action="save-settings">${icon('check', 15)} Save changes</button>` : ''}
      <div class="server-pill ${running ? 'on' : ''}">${dot(running ? 'good' : 'muted')} ${running ? 'Server running' : 'Server stopped'}</div>
      ${
        running
          ? `<button class="btn primary sm" data-action="open-chat">${icon('chat', 15)} Open chat</button>
             <button class="btn icon ghost sm" data-action="stop-server" title="Stop server">${icon('stop', 14)}</button>`
          : `<button class="btn primary sm" data-action="start-server">${icon('play', 15)} Start server</button>`
      }
    </div>`;
}

/* ------------------------------------------------------------------ */
/* Overview                                                           */
/* ------------------------------------------------------------------ */
function renderOverview() {
  const hw = state.hardware;
  const recommended = recommendedPreset();
  const setup = Boolean(state.config.setup_complete);
  return `
    ${renderHero(recommended, setup)}
    ${renderHardwareCard(hw)}
    <div class="section" style="margin-top:26px">
      <div class="section-head">
        <div>
          <div class="section-title">${icon('sparkles', 18)} Presets for this machine</div>
          <div class="section-sub">Hearth sized each tier from your VRAM, RAM and disk. Every model can be changed later.</div>
        </div>
        <div class="section-head-actions">
          <a class="btn sm ghost" href="#presets">${icon('arrowRight', 14)} Compare all</a>
        </div>
      </div>
      <div class="preset-grid">${state.presets.presets.map((preset) => renderPresetCard(preset)).join('')}</div>
    </div>
    <div class="section" style="margin-top:26px">
      <div class="section-head">
        <div>
          <div class="section-title">${icon('layers', 18)} Modalities</div>
          <div class="section-sub">Switch capabilities on or off. Hearth loads what it needs, when it needs it.</div>
        </div>
        <div class="section-head-actions"><a class="btn sm ghost" href="#models">${icon('settings', 14)} Configure</a></div>
      </div>
      <div class="modality-grid">${MODALITIES.map((modality) => renderModalityCard(modality)).join('')}</div>
    </div>
    ${renderFootprintCard()}
    <div class="overview-columns" style="margin-top:26px">
      <section class="card section-card">
        <div class="section-head">
          <div>
            <div class="section-title">${icon('server', 17)} Services</div>
            <div class="section-sub">Local processes Hearth can manage for you.</div>
          </div>
        </div>
        ${renderServices()}
      </section>
      <section class="card section-card">
        <div class="section-head">
          <div>
            <div class="section-title">${icon('download', 17)} Downloads</div>
            <div class="section-sub">Live installs and model downloads.</div>
          </div>
          <a class="link-btn" href="#activity">Activity ${icon('chevronRight', 13)}</a>
        </div>
        <div data-jobs-container data-jobs-detailed="false">${renderJobsInner(state.jobs || [], false)}</div>
      </section>
    </div>
    <div class="callout" style="margin-top:16px">
      <span class="callout-icon">${icon('shield', 17)}</span>
      <span>
        Chat, images, video, music, speech and 3D stay on this machine. Only the optional web search and page reader
        leave it — and you can point them at your own SearXNG instance.
      </span>
    </div>`;
}

function renderHero(recommended, setup) {
  const hw = state.hardware;
  const gpu = hw.gpus?.[0];
  const running = state.app.running;
  const title = setup
    ? `A quiet, capable AI — <em>all yours.</em>`
    : `Let's wake up your <em>local AI.</em>`;
  const subtitle = setup
    ? `Text, images, video, sound, music and 3D in one workspace. ${recommended ? `Your machine is tuned for the <strong>${recommended.name}</strong> tier.` : ''}`
    : `Hearth found ${esc(hw.summary)}. Pick a tier and it will fetch the right models from the fastest reachable source — no accounts, no cloud.`;
  return `
    <section class="hero">
      <div class="hero-copy">
        <div class="eyebrow">${dot('accent')} Everything stays on this machine</div>
        <h1 class="hero-title">${title}</h1>
        <p class="hero-sub">${subtitle}</p>
        <div class="hero-actions">
          ${
            setup
              ? running
                ? `<button class="btn primary lg" data-action="open-chat">${icon('chat', 17)} Open chat</button>`
                : `<button class="btn primary lg" data-action="start-server">${icon('play', 17)} Start server</button>`
              : `<button class="btn primary lg" data-action="show-onboarding">${icon('sparkles', 17)} Choose a preset</button>`
          }
          ${
            setup
              ? `<a class="btn ghost lg" href="#models">${icon('layers', 16)} Manage models</a>`
              : `<button class="btn ghost lg" data-action="onboarding-demo">${icon('zap', 16)} Explore with demo</button>`
          }
        </div>
        <div class="hero-chips">
          <span class="chip">${icon('gpu', 13)} ${esc(gpu ? `${gpu.name} · ${fmtGb(gpu.vram_gb)}` : 'CPU inference')}</span>
          <span class="chip">${icon('memory', 13)} ${fmtGb(hw.ram_gb)} RAM</span>
          <span class="chip">${icon('disk', 13)} ${fmtGb(hw.disk_free_gb)} free</span>
          ${hw.gpu_usable ? `<span class="chip">${icon('check', 13)} GPU ready</span>` : `<span class="chip">${icon('alert', 13)} CPU fallback</span>`}
        </div>
      </div>
      <div class="hero-visual">
        <div class="orbit">
          <div class="orbit-ring"></div>
          <div class="orbit-ring r2"></div>
          <div class="orbit-ring r3"></div>
          <div class="orbit-center"><img src="/assets/logo.svg" alt="" /></div>
          <span class="orbit-node n1" title="Text">${icon('chat', 17)}</span>
          <span class="orbit-node n2" title="Images">${icon('image', 17)}</span>
          <span class="orbit-node n3" title="3D">${icon('cube', 17)}</span>
          <span class="orbit-node n4" title="Sound">${icon('music', 17)}</span>
        </div>
      </div>
    </section>`;
}

function renderFootprintCard() {
  const media = ['image', 'video', 'three_d', 'music'];
  const items = [];
  for (const modality of media) {
    for (const model of state.catalog?.[modality] || []) {
      if (!state.installed?.models?.[model.id]) continue;
      items.push({ label: model.name, value: Number(model.size_gb) || 0 });
    }
  }
  for (const model of state.catalog?.text || []) {
    if (!state.installed?.models?.[model.id]) continue;
    items.push({ label: model.name, value: Number(model.size_gb) || 0 });
  }
  items.sort((a, b) => b.value - a.value);
  const total = items.reduce((sum, item) => sum + item.value, 0);
  return `
    <div class="section" style="margin-top:26px">
      <div class="section-head">
        <div>
          <div class="section-title">${icon('layers', 18)} Installed models</div>
          <div class="section-sub">${items.length} models on disk · ${fmtGb(total)} total. Bars are relative to the largest.</div>
        </div>
        <div class="section-head-actions"><a class="btn sm ghost" href="#models">${icon('settings', 14)} Manage</a></div>
      </div>
      <section class="card section-card">
        ${barChart(items.slice(0, 8), { tone: 'accent' })}
      </section>
    </div>`;
}

function renderHardwareCard(hw) {
  const gpu = hw.gpus?.[0];
  const ramUsed = Math.max(0, hw.ram_gb - hw.ram_available_gb);
  const ramPct = hw.ram_gb ? Math.min(100, (ramUsed / hw.ram_gb) * 100) : 0;
  const diskUsed = Math.max(0, hw.disk_total_gb - hw.disk_free_gb);
  const diskPct = hw.disk_total_gb ? Math.min(100, (diskUsed / hw.disk_total_gb) * 100) : 0;
  return `
    <section class="card hardware-panel" style="margin-top:14px">
      <div class="section-head">
        <div>
          <div class="section-title">${icon('cpu', 17)} This machine</div>
          <div class="section-sub">${esc(hw.distro)} · ${esc(hw.kernel)} · ${esc(hw.os_name)}</div>
        </div>
        <button class="btn sm ghost" data-action="refresh-hardware">${icon('refresh', 14)} Rescan</button>
      </div>
      <div class="hw-grid">
        <div class="hw-metric">
          <div class="hw-metric-top">${icon('cpu', 13)} CPU</div>
          <div class="hw-value" title="${escAttr(hw.cpu_model)}">${esc(truncate(hw.cpu_model, 34))}</div>
          <div class="hw-sub">${hw.physical_cores} cores · ${hw.threads} threads${hw.avx512 ? ' · AVX-512' : hw.avx2 ? ' · AVX2' : ''}</div>
        </div>
        <div class="hw-metric">
          <div class="hw-metric-top">${icon('gpu', 13)} GPU</div>
          <div class="hw-value" title="${escAttr(gpu?.name || 'No supported GPU')}">${esc(gpu ? truncate(gpu.name, 34) : 'CPU only')}</div>
          <div class="hw-sub">${gpu ? `${fmtGb(gpu.vram_gb)} VRAM · ${gpu.usable ? `driver ${esc(gpu.driver || 'ready')}` : 'driver unavailable'}` : 'Models run on system RAM'}</div>
        </div>
        <div class="hw-metric">
          <div class="hw-metric-top">${icon('memory', 13)} Memory</div>
          <div class="hw-value">${fmtGb(hw.ram_gb)} RAM</div>
          <div class="hw-sub">${fmtGb(hw.ram_available_gb)} available right now</div>
        </div>
        <div class="hw-metric">
          <div class="hw-metric-top">${icon('disk', 13)} Storage</div>
          <div class="hw-value">${fmtGb(hw.disk_free_gb)} free</div>
          <div class="hw-sub">of ${fmtGb(hw.disk_total_gb)} for models and media</div>
        </div>
      </div>
      <div class="chart-row">
        ${donut(ramPct, {
          label: 'RAM',
          sub: `${fmtGb(ramUsed)} of ${fmtGb(hw.ram_gb)}`,
          tone: ramPct > 85 ? 'red' : ramPct > 65 ? 'yellow' : 'green',
        })}
        ${donut(diskPct, {
          label: 'Disk',
          sub: `${fmtGb(hw.disk_free_gb)} free`,
          tone: diskPct > 90 ? 'red' : diskPct > 75 ? 'yellow' : 'blue',
        })}
        ${donut(hw.total_vram_gb ? 100 : 0, {
          label: 'VRAM',
          sub: hw.total_vram_gb ? `${fmtGb(hw.total_vram_gb)} usable` : 'CPU only',
          tone: hw.gpu_usable ? 'accent' : 'muted',
        })}
      </div>
      ${
        hw.notes?.length
          ? `<div class="hw-note-list">${hw.notes
              .map(
                (note) =>
                  `<div class="hw-note ${note.toLowerCase().includes('available') ? 'good' : ''}">${icon(
                    note.toLowerCase().includes('available') ? 'check' : 'alert',
                    13,
                  )}<span>${esc(note)}</span></div>`,
              )
              .join('')}</div>`
          : ''
      }
    </section>`;
}

function recommendedPreset() {
  return (state.presets?.presets || []).find((preset) => preset.tier === state.presets.recommended);
}

function presetById(tier) {
  return (state.presets?.presets || []).find((preset) => preset.tier === tier);
}

function presetIcon(tier) {
  return tier === 'fast' ? 'zap' : tier === 'smart' ? 'sparkles' : 'sliders';
}

function presetReadiness(preset) {
  const missing = [];
  if (state.config.text.backend === 'ollama' && !textModelInstalled(preset.text_model)) missing.push('text');
  const media = [
    ['images', preset.image_model],
    ['video', preset.video_model],
    ['3D', preset.three_d_model],
    ['music', preset.music_model],
  ];
  for (const [label, id] of media) {
    if (id && !state.installed?.models?.[id]) missing.push(label);
  }
  const audioReady = state.installed?.voices?.[preset.tts_voice] && state.installed?.stt?.[preset.stt_model];
  if (!audioReady) missing.push('speech');
  return { ready: missing.length === 0, missing };
}

function presetActionHtml(preset, { table = false } = {}) {
  const { ready, missing } = presetReadiness(preset);
  const active = state.config.preset === preset.tier;
  if (ready && active) {
    return `<button class="btn success sm" disabled>${icon('check', 13)} Installed</button>${
      table ? '' : `<a class="btn ghost sm" href="#models">${icon('settings', 13)} Settings</a>`
    }`;
  }
  if (ready) {
    return `<button class="btn primary sm" data-action="apply-preset-only" data-tier="${preset.tier}">
      ${icon('check', 13)} Use preset
    </button>${table ? '' : `<a class="btn ghost sm" href="#models">${icon('settings', 13)} Settings</a>`}`;
  }
  const remaining = presetRemainingGb(preset);
  const size = remaining > 0 ? ` · ${fmtGb(remaining)}` : '';
  const label = active ? `Install ${missing.length} missing${size}` : `Install${size}`;
  return `<button class="btn primary sm" data-action="apply-preset" data-tier="${preset.tier}">
      ${icon('download', 13)} ${label}
    </button>${table ? '' : `<button class="btn ghost sm" data-action="apply-preset-only" data-tier="${preset.tier}">Apply only</button>`}`;
}

function presetSelect(fieldName, modality, selected, { text = false } = {}) {
  const options = (state.catalog[modality] || []).map((model) => {
    const installed = text ? textModelInstalled(model.id) : Boolean(state.installed?.models?.[model.id]);
    return [
      model.id,
      `${model.name} · ${fmtGb(model.size_gb)}${installed ? ' · installed' : ''}`,
      model.id === selected,
    ];
  });
  return `<select class="select" data-preset-field="${fieldName}">${options
    .map(
      ([value, label, isSelected]) =>
        `<option value="${escAttr(value)}" ${isSelected ? 'selected' : ''}>${esc(label)}</option>`,
    )
    .join('')}</select>`;
}

function voicePresetSelect(selected) {
  return `<select class="select" data-preset-field="tts_voice">${(state.catalog.tts || [])
    .map(
      (voice) =>
        `<option value="${escAttr(voice.id)}" ${voice.id === selected ? 'selected' : ''}>${esc(voice.name)}${
          state.installed?.voices?.[voice.id] ? ' · installed' : ''
        }</option>`,
    )
    .join('')}</select>`;
}

function sttPresetSelect(selected) {
  return `<select class="select" data-preset-field="stt_model">${(state.catalog.stt || [])
    .map(
      (model) =>
        `<option value="${escAttr(model.id)}" ${model.id === selected ? 'selected' : ''}>${esc(model.name)} · ${fmtGb(
          model.size_gb,
        )}${state.installed?.stt?.[model.id] ? ' · installed' : ''}</option>`,
    )
    .join('')}</select>`;
}

function renderPresetBuilder() {
  const cfg = state.config;
  return `
    <div class="section" style="margin-top:26px" id="preset-builder">
      <div class="section-head">
        <div>
          <div class="section-title">${icon('sliders', 17)} Build a preset</div>
          <div class="section-sub">Pick one model per modality and save the mix. A saved preset installs and applies like the built-in tiers, and shows up here for reuse.</div>
        </div>
      </div>
      <div class="card section-card" style="margin-top:12px">
        <div class="form-grid">
          ${field('Name', '<input class="input" data-preset-field="name" placeholder="Night shift" />')}
          ${field('Text', presetSelect('text_model', 'text', cfg.text.model, { text: true }))}
          ${field('Images', presetSelect('image_model', 'image', cfg.image.model))}
          ${field('Video', presetSelect('video_model', 'video', cfg.video.model))}
          ${field('3D', presetSelect('three_d_model', 'three_d', cfg.three_d.model))}
          ${field('Music', presetSelect('music_model', 'music', cfg.music.model))}
          ${field('Voice', voicePresetSelect(cfg.audio.voice))}
          ${field('Transcription', sttPresetSelect(cfg.audio.stt_model))}
        </div>
        <div class="row" style="margin-top:14px;justify-content:flex-end">
          <button class="btn primary" data-action="save-preset-draft">${icon('check', 14)} Save preset</button>
        </div>
      </div>
    </div>`;
}

function renderPresetCard(preset) {
  const models = preset.models || {};
  const readiness = presetReadiness(preset);
  const active = state.config.preset === preset.tier;
  const rows = [
    ['chat', 'Text', models.text?.name],
    ['image', 'Images', models.image?.name],
    ['video', 'Video', models.video?.name],
    ['cube', '3D', models.three_d?.name],
    ['music', 'Music', models.music?.name],
    ['speaker', 'Speech', preset.audio ? `${preset.audio.tts_voice.name} + ${preset.audio.stt_model.name}` : ''],
  ];
  return `
    <article class="preset-card ${preset.recommended ? 'recommended' : ''}">
      <div class="preset-top">
        <div class="preset-icon">${icon(presetIcon(preset.tier), 19)}</div>
        <div style="flex:1;min-width:0">
          <div class="preset-name">${esc(preset.name)}</div>
          <div class="preset-tagline">${esc(preset.tagline)}</div>
        </div>
        ${
          active
            ? `<span class="badge badge-success preset-recommended">${icon('check', 11)} Active</span>`
            : readiness.ready
              ? `<span class="badge badge-info preset-recommended">${icon('check', 11)} Ready</span>`
              : preset.recommended
                ? `<span class="badge badge-accent preset-recommended">${icon('sparkles', 11)} Suggested</span>`
                : ''
        }
      </div>
      <div class="preset-models">
        ${rows
          .filter((row) => row[2])
          .map(
            ([rowIcon, kind, name]) => `
            <div class="preset-model-row">
              ${icon(rowIcon, 13)}
              <span class="kind">${kind}</span>
              <span class="name" title="${escAttr(name)}">${esc(name)}</span>
            </div>`,
          )
          .join('')}
      </div>
      <div class="preset-stats">
        <span class="preset-stat">${icon('download', 11)} <strong>${fmtGb(preset.download_gb)}</strong>${
          presetRemainingGb(preset) > 0 && presetRemainingGb(preset) < preset.download_gb
            ? ` <span class="tiny muted">(${fmtGb(presetRemainingGb(preset))} to go)</span>`
            : ''
        }</span>
        <span class="preset-stat">${icon('gpu', 11)} <strong>${fmtGb(preset.peak_vram_gb, 0)}</strong> VRAM</span>
        <span class="preset-stat">${icon('memory', 11)} <strong>${fmtGb(preset.peak_ram_gb, 0)}</strong> RAM</span>
      </div>
      <div class="preset-notes">
        ${(preset.notes || [])
          .slice(0, 2)
          .map((note) => `<div class="preset-note">${icon('info', 12)}<span>${esc(note)}</span></div>`)
          .join('')}
      </div>
      <div class="preset-actions">${presetActionHtml(preset)}${
        preset.custom
          ? `<button class="btn ghost sm" data-action="delete-preset" data-tier="${escAttr(preset.tier)}">${icon('trash', 13)} Delete</button>`
          : ''
      }</div>
    </article>`;
}

function renderModalityCard(modality) {
  const path = modality.path;
  const enabled = Boolean(getPath(state.config, path));
  let modelLabel = '';
  let installed = false;
  if (modality.key === 'text') {
    modelLabel = state.config.text.model;
    installed = textModelInstalled(state.config.text.model);
  } else if (modality.key === 'audio') {
    const voice = catalogItem('tts', state.config.audio.voice);
    modelLabel = `${voice?.name || state.config.audio.voice} · ${state.config.audio.stt_model}`;
    installed = Boolean(state.installed.voices?.[state.config.audio.voice] && state.installed.stt?.[state.config.audio.stt_model]);
  } else {
    const modelPath = `${modality.key}.model`;
    const modelId = getPath(state.config, modelPath);
    const spec = catalogItem(modelKeyFor(modality.key), modelId);
    modelLabel = spec?.name || modelId;
    installed = Boolean(state.installed.models?.[modelId]);
  }
  const ready = installed || (modality.key === 'audio' && (state.installed.voices?.[state.config.audio.voice] || state.installed.stt?.[state.config.audio.stt_model]));
  return `
    <div class="modality-card">
      <div class="modality-top">
        <div class="modality-icon">${icon(modality.icon, 16)}</div>
        <div style="flex:1;min-width:0">
          <div class="modality-name">${modality.label}</div>
          <div class="modality-model" title="${escAttr(modelLabel)}">${esc(modelLabel)}</div>
        </div>
        <label class="switch" title="Enable ${escAttr(modality.label)}">
          <input type="checkbox" data-action="toggle-modality" data-modality="${modality.key}" ${enabled ? 'checked' : ''} />
          <span></span>
        </label>
      </div>
      <div class="modality-foot">
        ${enabled ? badge(ready ? 'Ready' : 'Needs download', ready ? 'good' : 'warn', true) : badge('Off', 'neutral')}
        <button class="link-btn" data-action="goto-models" data-section="${modality.section}">
          Configure ${icon('chevronRight', 12)}
        </button>
      </div>
    </div>`;
}

/* ------------------------------------------------------------------ */
/* Services / jobs                                                    */
/* ------------------------------------------------------------------ */
function renderServices() {
  const { ollama, comfyui, audio, lmstudio } = state.runtimes;
  const rows = [
    {
      name: 'Ollama',
      icon: 'chat',
      installed: ollama.installed,
      running: ollama.running,
      detail: ollama.running
        ? `${ollama.version || 'running'} · ${ollama.models?.length || 0} models`
        : ollama.installed
          ? 'Installed, stopped'
          : 'Not installed',
      runtime: 'ollama',
    },
    {
      name: 'ComfyUI',
      icon: 'image',
      installed: comfyui.installed,
      running: comfyui.running,
      detail: comfyui.running
        ? `${comfyui.version || 'running'}${comfyui.cpu_mode ? ' · CPU mode' : ''}`
        : comfyui.installed
          ? 'Installed, starts on demand'
          : 'Not installed',
      runtime: 'comfyui',
    },
    {
      name: 'Speech',
      icon: 'speaker',
      installed: audio.piper || audio.whisper,
      running: false,
      detail: `${audio.piper ? 'Piper' : 'espeak fallback'} · ${audio.whisper ? 'Whisper' : 'no STT'}${audio.whisper_model_ready ? ` (${audio.whisper_model})` : ''}`,
      runtime: 'audio',
      optional: true,
    },
    {
      name: 'LM Studio',
      icon: 'bot',
      installed: lmstudio.running,
      running: lmstudio.running,
      detail: lmstudio.running
        ? `${lmstudio.models?.length || 0} models · 127.0.0.1:1234`
        : 'Not detected',
      runtime: 'lmstudio',
      optional: true,
    },
  ];
  return `<div class="service-list">${rows.map((row) => renderServiceRow(row)).join('')}</div>`;
}

function renderServiceRow(row) {
  const tone = !row.installed ? 'muted' : row.running ? 'good' : 'warn';
  const stateText = row.running ? 'Running' : row.installed ? 'Installed' : 'Not installed';
  let actions = '';
  if (row.runtime === 'lmstudio') {
    actions = row.running
      ? `<button class="btn sm subtle" data-action="use-lmstudio">${icon('plug', 13)} Use</button>`
      : `<span class="tiny muted">Optional</span>`;
  } else if (row.runtime === 'audio') {
    actions = `<button class="btn sm subtle" data-action="install-runtime" data-runtime="audio">${icon(
      row.installed ? 'refresh' : 'download',
      13,
    )} ${row.installed ? 'Repair' : 'Install'}</button>`;
  } else if (!row.installed) {
    actions = `<button class="btn sm primary" data-action="install-runtime" data-runtime="${row.runtime}">${icon('download', 13)} Install</button>`;
  } else if (row.running) {
    actions = `
      <button class="btn sm ghost" data-action="runtime-logs" data-runtime="${row.runtime}">${icon('terminal', 13)} Logs</button>
      <button class="btn sm subtle" data-action="stop-runtime" data-runtime="${row.runtime}">${icon('stop', 12)} Stop</button>`;
  } else {
    actions = `
      <button class="btn sm ghost" data-action="runtime-logs" data-runtime="${row.runtime}">${icon('terminal', 13)} Logs</button>
      <button class="btn sm subtle" data-action="start-runtime" data-runtime="${row.runtime}">${icon('play', 12)} Start</button>`;
  }
  return `
    <div class="service-row">
      <div class="icon-badge" style="width:31px;height:31px;border-radius:9px">${icon(row.icon, 15)}</div>
      <div class="service-main">
        <div class="service-title">${dot(tone)} ${esc(row.name)} ${row.running ? badge('live', 'good') : ''}</div>
        <div class="service-status" title="${escAttr(row.detail)}">${esc(stateText)} · ${esc(row.detail)}</div>
      </div>
      <div class="service-actions">${actions}</div>
    </div>`;
}

function renderJobsInner(jobs, detailed = false) {
  if (!jobs.length) {
    return `<div class="empty" style="padding:22px 12px">
      <div class="empty-icon" style="width:42px;height:42px;border-radius:12px">${icon('download', 20)}</div>
      <h3>Nothing downloading</h3>
      <p>Install a preset or a model and its progress will appear here.</p>
    </div>`;
  }
  return `<div class="jobs">${jobs
    .slice(0, detailed ? 20 : 4)
    .map((job) => renderJobCard(job, detailed))
    .join('')}</div>`;
}

function renderJobCard(job, detailed = false) {
  const active = job.status === 'running' || job.status === 'queued';
  const value = job.progress === null || job.progress === undefined ? null : job.progress;
  const items = (job.items || []).slice(0, detailed ? 12 : 4);
  const current = job.current;
  const bytes = job.bytes || {};
  const currentValue = current?.progress === null || current?.progress === undefined ? null : current.progress;
  const downloaded = Number(bytes.downloaded || 0);
  const total = Number(bytes.total || 0);
  const allItems = job.items || [];
  const isDownload = !['generate', 'transcribe'].includes(job.kind) && (total > 1 || allItems.some((item) => Number(item.size_gb) > 0));
  return `
    <article class="job-card">
      <div class="job-head">
        <div class="job-title">${esc(job.title)}</div>
        ${badge(jobStatusLabel(job.status), jobStatusKind(job.status), true)}
      </div>
      <div class="job-meta">${timeAgo(job.updated_at || job.created_at)}${job.kind ? ` · ${esc(job.kind)}` : ''}</div>
      <div class="job-progress">
        ${
          isDownload
            ? progress(active && value === null ? null : value, {
                label: value === null ? 'Overall · preparing' : `Overall · ${Math.round(value)}%`,
              }) +
              (active && current
                ? progress(currentValue, {
                    label: `Current file · ${current.label}${currentValue === null ? '' : ` · ${Math.round(currentValue)}%`}`,
                  })
                : '')
            : active && current
              ? progress(currentValue, { label: `Current · ${current.label}` })
              : ''
        }
      </div>
      ${
        isDownload
          ? `<div class="job-stats">
              <div><span>Downloading</span><strong>${esc(current?.label || (active ? 'Preparing…' : 'None'))}</strong></div>
              <div><span>Downloaded</span><strong>${fmtBytes(downloaded)}</strong></div>
              <div><span>Will download</span><strong>${fmtBytes(total)}</strong></div>
            </div>`
          : ''
      }
      ${
        job.error
          ? `<div class="callout danger" style="margin-top:8px;padding:8px 10px"><span class="callout-icon">${icon(
              'alert',
              14,
            )}</span><span>${esc(truncate(job.error, 260))}</span></div>`
          : ''
      }
      ${
        items.length
          ? `<div class="job-items">${items
              .map((item) => {
                const itemValue = item.progress;
                return `<div class="job-item">
                  ${dot(item.status === 'done' ? 'good' : item.status === 'error' ? 'danger' : item.status === 'running' ? 'accent' : 'muted')}
                  <span class="job-item-label" title="${escAttr(item.label)}">${esc(item.label)}</span>
                  <span class="job-item-state">${
                    itemValue !== null && itemValue !== undefined
                      ? `${Math.round(itemValue)}%`
                      : item.speed_bps
                        ? fmtSpeed(item.speed_bps)
                        : item.status === 'done'
                          ? 'done'
                          : item.status === 'skipped'
                            ? 'present'
                            : ''
                  }</span>
                </div>`;
              })
              .join('')}</div>`
          : ''
      }
      <div class="job-actions">
        <button class="btn sm ghost" data-action="job-logs" data-job="${job.id}">${icon('terminal', 12)} Details</button>
        ${active ? `<button class="btn sm danger" data-action="cancel-job" data-job="${job.id}">${icon('x', 12)} Cancel</button>` : ''}
      </div>
    </article>`;
}

/* ------------------------------------------------------------------ */
/* Models page                                                        */
/* ------------------------------------------------------------------ */
function catalogItem(modality, id) {
  return (state.catalog?.[modality] || []).find((item) => item.id === id);
}

function modelKeyFor(modality) {
  return modality === 'three_d' ? 'three_d' : modality;
}

function textModelInstalled(name) {
  const normalize = (value) => (String(value).endsWith(':latest') ? String(value).slice(0, -7) : String(value));
  const target = normalize(name);
  return (state.runtimes?.ollama?.models || []).some((item) => normalize(item.name) === target);
}

function modelMissing(id) {
  return state.installed?.missing?.[id] || null;
}

function missingGb(id) {
  const info = modelMissing(id);
  return info ? Number(info.gb) || 0 : 0;
}

function remainingLabel(id) {
  const gb = missingGb(id);
  return gb > 0 ? fmtGb(gb) : '';
}

function presetRemainingGb(preset) {
  const ids = [preset.image_model, preset.video_model, preset.three_d_model, preset.music_model];
  let gb = 0;
  if (preset.text_model && !textModelInstalled(preset.text_model)) gb += missingGb(preset.text_model);
  for (const id of ids) {
    if (id && !state.installed?.models?.[id]) gb += missingGb(id);
  }
  return gb;
}

function installedModelLabel(id) {
  const spec = (state.catalog?.text || []).find((item) => item.id === id);
  return Boolean(state.installed?.models?.[id]) || Boolean(spec && textModelInstalled(spec.id));
}

function modelStatusRow(id, { modality = '', text = false } = {}) {
  if (text) {
    const installed = textModelInstalled(id);
    const spec = state.catalog.text.find((item) => item.id === id);
    const runtimeModel = (state.runtimes?.ollama?.models || []).find((item) => item.name === id);
    const vision = Boolean(runtimeModel?.capabilities?.includes?.('vision') || spec?.vision);
    return `
      <div class="model-status-row">
        ${dot(installed ? 'good' : 'warn')}
        <span class="status-copy">${installed ? `${esc(id)} is installed in Ollama.` : `${esc(id)} is not installed yet.`}</span>
        ${vision ? badge('vision', 'good') : ''}
        ${spec && !installed ? `<button class="btn sm subtle" data-action="install-model" data-model="${escAttr(spec.id)}">${icon('download', 12)} Pull</button>` : ''}
        ${state.runtimes.lmstudio.running ? `<button class="btn sm ghost" data-action="use-lmstudio">${icon('plug', 12)} Use LM Studio</button>` : ''}
        ${state.runtimes.ollama.running ? `<span class="tiny muted">${state.runtimes.ollama.models?.length || 0} in Ollama</span>` : ''}
      </div>`;
  }
  const spec = catalogItem(modality, id);
  const installed = Boolean(state.installed?.models?.[id]);
  const runtimeReady = state.runtimes.comfyui.installed;
  return `
    <div class="model-status-row">
      ${dot(installed ? 'good' : 'warn')}
      <span class="status-copy">${
        !runtimeReady
          ? 'ComfyUI is not installed; install it to run this model.'
          : installed
            ? `${esc(spec?.name || id)} is downloaded.`
            : `${esc(spec?.name || id)} needs ${remainingLabel(id) || fmtGb(spec?.size_gb || 0)} more.`
      }</span>
      ${
        !runtimeReady
          ? `<button class="btn sm subtle" data-action="install-runtime" data-runtime="comfyui">${icon('download', 12)} Install ComfyUI</button>`
          : !installed && spec
            ? `<button class="btn sm subtle" data-action="install-model" data-model="${escAttr(id)}">${icon('download', 12)} Download${remainingLabel(id) ? ` ${remainingLabel(id)}` : ''}</button>`
            : ''
      }
    </div>`;
}

function customModels() {
  const found = [];
  for (const modality of ['image', 'video', 'three_d', 'music']) {
    for (const model of state.catalog?.[modality] || []) {
      if (model.custom) found.push({ ...model, modality });
    }
  }
  return found;
}

function fmtCount(value) {
  const number = Number(value || 0);
  if (number >= 1_000_000) return `${(number / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  if (number >= 1_000) return `${(number / 1_000).toFixed(1).replace(/\.0$/, '')}k`;
  return String(number);
}

function hfResultRow(item) {
  const detected = item.detected;
  const label = detected ? detected.label : 'No workflow for this architecture';
  const downloads = item.downloads ? `${fmtCount(item.downloads)} downloads` : 'new';
  return `<button type="button" class="hf-row ${detected ? '' : 'muted'}" data-hf-repo="${escAttr(item.id)}">
    <span class="hf-name">${esc(item.id)}</span>
    <span class="hf-meta">${esc(downloads)}${item.gated ? ' · gated' : ''} · ${esc(label)}</span>
    ${detected ? `<span class="hf-badge">${icon('check', 11)} can import</span>` : `<span class="hf-badge warn">${icon('alert', 11)} not supported</span>`}
  </button>`;
}

function showHfSearchModal() {
  const dialog = modal({
    title: 'Search Hugging Face',
    subtitle: 'Find a model, see whether Hearth can drive it, and import it in one click.',
    wide: true,
    body: `
      <div class="row" style="gap:8px">
        <input class="input" id="hf-query" placeholder="flux, wan 2.2, ace-step, sdxl…" />
        <button class="btn primary" id="hf-run">${icon('search', 14)} Search</button>
      </div>
      <div class="hint" style="margin-top:6px">Searches the public Hub index. Gated repositories show as such and must be fetched manually.</div>
      <div id="hf-results" class="hf-list" style="margin-top:14px"></div>
      <div id="hf-detail" style="margin-top:14px"></div>`,
    actions: [{ label: 'Close', kind: 'ghost' }],
  });
  const resultsBox = dialog.el.querySelector('#hf-results');
  const detailBox = dialog.el.querySelector('#hf-detail');
  const input = dialog.el.querySelector('#hf-query');
  const runButton = dialog.el.querySelector('#hf-run');

  const search = async () => {
    const query = input.value.trim();
    if (!query) return;
    resultsBox.innerHTML = `<div class="hf-empty">${spinner(13)} Searching the Hub…</div>`;
    detailBox.innerHTML = '';
    try {
      const payload = await api.hfSearch(query, 12);
      const items = payload.results || [];
      resultsBox.innerHTML = items.length
        ? items.map(hfResultRow).join('')
        : `<div class="hf-empty">Nothing matched “${esc(query)}”.</div>`;
    } catch (error) {
      resultsBox.innerHTML = `<div class="hf-empty">${esc(error.message || 'Search failed.')}</div>`;
    }
  };

  const preview = async (repo) => {
    detailBox.innerHTML = `<div class="hf-empty">${spinner(13)} Reading ${esc(repo)}…</div>`;
    try {
      const info = await api.hfPreview(repo);
      const files = (info.files || []).slice(0, 6);
      detailBox.innerHTML = `
        <div class="muted-box">
          <div class="row-between"><strong>${esc(info.repo)}</strong><span>${info.detected ? esc(info.detected.label) : 'unsupported'}</span></div>
          <div class="row-between" style="margin-top:6px"><span>${files.length} safetensors file(s)</span><span>${info.importable ? fmtGb(info.size_gb) : '—'}</span></div>
          <div class="hf-files">${files
            .map((file) => `<div class="row-between tiny"><span class="mono">${esc(file.filename)}</span><span>${fmtGb(file.size_gb)}</span></div>`)
            .join('')}</div>
          ${
            info.importable
              ? `<div class="row" style="margin-top:12px;justify-content:flex-end">
                   <button class="btn sm primary" data-hf-import="${escAttr(repo)}">${icon('download', 13)} Download &amp; import ${fmtGb(info.size_gb)}</button>
                 </div>`
              : `<div class="callout warn" style="margin-top:12px"><span class="callout-icon">${icon('alert', 14)}</span><span>${esc(info.reason || 'Hearth cannot drive this repository.')}</span></div>`
          }
        </div>`;
    } catch (error) {
      detailBox.innerHTML = `<div class="hf-empty">${esc(error.message || 'Could not read that repository.')}</div>`;
    }
  };

  runButton.addEventListener('click', search);
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      search();
    }
  });
  resultsBox.addEventListener('click', (event) => {
    const row = event.target.closest('[data-hf-repo]');
    if (row) preview(row.dataset.hfRepo);
  });
  detailBox.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-hf-import]');
    if (!button) return;
    setButtonBusy(button, true, 'Importing…');
    try {
      const result = await api.hfImport(button.dataset.hfImport, true);
      await api.refresh();
      state = api.state;
      draft = deepClone(state.config);
      dialog.close();
      render();
      toast(
        result.job
          ? `Imported ${result.model.name}; downloading its files in Activity.`
          : `Imported ${result.model.name}.`,
        'success',
        6000,
      );
      if (result.job) navigate('activity');
    } catch (error) {
      setButtonBusy(button, false);
      toast(error.message || 'Import failed.', 'error', 7000);
    }
  });
}

function renderImportCard() {
  const families = [
    ['image:sdxl', 'Images · SDXL checkpoint'],
    ['image:flux', 'Images · FLUX checkpoint'],
    ['video:wan', 'Video · Wan 2.1 (needs diffusion, text encoder and VAE files)'],
    ['video:wan22', 'Video · Wan 2.2 (needs diffusion, text encoder and VAE files)'],
    ['three_d:hunyuan3d', '3D · Hunyuan3D 2.1'],
    ['music:ace', 'Music · ACE-Step all-in-one checkpoint'],
    ['music:ace-xl', 'Music · ACE-Step XL turbo (split files)'],
    ['music:ace-xl-sft', 'Music · ACE-Step XL SFT (split files)'],
  ];
  const roles = ['checkpoint', 'diffusion', 'text_encoder', 'vae', 'encoder_small', 'encoder_large'];
  const imported = customModels();
  return `
    <section class="settings-card" id="models-import" style="margin-top:18px">
      <div class="settings-card-head">
        <div class="icon-badge green">${icon('download', 17)}</div>
        <div class="settings-card-title">
          <h3>Import a model</h3>
          <p>Bring a checkpoint you already have, or pull one from the Hub. Hearth only drives architectures it has a workflow for, so pick the family explicitly.</p>
        </div>
        <div class="section-head-actions">
          <button class="btn sm primary" data-action="hf-search">${icon('search', 13)} Search Hugging Face…</button>
        </div>
      </div>
      <div class="settings-card-body">
        <div class="form-grid">
          ${field('Name', '<input class="input" data-import-field="name" placeholder="My SDXL checkpoint" />')}
          ${field('Family', `<select class="select" data-import-field="family">${families
            .map(([value, label]) => `<option value="${escAttr(value)}">${esc(label)}</option>`)
            .join('')}</select>`)}
          ${field('Source', `<select class="select" data-import-field="source">
            <option value="hf">Hugging Face repository</option>
            <option value="local">Already in the ComfyUI models folder</option>
          </select>`)}
          ${field('File role', `<select class="select" data-import-field="role">${roles
            .map((role) => `<option value="${escAttr(role)}">${esc(role)}</option>`)
            .join('')}</select>`)}
          ${field('Hub repository', '<input class="input" data-import-field="repo" placeholder="org/name" />', 'Ignored for local files.')}
          ${field('Hub file path', '<input class="input" data-import-field="filename" placeholder="split_files/checkpoints/model.safetensors" />')}
          ${field('Destination', '<input class="input" data-import-field="dest" placeholder="checkpoints/my-model.safetensors" />', 'Path inside the ComfyUI models folder (or the local file path).')}
          ${field('Size (GB)', '<input class="input" type="number" min="0" step="0.1" data-import-field="size_gb" />', 'Optional for Hub files; local files are measured.')}
        </div>
        <label class="field span-2" style="margin-top:12px">
          <span class="label">Extra files</span>
          <textarea class="input textarea" data-import-field="extra" rows="3" placeholder="role|repo|filename|dest|size_gb&#10;text_encoder|comfyanonymous/flux_text_encoders|clip_l.safetensors|text_encoders/clip_l.safetensors|0.25"></textarea>
          <span class="hint">One per line, for families that need more than one file (Wan, ACE-Step XL).</span>
        </label>
        <div class="row" style="margin-top:14px;justify-content:flex-end">
          <button class="btn primary" data-action="import-model">${icon('download', 14)} Import model</button>
        </div>
        ${
          imported.length
            ? `<div class="section" style="margin-top:18px">
                <div class="section-sub">Imported models</div>
                ${imported
                  .map(
                    (model) => `<div class="model-status-row">
                      ${dot(state.installed?.models?.[model.id] ? 'good' : 'warn')}
                      <span class="status-copy">${esc(model.name)} · ${esc(model.modality)} · ${esc(model.workflow)}${
                        state.installed?.models?.[model.id] ? ' · files present' : ` · needs ${remainingLabel(model.id) || fmtGb(model.size_gb || 0)}`
                      }</span>
                      ${
                        !state.installed?.models?.[model.id]
                          ? `<button class="btn sm subtle" data-action="install-model" data-model="${escAttr(model.id)}">${icon('download', 12)} Fetch</button>`
                          : ''
                      }
                      <button class="btn sm ghost" data-action="remove-import" data-model="${escAttr(model.id)}">${icon('trash', 12)} Remove</button>
                    </div>`,
                  )
                  .join('')}
              </div>`
            : ''
        }
      </div>
    </section>`;
}

function renderModels() {
  if (!draft) draft = deepClone(state.config);
  const cfg = draft;
  const sections = [
    ['text', 'Text'],
    ['image', 'Images'],
    ['video', 'Video'],
    ['sound', 'Sound'],
    ['music', 'Music'],
    ['three-d', '3D'],
    ['search', 'Search'],
    ['tools', 'Tools'],
    ['advanced', 'Advanced'],
    ['import', 'Download models'],
  ];
  return `
    <div class="settings-layout">
      <div class="page-head" style="margin-bottom:0">
        <div>
          <h2>Model settings</h2>
          <p>Changes are saved together. Installed models are detected from Ollama and ComfyUI.</p>
        </div>
        <div class="page-head-actions">
          <button class="btn sm ghost" data-action="discard-settings">${icon('refresh', 14)} Discard</button>
          <button class="btn sm primary" data-action="save-settings">${icon('check', 14)} Save changes</button>
        </div>
      </div>
      <div class="settings-subnav">
        ${sections.map(([key, label]) => `<a href="#models" data-action="goto-models" data-section="${key}">${label}</a>`).join('')}
      </div>
      ${renderTextSettings(cfg)}
      <div class="settings-grid">
        ${renderImageSettings(cfg)}
        ${renderVideoSettings(cfg)}
        ${renderAudioSettings(cfg)}
        ${renderMusicSettings(cfg)}
        ${renderThreeDSettings(cfg)}
        ${renderSearchSettings(cfg)}
      </div>
      ${renderToolSettings(cfg)}
      ${renderAdvancedSettings(cfg)}
      ${renderImportCard()}
      <div class="callout" style="margin-top:4px">
        <span class="callout-icon">${icon('shield', 16)}</span>
        <span>These settings are stored in <span class="code">${esc(state.app.config_dir)}/config.json</span> with owner-only permissions. API keys, if any, never leave this machine.</span>
      </div>
    </div>`;
}

function settingsCard(id, iconName, color, title, description, body, actions = '') {
  return `
    <section class="settings-card" id="models-${id}">
      <div class="settings-card-head">
        <div class="icon-badge ${color}">${icon(iconName, 17)}</div>
        <div class="settings-card-title">
          <h3>${esc(title)}</h3>
          <p>${esc(description)}</p>
        </div>
        <div class="section-head-actions">${actions}</div>
      </div>
      <div class="settings-card-body">${body}</div>
    </section>`;
}

function field(label, control, hint = '', span = '') {
  return `<label class="field ${span}">
    <span class="label">${esc(label)}</span>
    ${control}
    ${hint ? `<span class="hint">${esc(hint)}</span>` : ''}
  </label>`;
}

function textInput(path, value, { type = 'text', placeholder = '', min, max, step, disabled = false, list = '', rerender = false } = {}) {
  return `<input class="input" type="${type}" data-path="${path}" value="${escAttr(value ?? '')}"
    ${placeholder ? `placeholder="${escAttr(placeholder)}"` : ''}
    ${min !== undefined ? `min="${min}"` : ''}
    ${max !== undefined ? `max="${max}"` : ''}
    ${step !== undefined ? `step="${step}"` : ''}
    ${list ? `list="${list}"` : ''}
    ${disabled ? 'disabled' : ''}
    ${rerender ? 'data-rerender="true"' : ''} />`;
}

function formatSliderValue(value, unit) {
  const number = Number(value) || 0;
  if (unit === 'tokens') {
    const k = number / 1024;
    const rounded = k >= 10 ? Math.round(k) : Math.round(k * 10) / 10;
    return `${number} · ${rounded}k`;
  }
  return unit ? `${number} ${unit}` : String(number);
}

function rangeInput(path, value, { min = 0, max = 100, step = 1, unit = '' } = {}) {
  return `<div class="slider-row">
    <input class="slider" type="range" data-path="${path}" data-unit="${escAttr(unit)}"
      min="${min}" max="${max}" step="${step}" value="${Number(value) || min}" />
    <span class="slider-value" data-readout-for="${path}" data-unit="${escAttr(unit)}">${formatSliderValue(
      Number(value) || min,
      unit,
    )}</span>
  </div>`;
}

function selectInput(path, options, value, { rerender = false, disabled = false } = {}) {
  return `<select class="select" data-path="${path}" ${rerender ? 'data-rerender="true"' : ''} ${disabled ? 'disabled' : ''}>
    ${options
      .map(
        ([optionValue, label]) =>
          `<option value="${escAttr(optionValue)}" ${String(optionValue) === String(value) ? 'selected' : ''}>${esc(label)}</option>`,
      )
      .join('')}
  </select>`;
}

function textareaInput(path, value, placeholder = '') {
  return `<textarea class="textarea" data-path="${path}" placeholder="${escAttr(placeholder)}">${esc(value ?? '')}</textarea>`;
}

function switchRow(path, title, description, checked) {
  return `<div class="switch-row">
    <div class="switch-copy">
      <div class="switch-title">${esc(title)}</div>
      ${description ? `<div class="switch-desc">${esc(description)}</div>` : ''}
    </div>
    <label class="switch"><input type="checkbox" data-path="${path}" ${checked ? 'checked' : ''}/><span></span></label>
  </div>`;
}

function renderTextSettings(cfg) {
  const backend = cfg.text.backend;
  const modelOptions = state.catalog.text
    .map(
      (model) =>
        `<option value="${escAttr(model.id)}">${esc(model.name)} · ${fmtGb(model.size_gb)}${model.vision ? ' · vision' : ''} · needs ~${fmtGb(model.min_vram_gb, 0)} VRAM</option>`,
    )
    .join('');
  const installedNames = (state.runtimes.ollama.models || []).map((item) => item.name);
  const customOptions = installedNames
    .filter((name) => !state.catalog.text.some((model) => model.id === name))
    .map((name) => `<option value="${escAttr(name)}"></option>`)
    .join('');
  return settingsCard(
    'text',
    'chat',
    '',
    'Text model',
    'The brain that answers, plans and decides when to call the other modalities.',
    `
      <div class="switch-row" style="padding-top:0">
        <div class="switch-copy">
          <div class="switch-title">Enable text chat</div>
          <div class="switch-desc">Turn off if you only want image, video or 3D generation.</div>
        </div>
        <label class="switch"><input type="checkbox" data-path="text.enabled" ${cfg.text.enabled ? 'checked' : ''}/><span></span></label>
      </div>
      <div class="form-grid" style="margin-top:14px">
        ${field(
          'Backend',
          selectInput(
            'text.backend',
            [
              ['ollama', 'Ollama (managed locally)'],
              ['openai', 'OpenAI-compatible server (LM Studio, llama.cpp…)'],
              ['demo', 'Demo mode (no model)'],
            ],
            backend,
            { rerender: true },
          ),
          'Ollama is installed and managed by Hearth. OpenAI-compatible mode can point at LM Studio or any local server.',
        )}
        ${
          backend === 'demo'
            ? `<div class="field span-2"><div class="callout warn"><span class="callout-icon">${icon(
                'info',
                15,
              )}</span><span>Demo mode streams a local setup guide instead of an AI answer. It is useful for exploring the interface before downloading a model.</span></div></div>`
            : field(
                'Base URL',
                textInput('text.base_url', cfg.text.base_url, { placeholder: 'http://127.0.0.1:11434' }),
                backend === 'openai' ? 'Use http://127.0.0.1:1234/v1 for LM Studio.' : 'Local Ollama endpoint.',
              )
        }
        ${
          backend === 'demo'
            ? ''
            : field(
                'Model',
                `<input class="input" data-path="text.model" list="text-model-list" value="${escAttr(
                  cfg.text.model,
                )}" placeholder="qwen3.5:9b" /><datalist id="text-model-list">${modelOptions}${customOptions}</datalist>`,
                'Catalog models show their download size; installed Ollama models appear as suggestions too.',
                'span-2',
              )
        }
        ${
          backend === 'openai'
            ? field(
                'API key',
                textInput('text.api_key', cfg.text.api_key, { type: 'password', placeholder: 'optional' }),
                'Only needed if your local server requires one.',
                'span-2',
              )
            : ''
        }
        ${field(
          'Context window',
          rangeInput('text.context_tokens', cfg.text.context_tokens, { min: 1024, max: 131072, step: 1024, unit: 'tokens' }),
          'How much conversation the model keeps in context. Each doubling costs memory: 8k is the safe default, 32k–64k needs a bigger model and headroom.',
          'span-2',
        )}
        ${field(
          'Temperature',
          textInput('text.temperature', cfg.text.temperature, { type: 'number', min: 0, max: 2, step: 0.05 }),
          'Higher is more creative; lower is more precise.',
        )}
        ${field(
          'Top-p',
          textInput('text.top_p', cfg.text.top_p, { type: 'number', min: 0, max: 1, step: 0.05 }),
          'Nucleus sampling threshold.',
        )}
        ${field(
          'Tool calling',
          selectInput(
            'text.tool_mode',
            [
              ['auto', 'Auto (native when supported)'],
              ['native', 'Native tool calls'],
              ['prompt', 'Prompt protocol (broad compatibility)'],
            ],
            cfg.text.tool_mode,
          ),
          'Auto asks Ollama what the model supports and falls back to a text protocol.',
        )}
        ${field(
          'Max tool rounds',
          textInput('text.max_tool_rounds', cfg.text.max_tool_rounds, { type: 'number', min: 1, max: 10 }),
          'How many tool calls the model can chain in one turn.',
        )}
        ${field(
          'Keep alive',
          textInput('text.keep_alive', cfg.text.keep_alive, { placeholder: '10m' }),
          'How long Ollama keeps the text model in memory.',
        )}
        <div class="field span-2">
          <span class="label">System prompt</span>
          ${textareaInput('text.system_prompt', cfg.text.system_prompt, 'Instructions for your local assistant…')}
          <span class="hint">Use {date} to insert today's date. Keep it short for smaller models.</span>
        </div>
      </div>
      ${modelStatusRow(cfg.text.model, { text: true })}
      <div class="switch-list" style="margin-top:10px">
        ${switchRow('text.tools_enabled', 'Let the assistant use tools', 'Search, read pages, generate media and speak.', cfg.text.tools_enabled)}
        ${switchRow('text.thinking', 'Show reasoning tokens', 'Off answers faster and keeps the thinking box quiet. Turn on for harder problems.', cfg.text.thinking)}
      </div>`,
  );
}

function mediaModelOptions(modality, selected) {
  return (state.catalog[modality] || []).map((model) => [
    model.id,
    `${model.name} · ${
      state.installed.models[model.id] ? 'installed' : `${fmtGb(missingGb(model.id) || model.size_gb)} to download`
    }`,
  ]);
}

function mediaRuntimeNote() {
  const comfy = state.runtimes.comfyui;
  if (!comfy.installed) {
    return `<div class="callout warn" style="margin-bottom:12px"><span class="callout-icon">${icon(
      'alert',
      15,
    )}</span><span>ComfyUI is required for media generation. <button class="link-btn" data-action="install-runtime" data-runtime="comfyui">Install ComfyUI</button></span></div>`;
  }
  return `<div class="runtime-note">${dot(comfy.running ? 'good' : 'warn')} ComfyUI ${
    comfy.running ? 'is running' : 'starts on demand'
  }${comfy.cpu_mode ? ' · CPU mode' : ''}</div>`;
}

function renderImageSettings(cfg) {
  return settingsCard(
    'image',
    'image',
    'blue',
    'Images',
    'Text-to-image through SDXL or FLUX in ComfyUI.',
    `
      ${mediaRuntimeNote()}
      ${switchRow('image.enabled', 'Enable image generation', 'Adds generate_image to the assistant and the chat tool menu.', cfg.image.enabled)}
      <div class="form-grid" style="margin-top:12px">
        ${field('Model', selectInput('image.model', imageModelOptions(cfg.image.model), cfg.image.model, { rerender: true }), '')}
        ${field('Size', `<div class="row"><input class="input" type="number" data-path="image.width" value="${cfg.image.width}" min="256" max="2048" step="64" /><span class="muted">×</span><input class="input" type="number" data-path="image.height" value="${cfg.image.height}" min="256" max="2048" step="64" /></div>`, 'Width × height in pixels.')}
        ${field('Steps', textInput('image.steps', cfg.image.steps, { type: 'number', min: 1, max: 80 }), 'SDXL Turbo likes 4; FLUX schnell likes 4.')}
        ${field('CFG', textInput('image.cfg', cfg.image.cfg, { type: 'number', min: 0, max: 20, step: 0.1 }), 'Classifier-free guidance.')}
        <div class="field span-2">
          <span class="label">Negative prompt</span>
          ${textareaInput('image.negative_prompt', cfg.image.negative_prompt, 'Optional things to avoid…')}
        </div>
      </div>
      ${modelStatusRow(cfg.image.model, { modality: 'image' })}`,
  );
}

function imageModelOptions(selected) {
  return mediaModelOptions('image', selected);
}

function renderVideoSettings(cfg) {
  return settingsCard(
    'video',
    'video',
    'blue',
    'Video',
    'Short text-to-video clips through Wan 2.1. Expect minutes, not seconds.',
    `
      ${mediaRuntimeNote()}
      ${switchRow('video.enabled', 'Enable video generation', 'Adds generate_video and makes long jobs visible in Activity.', cfg.video.enabled)}
      <div class="form-grid" style="margin-top:12px">
        ${field('Model', selectInput('video.model', mediaModelOptions('video', cfg.video.model), cfg.video.model, { rerender: true }))}
        ${field('Size', `<div class="row"><input class="input" type="number" data-path="video.width" value="${cfg.video.width}" min="256" max="1280" step="16" /><span class="muted">×</span><input class="input" type="number" data-path="video.height" value="${cfg.video.height}" min="256" max="1280" step="16" /></div>`)}
        ${field('Frames', textInput('video.frames', cfg.video.frames, { type: 'number', min: 9, max: 161, step: 4 }), 'Wan rounds to 4n+1 frames.')}
        ${field('FPS', textInput('video.fps', cfg.video.fps, { type: 'number', min: 4, max: 60 }), 'Playback frame rate. Seconds × FPS decides the frame count.')}
        ${field('Steps', textInput('video.steps', cfg.video.steps, { type: 'number', min: 4, max: 60 }))}
        ${field('CFG', textInput('video.cfg', cfg.video.cfg, { type: 'number', min: 1, max: 20, step: 0.5 }))}
        <div class="field span-2">
          <span class="label">Negative prompt</span>
          ${textareaInput('video.negative_prompt', cfg.video.negative_prompt)}
        </div>
      </div>
      ${modelStatusRow(cfg.video.model, { modality: 'video' })}
      <div class="switch-list" style="margin-top:10px">
        ${switchRow('video.safe_limits', 'Auto-fit video to this GPU', 'Shortens overly large clips to avoid OOM. Turn off to attempt longer/higher-resolution videos at your own risk.', cfg.video.safe_limits)}
      </div>`,
  );
}

function renderAudioSettings(cfg) {
  const voiceOptions = state.catalog.tts.map(
    (voice) =>
      `<option value="${escAttr(voice.id)}" ${voice.id === cfg.audio.voice ? 'selected' : ''}>${esc(
        voice.name,
      )}${state.installed.voices[voice.id] ? ' · installed' : ''}</option>`,
  );
  const sttOptions = state.catalog.stt.map(
    (model) =>
      `<option value="${escAttr(model.id)}" ${model.id === cfg.audio.stt_model ? 'selected' : ''}>${esc(
        model.name,
      )} · ${fmtGb(model.size_gb)}${state.installed.stt[model.id] ? ' · installed' : ''}</option>`,
  );
  const voiceInstalled = Boolean(state.installed.voices[cfg.audio.voice]);
  const sttInstalled = Boolean(state.installed.stt[cfg.audio.stt_model]);
  return settingsCard(
    'sound',
    'speaker',
    'green',
    'Sound & speech',
    'Local text-to-speech with Piper (or espeak-ng) and Whisper transcription.',
    `
      ${switchRow('audio.enabled', 'Enable speech', 'Adds text_to_speech and turns microphone uploads into text.', cfg.audio.enabled)}
      <div class="form-grid" style="margin-top:12px">
        ${field(
          'Speech engine',
          selectInput(
            'audio.tts_engine',
            [
              ['auto', 'Auto (Piper, then espeak-ng)'],
              ['piper', 'Piper only'],
              ['espeak', 'espeak-ng'],
              ['none', 'Disabled'],
            ],
            cfg.audio.tts_engine,
            { rerender: true },
          ),
        )}
        ${field('Voice', `<select class="select" data-path="audio.voice">${voiceOptions.join('')}</select>`, '')}
        ${field('Transcription model', `<select class="select" data-path="audio.stt_model">${sttOptions.join('')}</select>`)}
        ${field(
          'Transcription language',
          textInput('audio.language', cfg.audio.language, { placeholder: 'auto' }),
          'Use auto, en, de, fr…',
        )}
      </div>
      <div class="model-status-row">
        ${dot(voiceInstalled ? 'good' : 'warn')}
        <span class="status-copy">${voiceInstalled ? 'Piper voice is installed.' : 'Piper voice not downloaded; espeak-ng will be used.'}</span>
        ${!voiceInstalled ? `<button class="btn sm subtle" data-action="install-voice" data-voice="${escAttr(cfg.audio.voice)}">${icon('download', 12)} Voice</button>` : ''}
      </div>
      <div class="model-status-row">
        ${dot(sttInstalled ? 'good' : 'warn')}
        <span class="status-copy">${sttInstalled ? 'Whisper model is installed.' : 'Whisper model not downloaded yet.'}</span>
        ${!sttInstalled ? `<button class="btn sm subtle" data-action="install-stt" data-stt="${escAttr(cfg.audio.stt_model)}">${icon('download', 12)} Whisper</button>` : ''}
      </div>`,
  );
}

function renderMusicSettings(cfg) {
  return settingsCard(
    'music',
    'music',
    'green',
    'Music',
    'ACE-Step 1.5 composes short tracks, with or without lyrics.',
    `
      ${mediaRuntimeNote()}
      ${switchRow('music.enabled', 'Enable music generation', 'Adds generate_music to the assistant.', cfg.music.enabled)}
      <div class="form-grid" style="margin-top:12px">
        ${field('Model', selectInput('music.model', mediaModelOptions('music', cfg.music.model), cfg.music.model, { rerender: true }))}
        ${field('Duration', textInput('music.duration', cfg.music.duration, { type: 'number', min: 5, max: 180 }), 'Seconds.')}
        ${field('BPM', textInput('music.bpm', cfg.music.bpm, { type: 'number', min: 30, max: 240 }))}
        ${field('Language', textInput('music.language', cfg.music.language, { placeholder: 'en' }), 'Used for sung lyrics.')}
      </div>
      ${modelStatusRow(cfg.music.model, { modality: 'music' })}`,
  );
}

function renderThreeDSettings(cfg) {
  return settingsCard(
    'three-d',
    'cube',
    'accent',
    '3D models',
    'Hunyuan3D 2.1 turns a preview image into a GLB mesh.',
    `
      ${mediaRuntimeNote()}
      ${switchRow('three_d.enabled', 'Enable 3D generation', 'Adds generate_3d; an image is generated first unless you attach one.', cfg.three_d.enabled)}
      <div class="form-grid" style="margin-top:12px">
        ${field('Model', selectInput('three_d.model', mediaModelOptions('three_d', cfg.three_d.model), cfg.three_d.model, { rerender: true }))}
        ${field('Latent resolution', textInput('three_d.resolution', cfg.three_d.resolution, { type: 'number', min: 1024, max: 8192, step: 256 }))}
        ${field('Steps', textInput('three_d.steps', cfg.three_d.steps, { type: 'number', min: 8, max: 60 }))}
        ${field('CFG', textInput('three_d.cfg', cfg.three_d.cfg, { type: 'number', min: 1, max: 12, step: 0.5 }))}
        ${field('Octree resolution', textInput('three_d.octree_resolution', cfg.three_d.octree_resolution, { type: 'number', min: 64, max: 512, step: 16 }))}
      </div>
      ${modelStatusRow(cfg.three_d.model, { modality: 'three_d' })}`,
  );
}

function renderSearchSettings(cfg) {
  return settingsCard(
    'search',
    'globe',
    'blue',
    'Web search',
    'SearXNG is preferred; DuckDuckGo is the zero-config fallback.',
    `
      ${switchRow('search.enabled', 'Enable web search', 'Adds web_search and fetch_url to the assistant.', cfg.search.enabled)}
      <div class="form-grid" style="margin-top:12px">
        ${field(
          'Provider',
          selectInput(
            'search.provider',
            [
              ['auto', 'Auto (SearXNG, then DuckDuckGo)'],
              ['searxng', 'SearXNG only'],
              ['duckduckgo', 'DuckDuckGo'],
            ],
            cfg.search.provider,
            { rerender: true },
          ),
        )}
        ${field('SearXNG URL', textInput('search.searxng_url', cfg.search.searxng_url, { placeholder: 'http://127.0.0.1:8888' }), 'Leave empty to use DuckDuckGo.')}
        ${field('Results', textInput('search.max_results', cfg.search.max_results, { type: 'number', min: 1, max: 12 }))}
        ${field('Pages to read', textInput('search.fetch_count', cfg.search.fetch_count, { type: 'number', min: 0, max: 5 }), 'Extra page excerpts after the search.')}
      </div>
      <div class="switch-list">
        ${switchRow('search.fetch_pages', 'Read top results', 'Fetch page text so the model can quote more than a snippet.', cfg.search.fetch_pages)}
        ${switchRow('search.safe_search', 'Safe search', 'Ask the provider to filter adult results.', cfg.search.safe_search)}
      </div>
      <div class="callout" style="margin-top:12px"><span class="callout-icon">${icon(
        'alert',
        15,
      )}</span><span>Web search and page reading leave this machine. Point Hearth at a self-hosted SearXNG instance if you want search to stay on your network.</span></div>`,
  );
}

function renderToolSettings(cfg) {
  return settingsCard(
    'tools',
    'wand',
    '',
    'Tool permissions',
    'Let the assistant choose from these abilities. Disabled tools are hidden from the model.',
    `<div class="tool-grid">${TOOL_LIST.map(
      ([key, name, description, iconName]) => `
        <div class="tool-chip">
          ${icon(iconName, 16)}
          <div class="tool-copy">
            <div class="tool-name">${esc(name)}</div>
            <div class="tool-desc">${esc(description)}</div>
          </div>
          <label class="switch"><input type="checkbox" data-path="tools.${key}" ${cfg.tools[key] ? 'checked' : ''}/><span></span></label>
        </div>`,
    ).join('')}</div>`,
  );
}

function renderAdvancedSettings(cfg) {
  return settingsCard(
    'advanced',
    'settings',
    '',
    'Advanced runtime',
    'Ports and process behavior. Change these only if something else is already using the defaults.',
    `<div class="form-grid">
      ${field('Ollama port', textInput('runtimes.ollama_port', cfg.runtimes.ollama_port, { type: 'number', min: 1024, max: 65535 }))}
      ${field('ComfyUI port', textInput('runtimes.comfyui_port', cfg.runtimes.comfyui_port, { type: 'number', min: 1024, max: 65535 }))}
      ${field(
        'ComfyUI VRAM strategy',
        selectInput(
          'runtimes.comfyui_vram_mode',
          [
            ['auto', 'Automatic (dynamic VRAM offload)'],
            ['ram', 'Prefer system RAM offload'],
            ['high', 'Keep models on GPU'],
            ['cpu', 'CPU only'],
          ],
          cfg.runtimes.comfyui_vram_mode,
          { rerender: true },
        ),
        'Media jobs unload the text model first. Automatic already offloads what does not fit; “Prefer RAM” is more aggressive.',
        'span-2',
      )}
      ${field('Reserve VRAM (GB)', textInput('runtimes.comfyui_reserve_vram_gb', cfg.runtimes.comfyui_reserve_vram_gb, { type: 'number', min: 0, max: 16, step: 0.5 }), 'Keep this much VRAM free for the desktop/other apps; a larger reserve pushes more work into system RAM.')}
      ${field('Extra VRAM headroom (GB)', textInput('runtimes.comfyui_vram_headroom_gb', cfg.runtimes.comfyui_vram_headroom_gb, { type: 'number', min: 0, max: 16, step: 0.5 }), 'Dynamic VRAM tries to keep this extra amount unused.')}
    </div>
    <div class="callout" style="margin-top:12px"><span class="callout-icon">${icon('info', 15)}</span><span>Restart ComfyUI (or the server) after changing these memory settings. “Prefer system RAM offload” is the safest choice for 8 GB cards and video/3D models.</span></div>
    <div class="switch-list" style="margin-top:12px">
      ${switchRow('runtimes.ollama_auto_start', 'Start Ollama with the server', 'Hearth launches its managed Ollama process when you start the server.', cfg.runtimes.ollama_auto_start)}
      ${switchRow('runtimes.comfyui_auto_start', 'Start ComfyUI with the server', 'ComfyUI starts on demand anyway when a media tool is called.', cfg.runtimes.comfyui_auto_start)}
      ${switchRow('runtimes.prefer_system_ollama', 'Prefer a system Ollama', 'Use an Ollama binary from PATH before downloading Hearth’s own copy.', cfg.runtimes.prefer_system_ollama)}
    </div>
    <div class="kv-grid">
      <div class="kv"><div class="kv-label">Data</div><div class="kv-value" title="${escAttr(state.app.data_dir)}">${esc(state.app.data_dir)}</div></div>
      <div class="kv"><div class="kv-label">Config</div><div class="kv-value" title="${escAttr(state.app.config_dir)}">${esc(state.app.config_dir)}</div></div>
    </div>`,
  );
}

/* ------------------------------------------------------------------ */
/* Presets page                                                       */
/* ------------------------------------------------------------------ */
function renderPresetsPage() {
  const presets = state.presets.presets;
  const rows = [
    ['Text', (preset) => cell(preset.models.text?.name, preset.models.text ? fmtGb(preset.models.text.size_gb) : '')],
    ['Images', (preset) => cell(preset.models.image?.name, preset.models.image ? fmtGb(preset.models.image.size_gb) : '')],
    ['Video', (preset) => cell(preset.models.video?.name, preset.models.video ? fmtGb(preset.models.video.size_gb) : '')],
    ['3D', (preset) => cell(preset.models.three_d?.name, preset.models.three_d ? fmtGb(preset.models.three_d.size_gb) : '')],
    ['Music', (preset) => cell(preset.models.music?.name, preset.models.music ? fmtGb(preset.models.music.size_gb) : '')],
    ['Speech', (preset) => cell(`${preset.audio.tts_voice.name} + ${preset.audio.stt_model.name}`, `${fmtGb(preset.audio.stt_model.size_gb)} STT`)],
    ['Loading', (preset) => cell(loadModeLabel(preset.load_mode), preset.load_mode === 'lazy' ? 'unload when idle' : preset.load_mode === 'text_resident' ? 'text stays warm' : 'fit set resident')],
    ['Download', (preset) => `<strong>${fmtGb(preset.download_gb)}</strong>`],
    ['Peak VRAM', (preset) => `${fmtGb(preset.peak_vram_gb, 0)}`],
    ['Peak RAM', (preset) => `${fmtGb(preset.peak_ram_gb, 0)}`],
  ];
  const recommended = recommendedPreset();
  return `
    <div class="page-head">
      <div>
        <h2>Tuned to your machine</h2>
        <p>${esc(state.presets.hardware_summary)} · ${state.hardware.gpu_usable ? 'GPU available' : 'CPU fallback until the GPU driver responds'}</p>
      </div>
      <div class="page-head-actions">
        <button class="btn sm ghost" data-action="refresh-hardware">${icon('scan', 14)} Rescan hardware</button>
        <button class="btn sm subtle" data-action="custom-preset">${icon('edit', 13)} Save as custom</button>
      </div>
    </div>
    <div class="preset-grid">${presets.map((preset) => renderPresetCard(preset)).join('')}</div>
    ${renderPresetBuilder()}
    <div class="section" style="margin-top:26px">
      <div class="section-head">
        <div>
          <div class="section-title">${icon('sliders', 17)} Side by side</div>
          <div class="section-sub">Estimates include first-time runtime downloads; installed pieces are skipped.</div>
        </div>
      </div>
      <div class="preset-table-wrap scroll-x">
        <table class="preset-table">
          <thead>
            <tr>
              <th></th>
              ${presets
                .map(
                  (preset) => `<th class="tier-head ${preset.recommended ? 'recommended' : ''}">
                    <strong>${esc(preset.name)} ${preset.recommended ? '· suggested' : ''}</strong>
                    <span>${esc(preset.tagline)}</span>
                  </th>`,
                )
                .join('')}
            </tr>
          </thead>
          <tbody>
            ${rows
              .map(
                ([label, renderCell]) => `<tr><td class="row-label">${label}</td>${presets
                  .map((preset) => `<td class="tier-cell">${renderCell(preset)}</td>`)
                  .join('')}</tr>`,
              )
              .join('')}
            <tr>
              <td class="row-label">Apply</td>
              ${presets
                .map(
                  (preset) => `<td class="table-actions">${presetActionHtml(preset, { table: true })}</td>`,
                )
                .join('')}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="grid-2" style="margin-top:22px">
      <section class="card section-card">
        <div class="section-head"><div><div class="section-title">${icon('info', 16)} How these were chosen</div></div></div>
        <div class="muted-box" style="margin-top:12px">
          Hearth reads VRAM first, then system RAM, then free disk. Fast stays inside a small memory envelope;
          Balanced gives the text model room to breathe; Smart allows offload to system RAM when the quality jump is worth it.
        </div>
        <div class="stack" style="margin-top:12px">
          ${(recommended?.notes || [])
            .map((note) => `<div class="hw-note">${icon('info', 13)}<span>${esc(note)}</span></div>`)
            .join('')}
          ${(state.hardware.notes || [])
            .map((note) => `<div class="hw-note">${icon('alert', 13)}<span>${esc(note)}</span></div>`)
            .join('')}
        </div>
      </section>
      <section class="card section-card">
        <div class="section-head"><div><div class="section-title">${icon('download', 16)} Download sources</div></div></div>
        <p class="muted small" style="margin-top:8px">Hearth probes mirrors before a download and keeps the fastest reachable one for six hours.</p>
        <div class="source-list" style="margin-top:10px">
          ${renderSourceRow('Hugging Face', state.sources.hf, 'library')}
          ${renderSourceRow('PyPI', state.sources.pypi, 'code')}
        </div>
      </section>
    </div>`;
}

function cell(primary, secondary = '') {
  return `${esc(primary || '—')}${secondary ? `<span class="sub">${esc(secondary)}</span>` : ''}`;
}

function loadModeLabel(mode) {
  return { lazy: 'Lazy', text_resident: 'Text resident', keep_all: 'Keep all' }[mode] || mode;
}

/* ------------------------------------------------------------------ */
/* Server page                                                        */
/* ------------------------------------------------------------------ */
let serverUsers = null;
let serverUsersMeta = { insecure: [], allow_remote: false, port: 0 };
let panelConfigured = false;

async function refreshServerUsers() {
  try {
    if (typeof api.serverUsers !== 'function') {
      // A stale cached api.js would otherwise throw "is not a function".
      throw new Error('Reload the page to finish updating Hearth.');
    }
    const payload = await api.serverUsers();
    serverUsers = payload.users || [];
    try {
      panelConfigured = Boolean((await api.panelStatus()).configured);
    } catch (error) {
      panelConfigured = false;
    }
    serverUsersMeta = { insecure: payload.insecure || [], allow_remote: payload.allow_remote, port: payload.port };
  } catch (error) {
    serverUsers = [];
    toast(error.message || 'Could not load the account list.', 'error');
  }
  render();
}

function userRow(user) {
  const perms = user.permissions || {};
  const media = ['image', 'video', 'music', 'three_d', 'audio'].filter((key) => perms[key]).length;
  const flags = [
    perms.chat ? 'chat' : '',
    perms.attachments ? 'uploads' : '',
    perms.tools ? 'tools' : '',
    media ? `${media} media` : '',
    perms.change_model ? 'models' : '',
    perms.change_preset ? 'presets' : '',
  ].filter(Boolean);
  return `<div class="user-row ${user.enabled ? '' : 'off'}">
    <div class="user-main">
      <div class="user-name">${esc(user.name)} ${user.enabled ? '' : badge('off', 'neutral', true)}</div>
      <div class="tiny muted">${flags.length ? esc(flags.join(' · ')) : 'read only'}${user.last_seen ? ` · seen ${timeAgo(user.last_seen)}` : ''}</div>
      <div class="user-secret">
        ${
          user.has_secret
            ? `<span class="code tiny" data-secret-for="${escAttr(user.id)}">${esc(user.secret || '')}</span>
               <button class="btn icon ghost sm" data-action="copy-secret" data-id="${escAttr(user.id)}" data-copy="${escAttr(user.secret || '')}" title="Copy secret">${icon('copy', 12)}</button>`
            : `<span class="warn-text tiny">no secret — anyone who can reach this port can use this account</span>`
        }
      </div>
    </div>
    <div class="user-actions">
      <button class="btn sm ghost" data-action="rotate-secret" data-id="${escAttr(user.id)}" title="New secret">${icon('refresh', 12)} New secret</button>
      <button class="btn sm ghost" data-action="toggle-user" data-id="${escAttr(user.id)}" data-enabled="${user.enabled ? '0' : '1'}">${user.enabled ? 'Disable' : 'Enable'}</button>
      <button class="btn icon ghost sm" data-action="delete-user" data-id="${escAttr(user.id)}" title="Delete">${icon('trash', 13)}</button>
    </div>
  </div>`;
}

function renderClientMode() {
  const caps = state.capabilities || {};
  const media = Object.entries(caps.permissions?.media || {})
    .filter(([, allowed]) => allowed)
    .map(([name]) => name);
  const flags = [
    caps.permissions?.chat ? 'chat' : '',
    caps.permissions?.attachments ? 'uploads' : '',
    caps.permissions?.tools ? 'tools' : '',
    caps.permissions?.change_model ? 'model switching' : '',
    caps.permissions?.change_preset ? 'preset switching' : '',
    ...media,
  ].filter(Boolean);
  return `
    <div class="page-head"><div>
      <h2>Connected to ${esc(state.app.url || '')}</h2>
      <p>This browser is using a Hearth server elsewhere. Models run on that machine; every message is encrypted with the account secret.</p>
    </div></div>
    <section class="card section-card">
      <div class="row-between"><span>Account</span><strong>${esc(caps.user?.name || '')}</strong></div>
      <div class="row-between" style="margin-top:6px"><span>Encryption</span><strong>${caps.user?.secure ? 'on' : 'off'}</strong></div>
      <div class="cap-list" style="margin-top:12px">${flags.map((flag) => `<span class="badge badge-neutral">${esc(flag)}</span>`).join('')}</div>
      <div class="row" style="margin-top:16px;gap:8px">
        <button class="btn primary" data-action="open-chat">${icon('chat', 15)} Open chat</button>
        <button class="btn ghost" data-action="disconnect-remote">${icon('x', 14)} Disconnect</button>
      </div>
    </section>`;
}

function renderRemoteCard() {
  if (serverUsers === null) {
    refreshServerUsers();
    return `<section class="card section-card" style="margin-top:14px"><div class="section-head"><div><div class="section-title">${icon('plug', 16)} Remote access</div><div class="section-sub">Loading accounts…</div></div></div></section>`;
  }
  const cfg = draft || state.config;
  const insecure = serverUsers.filter((user) => user.enabled && !user.has_secret).map((user) => user.name);
  return `
    <section class="card section-card" style="margin-top:14px">
      <div class="section-head">
        <div>
          <div class="section-title">${icon('plug', 16)} Remote access</div>
          <div class="section-sub">Let other devices use this machine's models. Traffic is encrypted with each account's secret.</div>
        </div>
      </div>
      <div class="form-grid" style="margin-top:12px">
        ${field('Port', textInput('server.port', cfg.server.port, { type: 'number', min: 1024, max: 65535 }), 'Restart Hearth after changing this.')}
        ${field('Connect page', `<div class="copy-field"><span>${esc(state.app.url.replace(/\d+$/, '') )}${cfg.server.port}/connect</span>
          <button class="btn icon sm ghost" data-action="copy-url" data-copy="${escAttr(state.app.url.replace(/\d+$/, ''))}${cfg.server.port}/connect" title="Copy">${icon('copy', 12)}</button></div>`, 'Open this from the phone or laptop.')}
      </div>
      <div class="switch-list" style="margin-top:6px">
        ${switchRow('server.allow_remote', 'Accept connections from other devices', 'Binds to all interfaces. Off means this Hearth is only reachable from this machine.', cfg.server.allow_remote)}
      </div>
      ${
        insecure.length
          ? `<div class="callout warn" style="margin-top:12px"><span class="callout-icon">${icon('alert', 15)}</span><span><strong>Not secure:</strong> ${esc(
              insecure.join(', '),
            )} ${insecure.length === 1 ? 'has' : 'have'} no secret. Anyone who can reach this port can use that account. Add a secret to encrypt the connection.</span></div>`
          : ''
      }
      <div class="section-head" style="margin-top:18px"><div><div class="section-title">${icon('lock', 15)} Panel access</div>
        <div class="section-sub">A code that lets another device open these settings. Set it here, then log in from that device at <span class="code">http://&lt;this-pc&gt;:${cfg.server.port}/</span>.</div></div></div>
      <div class="row" style="gap:8px;margin-top:10px;align-items:flex-end">
        <label class="field" style="flex:1"><span class="label">${panelConfigured ? 'New code' : 'Set a code'}</span>
          <input class="input" id="panel-code-input" type="password" placeholder="at least 4 characters" autocomplete="off" />
        </label>
        <button class="btn primary" data-action="set-panel-code">${icon('lock', 14)} ${panelConfigured ? 'Replace' : 'Set'}</button>
        ${
          panelConfigured
            ? `<button class="btn ghost" data-action="clear-panel-code">${icon('x', 13)} Remove</button>`
            : ''
        }
      </div>
      <div class="hint">${panelConfigured ? 'A code is set. Devices that log in can change everything except the server code itself.' : 'Without a code, other devices only see the download page and the user connect screen.'}</div>
      <div class="section-head" style="margin-top:16px"><div><div class="section-title">${icon('user', 15)} Accounts</div></div></div>
      <div class="user-list" style="margin-top:8px">
        ${serverUsers.length ? serverUsers.map(userRow).join('') : `<div class="muted-box">No accounts yet. Add one so another device can connect.</div>`}
      </div>
      <div class="row" style="gap:8px;margin-top:12px;align-items:flex-end">
        <label class="field" style="flex:1"><span class="label">New account</span>
          <input class="input" id="new-user-name" placeholder="phone" />
        </label>
        <label class="field" style="flex:0 0 auto">
          <span class="label">&nbsp;</span>
          <label class="checkbox-inline tiny"><input type="checkbox" id="new-user-insecure" /> no secret (insecure)</label>
        </label>
        <button class="btn primary" data-action="add-user">${icon('plus', 14)} Add</button>
      </div>
    </section>`;
}

function renderServerPage() {
  const running = state.app.running;
  const policy = draft?.load?.mode || state.config.load.mode;
  const cfg = draft || state.config;
  return `
    <section class="server-hero ${running ? 'running' : ''}">
      <div>
        <div class="server-state">
          <div class="server-state-icon">${icon(running ? 'server' : 'play', 20)}</div>
          <div>
            <h2>${running ? 'Local engine is running' : 'Local engine is stopped'}</h2>
            <p>${running ? 'Chat, tools and media generation are available on this machine.' : 'Start the server when you are ready to chat; models stay unloaded until they are needed.'}</p>
          </div>
        </div>
        <div class="copy-field server-url" style="margin-top:14px">
          <span>${esc(state.app.url)}/chat</span>
          <button class="btn icon sm ghost" data-action="copy-url" data-copy="${escAttr(`${state.app.url}/chat`)}" title="Copy chat URL">${icon('copy', 13)}</button>
          <button class="btn icon sm ghost" data-action="open-chat" title="Open chat">${icon('external', 13)}</button>
        </div>
      </div>
      <div class="server-actions">
        ${running
          ? `<button class="btn ghost" data-action="open-chat">${icon('chat', 15)} Open chat</button><button class="btn danger" data-action="stop-server">${icon('stop', 14)} Stop server</button>`
          : `<button class="btn primary" data-action="start-server">${icon('play', 15)} Start server</button>`}
      </div>
    </section>
    ${renderRemoteCard()}
    <div class="grid-2" style="margin-top:14px">
      <section class="card section-card">
        <div class="section-head">
          <div><div class="section-title">${icon('memory', 16)} Load policy</div><div class="section-sub">How models occupy VRAM and RAM between requests.</div></div>
        </div>
        <div class="policy-grid">
          ${policyCard('lazy', 'pause', 'Lazy', 'Load on demand and unload when idle.', policy)}
          ${policyCard('text_resident', 'chat', 'Text resident', 'Keep the text model warm; media loads on demand.', policy)}
          ${policyCard('keep_all', 'layers', 'Keep all', 'Preload the fitted set for instant switching.', policy)}
        </div>
        <div class="form-grid" style="margin-top:14px">
          ${field('Idle unload', textInput('load.idle_unload_minutes', cfg.load.idle_unload_minutes, { type: 'number', min: 0, max: 240 }), 'Minutes. 0 disables idle unloading.')}
          ${field('Max loaded', textInput('load.max_loaded_models', cfg.load.max_loaded_models, { type: 'number', min: 1, max: 8 }), 'Ollama’s concurrent model limit.')}
        </div>
        <div class="switch-list">
          ${switchRow('load.memory_guard', 'Memory guard', 'Refuse or evict a model when it would not fit.', cfg.load.memory_guard)}
          ${switchRow('load.unload_comfy_after_job', 'Unload ComfyUI after each job', 'Frees VRAM immediately; the next generation reloads the model.', cfg.load.unload_comfy_after_job)}
          ${switchRow('server.keep_services_on_stop', 'Keep services running when the server stops', 'Leave Ollama/ComfyUI processes up; only unload the models.', cfg.server.keep_services_on_stop)}
        </div>
        <div class="savebar-hint muted tiny" style="margin-top:10px">Changes use the Save button; ${dirty ? 'you have unsaved changes.' : 'everything is saved.'}</div>
      </section>
      <section class="card section-card">
        <div class="section-head">
          <div><div class="section-title">${icon('server', 16)} Runtime readiness</div><div class="section-sub">What the chat engine will find when you press Start.</div></div>
        </div>
        <div class="runtime-table">
          ${runtimeRow('Ollama', 'chat', state.runtimes.ollama, 'ollama')}
          ${runtimeRow('ComfyUI', 'image', state.runtimes.comfyui, 'comfyui')}
          ${runtimeRow('Speech', 'speaker', { installed: state.runtimes.audio.piper || state.runtimes.audio.whisper, running: false }, 'audio')}
          ${runtimeRow('LM Studio', 'bot', { installed: state.runtimes.lmstudio.running, running: state.runtimes.lmstudio.running }, 'lmstudio')}
        </div>
        <div class="kv-grid">
          <div class="kv"><div class="kv-label">Text backend</div><div class="kv-value">${esc(state.config.text.backend)} · ${esc(state.config.text.model)}</div></div>
          <div class="kv"><div class="kv-label">Chat endpoint</div><div class="kv-value" title="${escAttr(`${state.app.url}/chat`)}">${esc(`${state.app.url}/chat`)}</div></div>
          <div class="kv"><div class="kv-label">Ollama</div><div class="kv-value" title="${escAttr(state.runtimes.ollama.base_url || '')}">${esc(state.runtimes.ollama.base_url || '—')}</div></div>
          <div class="kv"><div class="kv-label">ComfyUI</div><div class="kv-value" title="${escAttr(state.runtimes.comfyui.base_url || '')}">${esc(state.runtimes.comfyui.base_url || '—')}</div></div>
        </div>
        <div class="callout ${state.hardware.gpu_usable ? '' : 'warn'}" style="margin-top:12px"><span class="callout-icon">${icon(
          state.hardware.gpu_usable ? 'check' : 'alert',
          15,
        )}</span><span>${esc(
          state.hardware.gpu_usable
            ? 'GPU acceleration is available. ComfyUI starts with CUDA.'
            : 'GPU driver is not responding, so Hearth runs on CPU until it is available. Models still work, just slower.',
        )}</span></div>
      </section>
    </div>
    <div class="grid-2" style="margin-top:14px">
      <section class="card section-card">
        <div class="section-head"><div><div class="section-title">${icon('terminal', 16)} Recent logs</div></div></div>
        <details class="log-details" style="margin-top:10px">
          <summary>Ollama · ${state.runtimes.ollama.running ? 'running' : 'stopped'}</summary>
          <pre class="pre">${esc(state.runtimes.ollama.tail || 'No Ollama log yet.')}</pre>
        </details>
        <details class="log-details" style="margin-top:8px">
          <summary>ComfyUI · ${state.runtimes.comfyui.running ? 'running' : 'stopped'}</summary>
          <pre class="pre">${esc(state.runtimes.comfyui.tail || 'No ComfyUI log yet.')}</pre>
        </details>
      </section>
      <section class="card section-card">
        <div class="section-head"><div><div class="section-title">${icon('shield', 16)} Local only</div></div></div>
        <div class="stack" style="margin-top:10px">
          <div class="hw-note">${icon('check', 13)}<span>Hearth binds to ${esc(state.config.server.host)}:${state.config.server.port} by default.</span></div>
          <div class="hw-note">${icon('check', 13)}<span>No account, telemetry or cloud API is used by core features.</span></div>
          <div class="hw-note">${icon('info', 13)}<span>Web search and page reading are the only optional network features.</span></div>
          <div class="hw-note">${icon('folder', 13)}<span>Models live in <span class="code">${esc(state.app.data_dir)}</span>.</span></div>
        </div>
      </section>
    </div>`;
}

function policyCard(mode, iconName, title, description, activeMode) {
  return `<button class="policy-card ${activeMode === mode ? 'active' : ''}" data-action="set-load-mode" data-mode="${mode}">
    <div class="policy-icon">${icon(iconName, 17)}</div>
    <div class="policy-name">${esc(title)}</div>
    <div class="policy-desc">${esc(description)}</div>
  </button>`;
}

function runtimeRow(name, iconName, runtime, kind) {
  const installed = Boolean(runtime.installed);
  const running = Boolean(runtime.running);
  const tone = !installed ? 'muted' : running ? 'good' : 'warn';
  let actions = '';
  if (kind === 'lmstudio') {
    actions = running
      ? `<button class="btn sm subtle" data-action="use-lmstudio">${icon('plug', 12)} Use</button>`
      : `<span class="tiny muted">optional</span>`;
  } else if (kind === 'audio') {
    actions = `<button class="btn sm subtle" data-action="install-runtime" data-runtime="audio">${icon('download', 12)} Install</button>`;
  } else if (!installed) {
    actions = `<button class="btn sm primary" data-action="install-runtime" data-runtime="${kind}">${icon('download', 12)} Install</button>`;
  } else if (running) {
    actions = `<button class="btn sm ghost" data-action="runtime-logs" data-runtime="${kind}">${icon('terminal', 12)}</button><button class="btn sm subtle" data-action="stop-runtime" data-runtime="${kind}">${icon('stop', 11)} Stop</button>`;
  } else {
    actions = `<button class="btn sm ghost" data-action="runtime-logs" data-runtime="${kind}">${icon('terminal', 12)}</button><button class="btn sm subtle" data-action="start-runtime" data-runtime="${kind}">${icon('play', 11)} Start</button>`;
  }
  return `<div class="runtime-row">
    <div class="runtime-name">${icon(iconName, 15)} ${esc(name)} ${dot(tone)}</div>
    <div class="runtime-detail">${esc(!installed ? 'Not installed' : running ? `Running${runtime.version ? ` · ${runtime.version}` : ''}` : 'Installed, stopped')}</div>
    <div class="service-actions">${actions}</div>
  </div>`;
}

/* ------------------------------------------------------------------ */
/* Memory page                                                        */
/* ------------------------------------------------------------------ */
let memoryItems = null;
let memoryFeatureEnabled = true;

async function refreshMemories() {
  try {
    const payload = await api.memories();
    memoryItems = payload.items || [];
    memoryFeatureEnabled = payload.enabled !== false;
  } catch (error) {
    memoryItems = [];
    toast(error.message || 'Could not load memories.', 'error');
  }
  render();
}

function renderMemoryRow(item) {
  return `
    <div class="memory-row ${item.enabled ? '' : 'off'}">
      <label class="switch" title="${item.enabled ? 'Used in replies' : 'Ignored'}">
        <input type="checkbox" data-memory-toggle="${escAttr(item.id)}" ${item.enabled ? 'checked' : ''} />
        <span></span>
      </label>
      <div class="memory-text">
        <div>${esc(item.text)}</div>
        <div class="tiny muted">${item.source === 'model' ? 'Saved by the assistant' : 'Added by you'} · ${timeAgo(item.created_at)}</div>
      </div>
      <button class="btn icon ghost sm" data-action="delete-memory" data-id="${escAttr(item.id)}" title="Delete">${icon('trash', 13)}</button>
    </div>`;
}

function renderMemoryPage() {
  if (memoryItems === null) {
    refreshMemories();
    return `<div class="page-head"><div><h2>Memory</h2><p>Loading…</p></div></div>`;
  }
  const items = memoryItems;
  const enabledCount = items.filter((item) => item.enabled).length;
  return `
    <div class="page-head">
      <div>
        <h2>Memory</h2>
        <p>${items.length ? `${enabledCount} of ${items.length} memories are in use` : 'Nothing saved yet'}. The assistant writes here when it learns something durable about you.</p>
      </div>
      <div class="page-head-actions">
        ${
          items.length
            ? `<button class="btn sm ghost" data-action="clear-memories">${icon('trash', 13)} Forget all</button>`
            : ''
        }
      </div>
    </div>
    <section class="card section-card">
      <div class="switch-list">
        ${switchRow(
          'memory.enabled',
          'Let the assistant use memory',
          'When off, nothing is injected into the prompt and the remember tool is unavailable. Saved memories are kept.',
          memoryFeatureEnabled,
        )}
      </div>
    </section>
    <section class="card section-card" style="margin-top:14px">
      <div class="section-head"><div><div class="section-title">${icon('plus', 16)} Add a memory</div></div></div>
      <div class="row" style="gap:8px;margin-top:10px;align-items:flex-start">
        <textarea class="input textarea" id="memory-input" rows="2" placeholder="My name is Sam and I prefer short answers."></textarea>
        <button class="btn primary" data-action="add-memory">${icon('check', 14)} Save</button>
      </div>
      <div class="hint">Everything here can be switched off or deleted at any time.</div>
    </section>
    <section class="card section-card" style="margin-top:14px">
      <div class="section-head"><div><div class="section-title">${icon('memory', 16)} Saved memories</div></div></div>
      ${
        items.length
          ? `<div class="memory-list" style="margin-top:10px">${items.map(renderMemoryRow).join('')}</div>`
          : `<div class="muted-box" style="margin-top:10px">No memories yet. Ask the assistant to remember something, or add one above.</div>`
      }
    </section>`;
}

/* ------------------------------------------------------------------ */
/* Activity page                                                      */
/* ------------------------------------------------------------------ */
function renderActivityPage() {
  return `
    <div class="activity-grid">
      <section class="card section-card">
        <div class="section-head">
          <div>
            <div class="section-title">${icon('activity', 17)} Jobs</div>
            <div class="section-sub">Downloads, runtime installs and generation jobs.</div>
          </div>
          <button class="btn sm ghost" data-action="refresh-state">${icon('refresh', 13)} Refresh</button>
        </div>
        <div data-jobs-container data-jobs-detailed="true" style="margin-top:12px">${renderJobsInner(
          state.jobs || [],
          true,
        )}</div>
      </section>
      <div class="stack">
        <section class="card source-card">
          <div class="section-head"><div><div class="section-title">${icon('globe', 16)} Download sources</div></div></div>
          <div class="source-list" style="margin-top:8px">
            ${renderSourceRow('Hugging Face', state.sources.hf, 'library')}
            ${renderSourceRow('PyPI', state.sources.pypi, 'code')}
          </div>
          <p class="hint" style="margin-top:8px">Measured once, then cached for six hours. Downloads resume from partial files.</p>
        </section>
        <section class="card source-card">
          <div class="section-head"><div><div class="section-title">${icon('info', 16)} About</div></div></div>
          <div class="kv-grid" style="grid-template-columns:1fr">
            <div class="kv"><div class="kv-label">Version</div><div class="kv-value">${esc(state.app.version)}</div></div>
            <div class="kv"><div class="kv-label">Chats saved</div><div class="kv-value">${state.chat_count}</div></div>
            <div class="kv"><div class="kv-label">Data directory</div><div class="kv-value" title="${escAttr(state.app.data_dir)}">${esc(state.app.data_dir)}</div></div>
            <div class="kv"><div class="kv-label">Config</div><div class="kv-value" title="${escAttr(state.app.config_dir)}">${esc(state.app.config_dir)}</div></div>
            ${state.app.last_error ? `<div class="kv"><div class="kv-label">Last error</div><div class="kv-value" style="color:var(--red)">${esc(truncate(state.app.last_error, 80))}</div></div>` : ''}
          </div>
        </section>
      </div>
    </div>`;
}

function renderSourceRow(title, source, iconName) {
  const value = source?.value || 'Auto (probe on first download)';
  const speed = source?.meta?.speed_bps ? ` · ${fmtSpeed(source.meta.speed_bps)}` : '';
  return `<div class="source-row">
    <div class="source-icon">${icon(iconName, 15)}</div>
    <div class="source-copy">
      <div class="source-title">${esc(title)} ${source?.value ? badge('selected', 'good') : ''}</div>
      <div class="source-url" title="${escAttr(value)}">${esc(value)}${esc(speed)}</div>
    </div>
  </div>`;
}

/* ------------------------------------------------------------------ */
/* Onboarding                                                         */
/* ------------------------------------------------------------------ */
function showOnboarding() {
  if (!state) return;
  onboardingOpen = true;
  onboardTier = state.presets?.recommended || 'balanced';
  onboardMods = { text: true, image: true, video: true, audio: true, music: true, three_d: true };
  renderOnboarding();
}

function closeOnboarding(renderAfter = true) {
  onboardingOpen = false;
  const root = document.getElementById('onboarding-root');
  if (root) root.innerHTML = '';
  if (renderAfter) render();
}

function renderOnboarding() {
  const root = document.getElementById('onboarding-root');
  if (!root) return;
  const preset = presetById(onboardTier) || state.presets.presets[0];
  const hw = state.hardware;
  const total = estimatePresetSize(preset, onboardMods);
  root.innerHTML = `
    <div class="onboarding">
      <div class="onboarding-wrap">
        <div class="onboarding-top">
          <div class="onboarding-brand"><img src="/assets/logo.svg" alt="" /><span>Hearth</span></div>
          <button class="onboarding-close" data-action="onboarding-skip" aria-label="Skip setup">${icon('x', 17)}</button>
        </div>
        <div class="onboarding-hero">
          <div class="eyebrow">${dot('accent')} First run · hardware detected</div>
          <h1>Build a local AI stack <em>this machine can love.</em></h1>
          <p>Hearth looked at your VRAM, RAM and disk, then sized three tiers. Pick one, choose the modalities you want, and it will download everything from the fastest reachable mirror.</p>
          <div class="onboarding-hw">
            <span class="chip">${icon('gpu', 13)} ${esc(hw.gpus?.[0]?.name || 'CPU only')} ${hw.total_vram_gb ? `· ${fmtGb(hw.total_vram_gb)}` : ''}</span>
            <span class="chip">${icon('memory', 13)} ${fmtGb(hw.ram_gb)} RAM</span>
            <span class="chip">${icon('disk', 13)} ${fmtGb(hw.disk_free_gb)} free</span>
            ${hw.gpu_usable ? `<span class="chip">${icon('check', 13)} GPU ready</span>` : `<span class="chip">${icon('alert', 13)} CPU fallback</span>`}
          </div>
        </div>
        <div class="onboarding-grid">
          ${state.presets.presets
            .map(
              (item) => `<button class="onboarding-preset ${item.tier === onboardTier ? 'selected' : ''}" data-onboard-tier="${item.tier}">
                <div class="op-head">
                  <div class="op-icon">${icon(presetIcon(item.tier), 17)}</div>
                  <div style="flex:1;min-width:0">
                    <div class="op-name">${esc(item.name)} ${item.recommended ? `<span class="badge badge-accent">Suggested</span>` : ''}</div>
                    <div class="op-tag">${esc(item.tagline)}</div>
                  </div>
                </div>
                <div class="op-model">${esc(item.models.text?.name || '')} · ${esc(item.models.image?.name || '')}<br/>${esc(item.models.video?.name || '')} · ${esc(item.models.three_d?.name || '')}</div>
                <div class="op-stats">
                  <span class="preset-stat">${icon('download', 11)} ${fmtGb(item.download_gb)}</span>
                  <span class="preset-stat">${icon('gpu', 11)} ${fmtGb(item.peak_vram_gb, 0)} VRAM</span>
                  <span class="preset-stat">${icon('memory', 11)} ${fmtGb(item.peak_ram_gb, 0)} RAM</span>
                </div>
              </button>`,
            )
            .join('')}
        </div>
        <div class="divider-label" style="margin-top:22px">What should Hearth install?</div>
        <div class="onboarding-mods">
          ${MODALITIES.map((modality) => {
            const on = Boolean(onboardMods[modality.key]);
            return `<label class="onboarding-mod ${on ? 'on' : ''}">
              <input type="checkbox" data-onboard-mod="${modality.key}" ${on ? 'checked' : ''} />
              ${icon(modality.icon, 15)} <span>${modality.label}</span>
            </label>`;
          }).join('')}
        </div>
        <div class="onboarding-foot">
          <div>
            <div class="onboarding-total">Estimated download: <strong>${fmtGb(total)}</strong> · ${esc(preset.peak_vram_gb ? `${fmtGb(preset.peak_vram_gb, 0)} peak VRAM` : 'CPU')}</div>
            <div class="onboarding-note">Runtime downloads are included. Existing files are skipped and resumes are kept.</div>
          </div>
          <div class="onboarding-actions">
            <button class="btn ghost" data-action="onboarding-demo">${icon('zap', 15)} Explore with demo</button>
            <button class="btn subtle" data-action="onboarding-apply-only">${icon('check', 15)} Apply without downloading</button>
            <button class="btn primary" data-action="onboarding-install">${icon('download', 15)} Install ${esc(preset.name)}</button>
          </div>
        </div>
        ${!hw.gpu_usable ? `<div class="callout warn" style="margin-top:16px"><span class="callout-icon">${icon('alert', 16)}</span><span>${esc(hw.notes?.[0] || 'The GPU driver is not responding; Hearth will use the CPU until it is usable.')}</span></div>` : ''}
      </div>
    </div>`;
}

function estimatePresetSize(preset, mods) {
  const sizes = {
    text: preset.models.text?.size_gb || 0,
    image: preset.models.image?.size_gb || 0,
    video: preset.models.video?.size_gb || 0,
    three_d: preset.models.three_d?.size_gb || 0,
    music: preset.models.music?.size_gb || 0,
    audio: 0.6,
  };
  const anyMedia = ['image', 'video', 'three_d', 'music'].some((key) => mods[key]);
  const runtime = mods.text || anyMedia ? 9.5 : 0;
  return runtime + Object.entries(sizes).reduce((sum, [key, value]) => sum + (mods[key] ? value : 0), 0);
}

/* ------------------------------------------------------------------ */
/* Preset apply                                                       */
/* ------------------------------------------------------------------ */
function showApplyPresetModal(tier) {
  const preset = presetById(tier);
  if (!preset) return;
  const mods = { text: true, image: true, video: true, audio: true, music: true, three_d: true };
  const body = `
    <p class="modal-copy">Hearth will apply the <strong>${esc(preset.name)}</strong> models and queue the missing downloads. Uncheck anything you do not want on this machine.</p>
    <div class="onboarding-mods" style="margin-top:16px">
      ${MODALITIES.map(
        (modality) => `<label class="onboarding-mod on">
          <input type="checkbox" data-apply-mod="${modality.key}" checked />
          ${icon(modality.icon, 15)} <span>${modality.label}</span>
        </label>`,
      ).join('')}
    </div>
    <div class="muted-box" style="margin-top:14px">
      <div class="row-between"><span>Estimated download</span><strong id="apply-total">${fmtGb(estimatePresetSize(preset, mods))}</strong></div>
      <div class="row-between" style="margin-top:4px"><span>Peak VRAM / RAM</span><span>${fmtGb(preset.peak_vram_gb, 0)} / ${fmtGb(preset.peak_ram_gb, 0)}</span></div>
    </div>
    <div class="callout" style="margin-top:14px"><span class="callout-icon">${icon('info', 15)}</span><span>Downloads run in the background and can be cancelled from Activity. Install sources are probed automatically.</span></div>`;
  const dialog = modal({
    title: `Install the ${preset.name} preset`,
    subtitle: 'Choose modalities, then install.',
    wide: true,
    body,
    actions: [
      {
        label: 'Apply settings only',
        kind: 'ghost',
        icon: 'check',
        action: async () => {
          await applyPreset(tier, mods, false);
        },
      },
      {
        label: 'Install & apply',
        kind: 'primary',
        icon: 'download',
        busyLabel: 'Queuing…',
        action: async () => {
          await applyPreset(tier, mods, true);
        },
      },
    ],
  });
  const update = () => {
    dialog.el.querySelectorAll('[data-apply-mod]').forEach((input) => {
      mods[input.dataset.applyMod] = input.checked;
      input.closest('.onboarding-mod').classList.toggle('on', input.checked);
    });
    const total = dialog.el.querySelector('#apply-total');
    if (total) total.textContent = fmtGb(estimatePresetSize(preset, mods));
  };
  dialog.el.querySelectorAll('[data-apply-mod]').forEach((input) => input.addEventListener('change', update));
}

async function applyPreset(tier, modalities, download) {
  try {
    const result = await api.applyPreset(tier, modalities, download);
    dirty = false;
    await api.refresh();
    state = api.state;
    draft = deepClone(state.config);
    if (download && result.job) {
      toast(`Queued ${result.preset.name}: downloads are running in Activity.`, 'success', 6000);
      navigate('activity');
    } else {
      toast(`${result.preset.name} settings applied.`, 'success');
      render();
    }
  } catch (error) {
    toast(error.message, 'error', 7000);
  }
}

/* ------------------------------------------------------------------ */
/* Actions                                                            */
/* ------------------------------------------------------------------ */
async function handleAction(action, element) {
  try {
    if (action === 'toggle-theme') {
      await toggleTheme();
      return;
    }
    if (action === 'save-settings') {
      await saveDraft(element);
      return;
    }
    if (action === 'discard-settings') {
      draft = deepClone(state.config);
      dirty = false;
      updateSavebar();
      render();
      toast('Changes discarded', 'info', 2400);
      return;
    }
    if (action === 'start-server') {
      await startServer(element);
      return;
    }
    if (action === 'stop-server') {
      await stopServer(element);
      return;
    }
    if (action === 'open-chat') {
      await openChat(element);
      return;
    }
    if (action === 'refresh-state') {
      await api.refresh();
      state = api.state;
      if (!dirty) draft = deepClone(state.config);
      render({ preserveScroll: true });
      toast('Refreshed', 'success', 1800);
      return;
    }
    if (action === 'refresh-hardware') {
      await refreshHardware(element);
      return;
    }
    if (action === 'show-onboarding') {
      showOnboarding();
      return;
    }
    if (action === 'apply-preset') {
      showApplyPresetModal(element.dataset.tier);
      return;
    }
    if (action === 'apply-preset-only') {
      const preset = presetById(element.dataset.tier);
      if (!preset) return;
      await applyPreset(preset.tier, { text: true, image: true, video: true, audio: true, music: true, three_d: true }, false);
      return;
    }
    if (action === 'set-load-mode') {
      if (!draft) draft = deepClone(state.config);
      draft.load.mode = element.dataset.mode;
      dirty = true;
      updateSavebar();
      render({ preserveScroll: true });
      return;
    }
    if (action === 'save-preset-draft') {
      const payload = {};
      document.querySelectorAll('[data-preset-field]').forEach((input) => {
        payload[input.dataset.presetField] = input.value;
      });
      if (!String(payload.name || '').trim()) {
        toast('Give the preset a name first.', 'warn');
        return;
      }
      try {
        await api.saveCustomPreset(payload);
        await api.refresh();
        state = api.state;
        draft = deepClone(state.config);
        render();
        toast(`Saved “${payload.name}”.`, 'success');
      } catch (err) {
        toast(err.message || 'Could not save that preset.', 'error');
      }
      return;
    }
    if (action === 'delete-preset') {
      const tier = element.dataset.tier;
      try {
        await api.deleteCustomPreset(tier);
        await api.refresh();
        state = api.state;
        draft = deepClone(state.config);
        render();
        toast('Preset deleted.', 'success');
      } catch (err) {
        toast(err.message || 'Could not delete that preset.', 'error');
      }
      return;
    }
    if (action === 'custom-preset') {
      await api.applyCustomPreset();
      await api.refresh();
      state = api.state;
      draft = deepClone(state.config);
      dirty = false;
      updateSavebar();
      render();
      toast('Current settings saved as a custom preset.', 'success');
      return;
    }
    if (action === 'disconnect-remote') {
      api.disconnectRemote();
      await api.refresh();
      state = api.state;
      draft = deepClone(state.config);
      render();
      toast('Disconnected. This browser is back on the local Hearth.', 'success');
      return;
    }
    if (action === 'set-panel-code') {
      const input = document.getElementById('panel-code-input');
      const code = (input?.value || '').trim();
      if (code.length < 4) {
        toast('Use at least 4 characters for the panel code.', 'warn');
        return;
      }
      try {
        await api.setPanelCode(code);
        await refreshServerUsers();
        toast('Panel code set. Devices can now log in with it.', 'success', 6000);
      } catch (error) {
        toast(error.message || 'Could not set the code.', 'error');
      }
      return;
    }
    if (action === 'clear-panel-code') {
      try {
        await api.setPanelCode('');
        await refreshServerUsers();
        toast('Panel code removed; remote settings are closed again.', 'success');
      } catch (error) {
        toast(error.message || 'Could not remove the code.', 'error');
      }
      return;
    }
    if (action === 'add-user') {
      const name = document.getElementById('new-user-name')?.value?.trim() || '';
      const insecure = Boolean(document.getElementById('new-user-insecure')?.checked);
      if (!name) {
        toast('Give the account a name first.', 'warn');
        return;
      }
      try {
        const created = await api.addUser(insecure ? { name, secret: '' } : { name });
        await refreshServerUsers();
        toast(
          created.user.has_secret
            ? `Added ${created.user.name}. Copy its secret and paste it into the connect page.`
            : `Added ${created.user.name} without a secret — that account is open to anyone who can reach this port.`,
          created.user.has_secret ? 'success' : 'warn',
          7000,
        );
      } catch (error) {
        toast(error.message || 'Could not add that account.', 'error');
      }
      return;
    }
    if (action === 'rotate-secret') {
      try {
        const rotated = await api.rotateUserSecret(element.dataset.id);
        await refreshServerUsers();
        toast(`New secret for ${rotated.user.name}. Devices using the old one must reconnect.`, 'success', 6000);
      } catch (error) {
        toast(error.message || 'Could not rotate the secret.', 'error');
      }
      return;
    }
    if (action === 'toggle-user') {
      try {
        await api.updateUser(element.dataset.id, { enabled: element.dataset.enabled === '1' });
        await refreshServerUsers();
      } catch (error) {
        toast(error.message || 'Could not update that account.', 'error');
      }
      return;
    }
    if (action === 'delete-user') {
      const confirmed = await confirmDialog({
        title: 'Delete this account?',
        message: 'The device using it will be disconnected and cannot reconnect until you add it again.',
        confirmLabel: 'Delete',
        danger: true,
      });
      if (!confirmed) return;
      try {
        await api.deleteUser(element.dataset.id);
        await refreshServerUsers();
        toast('Account deleted.', 'success');
      } catch (error) {
        toast(error.message || 'Could not delete that account.', 'error');
      }
      return;
    }
    if (action === 'add-memory') {
      const input = document.getElementById('memory-input');
      const text = (input?.value || '').trim();
      if (!text) {
        toast('Write the memory first.', 'warn');
        return;
      }
      try {
        await api.addMemory(text);
        await refreshMemories();
        toast('Memory saved.', 'success');
      } catch (error) {
        toast(error.message || 'Could not save that memory.', 'error');
      }
      return;
    }
    if (action === 'delete-memory') {
      try {
        await api.deleteMemory(element.dataset.id);
        await refreshMemories();
      } catch (error) {
        toast(error.message || 'Could not delete that memory.', 'error');
      }
      return;
    }
    if (action === 'clear-memories') {
      const confirmed = await confirmDialog({
        title: 'Forget everything?',
        message: 'Every saved memory will be deleted. This cannot be undone.',
        confirmLabel: 'Forget all',
        danger: true,
      });
      if (!confirmed) return;
      try {
        await api.clearMemories();
        await refreshMemories();
        toast('Memories cleared.', 'success');
      } catch (error) {
        toast(error.message || 'Could not clear memories.', 'error');
      }
      return;
    }
    if (action === 'hf-search') {
      showHfSearchModal();
      return;
    }
    if (action === 'import-model') {
      const value = (name) => {
        const input = document.querySelector(`[data-import-field="${name}"]`);
        return input ? String(input.value || '').trim() : '';
      };
      const [modality, workflow] = value('family').split(':');
      const source = value('source');
      const files = [];
      if (value('dest')) {
        files.push(
          source === 'local'
            ? { source: 'local', dest: value('dest'), role: value('role') }
            : {
                source: 'hf',
                repo: value('repo'),
                filename: value('filename'),
                dest: value('dest'),
                role: value('role'),
                size_gb: Number(value('size_gb')) || 0,
              },
        );
      }
      for (const line of value('extra').split('\n')) {
        const [role, repo, filename, dest, size] = line.split('|').map((part) => part.trim());
        if (!role || !repo || !filename || !dest) continue;
        files.push({ source: 'hf', role, repo, filename, dest, size_gb: Number(size) || 0 });
      }
      try {
        await api.importCustomModel({ name: value('name'), modality, workflow, files });
        await api.refresh();
        state = api.state;
        draft = deepClone(state.config);
        render();
        toast('Model imported. Fetch its files, then pick it in the settings above.', 'success');
      } catch (err) {
        toast(err.message || 'Could not import that model.', 'error');
      }
      return;
    }
    if (action === 'remove-import') {
      try {
        await api.deleteCustomModel(element.dataset.model);
        await api.refresh();
        state = api.state;
        draft = deepClone(state.config);
        render();
        toast('Imported model removed. Its files stay on disk.', 'success');
      } catch (err) {
        toast(err.message || 'Could not remove that model.', 'error');
      }
      return;
    }
    if (action === 'goto-models') {
      pendingScroll = `models-${element.dataset.section || 'text'}`;
      if (route === 'models') {
        scrollToPending();
      } else {
        window.location.hash = '#models';
      }
      return;
    }
    if (action === 'install-runtime') {
      await installRuntime(element.dataset.runtime, element);
      return;
    }
    if (action === 'start-runtime') {
      await startRuntime(element.dataset.runtime, element);
      return;
    }
    if (action === 'stop-runtime') {
      await stopRuntime(element.dataset.runtime, element);
      return;
    }
    if (action === 'runtime-logs') {
      await openRuntimeLogs(element.dataset.runtime);
      return;
    }
    if (action === 'install-model') {
      await installModel(element.dataset.model, element);
      return;
    }
    if (action === 'install-voice') {
      await installVoice(element.dataset.voice, element);
      return;
    }
    if (action === 'install-stt') {
      await installSTT(element.dataset.stt, element);
      return;
    }
    if (action === 'job-logs') {
      await openJobLogs(element.dataset.job);
      return;
    }
    if (action === 'cancel-job') {
      await cancelJob(element.dataset.job, element);
      return;
    }
    if (action === 'copy-url') {
      await copyText(element.dataset.copy || '');
      return;
    }
    if (action === 'use-lmstudio') {
      await useLMStudio();
      return;
    }
    if (action === 'onboarding-install') {
      await onboardingInstall(element);
      return;
    }
    if (action === 'onboarding-apply-only') {
      await api.applyPreset(onboardTier, onboardMods, false);
      await api.refresh();
      state = api.state;
      draft = deepClone(state.config);
      dirty = false;
      closeOnboarding();
      toast('Preset settings applied. Fine-tune anything in Models.', 'success');
      return;
    }
    if (action === 'onboarding-demo') {
      await api.saveConfig({ text: { backend: 'demo' }, setup_complete: true });
      await api.refresh();
      state = api.state;
      draft = deepClone(state.config);
      dirty = false;
      closeOnboarding();
      toast('Demo mode enabled. You can explore the interface now.', 'success');
      return;
    }
    if (action === 'onboarding-skip') {
      await api.saveConfig({ setup_complete: true });
      await api.refresh();
      state = api.state;
      draft = deepClone(state.config);
      dirty = false;
      closeOnboarding();
      toast('Setup skipped. Install a model whenever you are ready.', 'info');
      return;
    }
    if (action === 'toggle-modality') {
      await toggleModality(element.dataset.modality, element);
      return;
    }
  } catch (error) {
    toast(error.message || String(error), 'error', 7000);
  }
}

async function saveDraft(button) {
  if (!draft) return;
  setButtonBusy(button, true, 'Saving…');
  try {
    const result = await api.saveConfig(draft);
    dirty = false;
    await api.refresh();
    state = api.state;
    draft = deepClone(state.config);
    updateSavebar();
    render();
    toast(result.restart_required ? 'Saved. Restart the Hearth process to apply the new host/port.' : 'Settings saved.', 'success');
  } finally {
    setButtonBusy(button, false);
  }
}

async function startServer(button) {
  setButtonBusy(button, true, 'Starting…');
  try {
    const result = await api.startServer();
    await api.refresh();
    state = api.state;
    if (!dirty) draft = deepClone(state.config);
    render();
    const warnings = result.warnings || [];
    toast(warnings.length ? warnings[0] : 'Server running. Opening chat…', warnings.length ? 'warn' : 'success', 6000);
    openChatWindow();
  } catch (error) {
    toast(error.message, 'error', 8000);
    if (String(error.message).toLowerCase().includes('install')) {
      navigate('presets');
    }
  } finally {
    setButtonBusy(button, false);
  }
}

async function stopServer(button) {
  if (!(await confirmDialog({ title: 'Stop the local server?', message: 'Active generations will be stopped and models unloaded. The launcher stays open.', confirmLabel: 'Stop server', danger: true }))) return;
  setButtonBusy(button, true, 'Stopping…');
  try {
    await api.stopServer();
    await api.refresh();
    state = api.state;
    if (!dirty) draft = deepClone(state.config);
    render();
    toast('Server stopped. Models are unloaded.', 'info');
  } catch (error) {
    toast(error.message, 'error', 7000);
  } finally {
    setButtonBusy(button, false);
  }
}

async function openChat(button) {
  if (!state.app.running) {
    await startServer(button);
    return;
  }
  openChatWindow();
}

function openChatWindow() {
  const windowRef = window.open('/chat', '_blank', 'noopener');
  if (!windowRef) window.location.assign('/chat');
}

async function refreshHardware(button) {
  setButtonBusy(button, true, 'Scanning…');
  try {
    const result = await api.refreshHardware();
    state.hardware = result.hardware;
    state.presets = result.presets;
    render({ preserveScroll: true });
    toast('Hardware scan complete', 'success');
  } finally {
    setButtonBusy(button, false);
  }
}

async function toggleModality(modality, input) {
  const enabled = Boolean(input.checked);
  const patch = { [modality]: { enabled } };
  try {
    await api.saveConfig(patch);
    await api.refresh();
    state = api.state;
    if (!dirty) draft = deepClone(state.config);
    render({ preserveScroll: true });
    toast(`${modality === 'three_d' ? '3D' : modality} ${enabled ? 'enabled' : 'disabled'}`, 'info', 2000);
  } catch (error) {
    input.checked = !enabled;
    toast(error.message, 'error', 6000);
  }
}

async function installRuntime(name, button) {
  setButtonBusy(button, true, 'Queuing…');
  try {
    const result = await api.installRuntime(name);
    toast(`Queued ${name}. Progress is in Activity.`, 'success');
    await api.refresh();
    state = api.state;
    render({ preserveScroll: true });
    navigate('activity');
    return result;
  } finally {
    setButtonBusy(button, false);
  }
}

async function startRuntime(name, button) {
  setButtonBusy(button, true, 'Starting…');
  try {
    await api.startRuntime(name);
    await api.refresh();
    state = api.state;
    render({ preserveScroll: true });
    toast(`${name} started`, 'success');
  } finally {
    setButtonBusy(button, false);
  }
}

async function stopRuntime(name, button) {
  setButtonBusy(button, true, 'Stopping…');
  try {
    await api.stopRuntime(name);
    await api.refresh();
    state = api.state;
    render({ preserveScroll: true });
    toast(`${name} stopped`, 'info');
  } finally {
    setButtonBusy(button, false);
  }
}

async function installModel(modelId, button) {
  if (!modelId) return;
  setButtonBusy(button, true, 'Queuing…');
  try {
    await api.installModel(modelId);
    toast(`Queued ${modelId}. Downloads continue in Activity.`, 'success');
    await api.refresh();
    state = api.state;
    render({ preserveScroll: true });
  } finally {
    setButtonBusy(button, false);
  }
}

async function installVoice(voiceId, button) {
  setButtonBusy(button, true, 'Queuing…');
  try {
    await api.installVoice(voiceId);
    toast('Voice download queued.', 'success');
    await api.refresh();
    state = api.state;
    render({ preserveScroll: true });
  } finally {
    setButtonBusy(button, false);
  }
}

async function installSTT(modelId, button) {
  setButtonBusy(button, true, 'Queuing…');
  try {
    await api.installSTT(modelId);
    toast('Whisper model queued.', 'success');
    await api.refresh();
    state = api.state;
    render({ preserveScroll: true });
  } finally {
    setButtonBusy(button, false);
  }
}

async function cancelJob(jobId, button) {
  setButtonBusy(button, true, 'Canceling…');
  try {
    await api.cancelJob(jobId);
    toast('Job canceled', 'info');
    await api.refresh();
    state = api.state;
    render({ preserveScroll: true });
  } finally {
    setButtonBusy(button, false);
  }
}

async function openRuntimeLogs(name) {
  const dialog = modal({
    title: `${name} log`,
    subtitle: 'The last lines written by the managed process.',
    wide: true,
    body: `<div class="loading-row">${spinner(16)} Loading log…</div>`,
  });
  try {
    const result = await api.runtimeLogs(name);
    dialog.setBody(`<pre class="pre" style="max-height:60vh">${esc(result.log || 'No log lines yet.')}</pre>`);
  } catch (error) {
    dialog.setBody(`<div class="callout danger"><span class="callout-icon">${icon('alert', 15)}</span><span>${esc(error.message)}</span></div>`);
  }
}

async function openJobLogs(jobId) {
  const dialog = modal({
    title: 'Job details',
    wide: true,
    body: `<div class="loading-row">${spinner(16)} Loading job…</div>`,
  });
  try {
    const job = await api.job(jobId);
    const items = (job.items || [])
      .map(
        (item) => `<div class="job-item">${dot(item.status === 'done' ? 'good' : item.status === 'error' ? 'danger' : 'accent')}
          <span class="job-item-label">${esc(item.label)}</span><span class="job-item-state">${esc(item.status)}</span></div>`,
      )
      .join('');
    dialog.setBody(`
      <div class="row-between"><div><strong>${esc(job.title)}</strong><div class="job-meta">${esc(job.status)} · ${timeAgo(job.created_at)}</div></div>${badge(jobStatusLabel(job.status), jobStatusKind(job.status), true)}</div>
      ${job.error ? `<div class="callout danger" style="margin-top:10px"><span class="callout-icon">${icon('alert', 15)}</span><span>${esc(job.error)}</span></div>` : ''}
      ${items ? `<div class="job-items" style="margin-top:12px">${items}</div>` : ''}
      <pre class="pre" style="margin-top:12px;max-height:46vh">${esc((job.logs || []).join('\n') || 'No log lines yet.')}</pre>`);
  } catch (error) {
    dialog.setBody(`<div class="callout danger"><span class="callout-icon">${icon('alert', 15)}</span><span>${esc(error.message)}</span></div>`);
  }
}

async function useLMStudio() {
  const models = state.runtimes.lmstudio.models || [];
  if (!models.length) {
    toast('LM Studio is not running, or it has no models loaded.', 'warn');
    return;
  }
  const model = models[0];
  await api.saveConfig({
    text: {
      backend: 'openai',
      base_url: 'http://127.0.0.1:1234/v1',
      model,
    },
  });
  await api.refresh();
  state = api.state;
  if (!dirty) draft = deepClone(state.config);
  render();
  toast(`Text backend now points at LM Studio (${model}).`, 'success');
}

async function onboardingInstall(button) {
  setButtonBusy(button, true, 'Queuing downloads…');
  try {
    const result = await api.applyPreset(onboardTier, onboardMods, true);
    await api.refresh();
    state = api.state;
    draft = deepClone(state.config);
    dirty = false;
    closeOnboarding(false);
    toast(`${result.preset.name} install queued. Follow it in Activity.`, 'success', 7000);
    navigate('activity');
    render();
  } finally {
    setButtonBusy(button, false);
  }
}

/* ------------------------------------------------------------------ */
/* Draft / savebar                                                    */
/* ------------------------------------------------------------------ */
function installSavebar() {
  if (document.getElementById('hearth-savebar')) return;
  const node = document.createElement('div');
  node.id = 'hearth-savebar';
  node.className = 'savebar';
  node.innerHTML = `<div class="savebar-inner">
    <span class="savebar-copy">Unsaved changes</span>
    <button class="btn sm ghost" data-action="discard-settings">Discard</button>
    <button class="btn sm primary" data-action="save-settings">${icon('check', 14)} Save</button>
  </div>`;
  document.body.appendChild(node);
  savebar = node;
}

function updateSavebar() {
  if (!savebar) return;
  savebar.classList.toggle('visible', Boolean(dirty));
}

function handlePathChange(element) {
  if (!draft) draft = deepClone(state.config);
  const path = element.dataset.path;
  let value;
  if (element.type === 'checkbox') value = element.checked;
  else if (element.type === 'number' || element.type === 'range') value = Number(element.value);
  else value = element.value;
  setPath(draft, path, value);
  document.querySelectorAll(`[data-readout-for="${path}"]`).forEach((node) => {
    node.textContent = formatSliderValue(value, node.dataset.unit || '');
  });
  dirty = true;
  updateSavebar();
  renderTopbar();
  if (element.dataset.rerender === 'true') render({ preserveScroll: true });
}

function scrollToPending() {
  if (!pendingScroll) return;
  const target = document.getElementById(pendingScroll);
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    pendingScroll = null;
  }
}

/* ------------------------------------------------------------------ */
/* Global events                                                      */
/* ------------------------------------------------------------------ */
document.addEventListener('click', (event) => {
  const target = event.target.closest('[data-action]');
  if (!target) return;
  const action = target.dataset.action;
  if (!action) return;
  if (target.dataset.action !== 'goto-models') event.preventDefault();
  handleAction(action, target);
});

document.addEventListener('input', (event) => {
  const target = event.target.closest('[data-path]');
  if (target && !['checkbox', 'radio'].includes(target.type)) handlePathChange(target);
});

document.addEventListener('change', async (event) => {
  const memoryToggle = event.target.closest('[data-memory-toggle]');
  if (memoryToggle) {
    try {
      await api.updateMemory(memoryToggle.dataset.memoryToggle, { enabled: memoryToggle.checked });
      memoryItems = null;
      await refreshMemories();
    } catch (error) {
      toast(error.message || 'Could not update that memory.', 'error');
    }
    return;
  }
  const master = event.target.closest('[data-path="memory.enabled"]');
  if (master) {
    try {
      await api.saveConfig({ memory: { enabled: master.checked } });
      await api.refresh();
      state = api.state;
      draft = deepClone(state.config);
      dirty = false;
      memoryFeatureEnabled = master.checked;
      render();
      updateSavebar();
      toast(master.checked ? 'Memory is on.' : 'Memory is off; nothing will be remembered.', 'success');
    } catch (error) {
      toast(error.message || 'Could not change the memory setting.', 'error');
    }
    return;
  }
  const target = event.target.closest('[data-path]');
  if (target && ['checkbox', 'radio'].includes(target.type)) handlePathChange(target);
  const onboard = event.target.closest('[data-onboard-mod]');
  if (onboard) {
    onboardMods[onboard.dataset.onboardMod] = onboard.checked;
    renderOnboarding();
  }
});

document.addEventListener('click', (event) => {
  const tier = event.target.closest('[data-onboard-tier]');
  if (tier) {
    onboardTier = tier.dataset.onboardTier;
    renderOnboarding();
  }
});

window.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && onboardingOpen) {
    // The close button is the explicit path; Escape is a gentle skip.
    if (event.metaKey || event.ctrlKey) closeOnboarding();
  }
});

boot();
