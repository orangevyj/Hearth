import { api } from './api.js?v=0.1.0';
import { icon } from './icons.js?v=0.1.0';
import {
  esc,
  escAttr,
  fmtGb,
  timeAgo,
  fmtTime,
  truncate,
  toast,
  modal,
  confirmDialog,
  copyText,
  spinner,
  dot,
  setButtonBusy,
  sleep,
} from './ui.js?v=0.1.0';

let state = null;
let chats = [];
let activeChat = null;
let activeChatId = null;
let pendingAttachments = [];
let composerDraft = '';
let webEnabled = false;
let toolMenuOpen = false;
let reasoningEnabled = null;
let streaming = false;
let abortController = null;
let live = null;
let liveScheduled = false;
let streamTicker = null;
let sidebarOpen = false;
let chatQuery = '';
let searchTimer = null;
let statusTimer = null;
let uploading = 0;
let shouldStick = true;
let focusComposerNext = true;

const TOOL_META = {
  web_search: ['Web search', 'globe'],
  fetch_url: ['Read page', 'link'],
  generate_image: ['Image', 'image'],
  generate_video: ['Video', 'video'],
  generate_music: ['Music', 'music'],
  text_to_speech: ['Speech', 'speaker'],
  generate_3d: ['3D model', 'cube'],
};

const SUGGESTIONS = [
  ['Explain something', 'Make a confusing idea feel simple.', 'chat', 'prompt', 'Explain a tricky idea in simple terms.'],
  ['Make an image', 'Describe a scene and generate it locally.', 'image', 'generate', '', 'image'],
  ['Search the web', 'Ask about something current, with citations.', 'globe', 'web', 'What happened in the world today?'],
  ['Create a video', 'Turn a scene description into a short clip.', 'video', 'generate', '', 'video'],
  ['Build a 3D model', 'Generate a preview image, then a GLB mesh.', 'cube', 'generate', '', '3d'],
  ['Compose a track', 'Make music with ACE-Step, vocals optional.', 'music', 'generate', '', 'music'],
];

/* ------------------------------------------------------------------ */
/* Boot                                                               */
/* ------------------------------------------------------------------ */
async function boot() {
  try {
    state = await api.fetchState();
    applyTheme(resolveTheme());
    document.getElementById('chat-boot').hidden = true;
    document.getElementById('chat-shell').hidden = false;
    renderSidebar();
    renderTopbar();
    renderComposer({ focus: true });
    await loadChats();
    const requested = chatIdFromHash();
    if (requested && chats.some((chat) => chat.id === requested)) {
      await loadChat(requested, { initial: true });
    } else if (chats.length) {
      await loadChat(chats[0].id, { initial: true });
    } else {
      showEmpty();
    }
    scheduleStatusPoll();
    bindGlobalEvents();
  } catch (error) {
    const boot = document.getElementById('chat-boot');
    boot.classList.add('error');
    boot.innerHTML = `
      <img src="/assets/logo.svg" alt="" />
      <div class="boot-title">Hearth</div>
      <div class="boot-sub">${esc(error?.message || 'Could not reach the local Hearth server.')}</div>
      <button class="btn primary" style="margin-top:16px" id="chat-boot-retry">${icon('refresh', 15)} Retry</button>`;
    document.getElementById('chat-boot-retry')?.addEventListener('click', () => window.location.reload());
  }
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', theme === 'light' ? '#f4eee4' : '#0c0b09');
}

function resolveTheme() {
  const stored = localStorage.getItem('hearth.theme');
  if (stored === 'dark' || stored === 'light') return stored;
  const configured = state?.config?.ui?.theme;
  if (configured === 'dark' || configured === 'light') return configured;
  return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
}

async function toggleTheme() {
  const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
  localStorage.setItem('hearth.theme', next);
  applyTheme(next);
  renderSidebar();
  renderTopbar();
  try {
    await api.saveConfig({ ui: { theme: next } });
    state.config.ui.theme = next;
  } catch {
    // Local preference still applies.
  }
}

function chatIdFromHash() {
  const raw = (window.location.hash || '').replace(/^#/, '');
  if (raw.startsWith('chat=')) return new URLSearchParams(raw).get('chat');
  return null;
}

function setChatHash(id) {
  if (id) history.replaceState(null, '', `#chat=${id}`);
  else history.replaceState(null, '', '#new');
}

/* ------------------------------------------------------------------ */
/* Status polling                                                     */
/* ------------------------------------------------------------------ */
function chromeSignature() {
  return JSON.stringify({
    running: state.app.running,
    backend: state.config.text.backend,
    model: state.config.text.model,
    models: (state.runtimes.ollama?.models || []).map((item) => item.name).sort(),
    lmstudio: state.runtimes.lmstudio?.running,
  });
}

function scheduleStatusPoll() {
  clearInterval(statusTimer);
  statusTimer = setInterval(async () => {
    if (document.hidden || streaming) return;
    try {
      const before = chromeSignature();
      state = await api.refresh();
      if (before === chromeSignature()) return;
      if (document.activeElement?.id !== 'chat-search') renderSidebar();
      if (document.activeElement?.id !== 'model-select') renderTopbar();
      if (document.activeElement?.id !== 'composer-input') renderComposer();
      if (!activeChat?.messages?.length) showEmpty();
    } catch {
      // Keep the last known state; send actions will surface errors.
    }
  }, 6000);
}

/* ------------------------------------------------------------------ */
/* Chat list / navigation                                             */
/* ------------------------------------------------------------------ */
async function loadChats(query = chatQuery) {
  try {
    const result = await api.chats(query);
    chats = result.chats || [];
    renderSidebar();
  } catch (error) {
    toast(`Could not load chats: ${error.message}`, 'error', 5000);
  }
}

function renderChatGroups() {
  if (!chats.length) {
    return `<div class="empty" style="padding:22px 10px">
      <div class="empty-icon" style="width:38px;height:38px;border-radius:11px">${icon('message', 17)}</div>
      <h3>No chats yet</h3>
      <p>${chatQuery ? 'No conversations match that search.' : 'Start with a question, an image, or a search.'}</p>
    </div>`;
  }
  const groups = new Map();
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  for (const chat of chats) {
    const updated = new Date(chat.updated_at || chat.created_at).getTime();
    let label = 'Older';
    if (updated >= startOfToday) label = 'Today';
    else if (updated >= startOfToday - 86400000) label = 'Yesterday';
    else if (updated >= startOfToday - 7 * 86400000) label = 'Previous 7 days';
    if (!groups.has(label)) groups.set(label, []);
    groups.get(label).push(chat);
  }
  return [...groups.entries()]
    .map(
      ([label, items]) => `<div class="chat-group">
        <div class="chat-group-title">${label}</div>
        ${items.map((chat) => renderChatItem(chat)).join('')}
      </div>`,
    )
    .join('');
}

function renderChatItem(chat) {
  const active = chat.id === activeChatId;
  return `<div class="chat-item ${active ? 'active' : ''}" data-chat-id="${escAttr(chat.id)}" role="button" tabindex="0">
    <div class="chat-item-top">
      <span class="chat-item-title" title="${escAttr(chat.title)}">${esc(chat.title)}</span>
      <span class="chat-item-time">${timeAgo(chat.updated_at)}</span>
    </div>
    <div class="chat-item-preview">${esc(chat.preview || 'No messages yet')}</div>
    <div class="chat-item-actions">
      <button class="btn icon ghost" data-action="rename-chat" data-chat-id="${escAttr(chat.id)}" title="Rename">${icon('edit', 11)}</button>
      <button class="btn icon ghost" data-action="delete-chat" data-chat-id="${escAttr(chat.id)}" title="Delete">${icon('trash', 11)}</button>
    </div>
  </div>`;
}

function renderSidebar() {
  const sidebar = document.getElementById('chat-sidebar');
  if (!sidebar) return;
  const running = state.app.running;
  const theme = document.documentElement.dataset.theme;
  sidebar.innerHTML = `
    <div class="chat-brand">
      <img src="/assets/logo.svg" alt="" />
      <div style="flex:1;min-width:0">
        <div class="chat-brand-name">Hearth</div>
        <div class="chat-brand-sub">local AI workspace</div>
      </div>
      <button class="btn icon ghost" data-action="new-chat" title="New chat">${icon('plus', 16)}</button>
    </div>
    <button class="btn chat-new" data-action="new-chat">${icon('plus', 15)} <span>New chat</span><span class="spacer"></span><kbd>⌘K</kbd></button>
    <div class="chat-search">${icon('search', 14)}<input class="input" id="chat-search" placeholder="Search chats…" value="${escAttr(chatQuery)}" autocomplete="off" /></div>
    <div class="chat-list" id="chat-list">${renderChatGroups()}</div>
    <div class="chat-sidebar-foot">
      <div class="server-mini ${running ? 'on' : ''}">${dot(running ? 'good' : 'muted')} ${running ? 'Engine running' : 'Engine stopped'}</div>
      <div class="chat-model-chip" title="${escAttr(state.config.text.backend === 'demo' ? 'Demo (no model)' : state.config.text.model)}">${icon('bot', 13)}<span>${esc(state.config.text.backend === 'demo' ? 'Demo mode' : state.config.text.model || 'Demo')}</span></div>
      <a class="sidebar-link" href="/">${icon('sliders', 13)} Launcher <span class="spacer"></span><span class="tiny">settings</span></a>
      <div class="chat-side-row">
        ${icon('shield', 12)} Local only
        <button class="sidebar-theme" data-action="toggle-theme" title="Toggle theme">${icon(theme === 'light' ? 'moon' : 'sun', 13)}</button>
      </div>
    </div>`;
}

async function loadChat(id, { initial = false } = {}) {
  if (streaming) {
    toast('Stop the current reply before switching chats.', 'warn');
    return;
  }
  try {
    const chat = await api.getChat(id);
    activeChat = chat;
    activeChatId = chat.id;
    setChatHash(chat.id);
    shouldStick = true;
    renderMessages();
    renderTopbar();
    renderSidebar();
    renderComposer();
    closeSidebar();
    if (!initial) scrollBottom(true);
  } catch (error) {
    toast(error.message, 'error', 6000);
  }
}

function newChat() {
  if (streaming) return;
  activeChat = null;
  activeChatId = null;
  pendingAttachments = [];
  composerDraft = '';
  webEnabled = false;
  toolMenuOpen = false;
  setChatHash(null);
  renderSidebar();
  renderTopbar();
  renderComposer({ focus: true });
  showEmpty();
  closeSidebar();
}

function showEmpty() {
  const empty = document.getElementById('empty-state');
  const messages = document.getElementById('messages');
  if (empty) empty.innerHTML = renderEmptyState();
  if (messages) messages.innerHTML = '';
  document.getElementById('chat-scroll')?.scrollTo({ top: 0 });
}

/* ------------------------------------------------------------------ */
/* Topbar                                                             */
/* ------------------------------------------------------------------ */
function renderTopbar() {
  const topbar = document.getElementById('chat-topbar');
  if (!topbar) return;
  const running = state.app.running;
  const model = state.config.text.model || 'Demo';
  const title = activeChat?.title || 'New chat';
  const count = activeChat?.messages?.length || 0;
  const backend = state.config.text.backend;
  const displayModel = backend === 'demo' ? 'Demo (no model)' : model;
  topbar.innerHTML = `
    <button class="btn icon ghost chat-menu-btn" data-action="toggle-sidebar" title="Conversations">${icon('menu', 18)}</button>
    <div class="chat-title-wrap">
      <button class="chat-title" data-action="rename-chat" title="Rename conversation">${esc(title)} ${activeChat ? icon('edit', 11) : ''}</button>
      <div class="chat-subtitle">${activeChat ? `${count} message${count === 1 ? '' : 's'} · ${esc(displayModel)}` : 'Local only · no cloud'}</div>
    </div>
    <div class="chat-top-actions">
      <div class="model-picker" title="Text model">
        ${icon('bot', 13)}
        <select id="model-select" ${backend === 'demo' ? 'disabled' : ''}>
          ${backend === 'demo' ? '<option>Demo (no model)</option>' : modelOptions(model, backend)}
        </select>
      </div>
      <div class="server-mini ${running ? 'on' : ''}">${dot(running ? 'good' : 'muted')} ${running ? 'Running' : 'Stopped'}</div>
      ${activeChat ? `<button class="btn icon ghost" data-action="export-chat" title="Export chat">${icon('download', 15)}</button>` : ''}
      ${activeChat ? `<button class="btn icon ghost" data-action="delete-chat" data-chat-id="${escAttr(activeChatId)}" title="Delete chat">${icon('trash', 15)}</button>` : ''}
      <button class="btn icon ghost" data-action="new-chat" title="New chat">${icon('plus', 16)}</button>
      <a class="btn icon ghost" href="/" title="Launcher">${icon('sliders', 15)}</a>
    </div>`;
}

function modelOptions(current, backend) {
  const names = new Set();
  if (backend !== 'demo') {
    for (const item of state.runtimes.ollama?.models || []) names.add(item.name);
    if (backend === 'openai') {
      for (const name of state.runtimes.lmstudio?.models || []) names.add(name);
    }
  }
  names.add(current);
  return [...names]
    .filter(Boolean)
    .map((name) => `<option value="${escAttr(name)}" ${name === current ? 'selected' : ''}>${esc(name)}</option>`)
    .join('');
}

async function changeModel(name) {
  if (!name || name === state.config.text.model) return;
  try {
    await api.saveConfig({ text: { model: name } });
    state.config.text.model = name;
    renderTopbar();
    renderSidebar();
    renderComposer();
    toast(`Text model set to ${name}`, 'success', 2600);
  } catch (error) {
    toast(error.message, 'error', 6000);
  }
}

/* ------------------------------------------------------------------ */
/* Empty state / server gate                                          */
/* ------------------------------------------------------------------ */
function renderEmptyState() {
  if (!state.app.running) {
    return `<div class="server-gate">
      <div class="server-gate-icon">${icon('server', 22)}</div>
      <h2>The local engine is stopped</h2>
      <p>Start it to chat, generate media and run tools. Models stay unloaded until they are actually needed.</p>
      <div class="server-gate-actions">
        <button class="btn primary" data-action="start-server">${icon('play', 15)} Start server</button>
        <a class="btn ghost" href="/">${icon('sliders', 14)} Open launcher</a>
      </div>
    </div>`;
  }
  const demo = state.config.text.backend === 'demo';
  const capabilities = [
    ['chat', 'Text'],
    ['image', 'Images'],
    ['video', 'Video'],
    ['speaker', 'Speech'],
    ['music', 'Music'],
    ['cube', '3D'],
    ['globe', 'Web'],
  ].filter(([key]) => {
    if (key === 'chat') return state.config.text.enabled;
    if (key === 'image') return state.config.image.enabled;
    if (key === 'video') return state.config.video.enabled;
    if (key === 'speaker') return state.config.audio.enabled;
    if (key === 'music') return state.config.music.enabled;
    if (key === 'cube') return state.config.three_d.enabled;
    if (key === 'globe') return state.config.search.enabled;
    return true;
  });
  return `<div class="chat-empty">
    <div class="chat-empty-logo"><img src="/assets/logo.svg" alt="" /></div>
    <h1>What should we <em>make?</em></h1>
    <p>Ask anything, search the web, or create an image, a clip, a track or a 3D model. Everything runs on this machine.</p>
    <div class="suggestion-grid">
      ${SUGGESTIONS.map(
        ([title, description, iconName, type, prompt, modality]) => `<button class="suggestion-card" data-suggestion="${type}" data-prompt="${escAttr(
          prompt,
        )}" data-modality="${modality || ''}">
          <span class="suggestion-icon">${icon(iconName, 14)}</span>
          <strong>${esc(title)}</strong>
          <span>${esc(description)}</span>
        </button>`,
      ).join('')}
    </div>
    <div class="capability-chips">
      ${capabilities.map(([key, label]) => `<span class="capability-chip">${icon(key, 11)} ${label}</span>`).join('')}
    </div>
    ${
      demo
        ? `<div class="chat-notice">${icon('info', 15)}<span><strong>Demo mode.</strong> Replies come from Hearth itself, not a model. Install a preset in the launcher for a real local assistant.</span></div>`
        : ''
    }
  </div>`;
}

/* ------------------------------------------------------------------ */
/* Messages                                                           */
/* ------------------------------------------------------------------ */
function renderMessages() {
  const messagesEl = document.getElementById('messages');
  const emptyEl = document.getElementById('empty-state');
  if (!messagesEl || !emptyEl) return;
  if (!activeChat || !activeChat.messages?.length) {
    messagesEl.innerHTML = '';
    emptyEl.innerHTML = renderEmptyState();
    return;
  }
  emptyEl.innerHTML = '';
  const banner = !state.app.running
    ? `<div class="composer-banner warn" style="margin:0 0 18px">${icon('alert', 14)} The local engine is stopped. Start it from the composer or the launcher to continue.</div>`
    : '';
  messagesEl.innerHTML = `${banner}${activeChat.messages.map((message) => renderMessage(message)).join('')}`;
  enhanceMarkdown(messagesEl);
  if (shouldStick) scrollBottom();
}

function renderMessage(message) {
  return message.role === 'user' ? renderUserMessage(message) : renderAssistantMessage(message);
}

function renderUserMessage(message) {
  return `<article class="message user" data-message-id="${escAttr(message.id)}">
    <div class="user-bubble">${esc(message.content || '')}${renderAttachments(message.attachments || [])}</div>
  </article>`;
}

function renderAssistantMessage(message, { live: isLive = false } = {}) {
  const meta = message.meta || {};
  const content = message.content || '';
  const tools = meta.tools || [];
  const sources = meta.sources || [];
  const thinking = meta.thinking || '';
  const attachments = message.attachments || [];
  const usage = meta.usage || {};
  const empty = !content && !attachments.length && !tools.length;
  const streamingNow = isLive || meta.streaming;
  const direct = meta.mode === 'direct';
  const rawModel = meta.model || state.config.text.model;
  const model = state.config.text.backend === 'demo' ? 'Demo' : rawModel;
  const status = meta.status || '';
  const error = meta.error || '';
  const elapsed = meta.startedAt ? `${Math.max(0, Math.floor((Date.now() - meta.startedAt) / 1000))}s` : '';
  const thinkingBlock = thinking
    ? `<details class="thinking-block" ${streamingNow ? 'open' : ''}><summary>Thinking</summary><div class="thinking-content">${esc(thinking)}</div></details>`
    : '';
  const toolsBlock = tools.length ? `<div class="tool-cards">${tools.map((tool) => renderToolCard(tool, isLive)).join('')}</div>` : '';
  const statusBlock = status && streamingNow ? `<div class="status-line">${spinner(11)} ${esc(status)}</div>` : '';
  const contentBlock = content
    ? `<div class="msg-content md ${streamingNow ? 'streaming' : ''}">${renderMarkdown(content)}</div>`
    : streamingNow || direct
      ? `<div class="status-line"><span class="typing-dots"><i></i><i></i><i></i></span> <span>${direct ? 'Generating locally…' : 'Hearth is thinking…'}</span>${elapsed ? `<span class="thinking-elapsed" data-live-elapsed>${elapsed}</span>` : ''}</div>`
      : empty
        ? '<div class="msg-content empty">No text response.</div>'
        : '';
  const errorBlock = error ? `<div class="error-callout">${icon('alert', 14)}<span>${esc(error)}</span></div>` : '';
  const stoppedBlock = meta.stopped ? `<div class="stopped-note">${icon('stop', 12)} Stopped${isLive ? '' : ' before completion'}</div>` : '';
  const attachmentsBlock = attachments.length ? renderAttachments(attachments) : '';
  const sourcesBlock = sources.length ? renderSources(sources) : '';
  return `<article class="message assistant" data-message-id="${escAttr(message.id)}" ${isLive ? 'data-live="true"' : ''}>
    <div class="msg-avatar"><img src="/assets/logo.svg" alt="" /></div>
    <div class="msg-body">
      <div class="msg-head">
        <span class="msg-name">Hearth</span>
        <span class="msg-time">${fmtTime(message.created_at) || 'now'}</span>
        <span class="badge badge-neutral msg-badge">${esc(model)}</span>
      </div>
      <div data-live-slot="thinking">${thinkingBlock}</div>
      <div data-live-slot="tools">${toolsBlock}</div>
      <div data-live-slot="status">${statusBlock}</div>
      <div data-live-slot="content">${contentBlock}</div>
      <div data-live-slot="error">${errorBlock}</div>
      <div data-live-slot="stopped">${stoppedBlock}</div>
      <div data-live-slot="attachments">${attachmentsBlock}</div>
      <div data-live-slot="sources">${sourcesBlock}</div>
      ${!isLive ? `<div class="message-footer">
        <span>${usageLabel(usage)}</span>
        <span class="spacer"></span>
        <div class="message-actions">
          ${content ? `<button class="btn icon ghost" data-action="copy-message" data-message-id="${escAttr(message.id)}" title="Copy">${icon('copy', 13)}</button>` : ''}
          ${content ? `<button class="btn icon ghost" data-action="speak-message" data-message-id="${escAttr(message.id)}" title="Read aloud">${icon('speaker', 13)}</button>` : ''}
          <button class="btn icon ghost" data-action="regenerate" data-message-id="${escAttr(message.id)}" title="Regenerate">${icon('refresh', 13)}</button>
        </div>
      </div>` : ''}
    </div>
  </article>`;
}

function renderToolCard(tool, isLive = false) {
  const [label, iconName] = TOOL_META[tool.name] || [tool.name || 'Tool', 'wand'];
  const running = tool.status === 'running';
  const error = tool.error || '';
  const status = running ? 'working…' : error ? 'error' : 'done';
  const args = tool.arguments && Object.keys(tool.arguments).length ? JSON.stringify(tool.arguments, null, 2) : '';
  const content = tool.content || '';
  const sourceCount = (tool.sources || []).length;
  const attachments = tool.attachments || [];
  return `<details class="tool-card ${running ? 'running' : ''} ${error ? 'error' : ''}" ${running ? 'open' : ''}>
    <summary class="tool-head">
      <span class="tool-icon">${running ? spinner(11) : icon(iconName, 13)}</span>
      <span class="tool-name">${esc(label)}</span>
      <span class="tool-status">${esc(status)}${sourceCount ? ` · ${sourceCount} source${sourceCount === 1 ? '' : 's'}` : ''}</span>
    </summary>
    <div class="tool-body">
      ${args ? `<div class="tool-args">${esc(args)}</div>` : ''}
      ${content ? `<pre class="pre">${esc(truncate(content, 2400))}</pre>` : running ? '<div class="muted">Running locally…</div>' : ''}
      ${attachments.length ? `<div class="tool-files">${attachments
        .map((attachment) => `<a class="tool-file" href="${escAttr(attachment.url || '#')}" target="_blank" rel="noopener">${icon('file', 10)} ${esc(attachment.filename || 'file')}</a>`)
        .join('')}</div>` : ''}
    </div>
  </details>`;
}

function usageLabel(usage) {
  if (!usage || (!usage.total_tokens && !usage.duration_ms)) return '';
  const parts = [];
  if (usage.duration_ms) parts.push(`${(usage.duration_ms / 1000).toFixed(1)}s`);
  if (usage.total_tokens) parts.push(`${usage.total_tokens} tok`);
  if (usage.completion_tokens && usage.prompt_tokens) parts.push(`${usage.prompt_tokens}↑ ${usage.completion_tokens}↓`);
  return parts.join(' · ');
}

function renderSources(sources) {
  if (!sources?.length) return '';
  return `<div class="sources">${sources
    .map(
      (source, index) => `<a class="source-chip" href="${escAttr(source.url || '#')}" target="_blank" rel="noopener noreferrer" title="${escAttr(
        source.title || source.url || '',
      )}">${icon('globe', 11)}<span>[${index + 1}] ${esc(sourceDomain(source.url) || source.title || 'source')}</span></a>`,
    )
    .join('')}</div>`;
}

function sourceDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

function renderAttachments(attachments) {
  if (!attachments?.length) return '';
  const images = attachments.filter((item) => item.kind === 'image');
  const video = attachments.filter((item) => item.kind === 'video');
  const audio = attachments.filter((item) => item.kind === 'audio');
  const models = attachments.filter((item) => item.kind === 'model3d');
  const files = attachments.filter((item) => !['image', 'video', 'audio', 'model3d'].includes(item.kind));
  return `<div class="attachments">
    ${
      images.length
        ? `<div class="attachment-grid">${images
            .map(
              (item) => `<button class="attachment-image" data-lightbox="${escAttr(item.url)}" data-name="${escAttr(
                item.filename,
              )}" title="Open ${escAttr(item.filename)}">
                <img src="${escAttr(item.url)}" alt="${escAttr(item.filename)}" loading="lazy" />
                <span class="attachment-label">${esc(item.filename)}</span>
              </button>`,
            )
            .join('')}</div>`
        : ''
    }
    ${video
      .map(
        (item) => `<div class="attachment-video"><video controls playsinline preload="metadata" src="${escAttr(
          item.url,
        )}"></video></div>`,
      )
      .join('')}
    ${audio
      .map(
        (item) => `<div class="attachment-audio"><div class="row small muted" style="margin-bottom:5px">${icon(
          'speaker',
          12,
        )} ${esc(item.filename)}</div><audio controls preload="metadata" src="${escAttr(item.url)}"></audio></div>`,
      )
      .join('')}
    ${models
      .map(
        (item) => `<div class="attachment-3d">
          <model-viewer src="${escAttr(item.url)}" camera-controls auto-rotate interaction-prompt="none" shadow-intensity="0.7" exposure="1"></model-viewer>
          <div class="attachment-3d-foot">${icon('cube', 12)} ${esc(item.filename)} <span class="spacer"></span><a class="link-btn" href="${escAttr(
            item.url,
          )}" download>${icon('download', 11)} GLB</a></div>
        </div>`,
      )
      .join('')}
    ${files
      .map(
        (item) => `<a class="attachment-file" href="${escAttr(item.url)}" target="_blank" rel="noopener">${icon(
          'file',
          12,
        )} ${esc(item.filename)}</a>`,
      )
      .join('')}
  </div>`;
}

/* ------------------------------------------------------------------ */
/* Markdown                                                           */
/* ------------------------------------------------------------------ */
function renderMarkdown(text) {
  if (!text) return '';
  if (!window.marked) return esc(text).replace(/\n/g, '<br>');
  let raw;
  try {
    raw = window.marked.parse(text, { gfm: true, breaks: true });
  } catch {
    raw = esc(text);
  }
  return window.DOMPurify ? window.DOMPurify.sanitize(raw, { ADD_ATTR: ['target', 'rel'] }) : raw;
}

function enhanceMarkdown(root) {
  if (!root) return;
  root.querySelectorAll('.md a').forEach((link) => {
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
  });
  root.querySelectorAll('.md pre').forEach((pre) => {
    if (pre.querySelector('.code-copy')) return;
    const code = pre.querySelector('code');
    const button = document.createElement('button');
    button.className = 'code-copy';
    button.dataset.copyCode = code ? code.textContent : pre.textContent;
    button.innerHTML = `${icon('copy', 10)} Copy`;
    pre.appendChild(button);
  });
}

/* ------------------------------------------------------------------ */
/* Composer                                                           */
/* ------------------------------------------------------------------ */
function renderComposer({ focus = false } = {}) {
  const area = document.getElementById('composer-area');
  if (!area) return;
  const running = state.app.running;
  const demo = state.config.text.backend === 'demo';
  const model = state.config.text.model || 'Demo';
  const canSend = running && !uploading && Boolean(composerDraft.trim() || pendingAttachments.length);
  const reasoning = reasoningEnabled === null ? Boolean(state.config.text?.thinking) : reasoningEnabled;
  const banner = !running
    ? `<div class="composer-banner warn">${icon('alert', 13)} The local engine is stopped. <button class="link-btn" data-action="start-server">Start server</button></div>`
    : demo
      ? `<div class="composer-banner">${icon('info', 13)} Demo mode — replies are generated by Hearth, not a model. <a class="link-btn" href="/">Install a preset</a></div>`
      : '';
  area.innerHTML = `<div class="composer-inner">
    ${banner}
    <form class="composer ${running ? '' : 'disabled'}" id="composer-form" autocomplete="off">
      ${
        pendingAttachments.length || uploading
          ? `<div class="composer-attachments">${pendingAttachments.map((attachment) => renderAttachmentChip(attachment)).join('')}${
              uploading ? `<div class="attachment-chip">${spinner(12)}<span class="chip-name">Uploading…</span></div>` : ''
            }</div>`
          : ''
      }
      <textarea id="composer-input" rows="1" placeholder="${
        running ? 'Ask anything, or describe what to make…' : 'Start the server to chat…'
      }" ${running ? '' : 'disabled'}>${esc(composerDraft)}</textarea>
      <div class="composer-toolbar">
        <button type="button" class="composer-icon" data-action="attach" title="Attach an image, audio, video or 3D file" ${running && capabilityAllowed('attach') ? '' : 'disabled'}>${icon(
          'paperclip',
          15,
        )}</button>
        <button type="button" class="composer-icon ${webEnabled ? 'active' : ''}" data-action="toggle-web" title="Web search for this message" ${running ? '' : 'disabled'}>${icon(
          'globe',
          15,
        )}</button>
        <button type="button" class="composer-icon ${toolMenuOpen ? 'active' : ''}" data-action="toggle-tools" title="Generate media directly" ${running ? '' : 'disabled'}>${icon(
          'wand',
          15,
        )}</button>
        <button type="button" class="composer-icon ${reasoning ? 'active' : ''}" data-action="toggle-reasoning" title="Reasoning: think before answering" ${running ? '' : 'disabled'}>${icon(
          'sparkles',
          15,
        )}</button>
        <span class="spacer"></span>
        <span class="composer-model" title="${escAttr(demo ? 'Demo (no model)' : model)}">${icon('bot', 11)} ${esc(demo ? 'Demo' : model)}</span>
        ${
          streaming
            ? `<button type="button" class="send-btn stop" data-action="stop-stream" title="Stop generating">${icon('stop', 15)}</button>`
            : `<button type="submit" class="send-btn" id="send-btn" title="Send" ${canSend ? '' : 'disabled'}>${icon('send', 15)}</button>`
        }
      </div>
      ${toolMenuOpen ? renderToolMenu() : ''}
      <input id="chat-file-input" type="file" multiple hidden accept="image/*,audio/*,video/*,.glb,.gltf,.obj,.stl,.txt,.md,.json,.csv" />
    </form>
    <div class="composer-hint">
      <span>Enter to send</span><span class="dot-sep">·</span><span>Shift+Enter for a new line</span>
      ${webEnabled ? `<span class="dot-sep">·</span><span class="accent-text">${icon('globe', 10)} web search on</span>` : ''}
      ${reasoning ? `<span class="dot-sep">·</span><span class="accent-text">${icon('sparkles', 10)} reasoning on</span>` : ''}
      <span class="dot-sep">·</span><span>Everything stays local</span>
    </div>
  </div>`;
  const input = document.getElementById('composer-input');
  if (input) {
    autoGrow(input);
    input.addEventListener('input', () => {
      composerDraft = input.value;
      autoGrow(input);
      updateSendButton();
    });
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        submitMessage();
      }
    });
    if (focus || focusComposerNext) {
      focusComposerNext = false;
      requestAnimationFrame(() => input.focus());
    }
  }
  const form = document.getElementById('composer-form');
  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    submitMessage();
  });
  updateSendButton();
}

function renderAttachmentChip(attachment) {
  const isImage = attachment.kind === 'image';
  const iconName = attachment.kind === 'audio' ? 'speaker' : attachment.kind === 'video' ? 'video' : attachment.kind === 'model3d' ? 'cube' : 'file';
  return `<div class="attachment-chip">
    ${
      isImage
        ? `<img src="${escAttr(attachment.url)}" alt="" />`
        : `<span class="chip-icon">${icon(iconName, 13)}</span>`
    }
    <span class="chip-name" title="${escAttr(attachment.filename)}">${esc(attachment.filename)}</span>
    <button type="button" class="chip-remove" data-action="remove-attachment" data-id="${escAttr(attachment.id)}" title="Remove">${icon('x', 11)}</button>
  </div>`;
}

function capabilityAllowed(key) {
  const caps = state.capabilities;
  if (!caps) return true;
  if (key === 'attach') return Boolean(caps.permissions?.attachments);
  if (key === 'tools') return Boolean(caps.permissions?.tools);
  if (key === 'model') return Boolean(caps.permissions?.change_model);
  return Boolean(caps.permissions?.media?.[key]);
}

function renderToolMenu() {
  const can = {
    image: capabilityAllowed('image'),
    video: capabilityAllowed('video'),
    music: capabilityAllowed('music'),
    '3d': capabilityAllowed('three_d'),
    speech: capabilityAllowed('speech'),
  };
  return `<div class="tool-menu">
    ${can.image ? `<button type="button" data-action="open-generate" data-modality="image">${icon('image', 15)}<span>Image<small>SDXL / FLUX</small></span></button>` : ''}
    ${can.video ? `<button type="button" data-action="open-generate" data-modality="video">${icon('video', 15)}<span>Video<small>Wan 2.1</small></span></button>` : ''}
    ${can.music ? `<button type="button" data-action="open-generate" data-modality="music">${icon('music', 15)}<span>Music<small>ACE-Step</small></span></button>` : ''}
    ${can['3d'] ? `<button type="button" data-action="open-generate" data-modality="3d">${icon('cube', 15)}<span>3D model<small>Hunyuan3D</small></span></button>` : ''}
    ${can.speech ? `<button type="button" data-action="open-generate" data-modality="speech">${icon('speaker', 15)}<span>Speak text<small>Piper / espeak</small></span></button>` : ''}
    ${capabilityAllowed('tools') ? `<button type="button" data-action="toggle-web">${icon('globe', 15)}<span>Web search<small>${webEnabled ? 'on for next message' : 'off'}</small></span></button>` : ''}
    <button type="button" data-action="toggle-reasoning">${icon('sparkles', 15)}<span>Reasoning<small>${
      (reasoningEnabled === null ? Boolean(state.config.text?.thinking) : reasoningEnabled) ? 'on for next message' : 'off'
    }</small></span></button>
  </div>`;
}

function autoGrow(input) {
  if (!input) return;
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 200)}px`;
}

function updateSendButton() {
  const button = document.getElementById('send-btn');
  if (!button) return;
  button.disabled = !(state.app.running && !uploading && (composerDraft.trim() || pendingAttachments.length));
}

/* ------------------------------------------------------------------ */
/* Sending / streaming                                                */
/* ------------------------------------------------------------------ */
async function submitMessage() {
  if (streaming) {
    await stopStream();
    return;
  }
  if (!state.app.running) {
    toast('Start the local server first.', 'warn');
    return;
  }
  if (uploading) {
    toast('Wait for the uploads to finish.', 'warn');
    return;
  }
  const content = composerDraft.trim();
  if (!content && !pendingAttachments.length) return;
  try {
    if (!activeChat) {
      const chat = await api.createChat();
      activeChat = chat;
      activeChatId = chat.id;
      setChatHash(chat.id);
      activeChat.messages = [];
      await loadChats();
    }
    const attachments = pendingAttachments.slice();
    composerDraft = '';
    pendingAttachments = [];
    toolMenuOpen = false;
    const userMessage = {
      id: `local-user-${Date.now()}`,
      role: 'user',
      content,
      attachments,
      created_at: new Date().toISOString(),
      meta: {},
    };
    const assistantMessage = {
      id: 'local-assistant',
      role: 'assistant',
      content: '',
      attachments: [],
      created_at: new Date().toISOString(),
      meta: { model: state.config.text.model, streaming: true, tools: [], sources: [], usage: {} },
    };
    activeChat.messages = [...(activeChat.messages || []), userMessage, assistantMessage];
    shouldStick = true;
    renderComposer();
    renderMessages();
    scrollBottom(true);
    live = {
      content: '',
      thinking: '',
      tools: [],
      attachments: [],
      sources: [],
      usage: {},
      error: '',
      stopped: false,
      status: '',
      model: state.config.text.model,
      serverAssistantId: null,
    };
    const signal = beginStream();
    await consumeStream(
      activeChat.id,
      api.streamChat(
        activeChat.id,
        {
          content,
          attachment_ids: attachments.map((item) => item.id),
          web: webEnabled,
          tools: true,
          reasoning: reasoningEnabled,
        },
        signal,
      ),
    );
  } catch (error) {
    toast(error.message, 'error', 7000);
    streaming = false;
    renderComposer();
  }
}

async function regenerate() {
  if (streaming) return;
  if (!state.app.running) {
    toast('Start the local server first.', 'warn');
    return;
  }
  if (!activeChat?.messages?.length) return;
  const lastAssistant = [...activeChat.messages].reverse().find((message) => message.role === 'assistant');
  if (!lastAssistant) {
    toast('There is no assistant reply to regenerate.', 'warn');
    return;
  }
  if (lastAssistant.id.startsWith('local-')) return;
  try {
    activeChat.messages = activeChat.messages.filter((message) => message.id !== lastAssistant.id);
    const assistantMessage = {
      id: 'local-assistant',
      role: 'assistant',
      content: '',
      attachments: [],
      created_at: new Date().toISOString(),
      meta: { model: state.config.text.model, streaming: true, tools: [], sources: [], usage: {} },
    };
    activeChat.messages.push(assistantMessage);
    live = {
      content: '',
      thinking: '',
      tools: [],
      attachments: [],
      sources: [],
      usage: {},
      error: '',
      stopped: false,
      status: '',
      model: state.config.text.model,
      serverAssistantId: null,
    };
    shouldStick = true;
    renderMessages();
    scrollBottom(true);
    const signal = beginStream();
    await consumeStream(
      activeChat.id,
      api.streamRegenerate(activeChat.id, { web: webEnabled, tools: true, reasoning: reasoningEnabled }, signal),
    );
  } catch (error) {
    toast(error.message, 'error', 7000);
    streaming = false;
    renderComposer();
  }
}

function beginStream() {
  abortController = new AbortController();
  streaming = true;
  if (live) {
    live.startedAt = Date.now();
    live._content = '';
    live._toolSig = '';
    live._errorHtml = '';
    live._stoppedHtml = '';
    live._attachmentSig = '';
    live._sourceSig = '';
  }
  clearInterval(streamTicker);
  streamTicker = setInterval(() => {
    if (live) scheduleLive(true);
  }, 1000);
  renderComposer();
  return abortController.signal;
}

async function consumeStream(chatId, events) {
  try {
    for await (const event of events) handleStreamEvent(event);
  } catch (error) {
    if (error.name === 'AbortError') {
      if (live) live.stopped = true;
    } else {
      if (live) live.error = error.message;
      toast(error.message, 'error', 7000);
    }
    scheduleLive();
  } finally {
    streaming = false;
    abortController = null;
    clearInterval(streamTicker);
    streamTicker = null;
    renderComposer();
    await sleep(320);
    await finishStream(chatId);
  }
}

function handleStreamEvent(event) {
  if (!live) return;
  switch (event.type) {
    case 'meta':
      live.serverAssistantId = event.assistant_message_id || null;
      break;
    case 'status':
      live.status = event.text || '';
      scheduleLive();
      break;
    case 'transcript':
      live.status = 'Transcribed audio';
      scheduleLive();
      break;
    case 'delta':
      live.content += event.text || '';
      live.status = '';
      scheduleLive();
      break;
    case 'thinking':
      live.thinking += event.text || '';
      scheduleLive();
      break;
    case 'replace':
      live.content = event.text || '';
      scheduleLive();
      break;
    case 'tool_start':
      live.tools.push({
        id: event.id,
        name: event.name,
        arguments: event.arguments,
        status: 'running',
        content: '',
        attachments: [],
        sources: [],
        error: '',
      });
      live.status = `Using ${TOOL_META[event.name]?.[0] || event.name}…`;
      scheduleLive();
      break;
    case 'tool_result': {
      const tool = live.tools.find((item) => item.id === event.id) || {
        id: event.id,
        name: event.name,
        arguments: {},
      };
      tool.status = event.error ? 'error' : 'done';
      tool.content = event.content || '';
      tool.attachments = event.attachments || [];
      tool.sources = event.sources || [];
      tool.error = event.error || '';
      if (!live.tools.some((item) => item.id === event.id)) live.tools.push(tool);
      for (const attachment of event.attachments || []) {
        if (!live.attachments.some((item) => item.id === attachment.id)) live.attachments.push(attachment);
      }
      for (const source of event.sources || []) {
        if (!live.sources.some((item) => item.url === source.url)) live.sources.push(source);
      }
      live.status = '';
      scheduleLive();
      break;
    }
    case 'usage':
      live.usage = event.usage || live.usage;
      scheduleLive();
      break;
    case 'error':
      live.error = event.error || 'Unknown error';
      live.status = '';
      scheduleLive();
      break;
    case 'done':
      live.stopped = Boolean(event.stopped);
      live.usage = event.usage || live.usage;
      live.status = '';
      scheduleLive();
      break;
    case 'saved':
      live.serverAssistantId = event.message_id || live.serverAssistantId;
      break;
    default:
      break;
  }
}

function scheduleLive(immediate = false) {
  if (liveScheduled) return;
  liveScheduled = true;
  setTimeout(() => {
    liveScheduled = false;
    refreshLive();
  }, immediate ? 0 : 70);
}

function refreshLive() {
  if (!live || !activeChat) return;
  const message = activeChat.messages.find((item) => item.id === 'local-assistant');
  if (!message) return;
  const startedAt = live.startedAt || Date.now();
  message.content = live.content;
  message.attachments = live.attachments;
  message.meta = {
    ...message.meta,
    model: live.model,
    thinking: live.thinking,
    tools: live.tools,
    sources: live.sources,
    usage: live.usage,
    error: live.error,
    stopped: live.stopped,
    status: live.status,
    startedAt,
    streaming: true,
  };
  const article = document.querySelector('[data-message-id="local-assistant"]');
  if (!article) {
    renderMessages();
    return;
  }
  const slot = (name) => article.querySelector(`[data-live-slot="${name}"]`);
  const near = isNearBottom();
  const elapsed = `${Math.max(0, Math.floor((Date.now() - startedAt) / 1000))}s`;

  const thinkingSlot = slot('thinking');
  if (live.thinking) {
    if (!thinkingSlot.querySelector('.thinking-block')) {
      thinkingSlot.innerHTML = '<details class="thinking-block" open><summary>Thinking</summary><div class="thinking-content"></div></details>';
    }
    const thinkingContent = thinkingSlot.querySelector('.thinking-content');
    if (thinkingContent && thinkingContent.textContent !== live.thinking) thinkingContent.textContent = live.thinking;
  }

  const toolSig = JSON.stringify(
    live.tools.map((tool) => [tool.id, tool.name, tool.status, (tool.content || '').length, tool.error || '']),
  );
  if (toolSig !== live._toolSig) {
    live._toolSig = toolSig;
    slot('tools').innerHTML = live.tools.length
      ? `<div class="tool-cards">${live.tools.map((tool) => renderToolCard(tool, true)).join('')}</div>`
      : '';
  }

  const statusHtml = live.status ? `<div class="status-line">${spinner(11)} ${esc(live.status)}</div>` : '';
  if (slot('status').innerHTML !== statusHtml) slot('status').innerHTML = statusHtml;

  const contentSlot = slot('content');
  if (live.content) {
    if (live._content !== live.content) {
      live._content = live.content;
      contentSlot.innerHTML = `<div class="msg-content md streaming">${renderMarkdown(live.content)}</div>`;
      enhanceMarkdown(contentSlot);
    }
  } else if (!contentSlot.querySelector('[data-live-thinking]')) {
    contentSlot.innerHTML = `<div class="status-line" data-live-thinking><span class="typing-dots"><i></i><i></i><i></i></span> <span>Hearth is thinking…</span><span class="thinking-elapsed" data-live-elapsed>${elapsed}</span></div>`;
  }
  const elapsedNode = contentSlot.querySelector('[data-live-elapsed]');
  if (elapsedNode) elapsedNode.textContent = elapsed;

  const errorHtml = live.error ? `<div class="error-callout">${icon('alert', 14)}<span>${esc(live.error)}</span></div>` : '';
  if (live._errorHtml !== errorHtml) {
    live._errorHtml = errorHtml;
    slot('error').innerHTML = errorHtml;
  }
  const stoppedHtml = live.stopped ? `<div class="stopped-note">${icon('stop', 12)} Stopped</div>` : '';
  if (live._stoppedHtml !== stoppedHtml) {
    live._stoppedHtml = stoppedHtml;
    slot('stopped').innerHTML = stoppedHtml;
  }
  const attachmentSig = live.attachments.map((item) => item.id).join('|');
  if (attachmentSig !== live._attachmentSig) {
    live._attachmentSig = attachmentSig;
    slot('attachments').innerHTML = live.attachments.length ? renderAttachments(live.attachments) : '';
  }
  const sourceSig = live.sources.map((item) => item.url).join('|');
  if (sourceSig !== live._sourceSig) {
    live._sourceSig = sourceSig;
    slot('sources').innerHTML = live.sources.length ? renderSources(live.sources) : '';
  }
  if (near || shouldStick) scrollBottom();
}

async function finishStream(chatId) {
  if (!chatId) return;
  try {
    const chat = await api.getChat(chatId);
    activeChat = chat;
    activeChatId = chat.id;
    live = null;
    renderMessages();
    renderTopbar();
    renderSidebar();
    renderComposer();
    await loadChats();
    scrollBottom();
  } catch {
    // Leave the local transcript visible if the server is unreachable.
  }
}

async function stopStream() {
  if (!streaming) return;
  try {
    await api.stopChat(activeChatId);
  } catch {
    // The abort below still stops the local stream.
  }
  abortController?.abort();
  toast('Stopped', 'info', 1800);
}

/* ------------------------------------------------------------------ */
/* Direct generation                                                  */
/* ------------------------------------------------------------------ */
function openGenerateModal(modality) {
  if (!state.app.running) {
    toast('Start the server first.', 'warn');
    return;
  }
  const titles = { image: 'Generate an image', video: 'Generate a video', music: 'Compose a track', '3d': 'Build a 3D model', speech: 'Speak text' };
  const icons = { image: 'image', video: 'video', music: 'music', '3d': 'cube', speech: 'speaker' };
  const body = `<div class="stack">
    <div class="callout"><span class="callout-icon">${icon(icons[modality], 15)}</span><span>${
      modality === '3d'
        ? 'Hearth creates a preview image first, then turns it into a GLB mesh. You can also attach a reference image in the composer.'
        : modality === 'speech'
          ? 'The generated audio will appear in this conversation.'
          : 'Generation runs locally in the background. It can take a few minutes on this hardware.'
    }</span></div>
    <label class="field"><span class="label">${modality === 'speech' ? 'Text' : 'Prompt'}</span><textarea class="textarea" id="gen-prompt" placeholder="${
      modality === 'image'
        ? 'A weathered brass lantern on a windowsill, warm morning light, shallow depth of field'
        : modality === 'video'
          ? 'A fox trotting through fresh snow at sunset, slow tracking shot'
          : modality === 'music'
            ? 'Warm lo-fi hip hop, dusty piano, vinyl crackle, 80 bpm'
            : modality === '3d'
              ? 'A stylized ceramic fox figurine'
              : 'Welcome to Hearth. Everything stays on this machine.'
    }"></textarea></label>
    ${
      modality === 'image'
        ? `<label class="field"><span class="label">Size</span><select class="select" id="gen-size"><option value="1024x1024">Square · 1024×1024</option><option value="1216x832">Landscape · 1216×832</option><option value="832x1216">Portrait · 832×1216</option></select></label>`
        : modality === 'video'
          ? `<div class="row" style="gap:8px;align-items:flex-start"><label class="field" style="flex:1"><span class="label">Size</span><select class="select" id="gen-video-size"><option value="832x480" selected>480p · 832×480</option><option value="1280x720">720p · 1280×720</option><option value="512x512">Square · 512×512</option></select></label><label class="field" style="flex:1"><span class="label">Length</span><select class="select" id="gen-seconds"><option value="1">≈1 second</option><option value="2" selected>≈2 seconds</option><option value="3">≈3 seconds</option><option value="4">≈4 seconds</option></select></label><label class="field" style="flex:1"><span class="label">Frame rate</span><select class="select" id="gen-fps"><option value="12">12 fps</option><option value="16" selected>16 fps</option><option value="24">24 fps</option><option value="30">30 fps</option></select></label></div>
             <div class="callout warn"><span class="callout-icon">${icon('info', 15)}</span><span>720p at 24–30 fps is a heavy workload on 8 GB cards. Hearth offloads model weights to system RAM, but the sampler still needs VRAM for activations, so long 720p clips are automatically shortened to fit (and can take 5–8 minutes). 480p/16 fps is much faster.</span></div>`
          : modality === 'music'
            ? `<div class="row" style="gap:8px"><label class="field" style="flex:1"><span class="label">Seconds</span><input class="input" id="gen-duration" type="number" value="30" min="5" max="120" /></label><label class="field" style="flex:1"><span class="label">BPM</span><input class="input" id="gen-bpm" type="number" value="120" min="30" max="240" /></label></div>
               <label class="field"><span class="label">Lyrics (optional)</span><textarea class="textarea" id="gen-lyrics" placeholder="[Verse]&#10;…"></textarea></label>`
            : ''
    }
  </div>`;
  const dialog = modal({
    title: titles[modality],
    subtitle: 'Generate directly, without asking the text model first.',
    body,
    wide: true,
    actions: [
      { label: 'Cancel', kind: 'ghost' },
      {
        label: 'Generate',
        kind: 'primary',
        icon: 'wand',
        busyLabel: 'Queuing…',
        action: async () => {
          const prompt = dialog.el.querySelector('#gen-prompt').value.trim();
          if (!prompt) {
            toast('Write a prompt first.', 'warn');
            return false;
          }
          const payload = { modality: modality === '3d' ? '3d' : modality, prompt };
          if (modality === 'image') {
            const size = (dialog.el.querySelector('#gen-size')?.value || '1024x1024').split('x');
            payload.width = Number(size[0]);
            payload.height = Number(size[1]);
          } else if (modality === 'video') {
            const size = (dialog.el.querySelector('#gen-video-size')?.value || '832x480').split('x');
            payload.width = Number(size[0]);
            payload.height = Number(size[1]);
            payload.seconds = Number(dialog.el.querySelector('#gen-seconds')?.value || 2);
            payload.fps = Number(dialog.el.querySelector('#gen-fps')?.value || 16);
          } else if (modality === 'music') {
            payload.duration = Number(dialog.el.querySelector('#gen-duration')?.value || 30);
            payload.lyrics = dialog.el.querySelector('#gen-lyrics')?.value || '';
          }
          await runDirectGenerate(payload);
        },
      },
    ],
  });
}

async function runDirectGenerate(payload) {
  try {
    if (!activeChat) {
      const chat = await api.createChat();
      activeChat = chat;
      activeChatId = chat.id;
      setChatHash(chat.id);
      activeChat.messages = [];
      await loadChats();
    }
    const result = await api.generate({ ...payload, chat_id: activeChat.id });
    activeChatId = result.chat_id;
    setChatHash(result.chat_id);
    await loadChat(result.chat_id);
    toast('Generation queued. It will appear here when it is ready.', 'info', 5000);
    pollGenerateJob(result.job_id, result.chat_id);
  } catch (error) {
    toast(error.message, 'error', 7000);
  }
}

async function pollGenerateJob(jobId, chatId) {
  let lastStatus = '';
  for (let attempt = 0; attempt < 4800; attempt += 1) {
    try {
      const job = await api.job(jobId);
      if (job.status !== lastStatus) {
        lastStatus = job.status;
        if (job.status === 'running') toast('Generation started locally…', 'info', 2600);
      }
      if (['done', 'error', 'canceled'].includes(job.status)) {
        if (chatId === activeChatId) await loadChat(chatId);
        if (job.status === 'done') toast('Generation ready', 'success');
        else if (job.status === 'error') toast(job.error || 'Generation failed', 'error', 8000);
        return;
      }
    } catch {
      // Keep polling; the job may be between states.
    }
    await sleep(1500);
  }
}

/* ------------------------------------------------------------------ */
/* Chat actions                                                       */
/* ------------------------------------------------------------------ */
async function renameChat(chatId = activeChatId) {
  const chat = chatId === activeChatId ? activeChat : chats.find((item) => item.id === chatId);
  if (!chat) return;
  const dialog = modal({
    title: 'Rename conversation',
    body: `<label class="field"><span class="label">Title</span><input class="input" id="rename-input" value="${escAttr(
      chat.title,
    )}" maxlength="120" /></label>`,
    actions: [
      { label: 'Cancel', kind: 'ghost' },
      {
        label: 'Save',
        kind: 'primary',
        icon: 'check',
        action: async () => {
          const title = dialog.el.querySelector('#rename-input').value.trim();
          if (!title) return false;
          const updated = await api.renameChat(chatId, title);
          if (activeChatId === chatId) {
            activeChat = updated;
            renderTopbar();
            renderMessages();
          }
          await loadChats();
          toast('Conversation renamed', 'success', 2200);
        },
      },
    ],
  });
}

async function deleteChat(chatId) {
  const chat = chats.find((item) => item.id === chatId) || (activeChatId === chatId ? activeChat : null);
  if (!chat) return;
  if (!(await confirmDialog({ title: 'Delete conversation?', message: `“${chat.title}” will be removed from this machine.`, confirmLabel: 'Delete', danger: true }))) return;
  try {
    await api.deleteChat(chatId);
    if (activeChatId === chatId) {
      activeChat = null;
      activeChatId = null;
      setChatHash(null);
      showEmpty();
      renderTopbar();
    }
    await loadChats();
    renderComposer();
    toast('Conversation deleted', 'info', 2400);
  } catch (error) {
    toast(error.message, 'error', 6000);
  }
}

function exportChat() {
  if (!activeChat) return;
  modal({
    title: 'Export conversation',
    subtitle: activeChat.title,
    body: '<p class="modal-copy">Choose a format. The exported file stays on your machine.</p>',
    actions: [
      { label: 'Cancel', kind: 'ghost' },
      {
        label: 'Markdown',
        kind: 'primary',
        icon: 'file',
        action: () => {
          window.open(api.exportUrl(activeChat.id, 'markdown'), '_blank', 'noopener');
        },
      },
      {
        label: 'JSON',
        kind: 'subtle',
        icon: 'code',
        action: () => {
          window.open(api.exportUrl(activeChat.id, 'json'), '_blank', 'noopener');
        },
      },
    ],
  });
}

function copyMessage(id) {
  const message = activeChat?.messages?.find((item) => item.id === id);
  if (message?.content) copyText(message.content);
}

async function speakMessage(id) {
  const message = activeChat?.messages?.find((item) => item.id === id);
  if (!message?.content) return;
  toast('Preparing speech…', 'info', 2200);
  try {
    const attachment = await api.tts(message.content, state.config.audio.voice);
    modal({
      title: 'Read aloud',
      subtitle: attachment.filename,
      body: `<audio controls autoplay src="${escAttr(attachment.url)}" style="width:100%"></audio>`,
    });
  } catch (error) {
    toast(error.message, 'error', 6000);
  }
}

/* ------------------------------------------------------------------ */
/* Attachments / uploads                                              */
/* ------------------------------------------------------------------ */
async function handleFiles(files) {
  const list = [...files];
  if (!list.length) return;
  for (const file of list) {
    if (file.size > 100 * 1024 * 1024) {
      toast(`${file.name} is larger than 100 MB`, 'error', 5000);
      continue;
    }
    uploading += 1;
    renderComposer();
    try {
      const attachment = await api.upload(file);
      pendingAttachments.push(attachment);
      if (attachment.kind === 'audio') toast('Audio will be transcribed locally when you send.', 'info', 3200);
    } catch (error) {
      toast(`Upload failed: ${error.message}`, 'error', 6000);
    } finally {
      uploading -= 1;
      renderComposer();
    }
  }
}

async function removeAttachment(id) {
  pendingAttachments = pendingAttachments.filter((item) => item.id !== id);
  renderComposer({ focus: true });
}

/* ------------------------------------------------------------------ */
/* Lightbox / server                                                  */
/* ------------------------------------------------------------------ */
function openLightbox(url, name = 'Image') {
  modal({
    title: name,
    wide: true,
    body: `<img src="${escAttr(url)}" alt="${escAttr(name)}" style="width:100%;max-height:74vh;object-fit:contain;border-radius:12px" />`,
  });
}

async function startServer(button) {
  setButtonBusy(button, true, 'Starting…');
  try {
    const result = await api.startServer();
    state = await api.refresh();
    renderSidebar();
    renderTopbar();
    renderComposer();
    if (!activeChat?.messages?.length) showEmpty();
    toast((result.warnings || [])[0] || 'Server running. You can chat now.', result.warnings?.length ? 'warn' : 'success', 6000);
  } catch (error) {
    toast(error.message, 'error', 8000);
  } finally {
    setButtonBusy(button, false);
  }
}

function toggleSidebar(force) {
  sidebarOpen = typeof force === 'boolean' ? force : !sidebarOpen;
  document.getElementById('chat-sidebar')?.classList.toggle('open', sidebarOpen);
  document.getElementById('sidebar-scrim')?.classList.toggle('open', sidebarOpen);
}

function closeSidebar() {
  toggleSidebar(false);
}

/* ------------------------------------------------------------------ */
/* Scroll                                                             */
/* ------------------------------------------------------------------ */
function isNearBottom() {
  const scroll = document.getElementById('chat-scroll');
  if (!scroll) return true;
  return scroll.scrollTop + scroll.clientHeight >= scroll.scrollHeight - 90;
}

function scrollBottom(force = false) {
  const scroll = document.getElementById('chat-scroll');
  if (!scroll) return;
  if (!force && !shouldStick) return;
  requestAnimationFrame(() => {
    scroll.scrollTop = scroll.scrollHeight;
  });
}

/* ------------------------------------------------------------------ */
/* Events                                                             */
/* ------------------------------------------------------------------ */
function bindGlobalEvents() {
  document.addEventListener('click', async (event) => {
    const actionEl = event.target.closest('[data-action]');
    if (actionEl) {
      event.preventDefault();
      const action = actionEl.dataset.action;
      try {
        if (action === 'new-chat') newChat();
        else if (action === 'toggle-sidebar') toggleSidebar();
        else if (action === 'close-sidebar') closeSidebar();
        else if (action === 'toggle-theme') await toggleTheme();
        else if (action === 'rename-chat') await renameChat(actionEl.dataset.chatId || activeChatId);
        else if (action === 'delete-chat') await deleteChat(actionEl.dataset.chatId || activeChatId);
        else if (action === 'export-chat') exportChat();
        else if (action === 'start-server') await startServer(actionEl);
        else if (action === 'copy-message') copyMessage(actionEl.dataset.messageId);
        else if (action === 'speak-message') await speakMessage(actionEl.dataset.messageId);
        else if (action === 'regenerate') await regenerate();
        else if (action === 'attach') document.getElementById('chat-file-input')?.click();
        else if (action === 'toggle-web') {
          webEnabled = !webEnabled;
          renderComposer({ focus: true });
        } else if (action === 'toggle-reasoning') {
          const current = reasoningEnabled === null ? Boolean(state.config.text?.thinking) : reasoningEnabled;
          reasoningEnabled = !current;
          renderComposer({ focus: true });
        } else if (action === 'toggle-tools') {
          toolMenuOpen = !toolMenuOpen;
          renderComposer({ focus: true });
        } else if (action === 'open-generate') {
          toolMenuOpen = false;
          renderComposer();
          openGenerateModal(actionEl.dataset.modality);
        } else if (action === 'remove-attachment') {
          await removeAttachment(actionEl.dataset.id);
        } else if (action === 'stop-stream') {
          await stopStream();
        }
      } catch (error) {
        toast(error.message || String(error), 'error', 7000);
      }
      return;
    }
    const lightbox = event.target.closest('[data-lightbox]');
    if (lightbox) {
      openLightbox(lightbox.dataset.lightbox, lightbox.dataset.name);
      return;
    }
    const copyCode = event.target.closest('[data-copy-code]');
    if (copyCode) {
      copyText(copyCode.dataset.copyCode || '');
      return;
    }
    const suggestion = event.target.closest('[data-suggestion]');
    if (suggestion) {
      const type = suggestion.dataset.suggestion;
      if (type === 'generate') {
        openGenerateModal(suggestion.dataset.modality);
      } else if (type === 'web') {
        webEnabled = true;
        composerDraft = suggestion.dataset.prompt || '';
        renderComposer({ focus: true });
      } else {
        composerDraft = suggestion.dataset.prompt || '';
        renderComposer({ focus: true });
      }
      return;
    }
    const chatItem = event.target.closest('[data-chat-id]');
    if (chatItem) {
      await loadChat(chatItem.dataset.chatId);
      return;
    }
    if (toolMenuOpen && !event.target.closest('.tool-menu') && !event.target.closest('[data-action="toggle-tools"]')) {
      toolMenuOpen = false;
      renderComposer();
    }
  });

  document.addEventListener('input', (event) => {
    if (event.target.id === 'chat-search') {
      chatQuery = event.target.value;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(async () => {
        try {
          const result = await api.chats(chatQuery);
          chats = result.chats || [];
          const list = document.getElementById('chat-list');
          if (list) list.innerHTML = renderChatGroups();
        } catch {
          // Keep the previous list on search errors.
        }
      }, 220);
    }
  });

  document.addEventListener('change', async (event) => {
    if (event.target.id === 'model-select') {
      await changeModel(event.target.value);
    } else if (event.target.id === 'chat-file-input') {
      await handleFiles(event.target.files || []);
      event.target.value = '';
    }
  });

  document.addEventListener('paste', (event) => {
    if (!event.target.closest('#composer-area')) return;
    const files = [...(event.clipboardData?.files || [])];
    if (files.length) {
      event.preventDefault();
      handleFiles(files);
    }
  });

  const composerArea = document.getElementById('composer-area');
  composerArea?.addEventListener('dragover', (event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  composerArea?.addEventListener('drop', (event) => {
    event.preventDefault();
    if (event.dataTransfer.files?.length) handleFiles(event.dataTransfer.files);
  });

  document.getElementById('chat-scroll')?.addEventListener('scroll', () => {
    shouldStick = isNearBottom();
  });

  window.addEventListener('keydown', (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      newChat();
    } else if (event.key === 'Escape') {
      if (streaming) {
        stopStream();
      } else if (sidebarOpen) {
        closeSidebar();
      }
    }
  });

  window.addEventListener('hashchange', async () => {
    if (streaming) return;
    const id = chatIdFromHash();
    if (id && id !== activeChatId) await loadChat(id);
    else if (!id) {
      activeChat = null;
      activeChatId = null;
      showEmpty();
      renderTopbar();
    }
  });
}

/* ------------------------------------------------------------------ */
/* Start                                                              */
/* ------------------------------------------------------------------ */
boot();
