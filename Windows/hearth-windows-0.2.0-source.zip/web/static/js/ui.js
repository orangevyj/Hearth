import { icon } from './icons.js?v=0.1.0';

export function esc(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

export function escAttr(value) {
  return esc(value).replaceAll('`', '&#96;');
}

export function fmtGb(value, digits = 1) {
  const number = Number(value || 0);
  if (!number) return '0 GB';
  if (number < 0.1) return '<0.1 GB';
  return `${number.toFixed(digits)} GB`;
}

export function fmtBytes(value) {
  let number = Number(value || 0);
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let index = 0;
  while (number >= 1024 && index < units.length - 1) {
    number /= 1024;
    index += 1;
  }
  return `${number.toFixed(index > 1 ? 1 : 0)} ${units[index]}`;
}

export function fmtSpeed(value) {
  const number = Number(value || 0);
  if (!number) return '';
  if (number > 1024 * 1024) return `${(number / 1024 / 1024).toFixed(1)} MB/s`;
  if (number > 1024) return `${(number / 1024).toFixed(0)} KB/s`;
  return `${number.toFixed(0)} B/s`;
}

export function fmtEta(seconds) {
  if (seconds === null || seconds === undefined) return '';
  const value = Math.max(0, Math.round(Number(seconds)));
  if (value < 60) return `${value}s`;
  const minutes = Math.floor(value / 60);
  const rest = value % 60;
  return `${minutes}m ${rest}s`;
}

export function timeAgo(iso) {
  if (!iso) return '';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '';
  const diff = Math.max(0, (Date.now() - then) / 1000);
  if (diff < 45) return 'just now';
  if (diff < 90) return '1 min ago';
  if (diff < 3600) return `${Math.round(diff / 60)} min ago`;
  if (diff < 86400) return `${Math.round(diff / 3600)} h ago`;
  return `${Math.round(diff / 86400)} d ago`;
}

export function fmtTime(iso) {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function deepClone(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

export function getPath(object, path) {
  return String(path)
    .split('.')
    .reduce((current, key) => (current == null ? undefined : current[key]), object);
}

export function setPath(object, path, value) {
  const parts = String(path).split('.');
  let current = object;
  for (let index = 0; index < parts.length - 1; index += 1) {
    const key = parts[index];
    if (!current[key] || typeof current[key] !== 'object') current[key] = {};
    current = current[key];
  }
  current[parts[parts.length - 1]] = value;
  return object;
}

export function truncate(text, length = 120) {
  const value = String(text ?? '');
  return value.length > length ? `${value.slice(0, length - 1)}…` : value;
}

export function debounce(fn, wait = 200) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function spinner(size = 16) {
  return `<span class="spinner" style="width:${size}px;height:${size}px" aria-hidden="true"></span>`;
}

export function dot(tone = 'muted') {
  return `<span class="dot dot-${tone}" aria-hidden="true"></span>`;
}

export function badge(text, kind = 'neutral', withDot = false) {
  return `<span class="badge badge-${kind}">${withDot ? dot(kind) : ''}${esc(text)}</span>`;
}

export function emptyState(iconName, title, text, action = '') {
  return `
    <div class="empty">
      <div class="empty-icon">${icon(iconName, 28)}</div>
      <h3>${esc(title)}</h3>
      <p>${esc(text)}</p>
      ${action}
    </div>`;
}

export function toast(message, kind = 'info', timeout = 5200) {
  const root = document.getElementById('toasts');
  if (!root) return;
  const node = document.createElement('div');
  node.className = `toast toast-${kind}`;
  const iconName = kind === 'success' ? 'check' : kind === 'error' ? 'alert' : kind === 'warn' ? 'alert' : 'info';
  node.innerHTML = `<span class="toast-icon">${icon(iconName, 17)}</span><span class="toast-text">${esc(message)}</span><button class="toast-close" aria-label="Dismiss">${icon('x', 14)}</button>`;
  root.appendChild(node);
  const remove = () => {
    node.classList.add('leaving');
    setTimeout(() => node.remove(), 220);
  };
  node.querySelector('.toast-close').addEventListener('click', remove);
  if (timeout) setTimeout(remove, timeout);
}

export function modal({ title, subtitle = '', body = '', actions = [], wide = false, closable = true, onClose = null }) {
  const root = document.getElementById('modal-root');
  if (!root) return { close: () => {} };
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = `
    <div class="modal ${wide ? 'modal-wide' : ''}" role="dialog" aria-modal="true" aria-label="${escAttr(title)}">
      <header class="modal-head">
        <div>
          <h2>${esc(title)}</h2>
          ${subtitle ? `<p>${esc(subtitle)}</p>` : ''}
        </div>
        ${closable ? `<button class="btn icon ghost modal-close" aria-label="Close">${icon('x', 18)}</button>` : ''}
      </header>
      <div class="modal-body">${body}</div>
      ${actions.length ? '<footer class="modal-actions"></footer>' : ''}
    </div>`;
  root.appendChild(backdrop);
  const panel = backdrop.querySelector('.modal');
  const close = () => {
    backdrop.classList.add('leaving');
    setTimeout(() => {
      backdrop.remove();
      if (onClose) onClose();
    }, 160);
    document.removeEventListener('keydown', onKey);
  };
  const onKey = (event) => {
    if (event.key === 'Escape' && closable) close();
  };
  document.addEventListener('keydown', onKey);
  if (closable) {
    backdrop.querySelector('.modal-close')?.addEventListener('click', close);
    backdrop.addEventListener('mousedown', (event) => {
      if (event.target === backdrop) close();
    });
  }
  const footer = backdrop.querySelector('.modal-actions');
  for (const action of actions) {
    const button = document.createElement('button');
    button.className = `btn ${action.kind || 'ghost'}`;
    button.innerHTML = `${action.icon ? icon(action.icon, 16) : ''}<span>${esc(action.label)}</span>`;
    button.addEventListener('click', async () => {
      if (button.disabled) return;
      const original = button.innerHTML;
      button.disabled = true;
      button.innerHTML = `${spinner(14)}<span>${esc(action.busyLabel || action.label)}</span>`;
      try {
        const result = action.action ? await action.action() : undefined;
        if (result !== false && action.close !== false) close();
      } finally {
        button.disabled = false;
        button.innerHTML = original;
      }
    });
    footer?.appendChild(button);
  }
  setTimeout(() => {
    const focusable = panel.querySelector('input:not([type=hidden]), select, textarea, button');
    focusable?.focus();
  }, 30);
  return { close, el: panel, backdrop, setBody: (html) => { panel.querySelector('.modal-body').innerHTML = html; } };
}

export function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false }) {
  return new Promise((resolve) => {
    const dialog = modal({
      title,
      body: `<p class="modal-copy">${esc(message)}</p>`,
      actions: [
        { label: 'Cancel', kind: 'ghost', action: () => resolve(false) },
        {
          label: confirmLabel,
          kind: danger ? 'danger' : 'primary',
          action: () => resolve(true),
        },
      ],
      onClose: () => resolve(false),
    });
    dialog.backdrop.addEventListener('mousedown', (event) => {
      if (event.target === dialog.backdrop) resolve(false);
    });
  });
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast('Copied to clipboard', 'success', 2200);
  } catch {
    toast('Could not access the clipboard', 'error');
  }
}

export function progress(value, { label = '', tone = '' } = {}) {
  const number = value === null || value === undefined ? null : Math.max(0, Math.min(100, Number(value)));
  return `
    <div class="progress-wrap">
      <div class="progress ${tone ? `progress-${tone}` : ''} ${number === null ? 'indeterminate' : ''}">
        <span style="${number === null ? '' : `width:${number}%`}"></span>
      </div>
      ${label ? `<div class="progress-label">${esc(label)}</div>` : ''}
    </div>`;
}

export function jobStatusKind(status) {
  return status === 'done' ? 'success' : status === 'error' ? 'danger' : status === 'canceled' ? 'warn' : 'info';
}

export function jobStatusLabel(status) {
  return {
    queued: 'Queued',
    running: 'Running',
    done: 'Done',
    error: 'Failed',
    canceled: 'Canceled',
  }[status] || status;
}

export function prettyBytes(n) {
  return fmtBytes(n);
}

export function setButtonBusy(button, busy, label = 'Working…') {
  if (!button) return;
  if (busy) {
    button.dataset.original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = `${spinner(14)}<span>${esc(label)}</span>`;
  } else {
    button.disabled = false;
    if (button.dataset.original) button.innerHTML = button.dataset.original;
    delete button.dataset.original;
  }
}

/* ------------------------------------------------------------------ */
/* Charts (plain SVG, no dependencies)                                */
/* ------------------------------------------------------------------ */

const TONE_COLOURS = {
  accent: 'var(--accent)',
  green: 'var(--green)',
  blue: 'var(--blue)',
  red: 'var(--red)',
  yellow: 'var(--yellow)',
  muted: 'var(--muted)',
};

export function donut(percent, { label = '', sub = '', tone = 'accent', size = 104, thickness = 9 } = {}) {
  const value = Math.max(0, Math.min(100, Number(percent) || 0));
  const radius = (size - thickness) / 2;
  const circumference = 2 * Math.PI * radius;
  const filled = (value / 100) * circumference;
  const colour = TONE_COLOURS[tone] || TONE_COLOURS.accent;
  return `<div class="donut">
    <svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" role="img" aria-label="${escAttr(
      `${label} ${Math.round(value)}%`,
    )}">
      <circle cx="${size / 2}" cy="${size / 2}" r="${radius}" fill="none" stroke="var(--line)" stroke-width="${thickness}" />
      <circle cx="${size / 2}" cy="${size / 2}" r="${radius}" fill="none" stroke="${colour}" stroke-width="${thickness}"
        stroke-linecap="round" stroke-dasharray="${filled} ${circumference}"
        transform="rotate(-90 ${size / 2} ${size / 2})" />
    </svg>
    <div class="donut-centre">
      <strong>${Math.round(value)}%</strong>
      ${label ? `<span>${esc(label)}</span>` : ''}
    </div>
    ${sub ? `<div class="donut-sub">${esc(sub)}</div>` : ''}
  </div>`;
}

export function sparkline(values, { tone = 'accent', height = 34, width = 120 } = {}) {
  const numbers = (values || []).map((value) => Number(value) || 0);
  if (numbers.length < 2) return '<span class="tiny muted">not enough data yet</span>';
  const max = Math.max(...numbers, 1);
  const step = width / (numbers.length - 1);
  const points = numbers
    .map((value, index) => `${(index * step).toFixed(1)},${(height - (value / max) * (height - 4) - 2).toFixed(1)}`)
    .join(' ');
  const colour = TONE_COLOURS[tone] || TONE_COLOURS.accent;
  return `<svg class="sparkline" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" width="${width}" height="${height}">
    <polyline points="${points}" fill="none" stroke="${colour}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
  </svg>`;
}

export function barChart(items, { tone = 'accent', unit = 'GB' } = {}) {
  const rows = (items || []).filter((item) => item && item.value > 0);
  if (!rows.length) return '<div class="muted small">Nothing to show yet.</div>';
  const max = Math.max(...rows.map((item) => item.value));
  const colour = TONE_COLOURS[tone] || TONE_COLOURS.accent;
  return `<div class="bar-chart">${rows
    .map(
      (item) => `<div class="bar-row">
        <span class="bar-label" title="${escAttr(item.label)}">${esc(item.label)}</span>
        <span class="bar-track"><span class="bar-fill" style="width:${Math.max(2, (item.value / max) * 100).toFixed(
          1,
        )}%;background:${colour}"></span></span>
        <span class="bar-value">${item.value.toFixed ? item.value.toFixed(item.value >= 10 ? 0 : 1) : item.value}${
          unit ? ` ${unit}` : ''
        }</span>
      </div>`,
    )
    .join('')}</div>`;
}
