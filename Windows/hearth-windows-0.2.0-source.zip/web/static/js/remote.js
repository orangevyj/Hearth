// Encrypted transport for connecting to a Hearth server from another device.
//
// The secret is turned into an AES-256-GCM key with PBKDF2-HMAC-SHA256 (same
// parameters as the server), and every request travels as a sealed envelope
// through /api/secure/rpc. Nothing is cached on the server side.

const STORE_KEY = 'hearth.remote';
const KDF_ITERATIONS = 200000;
const KEY_CACHE = new Map();

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export class RemoteError extends Error {
  constructor(message, status = 0) {
    super(message);
    this.name = 'RemoteError';
    this.status = status;
  }
}

export function loadConnection() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
    if (!raw || !raw.address || !raw.user) return null;
    return raw;
  } catch {
    return null;
  }
}

export function saveConnection(connection) {
  localStorage.setItem(
    STORE_KEY,
    JSON.stringify({
      address: String(connection.address || '').replace(/\/+$/, ''),
      user: connection.user,
      secret: connection.secret || '',
      salt: connection.salt || '',
      secure: Boolean(connection.secret),
    }),
  );
  KEY_CACHE.clear();
}

export function clearConnection() {
  localStorage.removeItem(STORE_KEY);
  KEY_CACHE.clear();
}

export function isRemote() {
  return Boolean(loadConnection());
}

function toBase64(bytes) {
  let binary = '';
  for (const byte of new Uint8Array(bytes)) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function fromBase64(value) {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

async function deriveKey(secret, salt) {
  const cacheKey = `${secret}\u0000${salt}`;
  if (KEY_CACHE.has(cacheKey)) return KEY_CACHE.get(cacheKey);
  const material = await crypto.subtle.importKey('raw', encoder.encode(secret), 'PBKDF2', false, ['deriveKey']);
  const key = await crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: encoder.encode(salt), iterations: KDF_ITERATIONS, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );
  KEY_CACHE.set(cacheKey, key);
  return key;
}

async function keyFor(connection) {
  if (!connection?.secret) throw new RemoteError('This connection has no secret, so it cannot be encrypted.', 403);
  if (!connection.salt) throw new RemoteError('Reconnect once so the server can hand out its key salt.', 428);
  return deriveKey(connection.secret, connection.salt);
}

async function seal(key, text, aad) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: encoder.encode(aad) },
    key,
    encoder.encode(text),
  );
  const combined = new Uint8Array(iv.length + ciphertext.byteLength);
  combined.set(iv, 0);
  combined.set(new Uint8Array(ciphertext), iv.length);
  return toBase64(combined);
}

async function open(key, envelope, aad) {
  const raw = fromBase64(envelope);
  const iv = raw.slice(0, 12);
  const plaintext = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv, additionalData: encoder.encode(aad) },
    key,
    raw.slice(12),
  );
  return decoder.decode(plaintext);
}

/** Ask a server for the salt used to derive this account's key. */
export async function fetchSalt(address) {
  const response = await fetch(`${address.replace(/\/+$/, '')}/api/remote/salt`, { cache: 'no-store' });
  if (!response.ok) throw new RemoteError(`That server did not answer (HTTP ${response.status}).`, response.status);
  const payload = await response.json();
  return payload.salt;
}

async function detailOf(response) {
  try {
    const data = await response.json();
    return data.detail || data.error || JSON.stringify(data);
  } catch {
    return (await response.text().catch(() => '')) || `HTTP ${response.status}`;
  }
}

/** One encrypted request/response. Returns { status, contentType, text }. */
export async function call(connection, path, { method = 'GET', body = null } = {}) {
  const key = await keyFor(connection);
  const inner = JSON.stringify({ method, path, body });
  const envelope = await seal(key, inner, connection.user);
  const response = await fetch(`${connection.address}/api/secure/rpc`, {
    method: 'POST',
    cache: 'no-store',
    headers: { 'Content-Type': 'application/json', 'X-Hearth-User': connection.user },
    body: JSON.stringify({ d: envelope }),
  });
  if (!response.ok) throw new RemoteError(await detailOf(response), response.status);
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('x-hearth-sealed')) {
    const opened = JSON.parse(await open(key, (await response.text()).trim(), connection.user));
    if (opened && typeof opened === 'object' && 'status' in opened) {
      return { status: opened.status, contentType: opened.content_type || '', text: opened.body || '' };
    }
    // A server that answers with the document itself is treated as a 200 JSON reply.
    return { status: 200, contentType: 'application/json', text: JSON.stringify(opened) };
  }
  return { status: response.status, contentType, text: await response.text() };
}

/**
 * Encrypted streaming call. `onChunk` receives decrypted SSE text as it
 * arrives; frames are length-prefixed and decrypted one by one.
 */
export async function callStream(connection, path, { method = 'POST', body = null, signal, onChunk }) {
  const key = await keyFor(connection);
  const inner = JSON.stringify({ method, path, body });
  const envelope = await seal(key, inner, connection.user);
  const response = await fetch(`${connection.address}/api/secure/rpc`, {
    method: 'POST',
    cache: 'no-store',
    signal,
    headers: { 'Content-Type': 'application/json', 'X-Hearth-User': connection.user },
    body: JSON.stringify({ d: envelope }),
  });
  if (!response.ok) throw new RemoteError(await detailOf(response), response.status);
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('x-hearth-frames')) {
    const opened = JSON.parse(await open(key, (await response.text()).trim(), connection.user));
    if (onChunk) onChunk(opened.body || '');
    return;
  }
  const reader = response.body.getReader();
  let buffer = new Uint8Array(0);
  const pump = async () => {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      const merged = new Uint8Array(buffer.length + value.length);
      merged.set(buffer, 0);
      merged.set(value, buffer.length);
      buffer = merged;
      while (buffer.length >= 4) {
        const length = new DataView(buffer.buffer, buffer.byteOffset, 4).getUint32(0);
        if (buffer.length < 4 + length) break;
        const frame = buffer.slice(4, 4 + length);
        buffer = buffer.slice(4 + length);
        const plaintext = await open(key, toBase64(frame), connection.user);
        if (onChunk) onChunk(plaintext);
      }
    }
  };
  await pump();
}

/** Verify a connection by asking for the capability document. */
export async function probe(connection) {
  const result = await call(connection, '/api/state');
  if (result.status !== 200) {
    let detail = result.text;
    try {
      detail = JSON.parse(result.text).detail || detail;
    } catch {
      /* keep the raw text */
    }
    throw new RemoteError(detail || `HTTP ${result.status}`, result.status);
  }
  const state = JSON.parse(result.text);
  return state.capabilities || state;
}
