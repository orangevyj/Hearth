import {
  call as remoteCall,
  callStream as remoteStream,
  clearConnection,
  fetchSalt,
  loadConnection,
  probe as remoteProbe,
  saveConnection,
} from './remote.js?v=0.1.0';

const TOKEN_KEY = 'hearth.token';

export class ApiError extends Error {
  constructor(message, status = 0, detail = '') {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.detail = detail;
  }
}

class HearthAPI {
  constructor() {
    this.state = null;
    this.token = sessionStorage.getItem(TOKEN_KEY) || '';
    this.remote = loadConnection();
  }

  get isRemote() {
    return Boolean(this.remote);
  }

  async connectRemote(address, user, secret) {
    const clean = String(address || '').trim().replace(/\/+$/, '');
    if (!clean) throw new ApiError('Enter the server address, for example http://192.168.1.20:8772');
    const salt = await fetchSalt(clean);
    const connection = { address: clean, user: String(user || '').trim(), secret: String(secret || ''), salt };
    saveConnection(connection);
    this.remote = loadConnection();
    try {
      const caps = await remoteProbe(this.remote);
      await this.fetchState();
      return caps;
    } catch (error) {
      this.disconnectRemote();
      throw error;
    }
  }

  disconnectRemote() {
    clearConnection();
    this.remote = null;
    this.state = null;
    sessionStorage.removeItem(TOKEN_KEY);
  }

  async request(path, { method = 'GET', body, headers = {}, retry = true } = {}) {
    if (this.remote && path.startsWith('/api/') && !(body instanceof FormData)) {
      const result = await remoteCall(this.remote, path, { method, body: body ?? null });
      if (result.status >= 400) {
        let detail = result.text;
        try {
          detail = JSON.parse(result.text).detail || detail;
        } catch {
          /* keep raw text */
        }
        throw new ApiError(detail || `HTTP ${result.status}`, result.status, detail);
      }
      if (result.contentType.includes('application/json') && result.text) return JSON.parse(result.text);
      return result.text;
    }
    const opts = { method, headers: { ...headers }, credentials: 'same-origin', cache: 'no-store' };
    if (body instanceof FormData) {
      opts.body = body;
    } else if (body !== undefined) {
      opts.body = JSON.stringify(body);
      opts.headers['Content-Type'] = 'application/json';
    }
    if (this.token && method !== 'GET') opts.headers['X-Hearth-Token'] = this.token;
    const response = await fetch(path, opts);
    if (response.status === 403 && retry) {
      await this.fetchState();
      return this.request(path, { method, body, headers, retry: false });
    }
    if (!response.ok) {
      let detail = '';
      try {
        const data = await response.json();
        detail = data.detail || data.error || JSON.stringify(data);
      } catch {
        detail = await response.text().catch(() => '');
      }
      throw new ApiError(detail || `HTTP ${response.status}`, response.status, detail);
    }
    if (response.status === 204) return null;
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) return response.json();
    return response.text();
  }

  async fetchState() {
    if (this.remote) {
      let result;
      try {
        result = await remoteCall(this.remote, '/api/state');
      } catch (error) {
        // The transport throws on a rejected request: 401/403/428 means the
        // account is gone, disabled or has no secret any more.
        if ([401, 403, 428].includes(error?.status)) {
          const lost = this.remote;
          this.disconnectRemote();
          const local = await this.fetchState();
          local.remoteLost = lost;
          return local;
        }
        throw error;
      }
      if ([401, 403, 428].includes(result.status)) {
        const lost = this.remote;
        this.disconnectRemote();
        const local = await this.fetchState();
        local.remoteLost = lost;
        return local;
      }
      if (result.status !== 200) {
        let detail = result.text;
        try {
          detail = JSON.parse(result.text).detail || detail;
        } catch {
          /* keep the raw text */
        }
        throw new ApiError(detail || `Could not reach the server (HTTP ${result.status})`, result.status);
      }
      const doc = JSON.parse(result.text);
      const caps = doc.capabilities || {};
      // A client only knows what the server chose to tell it.
      this.state = {
        remote: true,
        app: { ...doc.app, remote: true },
        capabilities: caps,
        chat_count: doc.chat_count || 0,
        config: {
          text: doc.config?.text || { model: '' },
          ui: doc.config?.ui || {},
          image: { enabled: Boolean(caps.permissions?.media?.image) },
          video: { enabled: Boolean(caps.permissions?.media?.video) },
          music: { enabled: Boolean(caps.permissions?.media?.music) },
          three_d: { enabled: Boolean(caps.permissions?.media?.three_d) },
          audio: { enabled: Boolean(caps.permissions?.media?.speech) },
          tools: { enabled: Boolean(caps.permissions?.tools) },
        },
        presets: { presets: caps.presets || [], recommended: null },
        catalog: {
          image: caps.models?.image || [],
          video: caps.models?.video || [],
          three_d: caps.models?.three_d || [],
          music: caps.models?.music || [],
          text: caps.text_models || [],
        },
      };
      this.token = '';
      return this.state;
    }
    const response = await fetch('/api/state', { cache: 'no-store', credentials: 'same-origin' });
    if (!response.ok) throw new ApiError(`Could not load Hearth state (HTTP ${response.status})`, response.status);
    const state = await response.json();
    this.state = state;
    this.token = state.csrf_token || '';
    sessionStorage.setItem(TOKEN_KEY, this.token);
    return state;
  }

  async refresh() {
    return this.fetchState();
  }

  memories() {
    return this.request('/api/memories');
  }

  addMemory(text) {
    return this.request('/api/memories', { method: 'POST', body: { text } });
  }

  updateMemory(id, changes) {
    return this.request(`/api/memories/${encodeURIComponent(id)}`, { method: 'PATCH', body: changes });
  }

  deleteMemory(id) {
    return this.request(`/api/memories/${encodeURIComponent(id)}`, { method: 'DELETE' });
  }

  clearMemories(onlyEnabled = false) {
    return this.request('/api/memories/clear', { method: 'POST', body: { only_enabled: onlyEnabled } });
  }

  panelStatus() {
    return this.request('/api/admin/status');
  }

  setPanelCode(code) {
    return this.request('/api/server/panel-code', { method: 'POST', body: { code } });
  }

  serverUsers() {
    return this.request('/api/server/users');
  }

  addUser(payload) {
    return this.request('/api/server/users', { method: 'POST', body: payload });
  }

  updateUser(id, changes) {
    return this.request(`/api/server/users/${encodeURIComponent(id)}`, { method: 'PATCH', body: changes });
  }

  rotateUserSecret(id) {
    return this.request(`/api/server/users/${encodeURIComponent(id)}/rotate`, { method: 'POST', body: {} });
  }

  deleteUser(id) {
    return this.request(`/api/server/users/${encodeURIComponent(id)}`, { method: 'DELETE' });
  }

  saveConfig(patch) {
    return this.request('/api/config', { method: 'POST', body: patch });
  }

  resetConfig() {
    return this.request('/api/config/reset', { method: 'POST', body: {} });
  }

  refreshHardware() {
    return this.request('/api/hardware/refresh', { method: 'POST', body: {} });
  }

  applyPreset(tier, modalities, download = true) {
    return this.request(`/api/presets/${encodeURIComponent(tier)}/apply`, {
      method: 'POST',
      body: { modalities, download },
    });
  }

  applyCustomPreset() {
    return this.request('/api/presets/custom', { method: 'POST', body: {} });
  }

  saveCustomPreset(payload) {
    return this.request('/api/presets/saved', { method: 'POST', body: payload });
  }

  deleteCustomPreset(id) {
    return this.request(`/api/presets/saved/${encodeURIComponent(id)}`, { method: 'DELETE' });
  }

  importCustomModel(payload) {
    return this.request('/api/models/custom', { method: 'POST', body: payload });
  }

  deleteCustomModel(id) {
    return this.request(`/api/models/custom/${encodeURIComponent(id)}`, { method: 'DELETE' });
  }

  hfSearch(query, limit = 12) {
    return this.request(`/api/hf/search?q=${encodeURIComponent(query)}&limit=${limit}`);
  }

  hfPreview(repo) {
    return this.request(`/api/hf/preview?repo=${encodeURIComponent(repo)}`);
  }

  hfImport(repo, download = true) {
    return this.request('/api/hf/import', { method: 'POST', body: { repo, download } });
  }

  installModel(id) {
    return this.request(`/api/models/${encodeURIComponent(id)}/install`, { method: 'POST', body: {} });
  }

  unloadModel(id) {
    return this.request(`/api/models/${encodeURIComponent(id)}/unload`, { method: 'POST', body: {} });
  }

  installVoice(id) {
    return this.request(`/api/voices/${encodeURIComponent(id)}/install`, { method: 'POST', body: {} });
  }

  installSTT(id) {
    return this.request(`/api/stt/${encodeURIComponent(id)}/install`, { method: 'POST', body: {} });
  }

  installRuntime(name) {
    return this.request(`/api/runtimes/${encodeURIComponent(name)}/install`, { method: 'POST', body: {} });
  }

  startRuntime(name) {
    return this.request(`/api/runtimes/${encodeURIComponent(name)}/start`, { method: 'POST', body: {} });
  }

  stopRuntime(name) {
    return this.request(`/api/runtimes/${encodeURIComponent(name)}/stop`, { method: 'POST', body: {} });
  }

  runtimeLogs(name, lines = 300) {
    return this.request(`/api/runtimes/${encodeURIComponent(name)}/logs?lines=${lines}`);
  }

  startServer() {
    return this.request('/api/server/start', { method: 'POST', body: {} });
  }

  stopServer() {
    return this.request('/api/server/stop', { method: 'POST', body: {} });
  }

  jobs(includeLogs = false) {
    return this.request(`/api/jobs?include_logs=${includeLogs ? 'true' : 'false'}`);
  }

  job(id) {
    return this.request(`/api/jobs/${encodeURIComponent(id)}`);
  }

  cancelJob(id) {
    return this.request(`/api/jobs/${encodeURIComponent(id)}/cancel`, { method: 'POST', body: {} });
  }

  chats(query = '') {
    return this.request(`/api/chats?q=${encodeURIComponent(query)}`);
  }

  createChat(title = '') {
    return this.request('/api/chats', { method: 'POST', body: title ? { title } : {} });
  }

  getChat(id) {
    return this.request(`/api/chats/${encodeURIComponent(id)}`);
  }

  renameChat(id, title) {
    return this.request(`/api/chats/${encodeURIComponent(id)}`, { method: 'PATCH', body: { title } });
  }

  deleteChat(id) {
    return this.request(`/api/chats/${encodeURIComponent(id)}`, { method: 'DELETE' });
  }

  stopChat(id) {
    return this.request(`/api/chats/${encodeURIComponent(id)}/stop`, { method: 'POST', body: {} });
  }

  exportUrl(id, fmt = 'markdown') {
    return `/api/chats/${encodeURIComponent(id)}/export?fmt=${encodeURIComponent(fmt)}`;
  }

  upload(file) {
    const form = new FormData();
    form.append('file', file);
    return this.request('/api/uploads', { method: 'POST', body: form });
  }

  generate(body) {
    return this.request('/api/generate', { method: 'POST', body });
  }

  tts(text, voice) {
    return this.request('/api/audio/tts', { method: 'POST', body: { text, voice } });
  }

  transcribe(attachmentId) {
    return this.request('/api/audio/transcribe', { method: 'POST', body: { attachment_id: attachmentId } });
  }

  async *stream(path, body, signal) {
    if (this.remote && path.startsWith('/api/')) {
      let buffered = '';
      const frames = [];
      await remoteStream(this.remote, path, {
        method: 'POST',
        body,
        signal,
        onChunk: (chunk) => frames.push(chunk),
      });
      buffered = frames.join('');
      for (const frame of buffered.split('\n\n')) {
        const parsed = parseSSEFrame(frame);
        if (parsed) yield parsed;
      }
      return;
    }
    const makeHeaders = () => {
      const headers = { 'Content-Type': 'application/json', Accept: 'text/event-stream' };
      if (this.token) headers['X-Hearth-Token'] = this.token;
      return headers;
    };
    const send = () =>
      fetch(path, {
        method: 'POST',
        headers: makeHeaders(),
        body: JSON.stringify(body),
        credentials: 'same-origin',
        signal,
      });
    let response = await send();
    if (response.status === 403) {
      await this.fetchState();
      response = await send();
    }
    if (!response.ok) {
      let detail = '';
      try {
        const data = await response.json();
        detail = data.detail || data.error || JSON.stringify(data);
      } catch {
        detail = await response.text().catch(() => '');
      }
      throw new ApiError(detail || `HTTP ${response.status}`, response.status, detail);
    }
    if (!response.body) throw new ApiError('This browser cannot read streaming responses.');
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let index;
        while ((index = buffer.indexOf('\n\n')) >= 0) {
          const frame = buffer.slice(0, index);
          buffer = buffer.slice(index + 2);
          const event = parseSSEFrame(frame);
          if (event) yield event;
        }
      }
      if (buffer.trim()) {
        const event = parseSSEFrame(buffer);
        if (event) yield event;
      }
    } finally {
      reader.releaseLock();
    }
  }

  streamChat(chatId, body, signal) {
    return this.stream(`/api/chats/${encodeURIComponent(chatId)}/messages`, body, signal);
  }

  streamRegenerate(chatId, body, signal) {
    return this.stream(`/api/chats/${encodeURIComponent(chatId)}/regenerate`, body, signal);
  }
}

function parseSSEFrame(frame) {
  let eventName = 'message';
  const dataLines = [];
  for (const line of frame.split('\n')) {
    if (line.startsWith('event:')) eventName = line.slice(6).trim();
    else if (line.startsWith('data:')) dataLines.push(line.slice(5).trimStart());
  }
  if (!dataLines.length) return null;
  const raw = dataLines.join('\n');
  try {
    const data = JSON.parse(raw);
    return { ...data, type: data.type || eventName };
  } catch {
    return { type: eventName, text: raw };
  }
}

export const api = new HearthAPI();
