package dev.hearth.client;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

import android.widget.ImageView;

/**
 * An ImageView you can pinch, drag and double-tap. Kept deliberately small: a
 * Matrix plus two gesture detectors, no external library.
 */
public class ZoomableImageView extends ImageView {

    private final Matrix matrix = new Matrix();
    private final float[] values = new float[9];
    private final PointF last = new PointF();
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector tapDetector;
    private float scale = 1f;
    private float baseScale = 1f;
    private float translateX;
    private float translateY;
    private int lastPointerCount;

    public ZoomableImageView(Context context) {
        this(context, null);
    }

    public ZoomableImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setScaleType(ScaleType.MATRIX);
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float factor = detector.getScaleFactor();
                float target = Math.max(baseScale, Math.min(scale * factor, baseScale * 6f));
                factor = target / scale;
                scale = target;
                matrix.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                constrain();
                setImageMatrix(matrix);
                return true;
            }
        });
        tapDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent event) {
                if (scale > baseScale * 1.2f) {
                    reset();
                } else {
                    matrix.postScale(2.5f, 2.5f, event.getX(), event.getY());
                    scale = baseScale * 2.5f;
                    constrain();
                    setImageMatrix(matrix);
                }
                return true;
            }
        });
    }

    /** Fit the image inside the view, centred. */
    public void reset() {
        if (getDrawable() == null) return;
        float viewWidth = getWidth();
        float viewHeight = getHeight();
        float drawableWidth = getDrawable().getIntrinsicWidth();
        float drawableHeight = getDrawable().getIntrinsicHeight();
        if (drawableWidth <= 0 || drawableHeight <= 0 || viewWidth <= 0 || viewHeight <= 0) return;
        baseScale = Math.min(viewWidth / drawableWidth, viewHeight / drawableHeight);
        scale = baseScale;
        translateX = 0f;
        translateY = 0f;
        matrix.reset();
        matrix.postScale(scale, scale);
        matrix.postTranslate((viewWidth - drawableWidth * scale) / 2f, (viewHeight - drawableHeight * scale) / 2f);
        constrain();
        setImageMatrix(matrix);
    }

    private void constrain() {
        matrix.getValues(values);
        float currentScale = values[Matrix.MSCALE_X];
        float drawableWidth = getDrawable() == null ? 0 : getDrawable().getIntrinsicWidth() * currentScale;
        float drawableHeight = getDrawable() == null ? 0 : getDrawable().getIntrinsicHeight() * currentScale;
        float width = getWidth();
        float height = getHeight();
        float x = values[Matrix.MTRANS_X];
        float y = values[Matrix.MTRANS_Y];
        float dx = 0f;
        float dy = 0f;
        if (drawableWidth <= width) {
            dx = (width - drawableWidth) / 2f - x;
        } else if (x > 0) {
            dx = -x;
        } else if (x + drawableWidth < width) {
            dx = width - (x + drawableWidth);
        }
        if (drawableHeight <= height) {
            dy = (height - drawableHeight) / 2f - y;
        } else if (y > 0) {
            dy = -y;
        } else if (y + drawableHeight < height) {
            dy = height - (y + drawableHeight);
        }
        matrix.postTranslate(dx, dy);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        tapDetector.onTouchEvent(event);
        int pointerCount = event.getPointerCount();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                last.set(event.getX(), event.getY());
                break;
            case MotionEvent.ACTION_MOVE:
                if (pointerCount == 1 && scale > baseScale * 1.01f) {
                    float dx = event.getX() - last.x;
                    float dy = event.getY() - last.y;
                    matrix.postTranslate(dx, dy);
                    constrain();
                    setImageMatrix(matrix);
                }
                last.set(event.getX(), event.getY());
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                lastPointerCount = 0;
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        reset();
    }
}
