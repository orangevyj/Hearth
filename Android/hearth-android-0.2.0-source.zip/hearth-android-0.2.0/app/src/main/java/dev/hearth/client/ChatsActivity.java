package dev.hearth.client;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The chats this account owns on the server. */
public class ChatsActivity extends Activity {

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Map<String, Object>> chats = new ArrayList<>();

    private ListView list;
    private TextView empty;
    private TextView title;
    private TextView subtitle;
    private ProgressBar progress;
    private Session session;
    private ChatAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chats);
        Insets.apply(findViewById(R.id.root));

        list = findViewById(R.id.list);
        empty = findViewById(R.id.empty);
        title = findViewById(R.id.title);
        subtitle = findViewById(R.id.subtitle);
        progress = findViewById(R.id.progress);

        session = Session.load(this);
        if (session == null) {
            finish();
            return;
        }
        title.setText("Chats");
        subtitle.setText(session.user + " · " + shortAddress(session.address));

        adapter = new ChatAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> openChat(chats.get(position)));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            confirmDelete(chats.get(position));
            return true;
        });

        findViewById(R.id.new_chat).setOnClickListener(view -> newChat());
        findViewById(R.id.menu).setOnClickListener(this::openMenu);
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (session != null) load();
    }

    private static String shortAddress(String address) {
        return address.replace("http://", "").replace("https://", "");
    }

    private void load() {
        progress.setVisibility(View.VISIBLE);
        empty.setVisibility(View.GONE);
        worker.execute(() -> {
            try {
                HearthClient client = session.client();
                HearthClient.Response response = client.call("/api/chats", "GET", null);
                if (response.status != 200) throw new IllegalStateException(response.body);
                Object items = response.json().get("chats");
                List<Map<String, Object>> parsed = new ArrayList<>();
                if (items instanceof List) {
                    for (Object item : (List<?>) items) {
                        if (item instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> chat = (Map<String, Object>) item;
                            parsed.add(chat);
                        }
                    }
                }
                main.post(() -> {
                    chats.clear();
                    chats.addAll(parsed);
                    adapter.notifyDataSetChanged();
                    progress.setVisibility(View.GONE);
                    empty.setVisibility(chats.isEmpty() ? View.VISIBLE : View.GONE);
                });
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                main.post(() -> {
                    progress.setVisibility(View.GONE);
                    empty.setVisibility(View.VISIBLE);
                    empty.setText("Could not load chats: " + message);
                });
            }
        });
    }

    private void newChat() {
        progress.setVisibility(View.VISIBLE);
        worker.execute(() -> {
            try {
                HearthClient client = session.client();
                HearthClient.Response response = client.call("/api/chats", "POST", new java.util.LinkedHashMap<>());
                if (response.status != 200) throw new IllegalStateException(response.body);
                Object id = response.json().get("id");
                if (id == null) throw new IllegalStateException("The server did not return a chat id");
                main.post(() -> {
                    progress.setVisibility(View.GONE);
                    openChatId(String.valueOf(id), "New chat");
                });
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                main.post(() -> {
                    progress.setVisibility(View.GONE);
                    toast("Could not start a chat: " + message);
                });
            }
        });
    }

    private void openChat(Map<String, Object> chat) {
        Object id = chat.get("id");
        if (id == null) return;
        Object name = chat.get("title");
        openChatId(String.valueOf(id), name == null ? "Chat" : String.valueOf(name));
    }

    private void openChatId(String chatId, String name) {
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra("chat_id", chatId);
        intent.putExtra("chat_title", name);
        startActivity(intent);
    }

    private void confirmDelete(Map<String, Object> chat) {
        Object id = chat.get("id");
        if (id == null) return;
        Object name = chat.get("title");
        new AlertDialog.Builder(this)
                .setTitle("Delete chat?")
                .setMessage("“" + (name == null ? "Chat" : name) + "” and its messages will be removed from the server.")
                .setPositiveButton("Delete", (dialog, which) -> deleteChat(String.valueOf(id)))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteChat(String chatId) {
        worker.execute(() -> {
            try {
                HearthClient client = session.client();
                HearthClient.Response response = client.call("/api/chats/" + chatId, "DELETE", null);
                if (response.status >= 400) throw new IllegalStateException(response.body);
                main.post(this::load);
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                main.post(() -> toast("Could not delete: " + message));
            }
        });
    }

    private void openMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Refresh");
        menu.getMenu().add("Disconnect");
        menu.setOnMenuItemClickListener(item -> {
            String label = String.valueOf(item.getTitle());
            if (label.startsWith("Refresh")) {
                load();
            } else if (label.startsWith("Disconnect")) {
                Session.clear(this);
                finish();
            }
            return true;
        });
        menu.show();
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private class ChatAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return chats.size();
        }

        @Override
        public Object getItem(int position) {
            return chats.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView != null ? convertView : getLayoutInflater().inflate(R.layout.chat_row, parent, false);
            Map<String, Object> chat = chats.get(position);
            TextView titleView = row.findViewById(R.id.row_title);
            TextView previewView = row.findViewById(R.id.row_preview);
            TextView metaView = row.findViewById(R.id.row_meta);

            Object title = chat.get("title");
            titleView.setText(title == null ? "Chat" : String.valueOf(title));

            Object preview = chat.get("preview");
            String previewText = preview == null ? "" : String.valueOf(preview).trim();
            previewView.setText(previewText.isEmpty() ? "No messages yet" : previewText);

            Object count = chat.get("message_count");
            Object updated = chat.get("updated_at");
            String when = "";
            if (updated != null) {
                String raw = String.valueOf(updated);
                when = raw;
                for (String pattern : new String[]{"yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss"}) {
                    try {
                        java.text.SimpleDateFormat parser = new java.text.SimpleDateFormat(pattern, java.util.Locale.US);
                        Date date = parser.parse(raw);
                        if (date != null) {
                            when = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(date);
                            break;
                        }
                    } catch (java.text.ParseException ignored) {
                        // try the next pattern
                    }
                }
            }
            String messages = count == null ? "" : (int) Double.parseDouble(String.valueOf(count)) + " messages";
            metaView.setText(when.isEmpty() ? messages : when + " · " + messages);
            return row;
        }
    }
}
