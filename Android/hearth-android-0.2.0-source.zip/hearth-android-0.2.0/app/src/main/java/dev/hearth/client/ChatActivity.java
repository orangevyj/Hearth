package dev.hearth.client;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.format.DateFormat;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Chat, attachments and media generation against a remote Hearth.
 *
 * Messages wrap inside a bounded bubble; media arrives as cards. Everything is
 * decrypted locally, so nothing needs an unauthenticated download URL.
 */
public class ChatActivity extends Activity {

    private static final int REQUEST_FILE = 11;
    private static final int MAX_UPLOAD = 100 * 1024 * 1024;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Map<String, Object>> pending = new ArrayList<>();

    private LinearLayout messages;
    private ScrollView scroll;
    private EditText input;
    private Button send;
    private Button attachButton;
    private Button generateButton;
    private TextView title;
    private TextView subtitle;
    private TextView pendingLabel;

    private Session session;
    private HearthClient client;
    private Map<String, Object> capabilities = new LinkedHashMap<>();
    private String chatId;
    private boolean streaming;
    private boolean reasoning;
    private TextView activeBubble;
    private final StringBuilder activeText = new StringBuilder();
    private MediaPlayer player;
    private ObjectAnimator typingAnimator;
    private View workingCard;
    private int bubbleMaxWidth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        Insets.apply(findViewById(R.id.root));

        messages = findViewById(R.id.messages);
        scroll = findViewById(R.id.scroll);
        input = findViewById(R.id.input);
        send = findViewById(R.id.send);
        attachButton = findViewById(R.id.attach);
        generateButton = findViewById(R.id.generate);
        title = findViewById(R.id.title);
        subtitle = findViewById(R.id.subtitle);
        pendingLabel = findViewById(R.id.pending);

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        bubbleMaxWidth = (int) (screenWidth * 0.82f);

        session = Session.load(this);
        if (session == null) {
            finish();
            return;
        }
        chatId = getIntent().getStringExtra("chat_id");
        String incomingTitle = getIntent().getStringExtra("chat_title");
        title.setText(incomingTitle == null || incomingTitle.isEmpty() ? session.user : incomingTitle);
        subtitle.setText(shortAddress(session.address) + " · connecting…");

        findViewById(R.id.menu).setOnClickListener(this::openMenu);
        send.setOnClickListener(view -> sendMessage());
        attachButton.setOnClickListener(view -> pickFile());
        generateButton.setOnClickListener(view -> chooseModality());
        updateToolbar();

        worker.execute(() -> {
            try {
                HearthClient opened = session.client();
                HearthClient.Response state = opened.call("/api/state", "GET", null);
                if (state.status != 200) throw new IllegalStateException(state.body);
                Object caps = state.json().get("capabilities");
                if (caps instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> map = (Map<String, Object>) caps;
                    capabilities = map;
                }
                String resolved = chatId;
                if (resolved == null || resolved.isEmpty()) {
                    HearthClient.Response created = opened.call("/api/chats", "POST", new LinkedHashMap<>());
                    if (created.status != 200) throw new IllegalStateException(created.body);
                    Object id = created.json().get("id");
                    if (id == null) throw new IllegalStateException("The server did not return a chat id");
                    resolved = String.valueOf(id);
                }
                HearthClient.Response historyResponse = opened.call("/api/chats/" + resolved, "GET", null);
                Object historyMessages = historyResponse.status == 200 ? historyResponse.json().get("messages") : null;
                String finalChat = resolved;
                main.post(() -> {
                    client = opened;
                    chatId = finalChat;
                    subtitle.setText(shortAddress(session.address) + " · encrypted");
                    updateToolbar();
                    renderHistory(opened, historyMessages);
                });
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                main.post(() -> subtitle.setText("Offline — " + message));
            }
        });
    }

    private static String shortAddress(String address) {
        return address.replace("http://", "").replace("https://", "");
    }

    // -- capabilities ------------------------------------------------

    private boolean allowed(String key) {
        Object permissions = capabilities.get("permissions");
        if (!(permissions instanceof Map)) return true;
        @SuppressWarnings("unchecked")
        Map<String, Object> map = (Map<String, Object>) permissions;
        if ("attach".equals(key)) return Boolean.TRUE.equals(map.get("attachments"));
        if ("tools".equals(key)) return Boolean.TRUE.equals(map.get("tools"));
        if ("model".equals(key)) return Boolean.TRUE.equals(map.get("change_model"));
        if ("preset".equals(key)) return Boolean.TRUE.equals(map.get("change_preset"));
        Object media = map.get("media");
        return media instanceof Map && Boolean.TRUE.equals(((Map<?, ?>) media).get(key));
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> textModels() {
        Object value = capabilities.get("text_models");
        return value instanceof List ? (List<Map<String, Object>>) value : new ArrayList<>();
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> presets() {
        Object value = capabilities.get("presets");
        return value instanceof List ? (List<Map<String, Object>>) value : new ArrayList<>();
    }

    private boolean anyMedia() {
        for (String key : new String[]{"image", "video", "music", "three_d", "speech"}) {
            if (allowed(key)) return true;
        }
        return false;
    }

    private void updateToolbar() {
        setEnabled(attachButton, allowed("attach"));
        setEnabled(generateButton, anyMedia());
    }

    private static void setEnabled(View view, boolean enabled) {
        view.setEnabled(enabled);
        view.setAlpha(enabled ? 1f : 0.35f);
    }

    // -- menu --------------------------------------------------------

    private void openMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("All chats");
        menu.getMenu().add("New chat");
        boolean canModel = allowed("model") && !textModels().isEmpty();
        boolean canPreset = allowed("preset") && !presets().isEmpty();
        if (canModel) menu.getMenu().add("Text model…");
        if (canPreset) menu.getMenu().add("Apply preset…");
        menu.getMenu().add(reasoning ? "Reasoning: on" : "Reasoning: off");
        menu.getMenu().add("Disconnect");
        menu.setOnMenuItemClickListener(item -> {
            String label = String.valueOf(item.getTitle());
            if (label.startsWith("All chats")) {
                startActivity(new Intent(this, ChatsActivity.class));
                finish();
            } else if (label.startsWith("New chat")) {
                startActivity(new Intent(this, ChatActivity.class));
                finish();
            } else if (label.startsWith("Text model")) {
                chooseModel();
            } else if (label.startsWith("Apply preset")) {
                choosePreset();
            } else if (label.startsWith("Reasoning")) {
                reasoning = !reasoning;
                toast(reasoning ? "Reasoning on for the next message" : "Reasoning off");
            } else if (label.startsWith("Disconnect")) {
                disconnect();
            }
            return true;
        });
        menu.show();
    }

    // -- sending -----------------------------------------------------

    private void sendMessage() {
        String text = input.getText().toString().trim();
        if (text.isEmpty() || streaming) return;
        if (client == null || chatId == null) {
            toast("Still connecting…");
            return;
        }
        input.setText("");
        appendBubble(text, true);
        List<String> attachmentIds = new ArrayList<>();
        for (Map<String, Object> item : pending) attachmentIds.add(String.valueOf(item.get("id")));
        pending.clear();
        renderPending();

        activeText.setLength(0);
        activeBubble = appendTyping();
        streaming = true;
        send.setEnabled(false);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("content", text);
        body.put("tools", allowed("tools"));
        body.put("web", false);
        body.put("reasoning", reasoning);
        if (!attachmentIds.isEmpty()) body.put("attachment_ids", attachmentIds);

        HearthClient streamClient = client;
        String streamChat = chatId;
        worker.execute(() -> {
            try {
                streamClient.stream("/api/chats/" + streamChat + "/messages", body, event -> {
                    String type = String.valueOf(event.get("type"));
                    if ("delta".equals(type)) {
                        Object chunk = event.get("text");
                        if (chunk != null) {
                            activeText.append(chunk);
                            main.post(() -> {
                                stopTyping();
                                renderActive();
                            });
                        }
                    } else if ("error".equals(type)) {
                        Object error = event.get("error");
                        main.post(() -> {
                            activeText.append("\n\n[").append(error == null ? "error" : error).append("]");
                            renderActive();
                        });
                    } else if ("tool_start".equals(type)) {
                        Object name = event.get("name");
                        String label = String.valueOf(name).replace("generate_", "").replace('_', ' ');
                        main.post(() -> showWorking("Making " + label + "…"));
                    } else if ("tool_result".equals(type)) {
                        main.post(this::hideWorking);
                        // A tool that produced media (image, audio, 3D) hands back
                        // attachments; show them instead of dropping them.
                        Object name = event.get("name");
                        Object attachments = event.get("attachments");
                        Object toolError = event.get("error");
                        if (attachments instanceof List && !((List<?>) attachments).isEmpty()) {
                            for (Object item : (List<?>) attachments) {
                                if (item instanceof Map) {
                                    @SuppressWarnings("unchecked")
                                    Map<String, Object> attachment = (Map<String, Object>) item;
                                    main.post(() -> showAttachment(streamClient, attachment));
                                }
                            }
                        } else if (toolError != null && !String.valueOf(toolError).isEmpty()) {
                            String note = name + " failed: " + toolError;
                            main.post(() -> appendNote(note));
                        }
                    } else if ("tool_start".equals(type)) {
                        Object name = event.get("name");
                        if (name != null && String.valueOf(name).startsWith("generate_")) {
                            String label = String.valueOf(name).replace("generate_", "").replace('_', ' ');
                            main.post(() -> subtitle.setText(shortAddress(session.address) + " · making " + label + "…"));
                        }
                    }
                });
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                main.post(() -> {
                    activeText.append(activeText.length() == 0 ? "" : "\n\n").append("[").append(message).append("]");
                    renderActive();
                });
            } finally {
                main.post(() -> {
                    streaming = false;
                    send.setEnabled(true);
                    stopTyping();
                    hideWorking();
                    if (activeText.length() == 0) activeText.append("(no reply)");
                    renderActive();
                    activeBubble = null;
                    subtitle.setText(shortAddress(session.address) + " · encrypted");
                });
            }
        });
        scrollToBottom(true);
    }

    private void renderActive() {
        if (activeBubble != null) {
            activeBubble.setText(activeText.toString().trim());
            scrollToBottom(true);
        }
    }

    // -- message views -----------------------------------------------

    private TextView appendBubble(String text, boolean mine) {
        LinearLayout wrapper = new LinearLayout(this);
        LinearLayout.LayoutParams wrapperParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        wrapperParams.topMargin = dp(4);
        wrapper.setLayoutParams(wrapperParams);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setGravity(mine ? Gravity.END : Gravity.START);

        TextView bubble = new TextView(this);
        bubble.setText(text);
        bubble.setTextSize(15);
        bubble.setLineSpacing(dp(2), 1f);
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10));
        bubble.setTextColor(getColor(mine ? R.color.hearth_on_accent : R.color.hearth_text));
        bubble.setBackgroundResource(mine ? R.drawable.bubble_out : R.drawable.bubble_in);
        bubble.setHorizontallyScrolling(false);
        bubble.setSingleLine(false);
        bubble.setMaxWidth(bubbleMaxWidth);
        bubble.setTextIsSelectable(true);
        if (text != null && text.contains("<tool_call>")) bubble.setText(text.replace("<tool_call>", ""));

        TextView stamp = new TextView(this);
        stamp.setText(DateFormat.getTimeFormat(this).format(new Date()));
        stamp.setTextSize(10);
        stamp.setTextColor(getColor(R.color.hearth_muted));
        stamp.setPadding(dp(6), dp(2), dp(6), 0);

        wrapper.addView(bubble);
        wrapper.addView(stamp);
        messages.addView(wrapper);
        scrollToBottom(true);
        return bubble;
    }

    private void appendMediaCard(View content, String caption) {
        LinearLayout card = new LinearLayout(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.topMargin = dp(8);
        card.setLayoutParams(cardParams);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bubble_media);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        // LinearLayout has no max-width; the children are bounded instead (the
        // image is sized and text children get setMaxWidth).
        card.addView(content);

        if (caption != null && !caption.isEmpty()) {
            TextView label = new TextView(this);
            label.setText(caption);
            label.setTextSize(11);
            label.setTextColor(getColor(R.color.hearth_muted));
            label.setPadding(dp(4), dp(6), dp(4), 0);
            card.addView(label);
        }

        LinearLayout row = new LinearLayout(this);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.topMargin = dp(4);
        row.setLayoutParams(rowParams);
        row.setGravity(Gravity.START);
        row.addView(card);
        messages.addView(row);
        scrollToBottom(true);
    }

    private void appendImage(byte[] bytes, String name, String mime) {
        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        if (bitmap == null) {
            appendNote("Could not decode " + name);
            return;
        }
        ImageView view = new ImageView(this);
        view.setImageBitmap(bitmap);
        view.setAdjustViewBounds(true);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int width = Math.min(bubbleMaxWidth - dp(20), bitmap.getWidth() * 2);
        int height = (int) ((float) width * bitmap.getHeight() / bitmap.getWidth());
        view.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        GradientDrawable rounded = new GradientDrawable();
        rounded.setCornerRadius(dp(12));
        rounded.setColor(Color.TRANSPARENT);
        view.setBackground(rounded);
        view.setClipToOutline(true);
        view.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View target, Outline outline) {
                outline.setRoundRect(0, 0, target.getWidth(), target.getHeight(), dp(12));
            }
        });
        view.setOnClickListener(v -> MediaViewer.show(this, bytes, name, mime));
        appendMediaCard(view, name + " · tap to open");
    }

    private void appendNote(String text) {
        TextView note = new TextView(this);
        note.setText(text);
        note.setTextSize(12);
        note.setTextColor(getColor(R.color.hearth_muted));
        note.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.START);
        row.addView(note);
        messages.addView(row);
        scrollToBottom(true);
    }

    private void scrollToBottom(boolean force) {
        scroll.post(() -> {
            View child = scroll.getChildAt(0);
            if (child == null) return;
            int distance = child.getBottom() - (scroll.getHeight() + scroll.getScrollY());
            // Keep the reader where they are unless they are already at the end.
            if (force || distance < dp(160)) scroll.fullScroll(View.FOCUS_DOWN);
        });
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    // -- attachments -------------------------------------------------

    private void pickFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "image/*", "audio/*", "video/*", "application/octet-stream", "model/*"});
        startActivityForResult(intent, REQUEST_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FILE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String name = displayName(uri);
        String mime = getContentResolver().getType(uri);
        toast("Uploading " + name + "…");
        HearthClient uploadClient = client;
        worker.execute(() -> {
            try {
                byte[] bytes = readUri(uri);
                if (bytes.length == 0) throw new IOException("That file is empty");
                if (bytes.length > MAX_UPLOAD) throw new IOException("Files larger than 100 MB are not supported");
                Map<String, Object> attachment = uploadClient.upload(bytes, name, mime);
                pending.add(attachment);
                main.post(() -> {
                    renderPending();
                    toast("Attached " + name);
                });
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                main.post(() -> toast("Upload failed: " + message));
            }
        });
    }

    private String displayName(Uri uri) {
        try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (RuntimeException ignored) {
            // fall through
        }
        return "upload.bin";
    }

    private byte[] readUri(Uri uri) throws IOException {
        try (InputStream stream = getContentResolver().openInputStream(uri)) {
            if (stream == null) throw new IOException("Could not open that file");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int read;
            while ((read = stream.read(buffer)) >= 0) out.write(buffer, 0, read);
            return out.toByteArray();
        }
    }

    private void renderPending() {
        if (pending.isEmpty()) {
            pendingLabel.setVisibility(View.GONE);
            return;
        }
        StringBuilder text = new StringBuilder("Attached: ");
        for (int index = 0; index < pending.size(); index++) {
            if (index > 0) text.append(", ");
            text.append(pending.get(index).get("filename"));
        }
        pendingLabel.setText(text.toString());
        pendingLabel.setVisibility(View.VISIBLE);
    }

    // -- media generation --------------------------------------------

    private void chooseModality() {
        final String[] keys = {"image", "video", "music", "3d", "speech"};
        final String[] labels = {"Image", "Video", "Music", "3D model", "Speech"};
        List<String> allowedLabels = new ArrayList<>();
        List<String> allowedKeys = new ArrayList<>();
        for (int index = 0; index < keys.length; index++) {
            String permissionKey = "3d".equals(keys[index]) ? "three_d" : keys[index];
            if (allowed(permissionKey)) {
                allowedLabels.add(labels[index]);
                allowedKeys.add(keys[index]);
            }
        }
        if (allowedKeys.isEmpty()) {
            toast("The server does not allow media generation for this account.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Generate")
                .setItems(allowedLabels.toArray(new String[0]), (dialog, which) -> promptFor(allowedKeys.get(which)))
                .show();
    }

    private void promptFor(String modality) {
        final EditText field = new EditText(this);
        field.setHint("Describe what to make…");
        field.setPadding(dp(16), dp(12), dp(16), dp(12));
        new AlertDialog.Builder(this)
                .setTitle("Generate " + modality)
                .setView(field)
                .setPositiveButton("Generate", (dialog, which) -> {
                    String prompt = field.getText().toString().trim();
                    if (prompt.isEmpty()) {
                        toast("Write a prompt first.");
                        return;
                    }
                    startGeneration(modality, prompt);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startGeneration(String modality, String prompt) {
        HearthClient genClient = client;
        String genChat = chatId;
        subtitle.setText(shortAddress(session.address) + " · generating " + modality + "…");
        final TextView bubble = appendBubble("Generating " + modality + "…", false);

        worker.execute(() -> {
            try {
                Map<String, Object> body = new LinkedHashMap<>();
                body.put("modality", modality);
                body.put("prompt", prompt);
                body.put("chat_id", genChat);
                Object jobId = genClient.generate(body).get("job_id");
                if (jobId == null) throw new IOException("The server did not return a job");
                String status = "running";
                String error = "";
                for (int attempt = 0; attempt < 1200; attempt++) {
                    Thread.sleep(1500);
                    Map<String, Object> job = genClient.job(String.valueOf(jobId));
                    status = String.valueOf(job.get("status"));
                    if (job.get("error") != null) error = String.valueOf(job.get("error"));
                    if ("done".equals(status) || "error".equals(status) || "canceled".equals(status)) break;
                }
                if (!"done".equals(status)) {
                    throw new IOException(error.isEmpty() ? "Generation " + status : error);
                }
                List<Map<String, Object>> produced = latestAttachments(genClient, genChat);
                main.post(() -> {
                    subtitle.setText(shortAddress(session.address) + " · encrypted");
                    bubble.setText(produced.isEmpty() ? "Done." : "Here it is:");
                });
                for (Map<String, Object> attachment : produced) {
                    showAttachment(genClient, attachment);
                }
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                main.post(() -> {
                    subtitle.setText(shortAddress(session.address) + " · encrypted");
                    bubble.setText("Generation failed: " + message);
                });
            }
        });
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> latestAttachments(HearthClient genClient, String genChat) throws Exception {
        HearthClient.Response response = genClient.call("/api/chats/" + genChat, "GET", null);
        if (response.status != 200) return new ArrayList<>();
        Object list = response.json().get("messages");
        if (!(list instanceof List)) return new ArrayList<>();
        List<Map<String, Object>> all = (List<Map<String, Object>>) list;
        for (int index = all.size() - 1; index >= 0; index--) {
            Object attachments = all.get(index).get("attachments");
            if (attachments instanceof List && !((List<?>) attachments).isEmpty()) {
                List<Map<String, Object>> produced = new ArrayList<>();
                for (Object item : (List<?>) attachments) {
                    if (item instanceof Map) produced.add((Map<String, Object>) item);
                }
                return produced;
            }
        }
        return new ArrayList<>();
    }

    private void showAttachment(HearthClient genClient, Map<String, Object> attachment) {
        Object url = attachment.get("url");
        Object filename = attachment.get("filename");
        Object kind = attachment.get("kind");
        if (url == null) return;
        worker.execute(() -> {
            try {
                Map<String, Object> file = genClient.readMedia(String.valueOf(url));
                byte[] bytes = Base64.decode(String.valueOf(file.get("data")), Base64.DEFAULT);
                String mime = String.valueOf(file.get("mime"));
                String name = String.valueOf(file.get("filename"));
                if ("image".equals(String.valueOf(kind)) || mime.startsWith("image/")) {
                    main.post(() -> appendImage(bytes, name, mime));
                    return;
                }
                File saved = new File(getFilesDir(), name);
                try (FileOutputStream out = new FileOutputStream(saved)) {
                    out.write(bytes);
                }
                main.post(() -> appendFileCard(saved, name, mime, bytes.length));
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                main.post(() -> appendNote("Could not fetch " + filename + ": " + message));
            }
        });
    }

    private void appendFileCard(File saved, String name, String mime, int size) {
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextSize(13);
        label.setTextColor(getColor(R.color.hearth_text));
        label.setMaxWidth(bubbleMaxWidth - dp(24));
        label.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        label.setSingleLine(true);
        column.addView(label);

        TextView details = new TextView(this);
        details.setText((size / 1024) + " KB · " + mime);
        details.setTextSize(11);
        details.setTextColor(getColor(R.color.hearth_muted));
        column.addView(details);

        Button preview = new Button(this);
        preview.setText("Preview");
        preview.setAllCaps(false);
        preview.setTextSize(12);
        preview.setBackgroundResource(R.drawable.field_bg);
        preview.setTextColor(getColor(R.color.hearth_text));
        preview.setOnClickListener(v -> openWithBytes(saved, name, mime, true));
        column.addView(preview);

        Button save = new Button(this);
        save.setText("Save");
        save.setAllCaps(false);
        save.setTextSize(12);
        save.setBackgroundResource(R.drawable.field_bg);
        save.setTextColor(getColor(R.color.hearth_text));
        save.setOnClickListener(v -> openWithBytes(saved, name, mime, false));
        column.addView(save);

        appendMediaCard(column, null);
    }

    private void openWithBytes(File file, String name, String mime, boolean preview) {
        worker.execute(() -> {
            try {
                byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
                main.post(() -> {
                    if (preview) {
                        MediaViewer.show(this, bytes, name, mime);
                    } else {
                        Downloads.save(this, bytes, name, mime);
                    }
                });
            } catch (Exception exc) {
                main.post(() -> toast("Could not read that file back"));
            }
        });
    }

    private TextView appendTyping() {
        TextView bubble = appendBubble("●", false);
        typingAnimator = ObjectAnimator.ofFloat(bubble, "alpha", 1f, 0.2f);
        typingAnimator.setDuration(650);
        typingAnimator.setRepeatMode(ObjectAnimator.REVERSE);
        typingAnimator.setRepeatCount(ObjectAnimator.INFINITE);
        typingAnimator.start();
        return bubble;
    }

    private void stopTyping() {
        if (typingAnimator != null) {
            typingAnimator.cancel();
            typingAnimator = null;
        }
    }

    private void showWorking(String label) {
        hideWorking();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.START);
        TextView text = new TextView(this);
        text.setText("◐ " + label);
        text.setTextSize(12);
        text.setTextColor(getColor(R.color.hearth_accent));
        text.setPadding(dp(14), dp(8), dp(14), dp(8));
        text.setBackgroundResource(R.drawable.bubble_media);
        ObjectAnimator pulse = ObjectAnimator.ofFloat(text, "alpha", 1f, 0.35f);
        pulse.setDuration(650);
        pulse.setRepeatMode(ObjectAnimator.REVERSE);
        pulse.setRepeatCount(ObjectAnimator.INFINITE);
        pulse.start();
        row.addView(text);
        messages.addView(row);
        workingCard = row;
        scrollToBottom(false);
    }

    private void hideWorking() {
        if (workingCard != null) {
            messages.removeView(workingCard);
            workingCard = null;
        }
    }

    @SuppressWarnings("unchecked")
    private void renderHistory(HearthClient opened, Object history) {
        if (!(history instanceof List)) return;
        for (Object item : (List<?>) history) {
            if (!(item instanceof Map)) continue;
            Map<String, Object> message = (Map<String, Object>) item;
            String role = String.valueOf(message.get("role"));
            if ("system".equals(role)) continue;
            String content = message.get("content") == null ? "" : String.valueOf(message.get("content"));
            if (!content.trim().isEmpty()) appendBubble(content, "user".equals(role));
            Object attachments = message.get("attachments");
            if (attachments instanceof List) {
                for (Object raw : (List<?>) attachments) {
                    if (!(raw instanceof Map)) continue;
                    Map<String, Object> attachment = (Map<String, Object>) raw;
                    Button load = new Button(this);
                    load.setText("Show " + attachment.get("kind") + " · " + attachment.get("filename"));
                    load.setAllCaps(false);
                    load.setTextSize(12);
                    load.setBackgroundResource(R.drawable.field_bg);
                    load.setTextColor(getColor(R.color.hearth_text));
                    load.setOnClickListener(view -> {
                        load.setEnabled(false);
                        load.setText("Loading…");
                        showAttachment(opened, attachment);
                    });
                    appendMediaCard(load, null);
                }
            }
        }
        scrollToBottom(true);
    }

    // -- model and preset --------------------------------------------

    private void chooseModel() {
        List<Map<String, Object>> models = textModels();
        if (models.isEmpty()) {
            toast("The server does not allow changing the model.");
            return;
        }
        List<String> labels = new ArrayList<>();
        for (Map<String, Object> model : models) {
            Object name = model.get("name");
            labels.add(String.valueOf(name == null ? model.get("id") : name));
        }
        new AlertDialog.Builder(this)
                .setTitle("Text model")
                .setItems(labels.toArray(new String[0]), (dialog, which) -> {
                    Object id = models.get(which).get("id");
                    if (id == null) return;
                    toast("Switching to " + labels.get(which) + "…");
                    worker.execute(() -> {
                        try {
                            client.setTextModel(String.valueOf(id));
                            main.post(() -> toast("Model set to " + labels.get(which)));
                        } catch (Exception exc) {
                            String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                            main.post(() -> toast("Could not switch: " + message));
                        }
                    });
                })
                .show();
    }

    private void choosePreset() {
        final List<Map<String, Object>> presets = presets();
        if (presets.isEmpty()) {
            toast("The server does not allow changing the preset.");
            return;
        }
        List<String> labels = new ArrayList<>();
        for (Map<String, Object> preset : presets) {
            Object name = preset.get("name");
            labels.add(String.valueOf(name == null ? preset.get("tier") : name));
        }
        new AlertDialog.Builder(this)
                .setTitle("Apply a preset")
                .setItems(labels.toArray(new String[0]), (dialog, which) -> {
                    Object tier = presets.get(which).get("tier");
                    if (tier == null) return;
                    toast("Applying " + labels.get(which) + "…");
                    worker.execute(() -> {
                        try {
                            client.applyPreset(String.valueOf(tier));
                            main.post(() -> toast("Preset applied: " + labels.get(which)));
                        } catch (Exception exc) {
                            String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                            main.post(() -> toast("Could not apply: " + message));
                        }
                    });
                })
                .show();
    }

    // -- housekeeping ------------------------------------------------

    private void disconnect() {
        Session.clear(this);
        finish();
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) player.release();
        worker.shutdownNow();
    }
}
