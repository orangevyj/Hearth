package dev.hearth.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;

/**
 * Talks to a Hearth server over the encrypted channel.
 *
 * Every request is sealed with the account key and posted to /api/secure/rpc;
 * responses are either one sealed JSON envelope or a series of sealed frames
 * carrying server-sent events.
 */
public final class HearthClient {

    /** Set from the activity, so the server can tell this build's age. */
    static String CLIENT_VERSION = "0.0.0";

    /** The server refuses clients older than the build it stores. */
    public static final class UpgradeRequired extends IOException {
        public final String clientVersion;
        public final String requiredVersion;
        public final String downloadUrl;

        UpgradeRequired(String detail, String clientVersion, String requiredVersion, String downloadUrl) {
            super(detail);
            this.clientVersion = clientVersion;
            this.requiredVersion = requiredVersion;
            this.downloadUrl = downloadUrl;
        }
    }

    private static Map<String, Object> upgradeFrom(String body) {
        try {
            return Json.parseObject(body == null ? "{}" : body);
        } catch (RuntimeException exc) {
            return new LinkedHashMap<>();
        }
    }

    public interface EventListener {
        void onEvent(Map<String, Object> event);
    }

    public static final class Response {
        public final int status;
        public final String contentType;
        public final String body;

        Response(int status, String contentType, String body) {
            this.status = status;
            this.contentType = contentType;
            this.body = body;
        }

        public Map<String, Object> json() {
            return Json.parseObject(body);
        }
    }

    private final String address;
    private final String user;
    private final String salt;
    private final SecretKeySpec key;

    public HearthClient(String address, String user, String secret, String salt) throws GeneralSecurityException {
        this.address = trimSlash(address);
        this.user = user;
        this.salt = salt;
        this.key = HearthCrypto.deriveKey(secret, salt);
    }

    public static String trimSlash(String value) {
        String out = value == null ? "" : value.trim();
        while (out.endsWith("/")) out = out.substring(0, out.length() - 1);
        return out;
    }

    /** Asks a server for its key salt. No account is needed for this. */
    public static String fetchSalt(String address) throws IOException, GeneralSecurityException {
        String url = trimSlash(address) + "/api/remote/salt";
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(15_000);
        connection.setRequestMethod("GET");
        try {
            int status = connection.getResponseCode();
            String body = readAll(status >= 400 ? connection.getErrorStream() : connection.getInputStream());
            if (status != 200) throw new IOException("That server did not answer (HTTP " + status + ")");
            Object salt = Json.parseObject(body).get("salt");
            if (salt == null) throw new IOException("That server did not return a key salt");
            return String.valueOf(salt);
        } finally {
            connection.disconnect();
        }
    }

    public Response call(String path, String method, Map<String, Object> body) throws IOException, GeneralSecurityException {
        Map<String, Object> inner = new LinkedHashMap<>();
        inner.put("method", method);
        inner.put("path", path);
        inner.put("body", body);
        String envelope = HearthCrypto.seal(key, Json.write(inner), user);

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("d", envelope);

        HttpURLConnection connection = (HttpURLConnection) new URL(address + "/api/secure/rpc").openConnection();
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(120_000);
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("X-Hearth-User", user);
        connection.setRequestProperty("X-Hearth-Client", "android/" + CLIENT_VERSION);
        connection.setDoOutput(true);
        try (OutputStream out = connection.getOutputStream()) {
            out.write(Json.write(payload).getBytes(StandardCharsets.UTF_8));
        }
        try {
            int status = connection.getResponseCode();
            String contentType = String.valueOf(connection.getContentType()).toLowerCase();
            String text = readAll(status >= 400 ? connection.getErrorStream() : connection.getInputStream());
            if (status == 426) {
                Map<String, Object> detail = upgradeFrom(text);
                throw new UpgradeRequired(
                        errorDetail(text, status),
                        String.valueOf(detail.getOrDefault("client_version", CLIENT_VERSION)),
                        String.valueOf(detail.getOrDefault("required_version", "")),
                        String.valueOf(detail.getOrDefault("download_url", "")));
            }
            if (status != 200) {
                throw new IOException(errorDetail(text, status));
            }
            if (contentType.contains("x-hearth-sealed")) {
                Map<String, Object> opened = Json.parseObject(HearthCrypto.open(key, text.trim(), user));
                if (opened.containsKey("status")) {
                    return new Response(
                            ((Number) opened.get("status")).intValue(),
                            String.valueOf(opened.get("content_type")),
                            opened.get("body") == null ? "" : String.valueOf(opened.get("body")));
                }
                return new Response(200, "application/json", Json.write(opened));
            }
            return new Response(status, contentType, text);
        } finally {
            connection.disconnect();
        }
    }

    /** Upload a file: the bytes travel base64 inside the sealed channel. */
    public Map<String, Object> upload(byte[] data, String filename, String mime)
            throws IOException, GeneralSecurityException {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("filename", filename == null ? "upload.bin" : filename);
        body.put("mime", mime == null ? "" : mime);
        body.put("data", HearthCrypto.base64(data));
        return ok(call("/api/uploads/encoded", "POST", body));
    }

    /** Read a generated file back through the channel. */
    public Map<String, Object> readMedia(String path) throws IOException, GeneralSecurityException {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("path", path);
        return ok(call("/api/media/read", "POST", body));
    }

    /** Start a generation job; the reply carries the job id. */
    public Map<String, Object> generate(Map<String, Object> body) throws IOException, GeneralSecurityException {
        return ok(call("/api/generate", "POST", body));
    }

    public Map<String, Object> job(String jobId) throws IOException, GeneralSecurityException {
        return ok(call("/api/jobs/" + jobId, "GET", null));
    }

    /** Adopt a preset's model mix. Downloads never start from a client. */
    public Map<String, Object> applyPreset(String tier) throws IOException, GeneralSecurityException {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("download", false);
        return ok(call("/api/presets/" + HearthClient.encode(tier) + "/apply", "POST", body));
    }

    public Map<String, Object> setTextModel(String model) throws IOException, GeneralSecurityException {
        Map<String, Object> text = new LinkedHashMap<>();
        text.put("model", model);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("text", text);
        return ok(call("/api/config", "POST", body));
    }

    private static Map<String, Object> ok(Response response) throws IOException {
        if (response.status >= 400) {
            String detail = errorDetail(response.body, response.status);
            throw new IOException(detail);
        }
        return response.json();
    }

    /**
     * Streaming call: decrypts each frame and hands the SSE events over as they
     * arrive. Runs on the calling thread, so callers use a background thread.
     */
    public void stream(String path, Map<String, Object> body, EventListener listener)
            throws IOException, GeneralSecurityException {
        Map<String, Object> inner = new LinkedHashMap<>();
        inner.put("method", "POST");
        inner.put("path", path);
        inner.put("body", body);
        String envelope = HearthCrypto.seal(key, Json.write(inner), user);

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("d", envelope);

        HttpURLConnection connection = (HttpURLConnection) new URL(address + "/api/secure/rpc").openConnection();
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(600_000);
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("X-Hearth-User", user);
        connection.setRequestProperty("X-Hearth-Client", "android/" + CLIENT_VERSION);
        connection.setDoOutput(true);
        try (OutputStream out = connection.getOutputStream()) {
            out.write(Json.write(payload).getBytes(StandardCharsets.UTF_8));
        }
        try {
            int status = connection.getResponseCode();
            if (status == 426) {
                String text = readAll(connection.getErrorStream());
                Map<String, Object> detail = upgradeFrom(text);
                throw new UpgradeRequired(
                        errorDetail(text, status),
                        String.valueOf(detail.getOrDefault("client_version", CLIENT_VERSION)),
                        String.valueOf(detail.getOrDefault("required_version", "")),
                        String.valueOf(detail.getOrDefault("download_url", "")));
            }
            if (status != 200) {
                throw new IOException(errorDetail(readAll(connection.getErrorStream()), status));
            }
            String contentType = String.valueOf(connection.getContentType()).toLowerCase();
            if (!contentType.contains("x-hearth-frames")) {
                // Not a stream: the server wrapped a normal reply, and if the
                // inner request failed the envelope carries the status and the
                // reason. Surface it instead of showing an empty answer.
                String text = readAll(connection.getInputStream());
                Map<String, Object> opened = Json.parseObject(HearthCrypto.open(key, text.trim(), user));
                Object statusValue = opened.get("status");
                int innerStatus = statusValue instanceof Number ? ((Number) statusValue).intValue() : 200;
                String replyBody = opened.get("body") == null ? "" : String.valueOf(opened.get("body"));
                if (innerStatus >= 400) {
                    throw new IOException(errorDetail(replyBody, innerStatus));
                }
                dispatch(replyBody, listener);
                return;
            }
            InputStream input = connection.getInputStream();
            byte[] header = new byte[4];
            StringBuilder pending = new StringBuilder();
            while (true) {
                int read = readFully(input, header, 4);
                if (read < 4) break;
                int length = ByteBuffer.wrap(header).getInt();
                if (length <= 0 || length > 8 * 1024 * 1024) break;
                byte[] frame = new byte[length];
                if (readFully(input, frame, length) < length) break;
                String chunk = new String(HearthCrypto.openBytes(key, frame, user), StandardCharsets.UTF_8);
                pending.append(chunk);
                int split;
                while ((split = pending.indexOf("\n\n")) >= 0) {
                    String raw = pending.substring(0, split);
                    pending.delete(0, split + 2);
                    dispatch(raw, listener);
                }
            }
            if (pending.length() > 0) dispatch(pending.toString(), listener);
        } finally {
            connection.disconnect();
        }
    }

    private static void dispatch(String raw, EventListener listener) {
        if (raw == null || raw.isEmpty()) return;
        StringBuilder data = new StringBuilder();
        for (String line : raw.split("\n")) {
            if (line.startsWith("data:")) {
                if (data.length() > 0) data.append('\n');
                data.append(line.substring(5).trim());
            }
        }
        if (data.length() == 0) return;
        try {
            listener.onEvent(Json.parseObject(data.toString()));
        } catch (RuntimeException ignored) {
            // A malformed frame is not worth killing the stream over.
        }
    }

    private static String errorDetail(String body, int status) {
        if (body != null && !body.isEmpty()) {
            try {
                Object detail = Json.parseObject(body).get("detail");
                if (detail != null) return String.valueOf(detail);
            } catch (RuntimeException ignored) {
                return body.length() > 300 ? body.substring(0, 300) : body;
            }
        }
        return "HTTP " + status;
    }

    private static int readFully(InputStream input, byte[] buffer, int length) throws IOException {
        int total = 0;
        while (total < length) {
            int read = input.read(buffer, total, length - total);
            if (read < 0) break;
            total += read;
        }
        return total;
    }

    private static String readAll(InputStream input) throws IOException {
        if (input == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int read;
        while ((read = input.read(buffer)) >= 0) out.write(buffer, 0, read);
        return out.toString(StandardCharsets.UTF_8.name());
    }

    static String encode(String value) {
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.name());
        } catch (Exception exc) {
            return value;
        }
    }
}
