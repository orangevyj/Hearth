package dev.hearth.client;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.view.MotionEvent;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Orbit-and-pinch preview of a GLB mesh with flat-ish lighting and a wireframe tint. */
final class Model3DView extends GLSurfaceView {

    private final SceneRenderer renderer;

    Model3DView(Context context, GlbModel model) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new SceneRenderer(model);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
    }

    private float lastX;
    private float lastY;
    private float pinchStart;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = event.getX();
                lastY = event.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                if (event.getPointerCount() == 1) {
                    renderer.yaw += (event.getX() - lastX) * 0.6f;
                    renderer.pitch += (event.getY() - lastY) * 0.6f;
                    renderer.pitch = Math.max(-89f, Math.min(89f, renderer.pitch));
                } else if (event.getPointerCount() >= 2) {
                    float dx = event.getX(0) - event.getX(1);
                    float dy = event.getY(0) - event.getY(1);
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);
                    if (pinchStart > 0f) {
                        renderer.zoom *= distance / pinchStart;
                        renderer.zoom = Math.max(0.4f, Math.min(4f, renderer.zoom));
                    }
                    pinchStart = distance;
                }
                lastX = event.getX();
                lastY = event.getY();
                requestRender();
                break;
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_UP:
                pinchStart = 0f;
                break;
            default:
                break;
        }
        return true;
    }

    private static final class SceneRenderer implements Renderer {

        private final GlbModel model;
        private float yaw = 25f;
        private float pitch = -15f;
        private float zoom = 1.6f;
        private int surfaceWidth = 1;
        private int surfaceHeight = 1;
        private int program;
        private int positionHandle;
        private int normalHandle;
        private int matrixHandle;
        private int lightHandle;
        private FloatBuffer vertexBuffer;
        private FloatBuffer normalBuffer;
        private IntBuffer indexBuffer;

        SceneRenderer(GlbModel model) {
            this.model = model;
        }

        @Override
        public void onSurfaceCreated(GL10 unused, EGLConfig config) {
            GLES20.glClearColor(0.09f, 0.08f, 0.06f, 1f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);

            String vertexShader =
                    "uniform mat4 uMatrix;"
                    + "attribute vec3 aPosition;"
                    + "attribute vec3 aNormal;"
                    + "varying vec3 vNormal;"
                    + "varying vec3 vPosition;"
                    + "void main() {"
                    + "  vNormal = aNormal;"
                    + "  vPosition = aPosition;"
                    + "  gl_Position = uMatrix * vec4(aPosition, 1.0);"
                    + "}";
            String fragmentShader =
                    "precision mediump float;"
                    + "uniform vec3 uLight;"
                    + "varying vec3 vNormal;"
                    + "varying vec3 vPosition;"
                    + "void main() {"
                    + "  vec3 n = normalize(vNormal);"
                    + "  float diffuse = max(dot(n, normalize(uLight)), 0.0);"
                    + "  float rim = pow(1.0 - max(dot(n, vec3(0.0, 0.0, 1.0)), 0.0), 2.0);"
                    + "  vec3 base = vec3(0.92, 0.56, 0.29);"
                    + "  vec3 colour = base * (0.35 + 0.65 * diffuse) + rim * 0.25 * vec3(0.95, 0.85, 0.7);"
                    + "  gl_FragColor = vec4(colour, 1.0);"
                    + "}";

            int vertex = loadShader(GLES20.GL_VERTEX_SHADER, vertexShader);
            int fragment = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShader);
            program = GLES20.glCreateProgram();
            GLES20.glAttachShader(program, vertex);
            GLES20.glAttachShader(program, fragment);
            GLES20.glLinkProgram(program);
            positionHandle = GLES20.glGetAttribLocation(program, "aPosition");
            normalHandle = GLES20.glGetAttribLocation(program, "aNormal");
            matrixHandle = GLES20.glGetUniformLocation(program, "uMatrix");
            lightHandle = GLES20.glGetUniformLocation(program, "uLight");

            vertexBuffer = floatBuffer(model.positions);
            normalBuffer = floatBuffer(model.normals);
            indexBuffer = (IntBuffer) ByteBuffer
                    .allocateDirect(model.indices.length * 4)
                    .order(ByteOrder.nativeOrder())
                    .asIntBuffer()
                    .put(model.indices)
                    .position(0);
        }

        private static FloatBuffer floatBuffer(float[] data) {
            return (FloatBuffer) ByteBuffer
                    .allocateDirect(data.length * 4)
                    .order(ByteOrder.nativeOrder())
                    .asFloatBuffer()
                    .put(data)
                    .position(0);
        }

        private static int loadShader(int type, String source) {
            int shader = GLES20.glCreateShader(type);
            GLES20.glShaderSource(shader, source);
            GLES20.glCompileShader(shader);
            return shader;
        }

        @Override
        public void onSurfaceChanged(GL10 unused, int width, int height) {
            GLES20.glViewport(0, 0, width, height);
            surfaceWidth = Math.max(1, width);
            surfaceHeight = Math.max(1, height);
        }

        @Override
        public void onDrawFrame(GL10 unused) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
            float[] projection = new float[16];
            float[] view = new float[16];
            float[] modelMatrix = new float[16];
            float[] matrix = new float[16];
            float aspect = (float) surfaceWidth / surfaceHeight;
            Matrix.perspectiveM(projection, 0, 45f, aspect, 0.1f, 50f);
            Matrix.setLookAtM(view, 0, 0f, 0f, 3.4f / zoom, 0f, 0f, 0f, 0f, 1f, 0f);
            Matrix.setIdentityM(modelMatrix, 0);
            Matrix.rotateM(modelMatrix, 0, pitch, 1f, 0f, 0f);
            Matrix.rotateM(modelMatrix, 0, yaw, 0f, 1f, 0f);
            Matrix.multiplyMM(matrix, 0, view, 0, modelMatrix, 0);
            Matrix.multiplyMM(matrix, 0, projection, 0, matrix, 0);

            GLES20.glUseProgram(program);
            GLES20.glUniformMatrix4fv(matrixHandle, 1, false, matrix, 0);
            GLES20.glUniform3f(lightHandle, 0.6f, 0.8f, 1f);

            GLES20.glEnableVertexAttribArray(positionHandle);
            GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer);
            GLES20.glEnableVertexAttribArray(normalHandle);
            GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, 0, normalBuffer);
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, model.indices.length, GLES20.GL_UNSIGNED_INT, indexBuffer);
            GLES20.glDisableVertexAttribArray(positionHandle);
            GLES20.glDisableVertexAttribArray(normalHandle);
        }
    }
}
