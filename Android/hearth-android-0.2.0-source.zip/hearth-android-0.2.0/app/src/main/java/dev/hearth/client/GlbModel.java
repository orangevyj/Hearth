package dev.hearth.client;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Just enough glTF-binary to preview a generated mesh: the first primitive's
 * positions and indices, with normals computed here so materials are optional.
 */
final class GlbModel {

    final float[] positions;
    final float[] normals;
    final int[] indices;
    final float radius;

    private GlbModel(float[] positions, float[] normals, int[] indices, float radius) {
        this.positions = positions;
        this.normals = normals;
        this.indices = indices;
        this.radius = radius;
    }

    static GlbModel parse(byte[] data) throws Exception {
        ByteBuffer buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if (buffer.getInt(0) != 0x46546C67) throw new IllegalArgumentException("Not a GLB file");
        int version = buffer.getInt(4);
        if (version != 2) throw new IllegalArgumentException("Unsupported glTF version " + version);

        String json = null;
        ByteBuffer bin = null;
        int offset = 12;
        while (offset + 8 <= buffer.limit()) {
            int length = buffer.getInt(offset);
            int type = buffer.getInt(offset + 4);
            int start = offset + 8;
            if (type == 0x4E4F534A) {
                byte[] chunk = new byte[length];
                System.arraycopy(data, start, chunk, 0, length);
                json = new String(chunk, java.nio.charset.StandardCharsets.UTF_8);
            } else if (type == 0x004E4942) {
                byte[] chunk = new byte[length];
                System.arraycopy(data, start, chunk, 0, length);
                bin = ByteBuffer.wrap(chunk).order(ByteOrder.LITTLE_ENDIAN);
            }
            offset = start + length;
        }
        if (json == null || bin == null) throw new IllegalArgumentException("GLB is missing its JSON or binary chunk");

        JSONObject root = new JSONObject(json);
        JSONArray meshes = root.getJSONArray("meshes");
        JSONObject primitive = meshes.getJSONObject(0).getJSONArray("primitives").getJSONObject(0);
        JSONObject attributes = primitive.getJSONObject("attributes");
        int positionAccessor = attributes.getInt("POSITION");
        int indexAccessor = primitive.has("indices") ? primitive.getInt("indices") : -1;

        JSONArray accessors = root.getJSONArray("accessors");
        JSONArray bufferViews = root.getJSONArray("bufferViews");

        float[] positions = readVec3(accessors, bufferViews, bin, positionAccessor);
        int[] indices;
        if (indexAccessor >= 0) {
            indices = readIndices(accessors, bufferViews, bin, indexAccessor);
        } else {
            indices = new int[positions.length / 3];
            for (int i = 0; i < indices.length; i++) indices[i] = i;
        }
        float[] normals = computeNormals(positions, indices);
        float radius = 0f;
        for (int i = 0; i < positions.length; i += 3) {
            radius = Math.max(radius, (float) Math.sqrt(
                    positions[i] * positions[i] + positions[i + 1] * positions[i + 1] + positions[i + 2] * positions[i + 2]));
        }
        if (radius <= 0f) radius = 1f;
        // Normalise to a unit sphere so any model frames nicely.
        for (int i = 0; i < positions.length; i++) positions[i] /= radius;
        return new GlbModel(positions, normals, indices, 1f);
    }

    private static float[] readVec3(JSONArray accessors, JSONArray bufferViews, ByteBuffer bin, int accessorIndex)
            throws Exception {
        JSONObject accessor = accessors.getJSONObject(accessorIndex);
        int count = accessor.getInt("count");
        int componentType = accessor.getInt("componentType");
        JSONObject view = bufferViews.getJSONObject(accessor.getInt("bufferView"));
        int base = view.optInt("byteOffset", 0) + accessor.optInt("byteOffset", 0);
        int stride = view.optInt("byteStride", 0);
        int elementSize = 3 * sizeOf(componentType);
        if (stride <= 0) stride = elementSize;
        float[] out = new float[count * 3];
        for (int i = 0; i < count; i++) {
            int at = base + i * stride;
            for (int axis = 0; axis < 3; axis++) {
                out[i * 3 + axis] = readComponent(bin, at + axis * sizeOf(componentType), componentType);
            }
        }
        return out;
    }

    private static int[] readIndices(JSONArray accessors, JSONArray bufferViews, ByteBuffer bin, int accessorIndex)
            throws Exception {
        JSONObject accessor = accessors.getJSONObject(accessorIndex);
        int count = accessor.getInt("count");
        int componentType = accessor.getInt("componentType");
        JSONObject view = bufferViews.getJSONObject(accessor.getInt("bufferView"));
        int base = view.optInt("byteOffset", 0) + accessor.optInt("byteOffset", 0);
        int stride = view.optInt("byteStride", 0);
        int elementSize = sizeOf(componentType);
        if (stride <= 0) stride = elementSize;
        int[] out = new int[count];
        for (int i = 0; i < count; i++) {
            out[i] = (int) readComponent(bin, base + i * stride, componentType);
        }
        return out;
    }

    private static int sizeOf(int componentType) {
        switch (componentType) {
            case 5126:
            case 5125:
                return 4;
            case 5123:
                return 2;
            default:
                return 1;
        }
    }

    private static float readComponent(ByteBuffer bin, int at, int componentType) {
        switch (componentType) {
            case 5126:
                return bin.getFloat(at);
            case 5125:
                return bin.getInt(at);
            case 5123:
                return bin.getShort(at) & 0xFFFF;
            default:
                return bin.get(at) & 0xFF;
        }
    }

    private static float[] computeNormals(float[] positions, int[] indices) {
        float[] normals = new float[positions.length];
        for (int i = 0; i + 2 < indices.length; i += 3) {
            int a = indices[i] * 3;
            int b = indices[i + 1] * 3;
            int c = indices[i + 2] * 3;
            float ux = positions[b] - positions[a];
            float uy = positions[b + 1] - positions[a + 1];
            float uz = positions[b + 2] - positions[a + 2];
            float vx = positions[c] - positions[a];
            float vy = positions[c + 1] - positions[a + 1];
            float vz = positions[c + 2] - positions[a + 2];
            float nx = uy * vz - uz * vy;
            float ny = uz * vx - ux * vz;
            float nz = ux * vy - uy * vx;
            for (int vertex : new int[]{a, b, c}) {
                normals[vertex] += nx;
                normals[vertex + 1] += ny;
                normals[vertex + 2] += nz;
            }
        }
        for (int i = 0; i < normals.length; i += 3) {
            float length = (float) Math.sqrt(
                    normals[i] * normals[i] + normals[i + 1] * normals[i + 1] + normals[i + 2] * normals[i + 2]);
            if (length > 0) {
                normals[i] /= length;
                normals[i + 1] /= length;
                normals[i + 2] /= length;
            } else {
                normals[i + 1] = 1f;
            }
        }
        return normals;
    }
}
