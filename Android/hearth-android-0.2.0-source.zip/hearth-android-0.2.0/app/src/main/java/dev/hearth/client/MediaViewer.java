package dev.hearth.client;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

/** In-app previews for everything the server can produce. */
final class MediaViewer {

    private MediaViewer() {
    }

    /** Picks the right preview for a generated file. */
    static void show(Activity activity, byte[] bytes, String name, String mime) {
        String kind = mime == null ? "" : mime;
        if (kind.startsWith("image/")) {
            showImage(activity, bytes, name, kind);
        } else if (kind.startsWith("video/")) {
            showVideo(activity, bytes, name, kind);
        } else if (kind.startsWith("audio/")) {
            showAudio(activity, bytes, name, kind);
        } else if (kind.contains("gltf") || name.toLowerCase().endsWith(".glb") || name.toLowerCase().endsWith(".gltf")) {
            showModel(activity, bytes, name, kind);
        } else {
            showFile(activity, bytes, name, kind);
        }
    }

    // -- image -------------------------------------------------------

    static void showImage(Activity activity, byte[] bytes, String name, String mime) {
        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        if (bitmap == null) {
            Downloads.toast(activity, "Could not decode " + name);
            return;
        }
        ZoomableImageView view = new ZoomableImageView(activity);
        view.setImageBitmap(bitmap);
        view.setBackgroundColor(Color.BLACK);
        FrameLayout frame = new FrameLayout(activity);
        frame.addView(view, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(activity, 420)));
        new AlertDialog.Builder(activity)
                .setTitle(name)
                .setView(frame)
                .setPositiveButton("Save", (dialog, which) -> Downloads.save(activity, bytes, name, mime))
                .setNeutralButton("Share", (dialog, which) -> Downloads.share(activity, bytes, name, mime))
                .setNegativeButton("Close", null)
                .show();
    }

    // -- video -------------------------------------------------------

    static void showVideo(Activity activity, byte[] bytes, String name, String mime) {
        VideoView player = new VideoView(activity);
        MediaController controls = new MediaController(activity);
        controls.setAnchorView(player);
        player.setMediaController(controls);
        player.setVideoPath(Downloads.tempFile(activity, bytes, name).getAbsolutePath());
        player.setOnPreparedListener(mediaPlayer -> {
            mediaPlayer.setLooping(true);
            player.start();
        });
        FrameLayout frame = new FrameLayout(activity);
        frame.setBackgroundColor(Color.BLACK);
        frame.addView(player, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(activity, 260)));
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(name)
                .setView(frame)
                .setPositiveButton("Save", (d, which) -> Downloads.save(activity, bytes, name, mime))
                .setNeutralButton("Share", (d, which) -> Downloads.share(activity, bytes, name, mime))
                .setNegativeButton("Close", null)
                .create();
        dialog.setOnDismissListener(d -> player.stopPlayback());
        dialog.show();
    }

    // -- audio -------------------------------------------------------

    static void showAudio(Activity activity, byte[] bytes, String name, String mime) {
        Handler handler = new Handler(Looper.getMainLooper());
        LinearLayout column = new LinearLayout(activity);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(activity, 20), dp(activity, 16), dp(activity, 20), dp(activity, 8));

        TextView position = new TextView(activity);
        position.setText("0:00");
        position.setGravity(Gravity.END);
        position.setTextColor(0xFFA79E92);
        position.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);

        SeekBar seekBar = new SeekBar(activity);
        Button play = new Button(activity);
        play.setText("Play");
        play.setAllCaps(false);

        column.addView(seekBar);
        column.addView(position);
        column.addView(play);

        MediaPlayer[] holder = new MediaPlayer[1];
        Runnable ticker = new Runnable() {
            @Override
            public void run() {
                MediaPlayer player = holder[0];
                if (player != null) {
                    try {
                        seekBar.setProgress(player.getCurrentPosition());
                        position.setText(format(player.getCurrentPosition()) + " / " + format(player.getDuration()));
                    } catch (IllegalStateException ignored) {
                        // player released mid-tick
                    }
                    handler.postDelayed(this, 300);
                }
            }
        };

        play.setOnClickListener(view -> {
            if (holder[0] == null) {
                try {
                    MediaPlayer player = new MediaPlayer();
                    player.setDataSource(Downloads.tempFile(activity, bytes, name).getAbsolutePath());
                    player.prepare();
                    holder[0] = player;
                    seekBar.setMax(player.getDuration());
                    player.setOnCompletionListener(mediaPlayer -> {
                        play.setText("Play");
                        seekBar.setProgress(0);
                    });
                    seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                            if (fromUser) player.seekTo(progress);
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar bar) {
                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar bar) {
                        }
                    });
                    player.start();
                    play.setText("Pause");
                    handler.post(ticker);
                } catch (Exception exc) {
                    Downloads.toast(activity, "Could not play that file");
                }
                return;
            }
            MediaPlayer player = holder[0];
            if (player.isPlaying()) {
                player.pause();
                play.setText("Play");
            } else {
                player.start();
                play.setText("Pause");
            }
        });

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(name)
                .setView(column)
                .setPositiveButton("Save", (d, which) -> Downloads.save(activity, bytes, name, mime))
                .setNeutralButton("Share", (d, which) -> Downloads.share(activity, bytes, name, mime))
                .setNegativeButton("Close", null)
                .create();
        dialog.setOnDismissListener(d -> {
            handler.removeCallbacks(ticker);
            if (holder[0] != null) {
                holder[0].release();
                holder[0] = null;
            }
        });
        dialog.show();
    }

    private static String format(int millis) {
        int seconds = Math.max(0, millis / 1000);
        return String.format(java.util.Locale.US, "%d:%02d", seconds / 60, seconds % 60);
    }

    // -- 3D model ----------------------------------------------------

    static void showModel(Activity activity, byte[] bytes, String name, String mime) {
        FrameLayout frame = new FrameLayout(activity);
        try {
            GlbModel model = GlbModel.parse(bytes);
            Model3DView view = new Model3DView(activity, model);
            frame.addView(view, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, dp(activity, 380)));
            new AlertDialog.Builder(activity)
                    .setTitle(name + " · drag to rotate")
                    .setView(frame)
                    .setPositiveButton("Save", (dialog, which) -> Downloads.save(activity, bytes, name, mime))
                    .setNeutralButton("Open", (dialog, which) -> Downloads.open(activity, bytes, name, mime))
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception exc) {
            String reason = exc.getMessage() == null ? exc.toString() : exc.getMessage();
            TextView note = new TextView(activity);
            note.setText("This mesh could not be previewed here (" + reason + "). Open it in another app instead.");
            note.setPadding(dp(activity, 20), dp(activity, 20), dp(activity, 20), dp(activity, 20));
            new AlertDialog.Builder(activity)
                    .setTitle(name)
                    .setView(note)
                    .setPositiveButton("Open", (dialog, which) -> Downloads.open(activity, bytes, name, mime))
                    .setNegativeButton("Close", null)
                    .show();
        }
    }

    // -- anything else -----------------------------------------------

    static void showFile(Activity activity, byte[] bytes, String name, String mime) {
        TextView note = new TextView(activity);
        note.setText(name + "\n" + (bytes.length / 1024) + " KB · " + mime);
        note.setPadding(dp(activity, 20), dp(activity, 20), dp(activity, 20), dp(activity, 20));
        new AlertDialog.Builder(activity)
                .setTitle("File")
                .setView(note)
                .setPositiveButton("Save", (dialog, which) -> Downloads.save(activity, bytes, name, mime))
                .setNeutralButton("Open", (dialog, which) -> Downloads.open(activity, bytes, name, mime))
                .setNegativeButton("Close", null)
                .show();
    }

    private static int dp(Activity activity, int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                activity.getResources().getDisplayMetrics());
    }
}
