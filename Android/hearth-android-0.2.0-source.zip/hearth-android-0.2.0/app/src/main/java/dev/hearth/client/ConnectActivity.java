package dev.hearth.client;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Connection screen: address, user, secret, with a remembered connection. */
public class ConnectActivity extends Activity {

    private static final int REQUEST_LOCAL_NETWORK = 21;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private EditText addressField;
    private EditText userField;
    private EditText secretField;
    private CheckBox remember;
    private Button connectButton;
    private ProgressBar progress;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);
        Insets.apply(findViewById(R.id.root));

        addressField = findViewById(R.id.address);
        userField = findViewById(R.id.user);
        secretField = findViewById(R.id.secret);
        remember = findViewById(R.id.remember);
        connectButton = findViewById(R.id.connect);
        progress = findViewById(R.id.progress);
        status = findViewById(R.id.status);

        Session saved = Session.load(this);
        if (saved != null) {
            addressField.setText(saved.address);
            userField.setText(saved.user);
            secretField.setText(saved.secret);
            showStatus("Saved connection to " + saved.address + " as " + saved.user + ".", false);
            findViewById(R.id.forget).setEnabled(true);
        } else {
            findViewById(R.id.forget).setEnabled(false);
        }

        connectButton.setOnClickListener(view -> connect());
        findViewById(R.id.save).setOnClickListener(view -> saveOnly());
        findViewById(R.id.forget).setOnClickListener(view -> forget());
    }

    // -- saving ------------------------------------------------------

    private boolean valid(boolean needSecret) {
        if (HearthClient.trimSlash(addressField.getText().toString()).isEmpty()) {
            showStatus("Enter the server address, for example http://192.168.1.9:8772", true);
            return false;
        }
        if (userField.getText().toString().trim().isEmpty()) {
            showStatus("Enter the user name the server gave you.", true);
            return false;
        }
        if (needSecret && secretField.getText().toString().isEmpty()) {
            showStatus("Enter the secret key for that account.", true);
            return false;
        }
        return true;
    }

    private Session current() {
        return new Session(
                HearthClient.trimSlash(addressField.getText().toString()),
                userField.getText().toString().trim(),
                secretField.getText().toString(),
                "");
    }

    private void saveOnly() {
        if (!valid(false)) return;
        Session.save(this, current());
        remember.setChecked(true);
        findViewById(R.id.forget).setEnabled(true);
        showStatus("Saved. Hearth will fill these in next time you open the app.", false);
        toast("Connection saved");
    }

    private void forget() {
        Session.clear(this);
        addressField.setText("");
        userField.setText("");
        secretField.setText("");
        findViewById(R.id.forget).setEnabled(false);
        showStatus("Saved connection removed.", false);
        toast("Saved connection removed");
    }

    // -- connecting --------------------------------------------------

    /**
     * Android 16+ needs a runtime grant before an app may talk to LAN hosts.
     * Without it the platform silently drops the packets, which surfaces as a
     * connect timeout rather than a permission error.
     */
    private boolean ensureLocalNetworkAccess() {
        if (Build.VERSION.SDK_INT < 36) return true;
        if (checkSelfPermission(Manifest.permission.ACCESS_LOCAL_NETWORK) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        requestPermissions(new String[]{Manifest.permission.ACCESS_LOCAL_NETWORK}, REQUEST_LOCAL_NETWORK);
        showStatus("Android needs permission to reach devices on your network.", false);
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_LOCAL_NETWORK) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted) {
            showStatus("Local network access granted — connecting…", false);
            connect();
        } else {
            showStatus(
                    "Without local network access Android blocks Hearth from reaching your server. "
                            + "Grant it in Settings → Apps → Hearth → Permissions.",
                    true);
        }
    }

    private void connect() {
        if (!ensureLocalNetworkAccess()) return;
        if (!valid(true)) return;
        Session draft = current();
        setBusy(true, "Deriving the key and asking the server…");
        worker.execute(() -> {
            try {
                String salt = HearthClient.fetchSalt(draft.address);
                HearthClient client = new HearthClient(draft.address, draft.user, draft.secret, salt);
                HearthClient.Response response = client.call("/api/state", "GET", null);
                if (response.status != 200) {
                    throw new IllegalStateException("The server answered HTTP " + response.status);
                }
                Map<String, Object> payload = response.json();
                if (!(payload.get("capabilities") instanceof Map)) {
                    throw new IllegalStateException("That server sent no capabilities");
                }
                Session session = new Session(draft.address, draft.user, draft.secret, salt);
                main.post(() -> {
                    if (remember.isChecked()) {
                        Session.save(this, session);
                    }
                    setBusy(false, "");
                    startActivity(new Intent(this, ChatsActivity.class));
                });
            } catch (HearthClient.UpgradeRequired exc) {
                main.post(() -> {
                    setBusy(false, "");
                    showUpgrade(exc, draft.address);
                });
            } catch (Exception exc) {
                String message = exc.getMessage() == null ? exc.toString() : exc.getMessage();
                if (exc instanceof java.net.SocketTimeoutException) {
                    message = "Timed out reaching " + draft.address + ". If the browser on this phone can open that "
                            + "address, Android is blocking LAN traffic for Hearth — allow local network access in "
                            + "Settings → Apps → Hearth → Permissions. (" + message + ")";
                } else if (exc instanceof java.net.UnknownServiceException) {
                    message = "Android blocked the plain-HTTP connection: " + message;
                }
                String detail = message;
                main.post(() -> {
                    setBusy(false, "");
                    showStatus(detail, true);
                });
            }
        });
    }

    // -- ui ----------------------------------------------------------

    private void showUpgrade(HearthClient.UpgradeRequired exc, String address) {
        String url = exc.downloadUrl.startsWith("http") ? exc.downloadUrl : address + exc.downloadUrl;
        new android.app.AlertDialog.Builder(this)
                .setTitle("This app is out of date")
                .setMessage("It is version " + exc.clientVersion + ", but the server offers " + exc.requiredVersion
                        + ". Download the newer build and install it over this one.")
                .setPositiveButton("Download", (dialog, which) -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)));
                    } catch (Exception error) {
                        showStatus("Download it from " + url, false);
                    }
                })
                .setNegativeButton("Later", null)
                .show();
        showStatus("Update required: server has " + exc.requiredVersion + ", this app is " + exc.clientVersion, true);
    }

    private void setBusy(boolean busy, String message) {
        connectButton.setEnabled(!busy);
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (!message.isEmpty()) showStatus(message, false);
    }

    private void showStatus(String message, boolean error) {
        status.setText(message);
        status.setTextColor(getColor(error ? R.color.hearth_danger : R.color.hearth_muted));
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        worker.shutdownNow();
    }
}
