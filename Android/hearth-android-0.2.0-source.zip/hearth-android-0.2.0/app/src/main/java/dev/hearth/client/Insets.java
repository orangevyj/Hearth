package dev.hearth.client;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/**
 * Android 15+ (API 35) draws app content edge-to-edge by default, so the top of
 * the UI slides under the status bar and the keyboard covers the composer. This
 * pads the root view with the system bars plus the IME inset.
 */
final class Insets {

    private Insets() {
    }

    static void apply(View root) {
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int left;
            int top;
            int right;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                left = bars.left;
                top = bars.top;
                right = bars.right;
                bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(left, top, right, bottom);
            return insets;
        });
        root.requestApplyInsets();
    }
}
