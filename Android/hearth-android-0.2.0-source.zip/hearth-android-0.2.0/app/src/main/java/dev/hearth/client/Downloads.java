package dev.hearth.client;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/** Saving, sharing and handing generated files to other apps. */
final class Downloads {

    private Downloads() {
    }

    static File tempFile(Activity activity, byte[] bytes, String name) {
        File file = new File(activity.getCacheDir(), name);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(bytes);
        } catch (IOException ignored) {
            // the caller falls back to "cannot open"
        }
        return file;
    }

    static void save(Activity activity, byte[] bytes, String name, String mime) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, folder(mime));
                Uri item = activity.getContentResolver().insert(collection(mime), values);
                if (item == null) throw new IOException("The gallery refused the file");
                try (OutputStream out = activity.getContentResolver().openOutputStream(item)) {
                    if (out == null) throw new IOException("Could not open the gallery file");
                    out.write(bytes);
                }
                toast(activity, "Saved to " + folder(mime));
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hearth");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create the folder");
                File target = new File(dir, name);
                try (FileOutputStream out = new FileOutputStream(target)) {
                    out.write(bytes);
                }
                toast(activity, "Saved to Download/Hearth/" + name);
            }
        } catch (Exception exc) {
            toast(activity, "Could not save: " + (exc.getMessage() == null ? exc.toString() : exc.getMessage()));
        }
    }

    static String folder(String mime) {
        if (mime.startsWith("image/")) return Environment.DIRECTORY_PICTURES + "/Hearth";
        if (mime.startsWith("video/")) return Environment.DIRECTORY_MOVIES + "/Hearth";
        if (mime.startsWith("audio/")) return Environment.DIRECTORY_MUSIC + "/Hearth";
        return Environment.DIRECTORY_DOWNLOADS + "/Hearth";
    }

    @android.annotation.TargetApi(29)
    static Uri collection(String mime) {
        if (mime.startsWith("image/")) return MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        if (mime.startsWith("video/")) return MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        if (mime.startsWith("audio/")) return MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        return MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
    }

    static void share(Activity activity, byte[] bytes, String name, String mime) {
        try {
            File file = tempFile(activity, bytes, name);
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".files", file);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(Intent.createChooser(intent, "Share " + name));
        } catch (Exception exc) {
            toast(activity, "Could not share that file");
        }
    }

    static void open(Activity activity, byte[] bytes, String name, String mime) {
        try {
            File file = tempFile(activity, bytes, name);
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".files", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(intent);
        } catch (Exception exc) {
            toast(activity, "No app can open " + name);
        }
    }

    static void toast(Activity activity, String message) {
        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
    }
}
