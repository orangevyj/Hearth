package dev.hearth.client;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

/** Where the connection details live between launches. */
public final class Session {

    private static final String PREFS = "hearth.session";

    public final String address;
    public final String user;
    public final String secret;
    public final String salt;

    public Session(String address, String user, String secret, String salt) {
        this.address = address;
        this.user = user;
        this.secret = secret;
        this.salt = salt;
    }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void save(Context context, Session session) {
        prefs(context)
                .edit()
                .putString("address", session.address)
                .putString("user", session.user)
                .putString("secret", session.secret)
                .putString("salt", session.salt == null ? "" : session.salt)
                .apply();
    }

    static Session load(Context context) {
        SharedPreferences store = prefs(context);
        String address = store.getString("address", "");
        String user = store.getString("user", "");
        String secret = store.getString("secret", "");
        String salt = store.getString("salt", "");
        if (address == null || address.isEmpty() || user == null || user.isEmpty()) return null;
        return new Session(address, user, secret == null ? "" : secret, salt == null ? "" : salt);
    }

    /** The installed app version, reported to the server on every request. */
    static String version(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException exc) {
            return "0.0.0";
        }
    }

    static void clear(Context context) {
        prefs(context).edit().clear().apply();
    }

    /** Builds a client, fetching the server salt if the saved entry predates it. */
    HearthClient client() throws Exception {
        String resolved = (salt == null || salt.isEmpty()) ? HearthClient.fetchSalt(address) : salt;
        return new HearthClient(address, user, secret, resolved);
    }
}
