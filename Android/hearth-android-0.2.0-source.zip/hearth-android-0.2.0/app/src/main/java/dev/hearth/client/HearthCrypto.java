package dev.hearth.client;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Matches the server: PBKDF2-HMAC-SHA256 (200k iterations) turns the shared
 * secret into an AES-256-GCM key, and every message is
 * base64(nonce[12] || ciphertext || tag[16]).
 */
public final class HearthCrypto {

    public static final int KDF_ITERATIONS = 200_000;
    private static final int KEY_BITS = 256;
    private static final int NONCE_BYTES = 12;
    private static final int TAG_BITS = 128;

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Base64.Encoder ENCODER = Base64.getEncoder();
    private static final Base64.Decoder DECODER = Base64.getDecoder();

    private HearthCrypto() {
    }

    public static SecretKeySpec deriveKey(String secret, String salt) throws GeneralSecurityException {
        if (secret == null || secret.isEmpty()) throw new GeneralSecurityException("A secret is required");
        if (salt == null || salt.isEmpty()) throw new GeneralSecurityException("A key salt is required");
        PBEKeySpec spec = new PBEKeySpec(
                secret.toCharArray(),
                salt.getBytes(StandardCharsets.UTF_8),
                KDF_ITERATIONS,
                KEY_BITS);
        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
        } finally {
            spec.clearPassword();
        }
    }

    public static byte[] sealBytes(SecretKeySpec key, byte[] plaintext, String aad) throws GeneralSecurityException {
        byte[] nonce = new byte[NONCE_BYTES];
        RANDOM.nextBytes(nonce);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, nonce));
        if (aad != null && !aad.isEmpty()) cipher.updateAAD(aad.getBytes(StandardCharsets.UTF_8));
        byte[] ciphertext = cipher.doFinal(plaintext);
        byte[] combined = new byte[nonce.length + ciphertext.length];
        System.arraycopy(nonce, 0, combined, 0, nonce.length);
        System.arraycopy(ciphertext, 0, combined, nonce.length, ciphertext.length);
        return combined;
    }

    public static byte[] openBytes(SecretKeySpec key, byte[] envelope, String aad) throws GeneralSecurityException {
        if (envelope.length <= NONCE_BYTES) throw new GeneralSecurityException("Encrypted payload is too short");
        byte[] nonce = new byte[NONCE_BYTES];
        System.arraycopy(envelope, 0, nonce, 0, NONCE_BYTES);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, nonce));
        if (aad != null && !aad.isEmpty()) cipher.updateAAD(aad.getBytes(StandardCharsets.UTF_8));
        return cipher.doFinal(envelope, NONCE_BYTES, envelope.length - NONCE_BYTES);
    }

    public static String seal(SecretKeySpec key, String plaintext, String aad) throws GeneralSecurityException {
        return ENCODER.encodeToString(sealBytes(key, plaintext.getBytes(StandardCharsets.UTF_8), aad));
    }

    public static String open(SecretKeySpec key, String envelope, String aad) throws GeneralSecurityException {
        byte[] raw;
        try {
            raw = DECODER.decode(envelope.trim());
        } catch (IllegalArgumentException exc) {
            throw new GeneralSecurityException("Encrypted payload is not valid base64", exc);
        }
        return new String(openBytes(key, raw, aad), StandardCharsets.UTF_8);
    }

    public static String base64(byte[] value) {
        return ENCODER.encodeToString(value);
    }
}
