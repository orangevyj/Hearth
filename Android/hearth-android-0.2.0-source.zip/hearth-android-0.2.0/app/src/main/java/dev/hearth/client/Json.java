package dev.hearth.client;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A tiny JSON reader/writer.
 *
 * Hearth's API speaks JSON and the client only needs maps, lists and scalars,
 * so this keeps the app free of third-party dependencies (and lets the same
 * classes run on a desktop JVM for protocol tests).
 */
final class Json {

    private final String text;
    private int index;

    private Json(String text) {
        this.text = text;
    }

    static Object parse(String text) {
        Json parser = new Json(text == null ? "" : text);
        parser.skipWhitespace();
        Object value = parser.readValue();
        parser.skipWhitespace();
        return value;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> parseObject(String text) {
        Object value = parse(text);
        if (value instanceof Map) {
            return (Map<String, Object>) value;
        }
        throw new IllegalArgumentException("Expected a JSON object");
    }

    static String write(Object value) {
        StringBuilder out = new StringBuilder();
        writeValue(out, value);
        return out.toString();
    }

    @SuppressWarnings("unchecked")
    private static void writeValue(StringBuilder out, Object value) {
        if (value == null) {
            out.append("null");
        } else if (value instanceof String) {
            writeString(out, (String) value);
        } else if (value instanceof Boolean) {
            out.append(value.toString());
        } else if (value instanceof Number) {
            double number = ((Number) value).doubleValue();
            if (number == Math.rint(number) && !Double.isInfinite(number)) {
                out.append((long) number);
            } else {
                out.append(number);
            }
        } else if (value instanceof Map) {
            out.append('{');
            boolean first = true;
            for (Map.Entry<String, Object> entry : ((Map<String, Object>) value).entrySet()) {
                if (!first) out.append(',');
                first = false;
                writeString(out, entry.getKey());
                out.append(':');
                writeValue(out, entry.getValue());
            }
            out.append('}');
        } else if (value instanceof List) {
            out.append('[');
            boolean first = true;
            for (Object item : (List<Object>) value) {
                if (!first) out.append(',');
                first = false;
                writeValue(out, item);
            }
            out.append(']');
        } else {
            writeString(out, value.toString());
        }
    }

    private static void writeString(StringBuilder out, String value) {
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"': out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
            }
        }
        out.append('"');
    }

    private Object readValue() {
        skipWhitespace();
        if (index >= text.length()) throw new IllegalArgumentException("Unexpected end of JSON");
        char c = text.charAt(index);
        switch (c) {
            case '{': return readObject();
            case '[': return readArray();
            case '"': return readString();
            case 't': expect("true"); return Boolean.TRUE;
            case 'f': expect("false"); return Boolean.FALSE;
            case 'n': expect("null"); return null;
            default: return readNumber();
        }
    }

    private Map<String, Object> readObject() {
        Map<String, Object> map = new LinkedHashMap<>();
        index++; // {
        skipWhitespace();
        if (peek() == '}') { index++; return map; }
        while (true) {
            skipWhitespace();
            String key = readString();
            skipWhitespace();
            if (peek() != ':') throw new IllegalArgumentException("Expected ':' at " + index);
            index++;
            map.put(key, readValue());
            skipWhitespace();
            char next = peek();
            index++;
            if (next == '}') return map;
            if (next != ',') throw new IllegalArgumentException("Expected ',' or '}' at " + index);
        }
    }

    private List<Object> readArray() {
        List<Object> list = new ArrayList<>();
        index++; // [
        skipWhitespace();
        if (peek() == ']') { index++; return list; }
        while (true) {
            list.add(readValue());
            skipWhitespace();
            char next = peek();
            index++;
            if (next == ']') return list;
            if (next != ',') throw new IllegalArgumentException("Expected ',' or ']' at " + index);
        }
    }

    private String readString() {
        if (peek() != '"') throw new IllegalArgumentException("Expected a string at " + index);
        index++;
        StringBuilder out = new StringBuilder();
        while (true) {
            char c = text.charAt(index++);
            if (c == '"') return out.toString();
            if (c != '\\') { out.append(c); continue; }
            char escape = text.charAt(index++);
            switch (escape) {
                case '"': out.append('"'); break;
                case '\\': out.append('\\'); break;
                case '/': out.append('/'); break;
                case 'b': out.append('\b'); break;
                case 'f': out.append('\f'); break;
                case 'n': out.append('\n'); break;
                case 'r': out.append('\r'); break;
                case 't': out.append('\t'); break;
                case 'u':
                    out.append((char) Integer.parseInt(text.substring(index, index + 4), 16));
                    index += 4;
                    break;
                default: throw new IllegalArgumentException("Bad escape \\" + escape);
            }
        }
    }

    private Object readNumber() {
        int start = index;
        while (index < text.length() && "-+.eE0123456789".indexOf(text.charAt(index)) >= 0) index++;
        String slice = text.substring(start, index);
        if (slice.indexOf('.') >= 0 || slice.indexOf('e') >= 0 || slice.indexOf('E') >= 0) {
            return Double.parseDouble(slice);
        }
        try {
            return Long.parseLong(slice);
        } catch (NumberFormatException exc) {
            return Double.parseDouble(slice);
        }
    }

    private void expect(String literal) {
        if (!text.startsWith(literal, index)) throw new IllegalArgumentException("Expected " + literal);
        index += literal.length();
    }

    private char peek() {
        if (index >= text.length()) throw new IllegalArgumentException("Unexpected end of JSON");
        return text.charAt(index);
    }

    private void skipWhitespace() {
        while (index < text.length()) {
            char c = text.charAt(index);
            if (c == ' ' || c == '\n' || c == '\r' || c == '\t') index++;
            else return;
        }
    }
}
