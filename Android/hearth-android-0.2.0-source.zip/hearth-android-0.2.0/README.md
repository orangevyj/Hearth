# Hearth Client for Android

A connect-only client for a Hearth server. The models run on the machine you
connect to; this app sends and receives only encrypted traffic.

## What it does

- **Connect** with server address, user and secret key (`ConnectActivity`).
- **Fetch the salt**, derive the AES-256 key with PBKDF2-HMAC-SHA256
  (200k iterations), and verify the account by asking the server for its
  capability document (`/api/state` through the sealed channel).
- **Chat** over `/api/secure/rpc`, decrypting streamed server-sent events frame
  by frame (`ChatActivity` + `HearthClient.stream`), with a Reasoning toggle.
- **Attachments** — pick a file with the system picker; the bytes are uploaded
  base64 inside the sealed channel (`/api/uploads/encoded`) and attached to the
  message. Images go to a vision model, audio and video pass through as well.
- **Media generation** — Generate offers only the modalities the server allows,
  starts the job, polls it, then reads the produced file back through the
  encrypted channel (`/api/media/read`). Images render inline, audio plays,
  video/3D save to the app folder and open in another app.
- **Model and preset switching** — when the server grants those permissions the
  header shows Model and Preset pickers. Applying a preset on a client never
  downloads anything; the server decides that.
- Remembers the last connection, and a one-tap **Disconnect** clears it.

Nothing is stored except the address, user name and secret in
`SharedPreferences`; there is no local model, no background service and no
telemetry.

## Layout

| File | Role |
|---|---|
| `HearthCrypto.java` | PBKDF2 key derivation, AES-256-GCM seal/open, base64 envelope |
| `HearthClient.java` | `/api/secure/rpc` transport, sealed replies, frame streaming |
| `Json.java` | small JSON reader/writer so the app has no third-party dependencies |
| `Session.java` | connection details in `SharedPreferences` |
| `ConnectActivity.java` | address / user / secret, verification, status |
| `ChatActivity.java` | message list, streaming replies, disconnect |

The crypto and transport classes use only `java.*` APIs, so they can be compiled
on a desktop JVM and tested against a real server (see below).

## Build

Android Studio can open this folder directly. From a terminal:

```bash
export JAVA_HOME=/home/administrator/android-studio/jbr
export ANDROID_HOME=/home/administrator/Android/Sdk
~/.gradle/wrapper/dists/gradle-9.6.0-bin/*/gradle-9.6.0/bin/gradle assembleDebug
```

The APK lands in `app/build/outputs/apk/debug/app-debug.apk`:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

`local.properties` points at the SDK (`sdk.dir=/home/administrator/Android/Sdk`);
Android Studio rewrites it if the SDK lives elsewhere.

`compileSdk`/`targetSdk` 37, `minSdk` 26 (PBKDF2 with HMAC-SHA256 needs 26).
Cleartext HTTP is allowed because Hearth encrypts at the application layer with
the account key rather than with TLS.

## Protocol check without a device

The crypto and transport classes compile on a desktop JVM, which is how this
client was verified against a live server:

```bash
javac -d /tmp/classes app/src/main/java/dev/hearth/client/{Json,HearthCrypto,HearthClient}.java Check.java
java -cp /tmp/classes Check http://192.168.1.20:8772 <user> <secret>
```

Expected: the salt is fetched, `/api/state` returns `hearth.remote-state/1` with
`secure=true`, a chat is created, the streamed reply arrives in several
`delta` events, and an admin endpoint such as `/api/server/start` is refused
with "That endpoint is only available on the server itself".

## Server side

Two endpoints exist for clients, both only reachable from the encrypted
channel:

- `POST /api/uploads/encoded` — `{filename, mime, data}` with `data` in base64,
  returns the same attachment object the web upload produces.
- `POST /api/media/read` — `{path}` where path is an attachment's `url`
  (`/media/outputs/…`); returns `{filename, mime, size, data}`.

`POST /api/presets/{tier}/apply` is allowed for accounts with the
`change_preset` permission, and the server forces `download: false` so a client
can adopt a model mix but never trigger installs.
